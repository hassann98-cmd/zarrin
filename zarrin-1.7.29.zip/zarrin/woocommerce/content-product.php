<?php
/**
 * کارت محصول در گرید (آرشیو فروشگاه + محصولات مرتبط + صفحه اصلی). طراحی
 * دقیقاً مطابق نمونه‌ی HTML/عکسِ ارسالیِ کاربر (باکس تصویر با پس‌زمینه‌ی
 * خاکستری روشن + object-contain، بج تخفیف/موجودی، ردیف عنوان/امتیاز و
 * CTA سریع (دکمهٔ + آیکونیِ فشرده در همهٔ اندازه‌ها) — با حفظ گالریِ
 * تامبنیلِ هاور (نمایش عکس‌های دیگر با هاور/لمس‌طولانی، قبلاً به‌درخواستِ صریحِ
 * کاربر ساخته شده) عمداً حفظ و روی همین طراحیِ جدید سوار شده — چیزی از
 * قبل حذف نشده.

 * @version 9.4.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! $product || ! $product->is_visible() ) {
	return;
}

$is_variable   = $product->is_type( 'variable' );
// موجودی محصول متغیر واقعاً سطحِ هر تنوعه، نه خودِ محصولِ والد — پس بج
// «ناموجود» فقط برای محصول ساده نشون داده می‌شه تا با «چند نوع موجود» تناقض نداشته باشه.
$out_of_stock  = ! $is_variable && ! $product->is_in_stock();
$regular_price = (float) $product->get_regular_price();
$sale_price    = (float) $product->get_sale_price();
$has_discount  = ! $is_variable && $product->is_on_sale() && $sale_price > 0 && $sale_price < $regular_price;
$discount_pct  = $has_discount ? (int) round( 100 - ( $sale_price / $regular_price ) * 100 ) : 0;
$rating        = (float) $product->get_average_rating();
$review_count  = (int) $product->get_review_count();
$image_id      = $product->get_image_id();
/*
 * منبعِ کارت عمداً از سایزِ uncropped «large» می‌آید: woocommerce_thumbnail
 * و jluxe-product-thumb-sm می‌توانند فایلِ مربعِ hard-crop‌شده باشند؛ در آن
 * صورت object-fit:contain هم محتوای بریده‌شده را برنمی‌گرداند. «large» نسبتِ
 * ذاتیِ تصویر را نگه می‌دارد و srcset هم فقط کاندیدهای هم‌نسبت را ارائه می‌کند؛
 * نسبتِ قابِ کارت همچنان از تنظیمِ square / classic / portrait می‌آید.
 */
$image_url     = $image_id ? ( wp_get_attachment_image_url( $image_id, 'large' ) ?: wp_get_attachment_image_url( $image_id, 'full' ) ) : wc_placeholder_img_src( 'woocommerce_thumbnail' );
$image_srcset  = $image_id ? wp_get_attachment_image_srcset( $image_id, 'large' ) : '';
/*
 * اخطارِ واقعیِ Lighthouse («This image file is larger than it needs to
 * be … use responsive images»): مقدارِ خودکارِ wp_get_attachment_image_sizes()
 * فرض می‌کنه اسلات تا ۳۰۰px (عرضِ اسمیِ خودِ سایزِ woocommerce_thumbnail)
 * می‌تونه بره، در حالی که در گریدِ واقعیِ کارتِ محصول عرضِ نمایشِ واقعی
 * حدودِ ۲۲۰-۲۴۰px هست — روی گوشیِ retina (dpr=2/3) همین اختلاف باعث می‌شه
 * مرورگر به‌جای نسخه‌ی ۳۰۰w، نسخه‌ی ۶۰۰w (خیلی بزرگ‌تر از لازم) رو انتخاب
 * کنه. مقدارِ دستیِ زیر با عرضِ واقعیِ کارت در گریدِ ۲/۳/۴ستونه هماهنگه.
 */
$image_sizes = $image_id ? '(max-width: 480px) 42vw, (max-width: 1024px) 24vw, 180px' : '';
/*
 * اخطارِ واقعیِ Lighthouse («Improve image delivery»): این تصویر نه srcset
 * داشت (یعنی موبایل هم همون فایلِ اندازه‌ی ثابتِ دسکتاپ رو دانلود می‌کرد)
 * نه eager/lazy درست تفکیک شده بود — هر عکسِ کارتِ محصول، حتی اولین/
 * دومینِ گرید (که تقریباً همیشه بالای صفحه‌ن و می‌تونن خودِ LCP باشن)،
 * لِیزی بود؛ لیزی‌کردنِ عکسِ LCP دقیقاً همون چیزیه که LCP رو بدتر می‌کنه.
 *
 * باگِ واقعیِ گزارش‌شده (رگرسیونِ جدی — LCP از ۳.۹s به ۱۹.۸s پرید): این‌جا
 * قبلاً `static $i = 0;` مستقیم توی همین فایل (نه توی یک تابع) بود. چون
 * این تمپلیت با wc_get_template_part() → include (نه include_once) برای
 * هر محصول جداگانه include می‌شه، static در سطحِ بالای یک فایل (نه داخلِ
 * تابع) بینِ include-های جدا پایدار نمی‌مونه — هر بار از نو صفر می‌شه و
 * بلافاصله ۱ می‌شه، یعنی «فقط کارتِ اول» در واقع «همه‌ی کارت‌ها» می‌شد:
 * ده‌ها عکسِ fetchpriority=high هم‌زمان، دقیقاً برعکسِ هدف. راه‌حل: شمارشگر
 * به یک تابعِ واقعی (jluxe_next_product_card_index در inc/woocommerce.php)
 * منتقل شد — static داخلِ تابع، برخلافِ static در فایل، بینِ فراخوانی‌های
 * مختلفِ همون تابع در طولِ یک درخواست واقعاً پایدار می‌مونه.
 */
$jluxe_card_render_count = function_exists( 'jluxe_next_product_card_index' ) ? jluxe_next_product_card_index() : 999;
$jluxe_card_is_eager     = $jluxe_card_render_count <= 4;

// JLuxe Theme → کارت محصول (نسبت تصویر/نمایش امتیاز و بج‌ها). قبلاً فقط
// دو حالت بود (مربع/عمودیِ ۴:۵) — طبقِ درخواستِ کاربر «فقط نباید مربع
// باشه»، یک حالتِ سومِ ۳:۴ («classic») هم اضافه شد.
$jluxe_ratio_map = array(
	'square'  => 'aspect-square',
	'classic' => 'aspect-[3/4]',
	'portrait' => 'aspect-[4/5]',
);
$jluxe_pc       = function_exists( 'jluxe_get_theme_settings' ) ? jluxe_get_theme_settings()['product_card'] : array();
$jluxe_ratio    = $jluxe_ratio_map[ $jluxe_pc['image_ratio'] ?? 'square' ] ?? $jluxe_ratio_map['square'];
$jluxe_show_rating = $jluxe_pc['show_rating'] ?? true;
$jluxe_show_sale   = $jluxe_pc['show_sale_badge'] ?? true;
$jluxe_show_stock  = $jluxe_pc['show_stock_badge'] ?? true;
$jluxe_price_style = ! empty( $jluxe_pc['price_color'] ) ? ' style="color:' . esc_attr( $jluxe_pc['price_color'] ) . '"' : '';
$jluxe_stock_color = isset( $jluxe_pc['in_stock_color'] ) ? sanitize_hex_color( $jluxe_pc['in_stock_color'] ) : '';
$jluxe_stock_style = $jluxe_stock_color ? ' style="background-color:' . esc_attr( $jluxe_stock_color ) . '"' : '';
/*
 * نگاشتِ گردیِ گوشه‌ها (تنظیمِ «کارت محصول» → گردی گوشه‌ها) — طبقِ درخواستِ
 * صریحِ کاربر («دور عکسا گرد بشه مثل کارت») جعبه‌ی تصویر دیگه یک گردیِ
 * کوچیک‌ترِ جداگونه نداره؛ چون تصویر حالا (بدونِ padding/margin اضافه‌ی
 * بیرونی) درست لبه‌به‌لبه‌ی بالای کارت می‌شینه، فقط دو گوشه‌ی بالاییش
 * دقیقاً هم‌اندازه‌ی خودِ کارت گرد می‌شن (rounded-t-*).
 */
/*
 * کلیدِ جدید 'image_inner' — طبقِ درخواستِ کاربر («گوشه‌ی خودِ عکس هم
 * کمی گرد بشه، شبیهِ خودِ کادر») چون جعبه‌ی عکس ۱۶px پدینگ (p-4) داره،
 * خودِ <img> از لبه‌های گردِ جعبه فاصله داره و گوشه‌های کاملاً تیزش کنارِ
 * اون فاصله عجیب به نظر می‌رسید. یک گردیِ کوچیک‌تر (تقریباً نصفِ گردیِ
 * خودِ کارت) به خودِ عکس اضافه شده — نه هم‌اندازه‌ی کارت (که با اون فاصله‌ی
 * پدینگ منطقی نیست)، فقط هماهنگ‌تر از گوشه‌ی کاملاً تیز.
 */
$jluxe_radius_map = array(
	'sm' => array( 'card' => 'rounded-xl', 'image' => 'rounded-t-xl', 'image_inner' => 'rounded-lg' ),
	'md' => array( 'card' => 'rounded-2xl', 'image' => 'rounded-t-2xl', 'image_inner' => 'rounded-xl' ),
	'lg' => array( 'card' => 'rounded-[24px]', 'image' => 'rounded-t-[24px]', 'image_inner' => 'rounded-2xl' ),
);
$jluxe_radius   = $jluxe_radius_map[ $jluxe_pc['radius'] ?? 'lg' ] ?? $jluxe_radius_map['lg'];
// طبقِ درخواستِ صریحِ کاربر — گردیِ خودِ عکس (image_inner، مستقل از گردیِ
// کلیِ کارت) حالا یک سوییچِ جدا داره: 'sharp' یعنی گوشه‌های کاملاً تیز
// (بدونِ هیچ کلاسِ rounded-*)، خالی/'rounded' یعنی همون رفتارِ قبلی.
$jluxe_image_inner_class = ( 'sharp' === ( $jluxe_pc['image_corners'] ?? 'rounded' ) ) ? '' : $jluxe_radius['image_inner'];

?>
<li <?php wc_product_class( 'group relative flex flex-col ' . esc_attr( $jluxe_radius['card'] ) . ' border border-border bg-gradient-to-b from-surface to-muted/40 transition-all duration-300 hover:border-primary/30', $product ); ?>>
	<?php
	// گالری محصول (عکس‌های دیگه، غیر از تصویر شاخص) — با هاور (دسکتاپ) یا
	// لمس طولانی (موبایل) به‌صورت ردیف تامبنیل کوچیک پایین باکس تصویر
	// نشون داده می‌شه. فقط وقتی واقعاً محصول عکس اضافه داره رندر می‌شه.
	$jluxe_all_gallery_ids  = $product->get_gallery_image_ids();
	$jluxe_gallery_ids      = array_slice( $jluxe_all_gallery_ids, 0, 4 );
	$jluxe_gallery_overflow = max( 0, count( $jluxe_all_gallery_ids ) - 4 );
	?>
	<?php
	/*
	 * طبقِ درخواستِ صریحِ کاربر: دیگه bg-muted جدا نداره (پس‌زمینه‌ی گرادیانِ
	 * خودِ کارت — li.product بالاتر — از پشتِ تصویر دیده می‌شه، «کل بکگراند
	 * رو بکگراند کارت بگیره»)، بزرگ‌نماییِ هاور (group-hover:scale) حذف
	 * شده، و p-3ِ بیرونیِ قبلی هم حذف شده تا جعبه‌ی تصویر واقعاً لبه‌به‌لبه‌ی
	 * بالای کارت بشینه (باگِ گزارش‌شده‌ی «تصویر کمی بالا قرار داره» دقیقاً
	 * همین فاصله‌ی اضافه بود). به‌جای بزرگ‌نمایی، یک درخشِ اریبِ سریع/ملایمِ
	 * jluxe-card-shine (در globals.css، همون تکنیکِ لوگو ولی سریع‌تر و
	 * کم‌شدت‌تر و فقط با هاور) اضافه شده.
	 *
	 * باگِ واقعیِ بعدی («عکس باید بیاد پایین‌تر تا بزلِ چپ/راست/بالا برابر
	 * شه»): با اندازه‌گیریِ مستقیمِ زنده (getBoundingClientRect) روی سایتِ
	 * واقعی، فاصله‌ی بالا ۸px و پایین ۲۴px بود، در حالی که چپ/راست هرکدوم
	 * ۱۶px (خودِ p-4) — یعنی flex + items-center روی <a> این عکسِ size-full
	 * رو دقیقاً وسط‌چین نمی‌کرد (رفتارِ نامنظمِ محاسبه‌ی اندازه‌ی عنصرِ
	 * جایگزین/replaced-element با ارتفاعِ درصدی در فلکس).
	 *
	 * تلاشِ اولِ رفع (absolute inset-4 مستقیم روی خودِ <img>) هم کار نکرد —
	 * با زنده‌تست دوباره معلوم شد: مرورگرها برای عنصرِ جایگزین (replaced
	 * element مثلِ <img>) با position:absolute، حتی وقتی هر ۴ سمتِ inset
	 * ست شده باشه، بازم عرض/ارتفاع رو بر اساسِ اندازه‌ی ذاتی/طبیعی حساب
	 * می‌کنن، نه کِشش تا پرکردنِ فاصله‌ی بینِ inset ها (برخلافِ یک <div>
	 * معمولی که این کِشش براش تضمین‌شده‌ست) — نتیجه یک جابه‌جاییِ نامتقارنِ
	 * دیگه بود. راه‌حلِ درست: یک <div> ساده (نه replaced) بینِ <a> و <img>
	 * که خودش absolute inset-4 می‌گیره (این کِشش براش قابلِ‌اتکاست)، و
	 * <img> داخلش فقط size-full می‌گیره — الان ۱۶px از هر چهار طرف
	 * تضمین‌شده و یکسانه، روی هر نسبت‌تصویری، بدونِ وابستگی به رفتارِ
	 * فلکس یا الگوریتمِ اندازه‌گیریِ عنصرِ جایگزین.
	 */
	?>
	<div class="relative">
		<a href="<?php echo esc_url( get_permalink( $product->get_id() ) ); ?>" class="jluxe-card-shine relative flex <?php echo esc_attr( $jluxe_ratio ); ?> overflow-hidden <?php echo esc_attr( $jluxe_radius['image'] ); ?>">
			<div class="absolute inset-4">
				<img
					data-jluxe-card-main-img
					src="<?php echo esc_url( $image_url ); ?>"
					<?php if ( $image_srcset ) : ?>srcset="<?php echo esc_attr( $image_srcset ); ?>" sizes="<?php echo esc_attr( $image_sizes ); ?>"<?php endif; ?>
					alt="<?php echo esc_attr( $product->get_name() ); ?>"
					<?php echo jluxe_lazy_attr( $jluxe_card_is_eager ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php // fetchpriority=high فقط برای اولین کارت (تنها کاندیدِ واقعیِ LCP) — دادنش به چند عکس هم‌زمان خودِ سیگنال رو کم‌اثر می‌کنه. ?>
					<?php echo 1 === $jluxe_card_render_count ? ' fetchpriority="high"' : ''; ?>
					<?php
					/*
					 * قابِ aspect-* نسبتِ تنظیم‌شده را نگه می‌دارد؛ خودِ منبع uncropped
					 * است و object-contain کلِ کالا را بدونِ تغییرِ رنگ نمایش می‌دهد.
					 */
					?>
					class="size-full object-contain <?php echo esc_attr( $jluxe_image_inner_class ); ?><?php echo $out_of_stock ? ' opacity-60 grayscale' : ''; ?>"
				/>
			</div>

			<?php if ( $has_discount && $jluxe_show_sale ) : ?>
				<span class="absolute top-2 end-2 rounded-lg bg-primary px-2 py-0.5 text-[11px] font-bold text-primary-foreground"><?php echo esc_html( jluxe_fa_digits( $discount_pct ) ); ?>٪</span>
			<?php elseif ( $out_of_stock && $jluxe_show_stock ) : ?>
				<span class="absolute top-2 end-2 rounded-lg bg-muted-foreground/80 px-2 py-0.5 text-[11px] font-bold text-white">ناموجود</span>
			<?php else : ?>
				<span class="absolute top-2.5 start-2.5 size-2 rounded-full bg-success ring-2 ring-surface"<?php echo $jluxe_stock_style; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> aria-hidden="true"></span>
			<?php endif; ?>

			<?php if ( ! empty( $jluxe_gallery_ids ) ) : ?>
				<div data-jluxe-card-thumbs class="pointer-events-none absolute inset-x-1.5 bottom-1.5 flex gap-1 opacity-0 transition-opacity duration-200 group-hover:opacity-100 group-hover:pointer-events-auto group-data-[thumbs-active]:opacity-100 group-data-[thumbs-active]:pointer-events-auto">
					<?php foreach ( $jluxe_gallery_ids as $jluxe_gid ) :
						$jluxe_thumb_url   = wp_get_attachment_image_url( $jluxe_gid, 'medium' );
						$jluxe_full_url    = wp_get_attachment_image_url( $jluxe_gid, 'large' ) ?: wp_get_attachment_image_url( $jluxe_gid, 'full' );
						$jluxe_full_srcset = wp_get_attachment_image_srcset( $jluxe_gid, 'large' );
						if ( ! $jluxe_thumb_url || ! $jluxe_full_url ) {
							continue;
						}
						?>
						<span data-jluxe-card-thumb data-full="<?php echo esc_url( $jluxe_full_url ); ?>"<?php if ( $jluxe_full_srcset ) : ?> data-srcset="<?php echo esc_attr( $jluxe_full_srcset ); ?>" data-sizes="<?php echo esc_attr( $image_sizes ); ?>"<?php endif; ?> class="size-8 shrink-0 overflow-hidden rounded-md border-2 border-white/90 bg-white/90 shadow-sm">
							<img src="<?php echo esc_url( $jluxe_thumb_url ); ?>" alt="" class="size-full object-contain" loading="lazy" />
						</span>
					<?php endforeach; ?>
					<?php if ( $jluxe_gallery_overflow > 0 ) : ?>
						<span class="flex size-8 shrink-0 items-center justify-center rounded-md border-2 border-white/90 bg-black/60 text-caption font-medium text-white">+<?php echo esc_html( jluxe_fa_digits( $jluxe_gallery_overflow ) ); ?></span>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</a>
	</div>

	<div class="flex flex-1 flex-col px-3 pb-3 md:px-4 md:pb-4">
		<a href="<?php echo esc_url( get_permalink( $product->get_id() ) ); ?>" class="jluxe-product-card-title min-h-[40px] text-[13px] leading-5 line-clamp-2 break-words text-text-secondary hover:text-primary">
			<?php echo esc_html( $product->get_name() ); ?>
		</a>

		<?php
		// عنوان پیش از امتیاز می‌آید تا کارت در اسکن سریع، اول خود محصول را
		// معرفی کند. ردیف امتیاز همیشه ارتفاع ثابت دارد تا کارت‌های گرید
		// هم‌تراز بمانند؛ اگر امتیازی نیست فقط از دید مخفی می‌شود.
		$jluxe_show_rating_row = $jluxe_show_rating && $review_count > 0;
		?>
		<div class="mb-3 mt-1 flex min-h-[16px] items-center gap-1<?php echo $jluxe_show_rating_row ? '' : ' invisible'; ?>" role="img" aria-label="<?php echo esc_attr( sprintf( 'امتیاز %s از ۵ بر اساس %s دیدگاه', jluxe_fa_digits( number_format( $rating, 1, '.', '' ) ), jluxe_fa_digits( $review_count ) ) ); ?>">
			<?php echo jluxe_boom_star_row( $rating, 'size-3' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<span aria-hidden="true" class="text-[10px] font-medium text-text-secondary"><?php echo esc_html( jluxe_fa_digits( number_format( $rating, 1, '.', '' ) ) ); ?></span>
			<span aria-hidden="true" class="text-[10px] text-text-muted">(<?php echo esc_html( jluxe_fa_digits( $review_count ) ); ?>)</span>
		</div>

		<div class="jluxe-product-card-footer">
			<div class="jluxe-product-card-price">
				<span class="jluxe-product-card-current-price text-[14px] font-semibold text-foreground md:text-[15px]"<?php echo $jluxe_price_style; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><?php echo wp_kses_post( wc_price( $has_discount ? $sale_price : ( $is_variable ? $product->get_variation_price( 'min' ) : $regular_price ) ) ); ?></span>
				<?php if ( $has_discount ) : ?>
					<del class="jluxe-product-card-old-price text-[11px] text-text-muted line-through"><?php echo wp_kses_post( wc_price( $regular_price ) ); ?></del>
				<?php endif; ?>
			</div>

			<?php
			/*
			 * CTA در همهٔ اندازه‌ها دکمهٔ + فشرده است؛ زمینهٔ تیره در hover/press
			 * به رنگ اصلی فروشگاه درمی‌آید و آیکون می‌چرخد. aria-label نامِ
			 * دسترس‌پذیر را می‌دهد؛ تنوع quick-pick و افزودنِ AJAX دست‌نخورده‌اند.
			 */
			?>
			<a
				href="<?php echo esc_url( $out_of_stock || $is_variable ? get_permalink( $product->get_id() ) : $product->add_to_cart_url() ); ?>"
				aria-label="<?php echo esc_attr( $out_of_stock ? 'ناموجود' : ( $is_variable ? 'انتخاب گزینه‌ها' : 'افزودن به سبد خرید' ) ); ?>"
				data-product_id="<?php echo esc_attr( $product->get_id() ); ?>"
				<?php echo ( $is_variable && ! $out_of_stock ) ? '' : 'data-quantity="1"'; ?>
				<?php echo ( $is_variable && ! $out_of_stock ) ? 'data-jluxe-quick-variant="' . esc_attr( $product->get_id() ) . '"' : ''; ?>
				class="jluxe-product-card-cta product_type_<?php echo esc_attr( $is_variable ? 'variable' : 'simple' ); ?> <?php echo $out_of_stock ? 'is-unavailable' : 'is-available'; ?> <?php echo ( ! $is_variable && ! $out_of_stock ) ? 'ajax_add_to_cart add_to_cart_button' : ''; ?>"
			>
				<svg class="jluxe-product-card-cta-icon size-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
			</a>
		</div>
	</div>
</li>
