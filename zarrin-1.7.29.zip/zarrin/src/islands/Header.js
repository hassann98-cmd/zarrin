import { useDialog } from "../lib/use-dialog.js";
import { siteUrl } from "../lib/api.js";
import { fetchLiveSearch } from "../lib/live-search.js";
import { j as e } from "../lib/jsx.js";
import { r as c } from "../lib/icons.js";
import { r as L } from "../lib/react-dom.js";
import { L as U, B as g } from "../components/button.js";
import { g as b } from "../lib/theme-settings.js";
import { u as R } from "../lib/use-cart.js";
import { S as f } from "../icons/search.js";
import { T } from "../icons/tag.js";
import { S as $ } from "../icons/shopping-cart.js";
import { U as A } from "../icons/user.js";
import { X as D } from "../icons/x.js";
import "../lib/utils.js";
const p = {
  products: [],
  categories: [],
  brands: [],
  viewAllUrl: "",
  query: "",
  correctedQuery: "",
};
function I(l) {
  const [r, n] = c.useState(p),
    [o, t] = c.useState(!1),
    d = c.useRef(0);
  return (
    c.useEffect(() => {
      const m = l.trim();
      if (m.length < 2) {
        (n(p), t(!1));
        return;
      }
      const i = b().search;
      if (!(i != null && i.ajaxUrl)) return;
      t(!0);
      const x = ++d.current,
        h = window.setTimeout(() => {
          fetchLiveSearch(i, m)
            .then((u) => {
              x === d.current && n(u.success && u.data ? u.data : p);
            })
            .catch(() => {
              x === d.current && n(p);
            })
            .finally(() => {
              x === d.current && t(!1);
            });
        }, 300);
      return () => window.clearTimeout(h);
    }, [l]),
    { results: r, loading: o }
  );
}
function C({ query: l, results: r, loading: n }) {
  const settings = b(),
    categoryUrl = (settings.megaMenu && settings.megaMenu.url) || siteUrl("shop"),
    o =
      r.products.length > 0 || r.categories.length > 0 || r.brands.length > 0,
    correctedQuery =
      typeof r.correctedQuery === "string" &&
      r.correctedQuery.trim() &&
      r.correctedQuery !== (r.query || l.trim())
        ? r.correctedQuery
        : "",
    displayQuery = correctedQuery || l;
  return n && !o
    ? e.jsxs("div", {
        className:
          "flex items-center justify-center gap-2 py-8 text-small text-text-muted",
        children: [
          e.jsx(U, { className: "size-4 animate-spin", "aria-hidden": !0 }),
          "در حال جستجو...",
        ],
      })
    : !n && !o
      ? e.jsxs("div", {
          className: "flex flex-col items-center gap-3 py-8 text-center",
          children: [
            e.jsx(f, {
              className: "size-6 text-text-muted/60",
              "aria-hidden": !0,
            }),
            e.jsxs("div", {
              className: "flex flex-col gap-1",
              children: [
                e.jsxs("p", {
                  className: "text-small font-semibold text-foreground",
                  children: ["نتیجه‌ای برای «", l, "» پیدا نشد."],
                }),
                e.jsx("p", {
                  className: "text-caption leading-6 text-text-muted",
                  children:
                    "املای عبارت را بررسی کنید، جستجو را کوتاه‌تر کنید یا نام یک برند/دسته‌بندی را امتحان کنید.",
                }),
                correctedQuery
                  ? e.jsxs("p", {
                      className: "text-caption text-text-secondary",
                      children: ["پیشنهاد املایی: «", correctedQuery, "»"],
                    })
                  : null,
              ],
            }),
            e.jsxs("div", {
              className: "flex w-full flex-col gap-2 sm:flex-row",
              children: [
                e.jsx("a", {
                  href: categoryUrl,
                  className:
                    "flex h-11 flex-1 items-center justify-center rounded-xl border border-border bg-muted px-3 text-button font-medium text-foreground transition-colors hover:border-primary/40 hover:text-primary",
                  children: "مرور دسته‌بندی‌ها",
                }),
                r.viewAllUrl
                  ? e.jsxs("a", {
                      href: r.viewAllUrl,
                      className:
                        "flex h-11 flex-1 items-center justify-center rounded-xl bg-primary px-3 text-button font-medium text-primary-foreground transition-colors hover:bg-primary-hover",
                      children: ["جستجوی کامل برای «", displayQuery, "»"],
                    })
                  : null,
              ],
            }),
          ],
        })
      : e.jsxs("div", {
          className: "flex flex-col gap-4",
          children: [
            e.jsxs("p", {
              className: "text-small font-bold text-foreground",
              "aria-live": "polite",
              children: correctedQuery
                ? [
                    "املای جستجو از «",
                    r.query || l,
                    "» به «",
                    correctedQuery,
                    "» اصلاح شد",
                  ]
                : ["پیشنهادها برای «", l, "»"],
            }),
            r.categories.length > 0
              ? e.jsxs("div", {
                  children: [
                    e.jsx("p", {
                      className:
                        "mb-2 text-caption font-bold text-text-secondary",
                      children: "دسته‌بندی‌ها",
                    }),
                    e.jsx("div", {
                      className: "flex flex-wrap gap-1.5",
                      children: r.categories.map((t) =>
                        e.jsx(
                          "a",
                          {
                            href: t.url,
                            className:
                              "rounded-full border border-border bg-muted px-3 py-1.5 text-caption text-foreground transition-colors hover:border-primary/40 hover:text-primary",
                            children: t.name,
                          },
                          t.url,
                        ),
                      ),
                    }),
                  ],
                })
              : null,
            r.brands.length > 0
              ? e.jsxs("div", {
                  children: [
                    e.jsx("p", {
                      className:
                        "mb-2 text-caption font-bold text-text-secondary",
                      children: "برندها",
                    }),
                    e.jsx("div", {
                      className: "flex flex-wrap gap-1.5",
                      children: r.brands.map((t) =>
                        e.jsxs(
                          "a",
                          {
                            href: t.url,
                            className:
                              "flex items-center gap-1 rounded-full border border-border bg-muted px-3 py-1.5 text-caption text-foreground transition-colors hover:border-primary/40 hover:text-primary",
                            children: [
                              e.jsx(T, {
                                className: "size-3",
                                "aria-hidden": !0,
                              }),
                              t.name,
                            ],
                          },
                          t.url,
                        ),
                      ),
                    }),
                  ],
                })
              : null,
            r.products.length > 0
              ? e.jsxs("div", {
                  children: [
                    e.jsx("p", {
                      className:
                        "mb-2 text-caption font-bold text-text-secondary",
                      children: "محصولات",
                    }),
                    e.jsx("div", {
                      className: "flex flex-col gap-1",
                      children: r.products.map((t) =>
                        e.jsxs(
                          "a",
                          {
                            href: t.url,
                            className:
                              "flex items-center gap-3 rounded-xl p-2 transition-colors hover:bg-muted",
                            children: [
                              e.jsx("img", {
                                src: t.image,
                                alt: t.name,
                                className:
                                  "size-12 shrink-0 rounded-lg border border-border object-cover",
                                loading: "lazy",
                              }),
                              e.jsxs("div", {
                                className: "min-w-0 flex-1",
                                children: [
                                  e.jsx("p", {
                                    className:
                                      "truncate text-small text-foreground",
                                    children: t.name,
                                  }),
                                  e.jsx("p", {
                                    className:
                                      "truncate text-caption text-primary [&_del]:text-text-muted [&_del]:me-1 [&_ins]:no-underline",
                                    dangerouslySetInnerHTML: {
                                      __html: t.price,
                                    },
                                  }),
                                ],
                              }),
                            ],
                          },
                          t.id,
                        ),
                      ),
                    }),
                  ],
                })
              : null,
            r.viewAllUrl
              ? e.jsxs("a", {
                  href: r.viewAllUrl,
                  className:
                    "flex h-11 items-center justify-center rounded-xl bg-primary text-button font-medium text-primary-foreground transition-colors hover:bg-primary-hover",
                  children: ["مشاهده همه‌ی نتایج برای «", displayQuery, "»"],
                })
              : null,
          ],
        });
}
const z = "jluxe:open-search";
function J() {
  var _;
  const { snapshot: l } = R(),
    r = l.itemCount,
    [n, o] = c.useState(""),
    [t, d] = c.useState(!1),
    [m, i] = c.useState(!1),
    { results: x, loading: h } = I(n),
    s = b().header,
    dialogRef = c.useRef(null);
  useDialog(m, dialogRef, () => i(!1));
  (c.useEffect(() => {
    function a() {
      i(!0);
    }
    return (
      window.addEventListener(z, a),
      () => window.removeEventListener(z, a)
    );
  }, []),
    c.useEffect(() => {
      if (m)
        return (
          (document.body.style.overflow = "hidden"),
          () => {
            document.body.style.overflow = "";
          }
        );
    }, [m]));
  const u = (s == null ? void 0 : s.show_search_desktop) ?? !0,
    j = (s == null ? void 0 : s.show_account_desktop) ?? !0,
    v = (s == null ? void 0 : s.show_account_mobile) ?? !0,
    N = (s == null ? void 0 : s.show_cart_desktop) ?? !0,
    w = (s == null ? void 0 : s.show_cart_mobile) ?? !0,
    y = ((_ = b().auth) == null ? void 0 : _.isLoggedIn) ?? !1,
    searchPlaceholder =
      typeof (s == null ? void 0 : s.search_placeholder) === "string" &&
      s.search_placeholder.trim()
        ? s.search_placeholder.trim()
        : "جستجو در فروشگاه";
  function S(a, k) {
    return a && k ? "" : a ? "hidden md:inline-flex" : k ? "md:hidden" : "";
  }
  return e.jsxs("div", {
    className: "jluxe-header-actions-layout",
    children: [
      u
        ? e.jsxs("div", {
            className: "relative hidden w-full min-w-0 md:block",
            "data-jluxe-header-grid": "search",
            children: [
              e.jsxs("form", {
                role: "search",
                action: siteUrl("home"),
                method: "get",
                className: "relative",
                children: [
                  e.jsx(f, {
                    className:
                      "pointer-events-none absolute start-4 top-1/2 size-4 -translate-y-1/2 text-text-muted",
                    "aria-hidden": !0,
                  }),
                  e.jsx("input", {
                    type: "search",
                    name: "s",
                    value: n,
                    onChange: (a) => o(a.target.value),
                    onFocus: () => d(!0),
                    onBlur: () => d(!1),
                    placeholder: searchPlaceholder,
                    "aria-label": "جستجو در فروشگاه",
                    enterKeyHint: "search",
                    "data-dialog-initial-focus": "",
                    className:
                      "h-14 w-full rounded-2xl border border-transparent bg-muted ps-10 pe-4 text-small text-foreground placeholder:text-text-muted focus:border-primary focus:bg-surface focus:outline-none",
                  }),
                  e.jsx("input", { type: "hidden", name: "post_type", value: "product" }),
                  e.jsx("button", {
                    type: "submit",
                    className: "sr-only",
                    children: "جستجوی محصولات",
                  }),
                ],
              }),
              t && n.trim().length >= 2
                ? e.jsx("div", {
                    onMouseDown: (a) => a.preventDefault(),
                    className:
                      "jluxe-header-search-results--desktop absolute inset-x-0 top-full z-40 mt-2 overflow-y-auto rounded-2xl border border-border bg-surface p-4 shadow-lg",
                    children: e.jsx(C, { query: n, results: x, loading: h }),
                  })
                : null,
            ],
          })
        : null,
      j || v
        ? e.jsx(g, {
            variant: "primary",
            className: `gap-1.5 rounded-2xl px-3 md:h-14 md:w-[151px] ${S(j, v)}`,
            "aria-label": y ? "حساب کاربری" : "ورود",
            "data-jluxe-header-grid": "account",
            asChild: !0,
            children: e.jsxs("a", {
              href: siteUrl(y ? "dashboard" : "login"),
              children: [
                e.jsx("span", {
                  className: "hidden text-button md:inline",
                  children: y ? "حساب کاربری" : "ورود",
                }),
                e.jsx(A, { className: "size-5", "aria-hidden": !0 }),
              ],
            }),
          })
        : null,
      N || w
        ? e.jsxs(g, {
            variant: "outline",
            className: `gap-1.5 rounded-2xl px-3 md:h-[58px] md:w-[171px] ${S(N, w)}`,
            "aria-label": `سبد خرید${r ? `، ${r} کالا` : ""}`,
            onClick: () =>
              window.dispatchEvent(new CustomEvent("jluxe:open-cart")),
            "data-jluxe-cart-icon-desktop": !0,
            "data-jluxe-header-grid": "cart",
            children: [
              e.jsx("span", {
                className:
                  "flex size-5 items-center justify-center rounded-full bg-muted text-caption font-bold text-foreground",
                children: r.toLocaleString("fa-IR"),
              }),
              e.jsx("span", {
                className: "hidden text-button md:inline",
                children: "سبد خرید",
              }),
              e.jsx($, { className: "size-5", "aria-hidden": !0 }),
            ],
          })
        : null,
      m
        ? L.createPortal(
            e.jsxs("div", {
              className:
                "fixed inset-0 z-50 flex flex-col bg-surface md:hidden",
              role: "dialog",
              "aria-modal": true,
              "aria-label": "جستجو در فروشگاه",
              ref: dialogRef,
              children: [
                e.jsxs("div", {
                  className:
                    "flex items-center gap-2 border-b border-border p-3",
                  children: [
                    e.jsxs("form", {
                      role: "search",
                      action: siteUrl("home"),
                      method: "get",
                      className: "relative flex-1",
                      children: [
                        e.jsx(f, {
                          className:
                            "pointer-events-none absolute start-4 top-1/2 size-4 -translate-y-1/2 text-text-muted",
                          "aria-hidden": !0,
                        }),
                        e.jsx("input", {
                          autoFocus: !0,
                          type: "search",
                          name: "s",
                          value: n,
                          onChange: (a) => o(a.target.value),
                          placeholder: searchPlaceholder,
                          "aria-label": "جستجو در فروشگاه",
                          enterKeyHint: "search",
                          "data-dialog-initial-focus": "",
                          className:
                            "h-12 w-full rounded-2xl border border-transparent bg-muted ps-10 pe-4 text-small text-foreground placeholder:text-text-muted focus:border-primary focus:outline-none",
                        }),
                        e.jsx("input", { type: "hidden", name: "post_type", value: "product" }),
                        e.jsx("button", {
                          type: "submit",
                          className: "sr-only",
                          children: "جستجوی محصولات",
                        }),
                      ],
                    }),
                    e.jsx("button", {
                      type: "button",
                      onClick: () => {
                        (i(!1), o(""));
                      },
                      "aria-label": "بستن جستجو",
                      className:
                        "grid size-11 shrink-0 place-items-center rounded-xl text-text-muted transition-colors hover:bg-muted",
                      children: e.jsx(D, {
                        className: "size-5",
                        "aria-hidden": !0,
                      }),
                    }),
                  ],
                }),
                e.jsx("div", {
                  className: "flex-1 overflow-y-auto p-4",
                  children:
                    n.trim().length >= 2
                      ? e.jsx(C, { query: n, results: x, loading: h })
                      : e.jsx("p", {
                          className:
                            "py-8 text-center text-small text-text-muted",
                          children:
                            "نام محصول، دسته‌بندی یا برند را جستجو کنید.",
                        }),
                }),
              ],
            }),
            document.body,
          )
        : null,
    ],
  });
}
function MobileSearch() {
  const [query, setQuery] = c.useState(""),
    [focused, setFocused] = c.useState(!1),
    { results, loading } = I(query),
    headerSettings = b().header,
    enabled =
      (headerSettings == null ? void 0 : headerSettings.show_search_mobile) ??
      !0,
    searchPlaceholder =
      typeof (headerSettings == null ? void 0 : headerSettings.search_placeholder) ===
        "string" && headerSettings.search_placeholder.trim()
        ? headerSettings.search_placeholder.trim()
        : "جستجو در فروشگاه";
  return enabled
    ? e.jsxs("div", {
        className: "relative h-10 w-full min-w-0 md:hidden",
        children: [
          e.jsxs("form", {
            role: "search",
            action: siteUrl("home"),
            method: "get",
            className: "relative h-full",
            children: [
              e.jsx(f, {
                className:
                  "pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-text-muted",
                "aria-hidden": !0,
              }),
              e.jsx("input", {
                type: "search",
                name: "s",
                value: query,
                onChange: (event) => setQuery(event.target.value),
                onFocus: () => setFocused(!0),
                onBlur: () => setFocused(!1),
                placeholder: searchPlaceholder,
                "aria-label": "جستجو در فروشگاه",
                enterKeyHint: "search",
                className:
                  "h-10 w-full rounded-xl border border-border bg-surface ps-10 pe-3 text-small text-foreground placeholder:text-text-muted focus:border-primary focus:outline-none",
              }),
              e.jsx("input", { type: "hidden", name: "post_type", value: "product" }),
              e.jsx("button", {
                type: "submit",
                className: "sr-only",
                children: "جستجوی محصولات",
              }),
            ],
          }),
          focused && query.trim().length >= 2
            ? e.jsx("div", {
                onMouseDown: (event) => event.preventDefault(),
                className:
                  "jluxe-header-search-results--mobile absolute inset-x-0 top-full z-40 mt-2 overflow-y-auto rounded-2xl border border-border bg-surface p-3 shadow-lg",
                children: e.jsx(C, {
                  query,
                  results,
                  loading,
                }),
              })
            : null,
        ],
      })
    : null;
}
function K({ className: l }) {
  const r = b(),
    n = r.logoUrl || "",
    o = r.mobileLogoUrl || n,
    t = r.siteName || "زرین";
  return !(n || o)
    ? e.jsx("a", {
        href: siteUrl("home"),
        className: `inline-block text-lg font-bold text-foreground ${l ?? ""}`,
        "aria-label": t,
        children: t,
      })
    : e.jsxs("a", {
        href: siteUrl("home"),
        className: `jluxe-logo-shine group inline-block ${l ?? ""}`,
        "aria-label": t,
        children: [
          e.jsx("img", {
            src: o || n,
            alt: t,
            className: "h-16 w-auto md:hidden",
            "data-jluxe-no-skeleton": !0,
          }),
          e.jsx("img", {
            src: n || o,
            alt: t,
            className: "hidden h-16 w-auto md:block",
            "data-jluxe-no-skeleton": !0,
          }),
        ],
      });
}
export { K as BrandLogo, J as default, MobileSearch as MobileHeaderSearch };
