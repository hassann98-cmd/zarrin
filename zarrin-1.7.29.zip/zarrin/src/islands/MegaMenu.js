import { siteUrl } from "../lib/api.js";
import { j as e } from "../lib/jsx.js";
import { r as c } from "../lib/icons.js";
import { c as x } from "../lib/utils.js";
import { g as m } from "../lib/theme-settings.js";
import { C as h } from "../icons/chevron-down.js";
import { G as d } from "../icons/grid-2x2.js";
import { C as p } from "../icons/chevron-left.js";
function y() {
  var l, n;
  const t = ((l = m().megaMenu) == null ? void 0 : l.categories) ?? [],
    [o, i] = c.useState(((n = t[0]) == null ? void 0 : n.id) ?? ""),
    s = t.find((r) => r.id === o) ?? t[0],
    // R93b — کلیک روی «دسته‌بندی‌ها» ← برگهٔ همه دسته‌بندی‌ها (inc/categories-page.php:
    // jluxe_header_categories_url)؛ دادهٔ قدیمیِ بدونِ url ⇒ فروشگاه، مثلِ قبل.
    u = (m().megaMenu && m().megaMenu.url) || siteUrl("shop");
  return t.length === 0
    ? e.jsx("a", {
        href: u,
        className:
          "flex items-center gap-1 text-body text-text-secondary transition-colors hover:text-foreground",
        children: "دسته‌بندی‌ها",
      })
    : e.jsxs("div", {
        className: "group relative",
        onMouseLeave: () => i(t[0].id),
        children: [
          e.jsxs("a", {
            href: u,
            className:
              "flex items-center gap-1 text-body text-text-secondary transition-colors hover:text-foreground",
            children: [
              "دسته‌بندی‌ها",
              e.jsx(h, {
                className:
                  "size-3.5 transition-transform group-hover:rotate-180",
                "aria-hidden": !0,
              }),
            ],
          }),
          e.jsxs("div", {
            className:
              "invisible absolute start-0 top-full z-40 flex w-[1180px] overflow-hidden rounded-xl border border-white/10 bg-surface/95 opacity-0 shadow-lg backdrop-blur-xl transition-all duration-150 group-hover:visible group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100",
            children: [
              e.jsx("nav", {
                "aria-label": "دسته‌بندی‌های اصلی",
                className: "w-56 shrink-0 border-s border-border py-3",
                children: t.map((r) => {
                  const a = r.id === o;
                  return e.jsxs(
                    "a",
                    {
                      href: r.url,
                      onMouseEnter: () => i(r.id),
                      onFocus: () => i(r.id),
                      className: x(
                        "flex items-center justify-between gap-2 border-e-2 px-4 py-2.5 text-small transition-colors",
                        a
                          ? "border-primary bg-primary/5 text-primary"
                          : "border-transparent text-text-secondary hover:bg-muted",
                      ),
                      children: [
                        r.label,
                        r.iconSvg
                          ? e.jsx("span", {
                              className: "size-4 shrink-0 [&>svg]:size-full",
                              dangerouslySetInnerHTML: { __html: r.iconSvg },
                            })
                          : e.jsx(d, {
                              className: "size-4 shrink-0",
                              "aria-hidden": !0,
                            }),
                      ],
                    },
                    r.id,
                  );
                }),
              }),
              s
                ? e.jsxs("div", {
                    className: "flex-1 p-6",
                    children: [
                      e.jsxs("div", {
                        className:
                          "flex items-center justify-between border-b border-border pb-3",
                        children: [
                          e.jsxs("a", {
                            href: s.url,
                            className:
                              "flex items-center gap-2 text-caption text-text-secondary hover:text-foreground",
                            children: [
                              "مشاهده همه",
                              e.jsx(p, {
                                className: "size-3.5",
                                "aria-hidden": !0,
                              }),
                            ],
                          }),
                          e.jsxs("div", {
                            className: "flex items-center gap-2",
                            children: [
                              e.jsxs("div", {
                                className: "text-end",
                                children: [
                                  e.jsx("p", {
                                    className: "text-h3 text-foreground",
                                    children: s.label,
                                  }),
                                  e.jsxs("p", {
                                    className: "text-caption text-text-muted",
                                    children: [
                                      s.groups.length.toLocaleString("fa-IR"),
                                      " زیردسته",
                                    ],
                                  }),
                                ],
                              }),
                              s.iconSvg
                                ? e.jsx("span", {
                                    className:
                                      "size-6 [&>svg]:size-full text-primary",
                                    dangerouslySetInnerHTML: {
                                      __html: s.iconSvg,
                                    },
                                  })
                                : e.jsx(d, {
                                    className: "size-6 text-primary",
                                    "aria-hidden": !0,
                                  }),
                            ],
                          }),
                        ],
                      }),
                      s.groups.length > 0
                        ? e.jsx("div", {
                            className: "mt-5 grid grid-cols-4 gap-6",
                            children: s.groups.map((r) =>
                              e.jsxs(
                                "div",
                                {
                                  children: [
                                    e.jsx("h3", {
                                      className:
                                        "border-s-2 border-primary ps-2 text-label text-foreground",
                                      children: e.jsx("a", {
                                        href: r.url,
                                        className: "hover:text-primary",
                                        children: r.title,
                                      }),
                                    }),
                                    r.items.length > 0
                                      ? e.jsx("ul", {
                                          className: "mt-3 flex flex-col gap-2",
                                          children: r.items.map((a) =>
                                            e.jsx(
                                              "li",
                                              {
                                                children: e.jsx("a", {
                                                  href: a.url,
                                                  className:
                                                    "text-small text-text-secondary hover:text-primary",
                                                  children: a.label,
                                                }),
                                              },
                                              a.label,
                                            ),
                                          ),
                                        })
                                      : null,
                                  ],
                                },
                                r.title,
                              ),
                            ),
                          })
                        : e.jsx("p", {
                            className: "mt-5 text-small text-text-muted",
                            children: "این دسته زیردسته‌ای ندارد.",
                          }),
                    ],
                  })
                : null,
            ],
          }),
        ],
      });
}
export { y as default };
