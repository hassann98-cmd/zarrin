import { siteUrl } from "../lib/api.js";
import { useDialog } from "../lib/use-dialog.js";
import { j as e } from "../lib/jsx.js";
import { r } from "../lib/icons.js";
import { r as k } from "../lib/react-dom.js";
import { g as H } from "../lib/theme-settings.js";
import { u as I } from "../lib/use-cart.js";
import { S as j } from "../icons/shopping-cart.js";
import { X as u } from "../icons/x.js";
import { T as L } from "../icons/truck.js";
import { T as _ } from "../icons/trash-2.js";
import { M as E, P as M } from "../icons/plus.js";
import { C as q } from "../icons/check.js";
import { T as R } from "../icons/tag.js";
function J() {
  var g;
  const [n, l] = r.useState(!1),
    [y, x] = r.useState(!1),
    [p, o] = r.useState(!1),
    i = r.useRef(null),
    dialogRef = r.useRef(null),
    {
      snapshot: s,
      loading: d,
      error: cartError,
      updateQty: f,
      removeItem: v,
      applyCoupon: N,
      removeCoupon: w,
      couponLoading: c,
      couponError: h,
    } = I(),
    [m, b] = r.useState(""),
    S = ((g = H().cart) == null ? void 0 : g.showCoupon) !== !1;
  return (
    r.useEffect(() => {
      function t() {
        l(!0);
      }
      return (
        window.addEventListener("jluxe:open-cart", t),
        () => window.removeEventListener("jluxe:open-cart", t)
      );
    }, []),
    r.useEffect(() => {
      if (n) {
        x(!0);
        let a = !1;
        const C = requestAnimationFrame(() => {
          const T = requestAnimationFrame(() => {
            a || ((a = !0), o(!0));
          });
          i.current = T;
        });
        i.current = C;
        const z = window.setTimeout(() => {
          a || ((a = !0), o(!0));
        }, 100);
        return () => {
          (i.current !== null && cancelAnimationFrame(i.current),
            window.clearTimeout(z));
        };
      }
      o(!1);
      const t = window.setTimeout(() => x(!1), 300);
      return () => window.clearTimeout(t);
    }, [n]),
    r.useEffect(() => {
      if (n)
        return (
          (document.body.style.overflow = "hidden"),
          () => {
            document.body.style.overflow = "";
          }
        );
    }, [n]),
    y
      ? k.createPortal(
          e.jsxs("div", {
            className: "fixed inset-0 z-[60]",
            children: [
              e.jsx("div", {
                className: `absolute inset-0 bg-foreground/50 transition-opacity duration-300 ease-out ${p ? "opacity-100" : "opacity-0"}`,
                onClick: () => l(!1),
                "aria-hidden": "true",
              }),
              e.jsxs("div", {
                className: `absolute inset-y-0 left-0 flex h-full w-full max-w-sm flex-col bg-surface shadow-xl transition-transform duration-300 ease-out ${p ? "translate-x-0" : "-translate-x-full"}`,
                role: "dialog",
                ref: dialogRef,
                "aria-modal": "true",
                "aria-label": "سبد خرید",
                children: [
                  e.jsxs("div", {
                    className:
                      "flex items-center justify-between border-b border-border p-4",
                    children: [
                      e.jsxs("h2", {
                        className:
                          "flex items-center gap-2 text-body font-bold text-foreground",
                        children: [
                          e.jsx(j, { className: "size-5", "aria-hidden": !0 }),
                          "سبد خرید",
                          s.itemCount > 0
                            ? e.jsxs("span", {
                                className:
                                  "text-caption font-normal text-text-muted",
                                children: [
                                  "(",
                                  s.itemCount.toLocaleString("fa-IR"),
                                  ")",
                                ],
                              })
                            : null,
                        ],
                      }),
                      e.jsx("button", {
                        type: "button",
                        onClick: () => l(!1),
                        "aria-label": "بستن سبد خرید",
                        className:
                          "grid size-9 place-items-center rounded-lg text-text-muted transition-all hover:bg-muted active:scale-90 active:bg-muted",
                        children: e.jsx(u, {
                          className: "size-5",
                          "aria-hidden": !0,
                        }),
                      }),
                    ],
                  }),
                  cartError
                    ? e.jsxs("div", {
                        role: "alert",
                        className: "p-4 text-small text-error",
                        children: [
                          e.jsx("p", { children: cartError }),
                          e.jsx("a", {
                            href: s.cartUrl,
                            className: "underline",
                            children: "مشاهدهٔ صفحهٔ سبد خرید",
                          }),
                        ],
                      })
                    : null,
                  s.items.length > 0 && s.freeShipping
                    ? e.jsxs("div", {
                        className:
                          "border-b border-border bg-muted/40 px-4 py-3",
                        children: [
                          e.jsxs("div", {
                            className:
                              "mb-2 flex items-center gap-1.5 text-caption font-medium",
                            children: [
                              e.jsx(L, {
                                className: `size-4 ${s.freeShipping.achieved ? "text-success" : "text-primary"}`,
                                "aria-hidden": !0,
                              }),
                              s.freeShipping.achieved
                                ? e.jsx("span", {
                                    className: "text-success",
                                    children: "ارسال شما رایگان شد 🎉",
                                  })
                                : e.jsxs("span", {
                                    className: "text-text-secondary",
                                    children: [
                                      e.jsx("bdi", {
                                        dir: "ltr",
                                        className: "font-bold text-foreground",
                                        dangerouslySetInnerHTML: {
                                          __html: s.freeShipping.remainingHtml,
                                        },
                                      }),
                                      " ",
                                      "تا ارسال رایگان",
                                    ],
                                  }),
                            ],
                          }),
                          e.jsx("div", {
                            className:
                              "h-1.5 overflow-hidden rounded-full bg-border",
                            children: e.jsx("div", {
                              className: `h-full rounded-full transition-all duration-500 ease-out ${s.freeShipping.achieved ? "bg-success" : "bg-primary"}`,
                              style: {
                                width: `${s.freeShipping.progressPercent}%`,
                              },
                            }),
                          }),
                        ],
                      })
                    : null,
                  e.jsx("div", {
                    className: "flex-1 overflow-y-auto p-4",
                    children:
                      d && s.items.length === 0
                        ? e.jsx("p", {
                            role: "status",
                            children: "در حال خواندن سبد خرید…",
                          })
                        : cartError && s.items.length === 0
                          ? null
                          : s.items.length === 0
                            ? e.jsxs("div", {
                                className:
                                  "flex h-full flex-col items-center justify-center gap-3 py-12 text-center",
                                children: [
                                  e.jsx("span", {
                                    className:
                                      "grid size-16 place-items-center rounded-2xl bg-muted text-text-muted/60",
                                    children: e.jsx(j, {
                                      className: "size-8",
                                      "aria-hidden": !0,
                                    }),
                                  }),
                                  e.jsxs("div", {
                                    children: [
                                      e.jsx("p", {
                                        className:
                                          "text-small font-bold text-foreground",
                                        children: "سبد خرید شما خالی است",
                                      }),
                                      e.jsx("p", {
                                        className:
                                          "mt-1 text-caption text-text-muted",
                                        children:
                                          "هنوز محصولی اضافه نکرده‌اید.",
                                      }),
                                    ],
                                  }),
                                  e.jsx("a", {
                                    href: siteUrl("shop"),
                                    onClick: () => l(!1),
                                    className:
                                      "mt-1 rounded-xl bg-primary px-5 py-2.5 text-caption font-bold text-primary-foreground transition-all hover:bg-primary-hover active:scale-95",
                                    children: "شروع خرید",
                                  }),
                                ],
                              })
                            : e.jsx("ul", {
                                className: "flex flex-col gap-1",
                                children: s.items.map((t) =>
                                  e.jsxs(
                                    "li",
                                    {
                                      className:
                                        "flex gap-3 rounded-xl p-2 transition-colors hover:bg-muted/50",
                                      children: [
                                        e.jsx("a", {
                                          href: t.url,
                                          className:
                                            "shrink-0 overflow-hidden rounded-xl border border-border bg-surface",
                                          children: e.jsx("img", {
                                            src: t.image,
                                            alt: t.name,
                                            className: "size-16 object-cover",
                                          }),
                                        }),
                                        e.jsxs("div", {
                                          className: "min-w-0 flex-1",
                                          children: [
                                            e.jsx("a", {
                                              href: t.url,
                                              className:
                                                "line-clamp-2 text-caption font-medium text-foreground hover:text-primary",
                                              children: t.name,
                                            }),
                                            t.variation
                                              ? e.jsx("p", {
                                                  className:
                                                    "mt-0.5 text-[11px] text-text-muted",
                                                  children: t.variation,
                                                })
                                              : null,
                                            e.jsxs("div", {
                                              className:
                                                "mt-1.5 flex items-center justify-between gap-2",
                                              children: [
                                                e.jsxs("div", {
                                                  className:
                                                    "flex items-center gap-1 rounded-lg border border-border",
                                                  children: [
                                                    e.jsx("button", {
                                                      type: "button",
                                                      disabled: d,
                                                      onClick: () =>
                                                        f(t.key, t.qty - 1),
                                                      "aria-label":
                                                        "کاهش تعداد",
                                                      className:
                                                        "grid size-7 place-items-center text-text-secondary transition-all hover:bg-muted active:scale-90 active:bg-muted disabled:opacity-40 disabled:active:scale-100",
                                                      children:
                                                        t.qty <= 1
                                                          ? e.jsx(_, {
                                                              className:
                                                                "size-3.5",
                                                              "aria-hidden": !0,
                                                            })
                                                          : e.jsx(E, {
                                                              className:
                                                                "size-3.5",
                                                              "aria-hidden": !0,
                                                            }),
                                                    }),
                                                    e.jsx("span", {
                                                      className:
                                                        "w-5 text-center text-caption font-bold tabular-nums text-foreground",
                                                      children:
                                                        t.qty.toLocaleString(
                                                          "fa-IR",
                                                        ),
                                                    }),
                                                    e.jsx("button", {
                                                      type: "button",
                                                      disabled:
                                                        d || t.qty >= t.maxQty,
                                                      onClick: () =>
                                                        f(t.key, t.qty + 1),
                                                      "aria-label":
                                                        "افزایش تعداد",
                                                      className:
                                                        "grid size-7 place-items-center text-text-secondary transition-all hover:bg-muted active:scale-90 active:bg-muted disabled:opacity-40 disabled:active:scale-100",
                                                      children: e.jsx(M, {
                                                        className: "size-3.5",
                                                        "aria-hidden": !0,
                                                      }),
                                                    }),
                                                  ],
                                                }),
                                                e.jsx("span", {
                                                  className:
                                                    "text-caption font-bold text-foreground",
                                                  dangerouslySetInnerHTML: {
                                                    __html: t.lineTotalHtml,
                                                  },
                                                }),
                                              ],
                                            }),
                                          ],
                                        }),
                                        e.jsx("button", {
                                          type: "button",
                                          disabled: d,
                                          onClick: () => v(t.key),
                                          "aria-label": "حذف از سبد خرید",
                                          className:
                                            "grid size-7 shrink-0 place-items-center rounded-lg text-text-muted transition-all hover:bg-muted hover:text-error active:scale-90 active:bg-muted active:text-error disabled:opacity-40 disabled:active:scale-100",
                                          children: e.jsx(u, {
                                            className: "size-4",
                                            "aria-hidden": !0,
                                          }),
                                        }),
                                      ],
                                    },
                                    t.key,
                                  ),
                                ),
                              }),
                  }),
                  s.items.length > 0
                    ? e.jsxs("div", {
                        className: "border-t border-border p-4",
                        children: [
                          s.coupons.length > 0
                            ? e.jsx("ul", {
                                className: "mb-3 flex flex-col gap-1.5",
                                children: s.coupons.map((t) =>
                                  e.jsxs(
                                    "li",
                                    {
                                      className:
                                        "flex items-center justify-between gap-2 rounded-lg bg-success/10 px-3 py-2 text-caption",
                                      children: [
                                        e.jsxs("span", {
                                          className:
                                            "flex items-center gap-1.5 font-medium text-success",
                                          children: [
                                            e.jsx(q, {
                                              className: "size-3.5",
                                              "aria-hidden": !0,
                                            }),
                                            e.jsx("bdi", {
                                              dir: "ltr",
                                              children: t.code,
                                            }),
                                          ],
                                        }),
                                        e.jsxs("div", {
                                          className: "flex items-center gap-2",
                                          children: [
                                            e.jsx("span", {
                                              className: "text-text-secondary",
                                              dangerouslySetInnerHTML: {
                                                __html: t.discountHtml,
                                              },
                                            }),
                                            e.jsx("button", {
                                              type: "button",
                                              onClick: () => w(t.code),
                                              disabled: c,
                                              "aria-label": `حذف کد تخفیف ${t.code}`,
                                              className:
                                                "text-text-muted transition-colors hover:text-error disabled:opacity-40",
                                              children: e.jsx(u, {
                                                className: "size-3.5",
                                                "aria-hidden": !0,
                                              }),
                                            }),
                                          ],
                                        }),
                                      ],
                                    },
                                    t.code,
                                  ),
                                ),
                              })
                            : null,
                          S
                            ? e.jsxs(e.Fragment, {
                                children: [
                                  e.jsxs("form", {
                                    onSubmit: (t) => {
                                      t.preventDefault();
                                      const a = m.trim();
                                      a && (N(a), b(""));
                                    },
                                    className: "mb-3 flex items-center gap-2",
                                    children: [
                                      e.jsxs("div", {
                                        className: "relative flex-1",
                                        children: [
                                          e.jsx(R, {
                                            className:
                                              "pointer-events-none absolute start-3 top-1/2 size-3.5 -translate-y-1/2 text-text-muted",
                                            "aria-hidden": !0,
                                          }),
                                          e.jsx("input", {
                                            type: "text",
                                            value: m,
                                            onChange: (t) => b(t.target.value),
                                            placeholder: "کد تخفیف",
                                            disabled: c,
                                            className:
                                              "w-full rounded-lg border border-border bg-surface py-2 ps-8 pe-3 text-caption text-foreground placeholder:text-text-muted focus:border-primary focus:outline-none disabled:opacity-60",
                                          }),
                                        ],
                                      }),
                                      e.jsx("button", {
                                        type: "submit",
                                        disabled: c || !m.trim(),
                                        className:
                                          "shrink-0 rounded-lg border border-border px-3 py-2 text-caption font-medium text-text-secondary transition-colors hover:border-primary hover:text-primary disabled:opacity-40",
                                        children: "اعمال",
                                      }),
                                    ],
                                  }),
                                  h
                                    ? e.jsx("p", {
                                        className:
                                          "-mt-2 mb-3 text-[11px] text-error",
                                        children: h,
                                      })
                                    : null,
                                ],
                              })
                            : null,
                          e.jsxs("div", {
                            className:
                              "mb-1 flex items-center justify-between text-body",
                            children: [
                              e.jsx("span", {
                                className: "font-medium text-text-secondary",
                                children: "جمع کل",
                              }),
                              e.jsx("span", {
                                className: "font-bold text-foreground",
                                dangerouslySetInnerHTML: {
                                  __html: s.subtotalHtml,
                                },
                              }),
                            ],
                          }),
                          s.discountHtml
                            ? e.jsxs("div", {
                                className:
                                  "mb-3 flex items-center justify-between text-caption",
                                children: [
                                  e.jsx("span", {
                                    className: "text-text-muted",
                                    children: "تخفیف",
                                  }),
                                  e.jsx("span", {
                                    className: "font-medium text-success",
                                    dangerouslySetInnerHTML: {
                                      __html: s.discountHtml,
                                    },
                                  }),
                                ],
                              })
                            : e.jsx("div", { className: "mb-3" }),
                          e.jsx("a", {
                            href: s.cartUrl,
                            className:
                              "flex h-12 items-center justify-center rounded-xl bg-primary text-button font-medium text-primary-foreground transition-colors hover:bg-primary-hover",
                            children: "مشاهده سبد خرید",
                          }),
                        ],
                      })
                    : null,
                ],
              }),
            ],
          }),
          document.body,
        )
      : null
  );
}
export { J as default };
