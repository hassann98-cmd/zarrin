import { siteUrl } from "../lib/api.js";
import { j as e } from "../lib/jsx.js";
import { c as u, r } from "../lib/icons.js";
import { c as l } from "../lib/utils.js";
import { B as _, P as D, S as $ } from "../components/product-card.js";
import { B as p } from "../components/button.js";
import { H as A } from "../icons/heart.js";
import { C as w, S as L } from "../icons/shield-check.js";
import { C as k } from "../icons/chevron-down.js";
import { M as U, P as B } from "../icons/plus.js";
import { S as z } from "../icons/shopping-cart.js";
import { T as E } from "../icons/truck.js";
import { S as V } from "../icons/send.js";
/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const F = u("Share2", [
  ["circle", { cx: "18", cy: "5", r: "3", key: "gq8acd" }],
  ["circle", { cx: "6", cy: "12", r: "3", key: "w7nqdw" }],
  ["circle", { cx: "18", cy: "19", r: "3", key: "1xt0gg" }],
  [
    "line",
    { x1: "8.59", x2: "15.42", y1: "13.51", y2: "17.49", key: "47mynk" },
  ],
  ["line", { x1: "15.41", x2: "8.59", y1: "6.51", y2: "10.49", key: "1n3mei" }],
]);
/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Z = u("ThumbsDown", [
  ["path", { d: "M17 14V2", key: "8ymqnk" }],
  [
    "path",
    {
      d: "M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22a3.13 3.13 0 0 1-3-3.88Z",
      key: "m61m77",
    },
  ],
]);
/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const S = u("ThumbsUp", [
  ["path", { d: "M7 10v12", key: "1qc93n" }],
  [
    "path",
    {
      d: "M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2a3.13 3.13 0 0 1 3 3.88Z",
      key: "emmmcr",
    },
  ],
]);
/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const G = u("Undo2", [
  ["path", { d: "M9 14 4 9l5-5", key: "102s5s" }],
  [
    "path",
    {
      d: "M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11",
      key: "f3b9sd",
    },
  ],
]);
function n(a) {
  const i = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800"><rect width="800" height="800" fill="hsl(${a} 40% 88%)"/><rect x="280" y="280" width="240" height="240" rx="24" fill="hsl(${a} 35% 70%)"/></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(i)}`;
}
const C = [340, 9, 61, 220].map((a) => n(a)),
  I = [
    { name: "سرمه‌ای", hex: "#1c2541" },
    { name: "کرم", hex: "#e9dfc7" },
    { name: "طوسی", hex: "#9a9a9a" },
  ],
  O = [
    {
      icon: G,
      title: "۷ روز ضمانت بازگشت کالا",
      subtitle: "به‌جز حوله، ملحفه، پتو",
    },
    {
      icon: E,
      title: "ارسال با پست/تیپاکس/چاپار",
      subtitle: "با کد رهگیری پیامکی",
    },
    { icon: L, title: "پرداخت امن", subtitle: "زرین‌پال یا کارت‌به‌کارت" },
  ],
  Q = [
    { label: "جنس پارچه", value: "ساتن درجه‌یک، ۱۰۰٪ پنبه" },
    { label: "تعداد پارچه", value: "۱۲ عدد" },
  ],
  W = [
    {
      title: "ابعاد و جنس",
      rows: [
        { label: "ابعاد ست (روتختی دونفره)", value: "۲۴۰ × ۲۲۰ سانتی‌متر" },
        { label: "جنس پارچه", value: "ساتن درجه‌یک، ۱۰۰٪ پنبه" },
        { label: "تعداد پارچه", value: "۱۲ عدد" },
        { label: "وزن تقریبی", value: "۳.۲ کیلوگرم" },
      ],
    },
    {
      title: "نگهداری و کیفیت",
      rows: [
        { label: "دستور شست‌وشو", value: "ماشینی، حداکثر ۳۰ درجه" },
        { label: "رنگ‌ثباتی", value: "بدون ریزش رنگ پس از شست‌وشو" },
        { label: "کشور تولید", value: "ایران" },
        { label: "ضمانت بازگشت", value: "۷ روزه، طبق قوانین فروشگاه" },
      ],
    },
  ],
  J = [
    { stars: 5, pct: 78 },
    { stars: 4, pct: 14 },
    { stars: 3, pct: 4 },
    { stars: 2, pct: 2 },
    { stars: 1, pct: 2 },
  ],
  K = [
    {
      id: "rv1",
      name: "نگار.ص",
      date: "۱۴۰۵/۰۵/۱۲",
      rating: 5,
      text: "کیفیت پارچه واقعاً عالیه و دقیقاً مثل عکس‌ها بود. بسته‌بندی هم خیلی مرتب رسید.",
      helpful: 24,
    },
    {
      id: "rv2",
      name: "امیر.ک",
      date: "۱۴۰۵/۰۴/۳۰",
      rating: 4,
      text: "رنگش کمی از تصویر روشن‌تره ولی در کل راضی‌ام. ارسال هم سریع بود.",
      helpful: 9,
    },
    {
      id: "rv3",
      name: "زهرا.م",
      date: "۱۴۰۵/۰۴/۱۸",
      rating: 5,
      text: "برای جهیزیه خریدم، از نظر دوخت و پارچه هیچ مشکلی نداشت. پیشنهاد می‌کنم.",
      helpful: 15,
    },
  ],
  X = [
    { id: "newest", label: "جدیدترین" },
    { id: "top", label: "بیشترین امتیاز" },
    { id: "low", label: "کمترین امتیاز" },
  ],
  Y = [
    {
      id: "r1",
      href: "#",
      image: n(186),
      name: "سرویس ۱۲ پارچه رومیزی گلدار طرح سلطنتی",
      price: 485e4,
      salePrice: 399e4,
      rating: 4.6,
      reviewCount: 128,
      stock: "in_stock",
    },
    {
      id: "r2",
      href: "#",
      image: n(9),
      name: "ست حوله ۶ تکه پنبه‌ای رنگ کرم",
      price: 125e4,
      salePrice: 99e4,
      rating: 4.9,
      reviewCount: 302,
      stock: "in_stock",
    },
    {
      id: "r3",
      href: "#",
      image: n(61),
      name: "روتختی دونفره طرح مخمل‌کاری‌شده",
      price: 34e5,
      rating: 3.8,
      reviewCount: 12,
      stock: "low_stock",
    },
    {
      id: "r4",
      href: "#",
      image: n(280),
      name: "پتو دونفره پشمی طرح‌دار",
      price: 21e5,
      rating: 4.2,
      reviewCount: 54,
      stock: "in_stock",
    },
  ];
function R(a) {
  return `${a.toLocaleString("fa-IR")} تومان`;
}
function b({ rating: a, size: i = "size-4" }) {
  return e.jsx("div", {
    className: "flex",
    "aria-hidden": !0,
    children: Array.from({ length: 5 }).map((d, c) =>
      e.jsx(
        $,
        {
          className: l(
            i,
            c < Math.round(a) ? "fill-accent text-accent" : "text-border",
          ),
        },
        c,
      ),
    ),
  });
}
function me() {
  const [a, i] = r.useState(0),
    [d, c] = r.useState(0),
    [j, N] = r.useState(1),
    [v, M] = r.useState(!1),
    [f, P] = r.useState(!1),
    [x, q] = r.useState("newest"),
    o = 485e4,
    m = 399e4,
    H = Math.round(100 - (m / o) * 100),
    h = 4.6,
    y = 128,
    T = [...K].sort((s, t) =>
      x === "top" ? t.rating - s.rating : x === "low" ? s.rating - t.rating : 0,
    );
  return e.jsxs("div", {
    className: "mx-auto w-full max-w-[1320px] px-3 md:px-4 py-6",
    children: [
      e.jsxs("nav", {
        "aria-label": "مسیر صفحه",
        className: "flex items-center gap-2 text-caption text-text-muted",
        children: [
          e.jsx("a", {
            href: "/",
            className: "hover:text-foreground",
            children: "صفحه اصلی",
          }),
          e.jsx("span", { children: "/" }),
          e.jsx("a", {
            href: siteUrl("shop"),
            className: "hover:text-foreground",
            children: "سرویس خواب",
          }),
          e.jsx("span", { children: "/" }),
          e.jsx("span", {
            className: "text-text-secondary",
            children: "سرویس ۱۲ پارچه رومیزی گلدار طرح سلطنتی",
          }),
        ],
      }),
      e.jsxs("div", {
        className: "mt-4 grid gap-5 lg:grid-cols-[26rem_1fr_19rem]",
        children: [
          e.jsxs("div", {
            className: "relative lg:sticky lg:top-24 lg:self-start",
            children: [
              e.jsxs("div", {
                className:
                  "absolute end-0 top-0 z-10 flex gap-2 sm:end-3 sm:top-3",
                children: [
                  e.jsx("button", {
                    type: "button",
                    onClick: () => M((s) => !s),
                    "aria-pressed": v,
                    "aria-label": "افزودن به علاقه‌مندی‌ها",
                    className:
                      "flex size-9 items-center justify-center rounded-full border border-border bg-surface/90 text-text-secondary shadow-sm backdrop-blur hover:text-accent-hover",
                    children: e.jsx(A, {
                      className: l(
                        "size-4",
                        v && "fill-accent-hover text-accent-hover",
                      ),
                      "aria-hidden": !0,
                    }),
                  }),
                  e.jsx("button", {
                    type: "button",
                    "aria-label": "اشتراک‌گذاری محصول",
                    className:
                      "flex size-9 items-center justify-center rounded-full border border-border bg-surface/90 text-text-secondary shadow-sm backdrop-blur hover:text-foreground",
                    children: e.jsx(F, {
                      className: "size-4",
                      "aria-hidden": !0,
                    }),
                  }),
                ],
              }),
              e.jsx("div", {
                className:
                  "aspect-square w-full overflow-hidden rounded-xl bg-muted",
                children: e.jsx("img", {
                  src: C[a],
                  alt: "سرویس ۱۲ پارچه رومیزی گلدار طرح سلطنتی",
                  loading: "eager",
                  className: "size-full object-cover",
                }),
              }),
              e.jsx("div", {
                className: "mt-3 flex gap-2 overflow-x-auto",
                children: C.map((s, t) =>
                  e.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => i(t),
                      "aria-label": `تصویر ${t + 1}`,
                      "aria-current": a === t,
                      className: l(
                        "size-16 shrink-0 overflow-hidden rounded-lg border-2 transition-colors",
                        a === t ? "border-primary" : "border-border",
                      ),
                      children: e.jsx("img", {
                        src: s,
                        alt: "",
                        className: "size-full object-cover",
                      }),
                    },
                    t,
                  ),
                ),
              }),
            ],
          }),
          e.jsxs("div", {
            children: [
              e.jsx("span", {
                className: "text-[12px] font-medium text-text-muted",
                children: "زرین",
              }),
              e.jsx("h1", {
                className:
                  "mt-1.5 text-lg font-bold leading-7 text-foreground sm:text-[20px] sm:leading-8",
                children: "سرویس ۱۲ پارچه رومیزی گلدار طرح سلطنتی",
              }),
              e.jsxs("div", {
                className:
                  "mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 border-b border-border pb-4",
                children: [
                  e.jsxs("a", {
                    href: "#reviews",
                    className:
                      "flex items-center gap-1.5 rounded-lg px-1 py-0.5 hover:bg-muted",
                    children: [
                      e.jsx(b, { rating: h, size: "size-[15px]" }),
                      e.jsx("span", {
                        className: "text-[13px] font-bold text-foreground",
                        children: h.toLocaleString("fa-IR"),
                      }),
                      e.jsxs("span", {
                        className: "text-[12px] text-text-muted",
                        children: ["(", y.toLocaleString("fa-IR"), " دیدگاه)"],
                      }),
                    ],
                  }),
                  e.jsx("span", {
                    className: "h-3.5 w-px bg-border",
                    "aria-hidden": !0,
                  }),
                  e.jsxs("a", {
                    href: "#qa",
                    className:
                      "flex items-center gap-1.5 text-[12px] text-text-secondary hover:text-primary",
                    children: [
                      e.jsx(w, { className: "size-4", "aria-hidden": !0 }),
                      "پرسش و پاسخ",
                    ],
                  }),
                ],
              }),
              e.jsxs(_, {
                variant: "new",
                className: "mt-4 w-fit gap-1",
                children: [
                  e.jsx(L, { className: "size-3.5", "aria-hidden": !0 }),
                  "گارانتی اصالت کالا",
                ],
              }),
              e.jsxs("div", {
                className: "mt-4",
                children: [
                  e.jsxs("div", {
                    className: "flex items-baseline gap-2",
                    children: [
                      e.jsx("h2", {
                        className: "text-[13px] font-bold text-foreground",
                        children: "رنگ:",
                      }),
                      e.jsx("span", {
                        className: "text-[13px] text-text-secondary",
                        children: I[d].name,
                      }),
                    ],
                  }),
                  e.jsx("div", {
                    className: "mt-2 flex flex-wrap items-center gap-2",
                    children: I.map((s, t) =>
                      e.jsxs(
                        "button",
                        {
                          type: "button",
                          title: s.name,
                          onClick: () => c(t),
                          "aria-pressed": d === t,
                          className:
                            "relative grid size-9 place-items-center rounded-full outline-none transition-transform hover:scale-110 active:scale-95",
                          children: [
                            e.jsx("span", {
                              className:
                                "size-7 rounded-full border border-black/10 shadow-inner",
                              style: { background: s.hex },
                            }),
                            d === t
                              ? e.jsx("span", {
                                  className:
                                    "pointer-events-none absolute inset-0 rounded-full ring-2 ring-primary ring-offset-2 ring-offset-surface",
                                })
                              : null,
                          ],
                        },
                        s.name,
                      ),
                    ),
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "mt-4 rounded-xl bg-muted/60 p-4",
                children: [
                  e.jsx("p", {
                    className: "text-label text-foreground",
                    children: "ویژگی‌های کلیدی",
                  }),
                  e.jsx("ul", {
                    className: "mt-2 flex flex-col gap-1",
                    children: Q.map((s) =>
                      e.jsxs(
                        "li",
                        {
                          className: "text-small text-text-secondary",
                          children: [
                            e.jsxs("span", {
                              className: "text-foreground",
                              children: [s.label, ":"],
                            }),
                            " ",
                            s.value,
                          ],
                        },
                        s.label,
                      ),
                    ),
                  }),
                  e.jsxs("a", {
                    href: "#specs",
                    className:
                      "mt-3 flex w-fit items-center gap-1 text-small text-primary hover:text-primary-hover",
                    children: [
                      "مشاهده مشخصات کامل",
                      e.jsx(k, { className: "size-3.5", "aria-hidden": !0 }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          e.jsx("div", {
            className: "lg:sticky lg:top-24 lg:self-start",
            children: e.jsxs("div", {
              className: "rounded-2xl border border-border bg-muted/40 p-3.5",
              children: [
                e.jsxs("div", {
                  className: "flex items-center justify-between gap-2",
                  children: [
                    e.jsxs("span", {
                      dir: "ltr",
                      className:
                        "inline-flex items-center gap-0.5 rounded-full bg-accent-hover px-2 py-0.5 text-[11px] font-bold text-accent-foreground",
                      children: [H, "٪"],
                    }),
                    e.jsx("span", {
                      className: "text-[12px] text-text-muted line-through",
                      children: o.toLocaleString("fa-IR"),
                    }),
                  ],
                }),
                e.jsxs("div", {
                  className: "mt-1.5 flex items-baseline justify-end gap-1",
                  children: [
                    e.jsx("span", {
                      className:
                        "text-xl font-bold text-foreground sm:text-2xl",
                      children: m.toLocaleString("fa-IR"),
                    }),
                    e.jsx("span", {
                      className: "text-[11px] text-text-secondary",
                      children: "تومان",
                    }),
                  ],
                }),
                e.jsxs("p", {
                  className:
                    "mt-1 text-end text-[11px] font-medium text-accent-hover",
                  children: [
                    (o - m).toLocaleString("fa-IR"),
                    " تومان سود شما از این خرید",
                  ],
                }),
                e.jsxs("div", {
                  className:
                    "mt-3 flex items-center justify-between gap-2 rounded-xl bg-surface px-2 py-1.5",
                  children: [
                    e.jsx("span", {
                      className: "ps-1 text-[12px] text-text-muted",
                      children: "تعداد",
                    }),
                    e.jsxs("div", {
                      className: "flex items-center gap-1",
                      children: [
                        e.jsx("button", {
                          type: "button",
                          onClick: () => N((s) => Math.max(1, s - 1)),
                          "aria-label": "کاهش تعداد",
                          className:
                            "grid size-7 place-items-center rounded-lg text-text-secondary transition-colors hover:bg-muted disabled:opacity-30",
                          disabled: j <= 1,
                          children: e.jsx(U, {
                            className: "size-3.5",
                            "aria-hidden": !0,
                          }),
                        }),
                        e.jsx("span", {
                          className:
                            "w-7 text-center text-[13px] font-bold tabular-nums text-foreground",
                          children: j.toLocaleString("fa-IR"),
                        }),
                        e.jsx("button", {
                          type: "button",
                          onClick: () => N((s) => s + 1),
                          "aria-label": "افزایش تعداد",
                          className:
                            "grid size-7 place-items-center rounded-lg text-text-secondary transition-colors hover:bg-muted",
                          children: e.jsx(B, {
                            className: "size-3.5",
                            "aria-hidden": !0,
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
                e.jsxs(p, {
                  variant: "primary",
                  className:
                    "mt-3 h-11 w-full gap-2 rounded-xl text-[14px] font-bold",
                  children: [
                    e.jsx(z, { className: "size-[18px]", "aria-hidden": !0 }),
                    "افزودن به سبد خرید",
                  ],
                }),
                e.jsx("ul", {
                  className:
                    "mt-3.5 flex flex-col gap-2.5 border-t border-border pt-3",
                  children: O.map(({ icon: s, title: t, subtitle: g }) =>
                    e.jsxs(
                      "li",
                      {
                        className: "flex items-start gap-2.5",
                        children: [
                          e.jsx(s, {
                            className: "mt-0.5 size-4 shrink-0 text-text-muted",
                            "aria-hidden": !0,
                          }),
                          e.jsxs("div", {
                            className: "min-w-0",
                            children: [
                              e.jsx("p", {
                                className:
                                  "text-[12px] font-medium text-foreground",
                                children: t,
                              }),
                              e.jsx("p", {
                                className: "text-[11px] text-text-muted",
                                children: g,
                              }),
                            ],
                          }),
                        ],
                      },
                      t,
                    ),
                  ),
                }),
              ],
            }),
          }),
        ],
      }),
      e.jsxs("div", {
        className: "mt-12 border-t border-border pt-8",
        children: [
          e.jsxs("h2", {
            className: "flex items-center gap-2 text-h2 text-foreground",
            children: [
              e.jsx("span", {
                className: "h-5 w-1 rounded-full bg-primary",
                "aria-hidden": !0,
              }),
              "معرفی محصول",
            ],
          }),
          e.jsxs("div", {
            className: "mt-4 rounded-xl border border-border p-5",
            children: [
              e.jsx("h3", {
                className: "text-label text-foreground",
                children: "معرفی کلی",
              }),
              e.jsx("p", {
                className:
                  "mt-2 max-w-3xl text-body leading-8 text-text-secondary",
                children:
                  "سرویس ۱۲ پارچه رومیزی با طرح گلدار سلطنتی، از پارچه‌ی درجه‌یک با دوخت مقاوم تهیه شده و مناسب جهیزیه عروس و استفاده‌ی روزمره است. شست‌وشو در دمای پایین توصیه می‌شود.",
              }),
              f
                ? e.jsxs("div", {
                    className: "mt-4 border-t border-border pt-4",
                    children: [
                      e.jsx("h3", {
                        className: "text-label text-foreground",
                        children: "طراحی و ظاهر",
                      }),
                      e.jsx("p", {
                        className:
                          "mt-2 max-w-3xl text-body leading-8 text-text-secondary",
                        children:
                          "طرح گلدار این ست با رنگ‌بندی ملایم طراحی شده تا هم با دکوراسیون کلاسیک و هم مدرن هماهنگ باشد. دوخت لبه‌ها با نخ مقاوم انجام شده تا پس از شست‌وشوهای مکرر شکل خود را حفظ کند.",
                      }),
                    ],
                  })
                : null,
              e.jsxs("button", {
                type: "button",
                onClick: () => P((s) => !s),
                className:
                  "mt-4 flex items-center gap-1 text-small text-primary hover:text-primary-hover",
                children: [
                  f ? "مشاهده کمتر" : "بیشتر بخوانید",
                  e.jsx(k, {
                    className: l(
                      "size-3.5 transition-transform",
                      f && "rotate-180",
                    ),
                    "aria-hidden": !0,
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        id: "specs",
        className: "mt-10 scroll-mt-24",
        children: [
          e.jsxs("h2", {
            className: "flex items-center gap-2 text-h2 text-foreground",
            children: [
              e.jsx("span", {
                className: "h-5 w-1 rounded-full bg-primary",
                "aria-hidden": !0,
              }),
              "مشخصات فنی",
            ],
          }),
          e.jsx("div", {
            className: "mt-4 grid gap-4 sm:grid-cols-2",
            children: W.map((s) =>
              e.jsxs(
                "div",
                {
                  className: "overflow-hidden rounded-xl border border-border",
                  children: [
                    e.jsx("div", {
                      className:
                        "border-b border-border bg-muted/60 px-4 py-2.5 text-label text-foreground",
                      children: s.title,
                    }),
                    e.jsx("dl", {
                      children: s.rows.map((t, g) =>
                        e.jsxs(
                          "div",
                          {
                            className: l(
                              "flex items-center justify-between gap-4 px-4 py-3 text-small",
                              g % 2 === 1 && "bg-muted/30",
                            ),
                            children: [
                              e.jsx("dt", {
                                className: "text-text-muted",
                                children: t.label,
                              }),
                              e.jsx("dd", {
                                className: "text-foreground",
                                children: t.value,
                              }),
                            ],
                          },
                          t.label,
                        ),
                      ),
                    }),
                  ],
                },
                s.title,
              ),
            ),
          }),
        ],
      }),
      e.jsxs("div", {
        id: "reviews",
        className: "mt-10 scroll-mt-24",
        children: [
          e.jsxs("h2", {
            className: "flex items-center gap-2 text-h2 text-foreground",
            children: [
              e.jsx("span", {
                className: "h-5 w-1 rounded-full bg-primary",
                "aria-hidden": !0,
              }),
              "دیدگاه کاربران",
            ],
          }),
          e.jsxs("div", {
            className: "mt-4 flex flex-col gap-6 lg:flex-row",
            children: [
              e.jsxs("div", {
                className:
                  "flex shrink-0 flex-col gap-4 rounded-xl border border-border p-5 lg:w-72",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center gap-4",
                    children: [
                      e.jsxs("div", {
                        children: [
                          e.jsx("p", {
                            className:
                              "text-display leading-none text-foreground",
                            children: h.toLocaleString("fa-IR"),
                          }),
                          e.jsx(b, { rating: h, size: "size-4" }),
                          e.jsxs("p", {
                            className: "mt-1 text-caption text-text-muted",
                            children: [
                              "از ",
                              y.toLocaleString("fa-IR"),
                              " دیدگاه",
                            ],
                          }),
                        ],
                      }),
                      e.jsx("div", {
                        className: "flex flex-1 flex-col gap-1",
                        children: J.map((s) =>
                          e.jsxs(
                            "div",
                            {
                              className:
                                "flex items-center gap-2 text-caption text-text-muted",
                              children: [
                                e.jsx("span", {
                                  className: "w-3 shrink-0",
                                  children: s.stars.toLocaleString("fa-IR"),
                                }),
                                e.jsx("div", {
                                  className:
                                    "h-1.5 flex-1 overflow-hidden rounded-full bg-muted",
                                  children: e.jsx("div", {
                                    className: "h-full rounded-full bg-accent",
                                    style: { width: `${s.pct}%` },
                                  }),
                                }),
                                e.jsxs("span", {
                                  className: "w-8 shrink-0 text-start",
                                  children: [
                                    s.pct.toLocaleString("fa-IR"),
                                    "٪",
                                  ],
                                }),
                              ],
                            },
                            s.stars,
                          ),
                        ),
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className:
                      "flex items-center gap-2 rounded-lg bg-success/10 px-3 py-2 text-caption text-success",
                    children: [
                      e.jsx(S, {
                        className: "size-3.5 shrink-0",
                        "aria-hidden": !0,
                      }),
                      "۹۶٪ از خریداران این کالا را پیشنهاد کرده‌اند",
                    ],
                  }),
                  e.jsx(p, {
                    variant: "outline",
                    size: "md",
                    children: "ثبت دیدگاه",
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "flex-1",
                children: [
                  e.jsx("div", {
                    className: "flex flex-wrap gap-2",
                    children: X.map((s) =>
                      e.jsx(
                        "button",
                        {
                          type: "button",
                          onClick: () => q(s.id),
                          "aria-pressed": x === s.id,
                          className: l(
                            "rounded-full border px-3 py-1.5 text-caption transition-colors",
                            x === s.id
                              ? "border-primary bg-primary/5 text-primary"
                              : "border-border text-text-secondary hover:border-primary/50",
                          ),
                          children: s.label,
                        },
                        s.id,
                      ),
                    ),
                  }),
                  e.jsx("div", {
                    className: "mt-4 flex flex-col divide-y divide-border",
                    children: T.map((s) =>
                      e.jsxs(
                        "div",
                        {
                          className: "flex flex-col gap-2 py-4 first:pt-0",
                          children: [
                            e.jsxs("div", {
                              className:
                                "flex items-center justify-between gap-2",
                              children: [
                                e.jsxs("div", {
                                  className: "flex items-center gap-2",
                                  children: [
                                    e.jsx("span", {
                                      className:
                                        "text-small font-medium text-foreground",
                                      children: s.name,
                                    }),
                                    e.jsx(b, {
                                      rating: s.rating,
                                      size: "size-3.5",
                                    }),
                                  ],
                                }),
                                e.jsx("span", {
                                  className: "text-caption text-text-muted",
                                  children: s.date,
                                }),
                              ],
                            }),
                            e.jsx("p", {
                              className:
                                "text-body leading-7 text-text-secondary",
                              children: s.text,
                            }),
                            e.jsxs("div", {
                              className:
                                "flex items-center gap-4 text-caption text-text-muted",
                              children: [
                                e.jsx("span", {
                                  children: "آیا این دیدگاه مفید بود؟",
                                }),
                                e.jsxs("button", {
                                  type: "button",
                                  className:
                                    "flex items-center gap-1 hover:text-foreground",
                                  children: [
                                    e.jsx(S, {
                                      className: "size-3.5",
                                      "aria-hidden": !0,
                                    }),
                                    s.helpful.toLocaleString("fa-IR"),
                                  ],
                                }),
                                e.jsx("button", {
                                  type: "button",
                                  className:
                                    "flex items-center gap-1 hover:text-foreground",
                                  children: e.jsx(Z, {
                                    className: "size-3.5",
                                    "aria-hidden": !0,
                                  }),
                                }),
                              ],
                            }),
                          ],
                        },
                        s.id,
                      ),
                    ),
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        id: "qa",
        className: "mt-10 scroll-mt-24",
        children: [
          e.jsxs("h2", {
            className: "flex items-center gap-2 text-h2 text-foreground",
            children: [
              e.jsx("span", {
                className: "h-5 w-1 rounded-full bg-primary",
                "aria-hidden": !0,
              }),
              "پرسش و پاسخ",
            ],
          }),
          e.jsxs("div", {
            className:
              "mt-4 flex flex-col items-start gap-4 rounded-xl border border-border p-5 sm:flex-row sm:items-center sm:justify-between",
            children: [
              e.jsxs("div", {
                className: "flex items-start gap-3",
                children: [
                  e.jsx(w, {
                    className: "mt-0.5 size-6 shrink-0 text-primary",
                    "aria-hidden": !0,
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx("p", {
                        className: "text-body font-medium text-foreground",
                        children: "پرسشی درباره این کالا دارید؟",
                      }),
                      e.jsx("p", {
                        className: "text-small text-text-muted",
                        children:
                          "سوال خود را بپرسید تا فروشنده و سایر خریداران پاسخ دهند.",
                      }),
                    ],
                  }),
                ],
              }),
              e.jsxs(p, {
                size: "md",
                className: "w-full gap-2 sm:w-auto",
                children: [
                  e.jsx(V, { className: "size-4", "aria-hidden": !0 }),
                  "ثبت پرسش",
                ],
              }),
            ],
          }),
          e.jsx("p", {
            className: "mt-4 text-center text-small text-text-muted",
            children: "هنوز پرسشی ثبت نشده است. اولین نفر باشید!",
          }),
        ],
      }),
      e.jsxs("div", {
        className: "mt-10",
        children: [
          e.jsx("h2", {
            className: "text-h2 text-foreground",
            children: "محصولات مرتبط",
          }),
          e.jsx("div", {
            className:
              "mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4",
            children: Y.map((s) => e.jsx(D, { product: s }, s.id)),
          }),
        ],
      }),
      e.jsxs("div", {
        className:
          "fixed inset-x-0 bottom-16 z-30 flex items-center gap-3 border-t border-border bg-surface p-3 shadow-lg md:hidden",
        children: [
          e.jsxs("div", {
            className: "flex flex-col",
            children: [
              e.jsx("span", {
                className: "text-price text-foreground",
                children: R(m),
              }),
              e.jsx("span", {
                className: "text-caption text-text-muted line-through",
                children: R(o),
              }),
            ],
          }),
          e.jsxs(p, {
            variant: "primary",
            size: "lg",
            className: "flex-1 gap-2",
            children: [
              e.jsx(z, { className: "size-5", "aria-hidden": !0 }),
              "افزودن به سبد خرید",
            ],
          }),
        ],
      }),
      e.jsx("div", { className: "h-20 md:hidden", "aria-hidden": "true" }),
    ],
  });
}
export { me as default };
