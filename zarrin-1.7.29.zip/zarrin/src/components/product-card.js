import { j as e } from "../lib/jsx.js";
import { c as N, r as q } from "../lib/icons.js";
import { c as n } from "../lib/utils.js";
import { c as I, B as R } from "./button.js";
import { H as $ } from "../icons/heart.js";
import { S as B } from "../icons/shopping-cart.js";
/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const P = N("Layers", [
  [
    "path",
    {
      d: "M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",
      key: "zw3jo",
    },
  ],
  [
    "path",
    {
      d: "M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",
      key: "1wduqc",
    },
  ],
  [
    "path",
    {
      d: "M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",
      key: "kqbvx6",
    },
  ],
]);
/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const V = N("Star", [
    [
      "path",
      {
        d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",
        key: "r04s7s",
      },
    ],
  ]),
  _ = I(
    "inline-flex items-center rounded-full px-2.5 py-0.5 text-caption font-medium",
    {
      variants: {
        variant: {
          sale: "bg-accent-hover text-accent-foreground",
          new: "bg-primary text-primary-foreground",
          "out-of-stock": "bg-muted text-muted-foreground",
          neutral: "bg-secondary text-secondary-foreground",
        },
      },
      defaultVariants: { variant: "neutral" },
    },
  );
function p({ className: t, variant: x, ...r }) {
  return e.jsx("span", { className: n(_({ variant: x, className: t })), ...r });
}
function y(t) {
  return `${t.toLocaleString("fa-IR")} تومان`;
}
function G({ product: t, className: x, onAddToCart: r, onToggleWishlist: u }) {
  const [f, w] = q.useState(!1),
    {
      href: i,
      image: k,
      name: b,
      brand: j,
      price: o,
      salePrice: c,
      rating: d,
      reviewCount: g,
      stock: z,
      isNew: S,
      isVariable: v,
      gallery: s,
    } = t,
    m = typeof c == "number" && c < o,
    L = m ? Math.round(100 - (c / o) * 100) : 0,
    h = z === "out_of_stock",
    M = () => {
      (w((a) => !a), u == null || u(t));
    };
  return e.jsxs("div", {
    className: n(
      "group relative flex flex-col overflow-hidden rounded-lg border border-border bg-surface transition-shadow hover:shadow-md",
      x,
    ),
    children: [
      e.jsxs("a", {
        href: i,
        className: "relative block aspect-square overflow-hidden bg-muted",
        children: [
          e.jsx("img", {
            src: k,
            alt: b,
            loading: "lazy",
            className: n(
              "size-full object-cover transition-transform duration-300 group-hover:scale-105",
              h && "opacity-60 grayscale",
            ),
          }),
          e.jsxs("div", {
            className: "absolute top-2 start-2 flex flex-col gap-1",
            children: [
              m ? e.jsxs(p, { variant: "sale", children: [L, "%-"] }) : null,
              S ? e.jsx(p, { variant: "new", children: "جدید" }) : null,
              h
                ? e.jsx(p, { variant: "out-of-stock", children: "ناموجود" })
                : null,
            ],
          }),
          e.jsx("button", {
            type: "button",
            onClick: (a) => {
              (a.preventDefault(), M());
            },
            "aria-pressed": f,
            "aria-label": f
              ? "حذف از علاقه‌مندی‌ها"
              : "افزودن به علاقه‌مندی‌ها",
            className:
              "absolute end-2 top-2 flex size-8 items-center justify-center rounded-full bg-surface/90 text-text-secondary shadow-sm transition-colors hover:text-accent-hover",
            children: e.jsx($, {
              className: n(
                "size-4",
                f && "fill-accent-hover text-accent-hover",
              ),
              "aria-hidden": !0,
            }),
          }),
          s && s.length > 0
            ? e.jsxs("div", {
                className:
                  "absolute inset-x-1.5 bottom-1.5 flex gap-1 opacity-0 transition-opacity duration-200 group-hover:opacity-100",
                children: [
                  s.slice(0, 3).map((a, l) =>
                    e.jsx(
                      "a",
                      {
                        href: a.href ?? i,
                        "aria-label": a.label ?? `تصویر ${l + 1}`,
                        className:
                          "aspect-square flex-1 overflow-hidden rounded-md border-2 border-surface shadow-sm transition-[border-color] hover:border-primary",
                        children: e.jsx("img", {
                          src: a.image,
                          alt: "",
                          loading: "lazy",
                          className: "size-full object-cover",
                        }),
                      },
                      a.href ?? l,
                    ),
                  ),
                  s.length > 3
                    ? e.jsxs("a", {
                        href: i,
                        "aria-label": `${s.length - 3} تصویر دیگر`,
                        className:
                          "relative aspect-square flex-1 overflow-hidden rounded-md border-2 border-surface shadow-sm",
                        children: [
                          e.jsx("img", {
                            src: s[3].image,
                            alt: "",
                            loading: "lazy",
                            className: "size-full object-cover",
                          }),
                          e.jsxs("span", {
                            className:
                              "absolute inset-0 flex items-center justify-center bg-black/50 text-caption font-bold text-white",
                            children: [
                              "+",
                              (s.length - 3).toLocaleString("fa-IR"),
                            ],
                          }),
                        ],
                      })
                    : null,
                ],
              })
            : null,
        ],
      }),
      e.jsxs("div", {
        className: "flex flex-1 flex-col gap-1.5 p-3",
        children: [
          j
            ? e.jsx("span", {
                className: "text-caption text-text-muted",
                children: j,
              })
            : null,
          e.jsx("a", {
            href: i,
            className:
              "line-clamp-2 break-words text-small font-medium text-foreground hover:text-primary",
            children: b,
          }),
          typeof d == "number"
            ? e.jsxs("div", {
                className:
                  "flex items-center gap-1 text-caption text-text-muted",
                children: [
                  e.jsx("div", {
                    className: "flex",
                    "aria-hidden": !0,
                    children: Array.from({ length: 5 }).map((a, l) =>
                      e.jsx(
                        V,
                        {
                          className: n(
                            "size-3.5",
                            l < Math.round(d)
                              ? "fill-accent text-accent"
                              : "text-border",
                          ),
                        },
                        l,
                      ),
                    ),
                  }),
                  e.jsx("span", {
                    "aria-label": `امتیاز ${d} از ۵`,
                    children: g
                      ? `(${g.toLocaleString("fa-IR")})`
                      : d.toLocaleString("fa-IR"),
                  }),
                ],
              })
            : null,
          e.jsxs("div", {
            className: "mt-auto flex items-end justify-between gap-2 pt-1",
            children: [
              e.jsxs("div", {
                className: "flex flex-col",
                children: [
                  v
                    ? e.jsxs("span", {
                        className:
                          "flex items-center gap-1 text-caption text-text-muted",
                        children: [
                          e.jsx(P, {
                            className: "size-3.5",
                            "aria-hidden": !0,
                          }),
                          "چند نوع موجود",
                        ],
                      })
                    : null,
                  e.jsxs("span", {
                    className: "flex items-baseline gap-2",
                    children: [
                      e.jsx("span", {
                        className: "text-price text-foreground",
                        children: y(m ? c : o),
                      }),
                      m
                        ? e.jsx("span", {
                            className:
                              "text-caption text-text-muted line-through",
                            children: y(o),
                          })
                        : null,
                    ],
                  }),
                ],
              }),
              e.jsx(R, {
                size: "sm",
                variant: "primary",
                disabled: h,
                "aria-label": v ? "انتخاب گزینه‌ها" : "افزودن به سبد خرید",
                onClick: () => (r == null ? void 0 : r(t)),
                children: e.jsx(B, { className: "size-4", "aria-hidden": !0 }),
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
export { p as B, G as P, V as S };
