<?php
/**
 * Plugin Name: رونق – بازاریابی و پیامک هوشمند ووکامرس (نسخهٔ توسعه)
 * Description: افزونهٔ بازاریابی و رشد فروش ووکامرس: سبد خرید رها شده، مشتریان غیرفعال، خوش‌آمدگویی، پیام پس از خرید، درخواست نظر با تأیید مدیر، نظرسنجی، کمپین‌ها، کیف پول مشتری و گزارش‌های تحلیلی — با اتصال به ملی‌پیامک، کاوه‌نگار، قاصدک، آی‌پی‌پنل و sms.ir.
 * Version:     3.9.0
 * Author:      تیم رونق
 * Text Domain: rounaq
 * Domain Path: /languages
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * WC requires at least: 6.0
 * License:     GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// نسخهٔ توسعه/شخصی — عمداً بدون بررسی لایسنس راست‌چین، تا همیشه روی jluxe.ir
// بدون قفل قابل تست و تکمیل باشد. نسخهٔ فروشی (پوشهٔ rounaq/) این بخش را دارد.
//
// همهٔ منطق راه‌اندازی داخل includes/class-jsms-bootstrap.php است (نه همین‌جا)،
// تا rounaq.php همیشه یک فایل ساده و بدون تابع/کلاس بماند — دقیقاً مثل نسخهٔ
// فروشی. این یعنی اگر این افزونه به‌هر دلیلی (مثلاً به‌اشتباه) کنار نسخهٔ فروشی
// فعال بماند، توابع سراسری (jsms_activate و...) که داخل بوت‌استرپ با
// function_exists محافظت شده‌اند، دوباره تعریف نمی‌شوند و سایت Fatal نمی‌گیرد.
require_once __DIR__ . '/includes/class-jsms-bootstrap.php';
jsms_bootstrap( __FILE__ );
