<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * باشگاه مشتریان: کیف پول اعتباری + کش‌بک خودکار + سطوح وفاداری.
 *
 * جریان کار:
 *  - پس از تکمیل سفارش (وضعیت قابل‌تنظیم)، درصدی از مبلغ به کیف پول مشتری اضافه می‌شود.
 *  - درصد کش‌بک بر اساس سطح وفاداری (برنز/نقره/طلا) که از مجموع خرید محاسبه می‌شود، تعیین می‌گردد.
 *  - مشتری با پیامک از کش‌بک و موجودی مطلع می‌شود.
 *  - برای «خرج کردن» موجودی (سازگار با قالب SPA)، موجودی به یک کد تخفیف ووکامرس تبدیل می‌شود
 *    که مشتری در پرداخت اعمال می‌کند؛ این کار از طریق شورت‌کد [jsms_wallet] یا اندپوینت REST انجام می‌شود.
 */
if ( ! class_exists( 'JSMS_Wallet' ) ) :

class JSMS_Wallet {

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'init', array( $this, 'maybe_hook_trigger' ) );
		add_action( 'rest_api_init', array( $this, 'register_rest' ) );
		add_shortcode( 'jsms_wallet', array( $this, 'shortcode' ) );
	}

	public function maybe_hook_trigger() {
		if ( ! jsms_get( 'wallet_enabled' ) ) {
			return;
		}
		$status = jsms_get( 'cashback_trigger_status', 'completed' );
		add_action( 'woocommerce_order_status_' . $status, array( $this, 'on_qualify' ), 20, 1 );
	}

	/* ---------------------------------------------------------------------
	 * تعریف سطوح وفاداری
	 * ------------------------------------------------------------------- */
	public static function tiers() {
		return array(
			'bronze' => array(
				'label' => 'برنزی',
				'min'   => 0,
				'pct'   => (float) jsms_get( 'cashback_percent', 5 ),
			),
			'silver' => array(
				'label' => 'نقره‌ای',
				'min'   => (float) jsms_get( 'tier_silver_min', 10000000 ),
				'pct'   => (float) jsms_get( 'tier_silver_pct', 7 ),
			),
			'gold'   => array(
				'label' => 'طلایی',
				'min'   => (float) jsms_get( 'tier_gold_min', 30000000 ),
				'pct'   => (float) jsms_get( 'tier_gold_pct', 10 ),
			),
		);
	}

	/**
	 * سطح مشتری بر اساس مجموع خرید.
	 */
	public static function tier_for( $total_spent ) {
		$tier = self::tiers()['bronze'];
		foreach ( self::tiers() as $t ) {
			if ( $total_spent >= $t['min'] && $t['min'] >= $tier['min'] ) {
				$tier = $t;
			}
		}
		return $tier;
	}

	public static function total_spent( $user_id ) {
		if ( ! $user_id || ! function_exists( 'wc_get_customer_total_spent' ) ) {
			return 0;
		}
		return (float) wc_get_customer_total_spent( $user_id );
	}

	/* ---------------------------------------------------------------------
	 * محاسبه و اعطای کش‌بک هنگام تکمیل سفارش
	 * ------------------------------------------------------------------- */
	public function on_qualify( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || $order->get_meta( '_jsms_cashback_done' ) ) {
			return;
		}
		$user_id = $order->get_customer_id();
		if ( ! $user_id ) {
			return; // کیف پول نیازمند حساب کاربری است.
		}
		$total = (float) $order->get_total();
		$min   = (float) jsms_get( 'cashback_min_order', 0 );
		if ( $min > 0 && $total < $min ) {
			return;
		}

		$tier = self::tier_for( self::total_spent( $user_id ) );
		$pct  = $tier['pct'];
		$cash = floor( $total * $pct / 100 );
		$cap  = (float) jsms_get( 'cashback_max', 0 );
		if ( $cap > 0 && $cash > $cap ) {
			$cash = $cap;
		}
		if ( $cash <= 0 ) {
			return;
		}

		$order->update_meta_data( '_jsms_cashback_done', 1 );
		$order->save();

		$mobile = JSMS_Automations::instance()->order_mobile( $order );
		$this->credit( $user_id, $cash, 'cashback', $order_id, 'کش‌بک سفارش #' . $order->get_order_number(), $mobile );

		// اطلاع‌رسانی پیامکی.
		if ( ! jsms_get( 'wallet_sms_enabled', 1 ) || ! $mobile ) {
			return;
		}
		$vars = JSMS_Templates::user_vars( $user_id );
		$vars['cashback']       = number_format( $cash );
		$vars['wallet_balance'] = number_format( $this->get_balance( $user_id ) );
		$vars['tier']           = $tier['label'];
		JSMS_Templates::dispatch( array(
			'to' => $mobile, 'user_id' => $user_id, 'type' => 'cashback', 'ref_id' => $order_id, 'force' => true,
			'mode' => 'text',
			'text' => JSMS_Templates::render( jsms_get( 'wallet_cashback_text' ), $vars ),
		) );
	}

	/* ---------------------------------------------------------------------
	 * دفتر کل کیف پول
	 * ------------------------------------------------------------------- */
	public function credit( $user_id, $amount, $type, $ref_id = 0, $note = '', $mobile = '' ) {
		global $wpdb;
		$wpdb->insert( JSMS_DB::wallet_table(), array(
			'created_at' => current_time( 'mysql' ),
			'user_id'    => $user_id,
			'mobile'     => $mobile,
			'amount'     => (int) $amount,
			'type'       => $type,
			'ref_id'     => $ref_id,
			'note'       => $note,
		) );
		$new = $this->get_balance( $user_id, true );
		update_user_meta( $user_id, '_jsms_wallet_balance', $new );
		return $new;
	}

	public function get_balance( $user_id, $recount = false ) {
		if ( ! $recount ) {
			$cached = get_user_meta( $user_id, '_jsms_wallet_balance', true );
			if ( '' !== $cached ) {
				return (int) $cached;
			}
		}
		global $wpdb;
		$sum = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COALESCE(SUM(amount),0) FROM " . JSMS_DB::wallet_table() . " WHERE user_id=%d",
			$user_id
		) );
		return $sum;
	}

	/**
	 * تبدیل موجودی (یا بخشی از آن) به کد تخفیف قابل‌استفاده در پرداخت.
	 */
	public function redeem_to_coupon( $user_id, $amount = 0 ) {
		// قفلِ کوتاه‌مدت روی این کاربر — جلوگیری از دو درخواستِ هم‌زمانِ برداشت که هر دو
		// روی همان موجودیِ خوانده‌شده حساب کنند و کیف پول را دوبار خالی کنند (race condition مالی).
		// از add_option (نه transient) استفاده می‌شود چون در سطح دیتابیس روی کلید یکتا اتمیک
		// است — دو درخواست هم‌زمان نمی‌توانند هر دو قفل را با موفقیت بگیرند.
		$lock_key    = 'jsms_wallet_lock_' . $user_id;
		$existing_at = get_option( $lock_key );
		if ( false !== $existing_at && ( time() - (int) $existing_at ) > 15 ) {
			delete_option( $lock_key ); // قفلِ باقی‌مانده از یک درخواستِ قطع‌شده/کرش‌کرده — بیش از ۱۵ ثانیه از آن گذشته، رهایش کن.
		}
		if ( ! add_option( $lock_key, time(), '', 'no' ) ) {
			return array( 'ok' => false, 'msg' => 'یک درخواست برداشت دیگر در حال پردازش است، چند لحظه صبر کنید.' );
		}

		// موجودی را دوباره (بدون کش) و *داخل* قفل بخوان تا با درخواست هم‌زمانِ دیگر تداخل نکند.
		$balance = $this->get_balance( $user_id, true );
		$min     = (int) jsms_get( 'wallet_redeem_min', 50000 );
		if ( $balance < $min ) {
			delete_option( $lock_key );
			return array( 'ok' => false, 'msg' => 'حداقل موجودی برای برداشت ' . number_format( $min ) . ' تومان است.' );
		}
		$amount = $amount > 0 ? min( (int) $amount, $balance ) : $balance;

		$u    = get_userdata( $user_id );
		$code = JSMS_Coupons::generate( array(
			'amount'      => $amount,
			'type'        => 'fixed_cart',
			'expiry_days' => (int) jsms_get( 'wallet_coupon_expiry_days', 30 ),
			'email'       => $u ? $u->user_email : '',
			'prefix'      => 'WALLET',
		) );
		if ( ! $code ) {
			delete_option( $lock_key );
			return array( 'ok' => false, 'msg' => 'ساخت کد تخفیف ناموفق بود.' );
		}
		// کسر از موجودی.
		$mobile = JSMS_Automations::instance()->user_mobile( $user_id );
		$this->credit( $user_id, -$amount, 'redeem', 0, 'برداشت به کد ' . $code, $mobile );
		delete_option( $lock_key );

		// پیامک تأیید.
		if ( jsms_get( 'wallet_sms_enabled', 1 ) && $mobile ) {
			$vars = JSMS_Templates::user_vars( $user_id );
			$vars['coupon_code']    = $code;
			$vars['redeem_amount']  = number_format( $amount );
			$vars['wallet_balance'] = number_format( $this->get_balance( $user_id ) );
			JSMS_Templates::dispatch( array(
				'to' => $mobile, 'user_id' => $user_id, 'type' => 'wallet_redeem', 'force' => true, 'mode' => 'text',
				'text' => JSMS_Templates::render( jsms_get( 'wallet_redeem_text' ), $vars ),
			) );
		}
		return array( 'ok' => true, 'code' => $code, 'amount' => $amount, 'balance' => $this->get_balance( $user_id ) );
	}

	/* ---------------------------------------------------------------------
	 * REST + شورت‌کد برای مشتری (سازگار با قالب SPA)
	 * ------------------------------------------------------------------- */
	public function register_rest() {
		register_rest_route( 'jsms/v1', '/wallet', array(
			'methods'  => 'GET',
			'permission_callback' => function ( $req ) {
				return is_user_logged_in() && wp_verify_nonce( $req->get_header( 'X-WP-Nonce' ), 'wp_rest' );
			},
			'callback' => function () {
				$uid = get_current_user_id();
				$tier = self::tier_for( self::total_spent( $uid ) );
				return array(
					'balance' => $this->get_balance( $uid ),
					'tier'    => $tier['label'],
					'pct'     => $tier['pct'],
				);
			},
		) );
		// عملیات تبدیل کیف پول به کد تخفیف: علاوه بر لاگین، نانس REST را هم بررسی کن —
		// وگرنه یک صفحهٔ مخرب می‌تواند با اتکا به کوکیِ لاگینِ مرورگر، این عملیات مالی
		// را بدون اطلاع کاربر فراخوانی کند (CSRF). فرانت‌اندی که این را صدا می‌زند باید
		// هدر X-WP-Nonce را (طبق روال استاندارد وردپرس/wp_create_nonce('wp_rest')) بفرستد.
		register_rest_route( 'jsms/v1', '/wallet/redeem', array(
			'methods'  => 'POST',
			'permission_callback' => function ( $req ) {
				return is_user_logged_in() && wp_verify_nonce( $req->get_header( 'X-WP-Nonce' ), 'wp_rest' );
			},
			'callback' => function ( $req ) {
				return $this->redeem_to_coupon( get_current_user_id(), (int) $req->get_param( 'amount' ) );
			},
		) );
	}

	public function shortcode() {
		if ( ! is_user_logged_in() ) {
			return '<p>برای مشاهده کیف پول وارد شوید.</p>';
		}
		$uid     = get_current_user_id();
		$balance = $this->get_balance( $uid );
		$tier    = self::tier_for( self::total_spent( $uid ) );
		ob_start();
		?>
		<div class="jsms-wallet-card" style="max-width:420px;border:1px solid #e9e0e7;border-radius:16px;padding:22px;font-family:inherit">
			<div style="font-size:13px;color:#8b8291">موجودی کیف پول شما</div>
			<div style="font-size:30px;font-weight:800;color:#7a2e57"><?php echo number_format( $balance ); ?> <span style="font-size:14px">تومان</span></div>
			<div style="margin-top:6px;font-size:13px">سطح وفاداری: <b><?php echo esc_html( $tier['label'] ); ?></b> · کش‌بک <?php echo esc_html( $tier['pct'] ); ?>٪</div>
			<button id="jsms-wallet-redeem" style="margin-top:16px;background:#7a2e57;color:#fff;border:0;border-radius:11px;padding:10px 20px;font-weight:700;cursor:pointer">دریافت کد تخفیف از موجودی</button>
			<div id="jsms-wallet-msg" style="margin-top:12px;font-size:13px"></div>
		</div>
		<script>
		(function(){
			var btn=document.getElementById('jsms-wallet-redeem');
			if(!btn)return;
			btn.addEventListener('click',function(){
				btn.disabled=true;var msg=document.getElementById('jsms-wallet-msg');msg.textContent='در حال پردازش…';
				fetch('<?php echo esc_url_raw( rest_url( 'jsms/v1/wallet/redeem' ) ); ?>',{method:'POST',headers:{'X-WP-Nonce':'<?php echo esc_js( wp_create_nonce( 'wp_rest' ) ); ?>'}})
				.then(function(r){return r.json();}).then(function(d){
					btn.disabled=false;
					if(d.ok){msg.innerHTML='کد تخفیف شما: <b>'+d.code+'</b> (به مبلغ '+d.amount.toLocaleString()+' تومان)';}
					else{msg.textContent=d.msg||'خطا';}
				}).catch(function(){btn.disabled=false;msg.textContent='خطای ارتباط';});
			});
		})();
		</script>
		<?php
		return ob_get_clean();
	}
}
endif;
