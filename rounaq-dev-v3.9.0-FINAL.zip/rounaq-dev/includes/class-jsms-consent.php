<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * مدیریت لغو اشتراک (Opt-out).
 * شماره‌های لغو شده در یک آپشن آرایه‌ای نگهداری می‌شوند.
 */
if ( ! class_exists( 'JSMS_Consent' ) ) :

class JSMS_Consent {

	private static $instance;
	const OPTION = 'jsms_optout_list';

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// لینک عمومی لغو اشتراک: /?jsms_optout=MOBILE
		add_action( 'init', array( $this, 'handle_public_optout' ) );
	}

	public static function list() {
		$l = get_option( self::OPTION, array() );
		return is_array( $l ) ? $l : array();
	}

	public static function is_opted_out( $mobile ) {
		$mobile = JSMS_Gateway::normalize_mobile( $mobile );
		return in_array( $mobile, self::list(), true );
	}

	public static function opt_out( $mobile ) {
		$mobile = JSMS_Gateway::normalize_mobile( $mobile );
		if ( ! $mobile ) {
			return;
		}
		$l = self::list();
		if ( ! in_array( $mobile, $l, true ) ) {
			$l[] = $mobile;
			update_option( self::OPTION, $l );
		}
	}

	public static function opt_in( $mobile ) {
		$mobile = JSMS_Gateway::normalize_mobile( $mobile );
		$l = array_values( array_diff( self::list(), array( $mobile ) ) );
		update_option( self::OPTION, $l );
	}

	public function handle_public_optout() {
		if ( isset( $_GET['jsms_optout'] ) ) {
			$m = sanitize_text_field( wp_unslash( $_GET['jsms_optout'] ) );
			self::opt_out( $m );
			wp_die( 'اشتراک پیامکی شما با موفقیت لغو شد. دیگر پیام تبلیغاتی دریافت نخواهید کرد.', 'لغو اشتراک', array( 'response' => 200 ) );
		}
	}
}
endif;
