<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * نظرسنجی مشتریان: ساخت پرسش‌نامه (امتیازی/چندگزینه‌ای/متنی)، ارسال لینک
 * پیامکی، صفحهٔ عمومی پاسخ‌دهی (مستقل از قالب سایت — دقیقاً به همان روش
 * صفحهٔ ثبت نظر در JSMS_Reviews: رندر مستقیم روی هوک init و exit، بدون
 * وابستگی به تمپلیت پوسته، تا روی هر پوستهٔ ووکامرسی‌ای کار کند)، و نمایش
 * پاسخ‌های مشتریان به مدیر.
 */
if ( ! class_exists( 'JSMS_Surveys' ) ) :

class JSMS_Surveys {

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// صفحه عمومی پاسخ‌دهی: /?jsms_survey=TOKEN
		add_action( 'init', array( $this, 'maybe_render_survey_page' ) );
	}

	/* ---------------------------------------------------------------------
	 * CRUD نظرسنجی‌ها
	 * ------------------------------------------------------------------- */
	public static function get_survey( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . JSMS_DB::surveys_table() . ' WHERE id=%d', $id ) );
	}

	public static function get_surveys() {
		global $wpdb;
		return $wpdb->get_results( 'SELECT * FROM ' . JSMS_DB::surveys_table() . ' ORDER BY id DESC' );
	}

	public static function save_survey( $id, $data ) {
		global $wpdb;
		$row = array(
			'title'      => sanitize_text_field( $data['title'] ?? '' ),
			'intro_text' => sanitize_textarea_field( $data['intro_text'] ?? '' ),
			'logo_url'   => esc_url_raw( $data['logo_url'] ?? '' ),
			'sms_text'   => sanitize_textarea_field( $data['sms_text'] ?? '' ),
			'status'     => in_array( $data['status'] ?? '', array( 'draft', 'active' ), true ) ? $data['status'] : 'draft',
		);
		if ( $id ) {
			$wpdb->update( JSMS_DB::surveys_table(), $row, array( 'id' => $id ) );
			return $id;
		}
		$row['created_at'] = current_time( 'mysql' );
		$wpdb->insert( JSMS_DB::surveys_table(), $row );
		return $wpdb->insert_id;
	}

	public static function delete_survey( $id ) {
		global $wpdb;
		$wpdb->delete( JSMS_DB::survey_questions_table(), array( 'survey_id' => $id ) );
		$wpdb->delete( JSMS_DB::survey_responses_table(), array( 'survey_id' => $id ) );
		$wpdb->delete( JSMS_DB::surveys_table(), array( 'id' => $id ) );
	}

	/* ---------------------------------------------------------------------
	 * CRUD پرسش‌ها
	 * ------------------------------------------------------------------- */
	public static function get_questions( $survey_id ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM ' . JSMS_DB::survey_questions_table() . ' WHERE survey_id=%d ORDER BY sort_order ASC, id ASC', $survey_id
		) );
	}

	public static function question_types() {
		return array(
			'rating'        => 'امتیازی (۱ تا ۵)',
			'choice_single' => 'چندگزینه‌ای (یک پاسخ)',
			'choice_multi'  => 'چندگزینه‌ای (چند پاسخ)',
			'text'          => 'متنی (پاسخ آزاد)',
		);
	}

	public static function save_question( $id, $survey_id, $data ) {
		global $wpdb;
		$type = array_key_exists( $data['type'] ?? '', self::question_types() ) ? $data['type'] : 'rating';
		$options = array();
		if ( in_array( $type, array( 'choice_single', 'choice_multi' ), true ) ) {
			foreach ( preg_split( '/\r\n|\r|\n/', (string) ( $data['options'] ?? '' ) ) as $line ) {
				$line = trim( $line );
				if ( '' !== $line ) {
					$options[] = sanitize_text_field( $line );
				}
			}
		}
		$row = array(
			'survey_id'     => $survey_id,
			'type'          => $type,
			'question_text' => sanitize_text_field( $data['question_text'] ?? '' ),
			'options'       => wp_json_encode( $options ),
			'sort_order'    => (int) ( $data['sort_order'] ?? 0 ),
		);
		if ( $id ) {
			$wpdb->update( JSMS_DB::survey_questions_table(), $row, array( 'id' => $id ) );
			return $id;
		}
		$wpdb->insert( JSMS_DB::survey_questions_table(), $row );
		return $wpdb->insert_id;
	}

	public static function delete_question( $id ) {
		global $wpdb;
		$wpdb->delete( JSMS_DB::survey_questions_table(), array( 'id' => $id ) );
	}

	/* ---------------------------------------------------------------------
	 * ارسال لینک نظرسنجی (دستی یا خودکار)
	 * ------------------------------------------------------------------- */
	public static function send_link( $survey_id, $mobile, $args = array() ) {
		$survey = self::get_survey( $survey_id );
		if ( ! $survey ) {
			return array( 'ok' => false, 'error' => 'نظرسنجی پیدا نشد.' );
		}
		$mobile = JSMS_Gateway::normalize_mobile( $mobile );
		if ( ! $mobile ) {
			return array( 'ok' => false, 'error' => 'شمارهٔ موبایل نامعتبر است.' );
		}
		global $wpdb;
		$user_id = (int) ( $args['user_id'] ?? 0 );
		$author  = (string) ( $args['author'] ?? '' );
		$token   = wp_generate_password( 24, false );
		$wpdb->insert( JSMS_DB::survey_responses_table(), array(
			'created_at' => current_time( 'mysql' ),
			'survey_id'  => $survey_id,
			'user_id'    => $user_id,
			'mobile'     => $mobile,
			'author'     => $author,
			'token'      => $token,
			'status'     => 'pending',
		) );
		$response_id = (int) $wpdb->insert_id;

		$vars = $user_id ? JSMS_Templates::user_vars( $user_id ) : array( 'first_name' => $author ?: 'مشتری' );
		$vars['survey_url'] = JSMS_Templates::shorten( add_query_arg( 'jsms_survey', $token, home_url( '/' ) ) );
		$text_tpl = $survey->sms_text ?: jsms_get( 'survey_default_text' );

		$result = JSMS_Templates::dispatch( array(
			'to' => $mobile, 'user_id' => $user_id, 'type' => 'survey_request', 'ref_id' => $survey_id,
			'force' => ! empty( $args['force'] ), 'mode' => 'text',
			'text' => JSMS_Templates::render( $text_tpl, $vars ),
		) );
		if ( empty( $result['ok'] ) && $response_id ) {
			// ارسال ناموفق بود — رکورد را پاک کن تا اسکن بعدی همین مشتری را «قبلاً ارسال‌شده»
			// حساب نکند و واقعاً دوباره تلاش کند (وگرنه پیامک شکست‌خورده دیگر هرگز رفتار نمی‌شد).
			$wpdb->delete( JSMS_DB::survey_responses_table(), array( 'id' => $response_id ) );
		}
		return $result;
	}

	/**
	 * اسکن روزانه: ارسال خودکار نظرسنجیِ انتخاب‌شده N روز بعد از سفارش‌های
	 * واجد شرایط — دقیقاً همان الگوی JSMS_Reviews::scan_review_requests().
	 */
	public static function scan_survey_requests() {
		if ( ! jsms_get( 'survey_auto_enabled' ) ) {
			return;
		}
		$survey_id = (int) jsms_get( 'survey_auto_survey_id' );
		$survey    = $survey_id ? self::get_survey( $survey_id ) : null;
		if ( ! $survey || 'active' !== $survey->status ) {
			return; // نظرسنجیِ پیش‌نویس یا حذف‌شده نباید خودکار ارسال شود.
		}
		global $wpdb;
		$days   = (int) jsms_get( 'survey_after_days', 3 );
		$status = jsms_get( 'survey_order_status', 'completed' );
		$before = strtotime( '-' . $days . ' days' );

		$orders = wc_get_orders( array(
			'limit' => 30, 'status' => 'wc-' . $status, 'orderby' => 'date', 'order' => 'DESC',
			'date_modified' => '<' . $before, 'return' => 'objects',
		) );

		$rt = JSMS_DB::survey_responses_table();
		foreach ( (array) $orders as $order ) {
			$mobile = JSMS_Automations::instance()->order_mobile( $order );
			if ( ! $mobile ) {
				continue;
			}
			$already = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT COUNT(*) FROM {$rt} WHERE survey_id=%d AND mobile=%s", $survey_id, JSMS_Gateway::normalize_mobile( $mobile )
			) );
			if ( $already ) {
				continue; // برای این شماره قبلاً همین نظرسنجی ارسال شده — دوباره نرود.
			}
			self::send_link( $survey_id, $mobile, array(
				'user_id' => $order->get_customer_id(),
				'author'  => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
			) );
		}
	}

	/* ---------------------------------------------------------------------
	 * نتایج
	 * ------------------------------------------------------------------- */
	public static function get_responses( $survey_id ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM ' . JSMS_DB::survey_responses_table() . ' WHERE survey_id=%d ORDER BY id DESC', $survey_id
		) );
	}

	/**
	 * خلاصهٔ آماری هر پرسش (میانگین امتیاز/توزیع ستاره یا شمار هر گزینه)
	 * فقط از پاسخ‌های تکمیل‌شده (status=done).
	 */
	public static function results_summary( $survey_id, $questions ) {
		global $wpdb;
		$done = $wpdb->get_results( $wpdb->prepare(
			"SELECT answers FROM " . JSMS_DB::survey_responses_table() . " WHERE survey_id=%d AND status='done'", $survey_id
		) );
		$summary = array();
		foreach ( $questions as $q ) {
			$summary[ $q->id ] = array( 'avg' => 0, 'count' => 0, 'dist' => array( 1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0 ), 'options' => array() );
			if ( 'choice_single' === $q->type || 'choice_multi' === $q->type ) {
				foreach ( (array) json_decode( $q->options, true ) as $opt ) {
					$summary[ $q->id ]['options'][ $opt ] = 0;
				}
			}
		}
		foreach ( $done as $row ) {
			$answers = json_decode( $row->answers, true );
			if ( ! is_array( $answers ) ) {
				continue;
			}
			foreach ( $questions as $q ) {
				if ( ! isset( $answers[ $q->id ] ) || '' === $answers[ $q->id ] ) {
					continue;
				}
				$val = $answers[ $q->id ];
				if ( 'rating' === $q->type ) {
					$n = max( 1, min( 5, (int) $val ) );
					$summary[ $q->id ]['count']++;
					$summary[ $q->id ]['avg'] += $n;
					$summary[ $q->id ]['dist'][ $n ]++;
				} elseif ( 'choice_single' === $q->type ) {
					if ( isset( $summary[ $q->id ]['options'][ $val ] ) ) {
						$summary[ $q->id ]['options'][ $val ]++;
					}
				} elseif ( 'choice_multi' === $q->type ) {
					foreach ( (array) $val as $v ) {
						if ( isset( $summary[ $q->id ]['options'][ $v ] ) ) {
							$summary[ $q->id ]['options'][ $v ]++;
						}
					}
				}
			}
		}
		foreach ( $summary as &$s ) {
			if ( $s['count'] > 0 ) {
				$s['avg'] = round( $s['avg'] / $s['count'], 1 );
			}
		}
		return $summary;
	}

	/* ---------------------------------------------------------------------
	 * صفحه عمومی پاسخ‌دهی (لینک پیامک) — مستقل از پوستهٔ سایت
	 * ------------------------------------------------------------------- */
	public function maybe_render_survey_page() {
		if ( empty( $_GET['jsms_survey'] ) ) {
			return;
		}
		$token = sanitize_text_field( wp_unslash( $_GET['jsms_survey'] ) );
		global $wpdb;
		$rt  = JSMS_DB::survey_responses_table();
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$rt} WHERE token=%s", $token ) );
		if ( ! $row ) {
			wp_die( 'لینک نظرسنجی معتبر نیست یا منقضی شده است.' );
		}
		$survey    = self::get_survey( $row->survey_id );
		$questions = self::get_questions( $row->survey_id );
		if ( ! $survey || empty( $questions ) ) {
			wp_die( 'این نظرسنجی دیگر در دسترس نیست.' );
		}

		$done  = ( 'done' === $row->status );
		$error = '';
		if ( ! $done && ! empty( $_POST['jsms_survey_submit'] ) && wp_verify_nonce( $_POST['_jsms_nonce'] ?? '', 'jsms_survey_' . $token ) ) {
			$answers = array();
			foreach ( $questions as $q ) {
				$field = 'q' . $q->id;
				if ( 'choice_multi' === $q->type ) {
					$vals = isset( $_POST[ $field ] ) ? (array) wp_unslash( $_POST[ $field ] ) : array();
					$answers[ $q->id ] = array_map( 'sanitize_text_field', $vals );
					if ( empty( $answers[ $q->id ] ) ) {
						$error = 'لطفاً به همهٔ پرسش‌ها پاسخ دهید.';
					}
				} elseif ( 'text' === $q->type ) {
					$val = sanitize_textarea_field( wp_unslash( $_POST[ $field ] ?? '' ) );
					if ( '' === $val ) {
						$error = 'لطفاً به همهٔ پرسش‌ها پاسخ دهید.';
					}
					$answers[ $q->id ] = $val;
				} else {
					$val = sanitize_text_field( wp_unslash( $_POST[ $field ] ?? '' ) );
					if ( '' === $val ) {
						$error = 'لطفاً به همهٔ پرسش‌ها پاسخ دهید.';
					}
					$answers[ $q->id ] = $val;
				}
				if ( $error ) {
					break;
				}
			}
			if ( ! $error ) {
				$wpdb->update( $rt, array(
					'answers'      => wp_json_encode( $answers ),
					'status'       => 'done',
					'completed_at' => current_time( 'mysql' ),
				), array( 'id' => $row->id ) );
				$done = true;
			}
		}
		$this->render_survey_html( $survey, $questions, $row, $done, $error, $token );
		exit;
	}

	private function render_survey_html( $survey, $questions, $row, $done, $error, $token ) {
		$author    = $row->author ? $row->author : 'دوست عزیز';
		$star_path = 'm12 3.6 2.6 5.3 5.8.85-4.2 4.1 1 5.75L12 16.85 6.8 19.6l1-5.75L3.6 9.75l5.8-.85Z';
		$fa_digits = array( 1 => '۱', 2 => '۲', 3 => '۳', 4 => '۴', 5 => '۵' );
		$logo_url  = $survey->logo_url ?: JSMS_Templates::default_logo_url();
		?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="color-scheme" content="light dark">
<title><?php echo esc_html( $survey->title ); ?></title>
<style>
	:root{
		--brand-400:#6fd94f; --brand-500:#33c115; --brand-600:#28960f;
		--gold:#dd9f54; --gold-light:#ffd687;
		--ink-50:#fafafa; --ink-100:#f4f4f5; --ink-200:#e4e4e7; --ink-300:#d4d4d8;
		--ink-400:#a1a1aa; --ink-500:#71717a; --ink-700:#3f3f46; --ink-800:#27272a; --ink-900:#18181b;
		--star:#dd9f54;
		--bg:var(--ink-50); --card:#fff; --border:var(--ink-200); --text:var(--ink-900); --muted:var(--ink-500);
	}
	@media (prefers-color-scheme: dark){
		:root{ --bg:#000; --card:var(--ink-900); --border:var(--ink-800); --text:#fff; --muted:var(--ink-400); }
	}
	*{box-sizing:border-box}
	html,body{height:100%}
	body{font-family:'Shabnam',Tahoma,system-ui,sans-serif;background:var(--bg);margin:0;color:var(--text);min-height:100dvh;-webkit-tap-highlight-color:transparent;position:relative;overflow-x:hidden;
		display:flex;flex-direction:column;
		padding:max(16px,env(safe-area-inset-top)) max(14px,env(safe-area-inset-right)) max(16px,env(safe-area-inset-bottom)) max(14px,env(safe-area-inset-left))}
	body::before{content:'';position:fixed;inset:0;z-index:-1;background:radial-gradient(circle at 50% -10%, color-mix(in srgb, var(--brand-500) 10%, transparent), transparent 60%)}
	body::after{content:'';position:fixed;inset:0;z-index:-1;background:radial-gradient(circle at 100% 100%, color-mix(in srgb, var(--gold-light) 12%, transparent), transparent 55%)}
	.wrap{max-width:440px;margin:0 auto;position:relative;flex:1;display:flex;flex-direction:column;width:100%}
	.card{background:var(--card);border:1px solid var(--border);border-radius:24px;box-shadow:0 20px 60px rgba(0,0,0,.1),0 2px 8px rgba(0,0,0,.04);padding:20px 22px 22px;overflow:hidden;flex:1;display:flex;flex-direction:column;min-height:0;position:relative}
	.card::before{content:'';position:absolute;top:0;inset-inline:0;height:4px;background:linear-gradient(90deg,var(--brand-400),var(--gold-light),var(--brand-600))}
	.topbar{display:flex;align-items:center;gap:10px;margin-bottom:22px;flex:0 0 auto}
	.navback{flex:0 0 auto;width:30px;height:30px;border:1px solid var(--border);border-radius:50%;background:var(--card);color:var(--text);font-size:17px;line-height:1;cursor:pointer;display:flex;align-items:center;justify-content:center;font-family:inherit;transition:opacity .15s,border-color .15s}
	.navback:hover{border-color:var(--brand-500)}
	.navback.is-hidden{visibility:hidden}
	.step-label{font-size:11.5px;font-weight:500;color:var(--muted);white-space:nowrap;flex:0 0 auto}
	.progress{height:5px;flex:1;background:var(--ink-100);border-radius:99px;overflow:hidden}
	.progress .bar{height:100%;width:0;border-radius:99px;background:linear-gradient(90deg,var(--brand-400),var(--brand-600));transition:width .35s cubic-bezier(.22,1,.36,1)}
	.logo-wrap{width:76px;height:76px;margin:0 auto 16px;position:relative;display:flex;align-items:center;justify-content:center}
	.logo-wrap::before{content:'';position:absolute;inset:0;border-radius:20px;background:linear-gradient(135deg,var(--brand-400),var(--gold-light));opacity:.18;transform:rotate(8deg)}
	.logo{display:block;width:60px;height:60px;border-radius:16px;object-fit:cover;box-shadow:0 6px 18px rgba(0,0,0,.14);position:relative}
	.muted{color:var(--muted);font-size:12.5px;line-height:1.8}
	h1{font-size:19px;font-weight:700;margin:2px 0 6px;line-height:1.6}
	.center{text-align:center}
	form{flex:1;display:flex;flex-direction:column;min-height:0}
	.step{flex-direction:column}
	.jsms-js .step{display:none}
	.jsms-js .step.is-current{display:flex;flex:1;min-height:0;animation:stepIn .38s cubic-bezier(.22,1,.36,1)}
	.jsms-js .step.is-current .step-body{flex:1;display:flex;flex-direction:column;justify-content:center;min-height:0;overflow-y:auto}
	@keyframes stepIn{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
	.rate-numbers{display:flex;justify-content:center;gap:9px;margin:26px 0 4px}
	.rate-numbers input{position:absolute;opacity:0;width:1px;height:1px}
	.rate-numbers label{width:46px;height:46px;flex:0 0 46px;border-radius:50%;display:flex;align-items:center;justify-content:center;
		font-size:18px;font-weight:800;border:2px solid var(--border);color:var(--muted);cursor:pointer;
		transition:transform .18s cubic-bezier(.34,1.56,.64,1),border-color .15s,background .15s,color .15s,box-shadow .15s;
		font-variant-numeric:tabular-nums;background:var(--card)}
	.rate-numbers input:checked + label{background:linear-gradient(135deg,var(--brand-400),var(--brand-600));border-color:transparent;
		color:#fff;transform:scale(1.12);box-shadow:0 8px 18px color-mix(in srgb, var(--brand-500) 45%, transparent)}
	.rate-numbers label:active{transform:scale(.92)}
	.stars-display{display:flex;justify-content:center;gap:5px;margin:14px 0 4px;pointer-events:none}
	.stars-display svg{width:24px;height:24px;fill:none;stroke:var(--ink-300);stroke-width:1.6;stroke-linejoin:round;transition:transform .25s cubic-bezier(.34,1.56,.64,1),stroke .2s,fill .2s}
	.stars-display .star.is-on svg{fill:var(--star);stroke:var(--star);transform:scale(1.08)}
	textarea{width:100%;min-height:130px;border:1px solid var(--border);background:transparent;color:var(--text);border-radius:14px;padding:13px;font-family:inherit;font-size:16px;resize:vertical;transition:border-color .15s,box-shadow .15s}
	textarea::placeholder{color:var(--muted)}
	textarea:focus{outline:none;border-color:var(--brand-500);box-shadow:0 0 0 3px color-mix(in srgb, var(--brand-500) 12%, transparent)}
	.choices{display:grid;gap:10px;margin:20px 0 6px}
	.choice{position:relative}
	.choice input{position:absolute;opacity:0;inset:0;width:100%;height:100%;cursor:pointer;margin:0}
	.choice .box{display:flex;align-items:center;gap:12px;border:1.5px solid var(--border);border-radius:14px;padding:14px 16px;font-size:14.5px;font-weight:500;transition:.15s}
	.choice input:checked ~ .box{border-color:var(--brand-500);background:color-mix(in srgb, var(--brand-500) 8%, transparent);transform:translateY(-1px);box-shadow:0 6px 16px color-mix(in srgb, var(--brand-500) 15%, transparent)}
	.btn{width:100%;border:0;border-radius:14px;padding:15px;font-size:16px;font-weight:700;cursor:pointer;margin-top:16px;transition:.15s;font-family:inherit}
	.btn-primary{background:linear-gradient(135deg,var(--brand-400),var(--brand-600));color:#fff;box-shadow:0 10px 24px color-mix(in srgb, var(--brand-500) 30%, transparent)}
	.btn-primary:disabled{opacity:.4;cursor:not-allowed;box-shadow:none}
	.btn-primary:not(:disabled):active{transform:scale(.98)}
	.err{background:rgba(221,80,80,.1);color:#c0392b;padding:11px 14px;border-radius:12px;margin-bottom:16px;font-size:13.5px}
	.ok-wrap{text-align:center;padding:12px 0;position:relative}
	.ok-icon{width:68px;height:68px;border-radius:50%;background:linear-gradient(135deg,var(--brand-400),var(--brand-600));display:flex;align-items:center;justify-content:center;
		margin:4px auto 18px;font-size:32px;box-shadow:0 12px 26px color-mix(in srgb, var(--brand-500) 35%, transparent);animation:okPop .5s cubic-bezier(.34,1.56,.64,1)}
	@keyframes okPop{from{transform:scale(0);opacity:0}to{transform:scale(1);opacity:1}}
	.ok-wrap h1{font-size:18px}
</style>
</head>
<body>
<div class="wrap">
<div class="card">
	<?php if ( $done ) : ?>
		<div class="ok-wrap">
			<div class="ok-icon">✅</div>
			<h1>سپاسگزاریم، <?php echo esc_html( $author ); ?> 🌱</h1>
			<p class="muted">پاسخ‌های شما با موفقیت ثبت شد و به ما کمک می‌کند تجربهٔ بهتری برایتان بسازیم.</p>
		</div>
	<?php else : ?>
		<div class="topbar">
			<button type="button" class="navback is-hidden" id="jsmsBack" aria-label="بازگشت">›</button>
			<div class="progress"><span class="bar" id="jsmsBar"></span></div>
			<span class="step-label" id="jsmsStepLabel">۱/<?php echo count( $questions ) + 1; ?></span>
		</div>
		<?php if ( $error ) : ?><div class="err"><?php echo esc_html( $error ); ?></div><?php endif; ?>

		<form method="post" id="jsmsForm">
			<?php wp_nonce_field( 'jsms_survey_' . $token, '_jsms_nonce' ); ?>

			<section class="step is-current" data-step="0">
				<div class="step-body">
					<?php if ( $logo_url ) : ?>
					<div class="logo-wrap"><img class="logo" src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"></div>
					<?php endif; ?>
					<h1 class="center"><?php echo esc_html( $survey->title ); ?></h1>
					<p class="muted center"><?php echo esc_html( $survey->intro_text ?: 'سلام ' . $author . '! فقط چند لحظه از وقت‌تان را می‌گیرد.' ); ?></p>
				</div>
				<button type="button" class="btn btn-primary" data-next>بزن بریم</button>
			</section>

			<?php foreach ( $questions as $i => $q ) :
				$options = (array) json_decode( $q->options, true );
				?>
				<section class="step" data-step="<?php echo $i + 1; ?>">
					<div class="step-body">
						<h1 class="center"><?php echo esc_html( $q->question_text ); ?></h1>

						<?php if ( 'rating' === $q->type ) : ?>
							<div class="rate-numbers" role="radiogroup">
								<?php for ( $n = 5; $n >= 1; $n-- ) : ?>
									<input type="radio" name="q<?php echo $q->id; ?>" id="q<?php echo $q->id; ?>_<?php echo $n; ?>" value="<?php echo $n; ?>" required>
									<label for="q<?php echo $q->id; ?>_<?php echo $n; ?>"><?php echo esc_html( $fa_digits[ $n ] ); ?></label>
								<?php endfor; ?>
							</div>
							<div class="stars-display" data-rating-display="<?php echo $q->id; ?>" aria-hidden="true">
								<?php for ( $n = 5; $n >= 1; $n-- ) : ?>
									<span class="star" data-i="<?php echo $n; ?>"><svg viewBox="0 0 24 24"><path d="<?php echo esc_attr( $star_path ); ?>"></path></svg></span>
								<?php endfor; ?>
							</div>
						<?php elseif ( 'choice_single' === $q->type ) : ?>
							<div class="choices">
								<?php foreach ( $options as $oi => $opt ) : ?>
									<label class="choice">
										<input type="radio" name="q<?php echo $q->id; ?>" value="<?php echo esc_attr( $opt ); ?>" required>
										<span class="box"><?php echo esc_html( $opt ); ?></span>
									</label>
								<?php endforeach; ?>
							</div>
						<?php elseif ( 'choice_multi' === $q->type ) : ?>
							<div class="choices">
								<?php foreach ( $options as $oi => $opt ) : ?>
									<label class="choice">
										<input type="checkbox" name="q<?php echo $q->id; ?>[]" value="<?php echo esc_attr( $opt ); ?>" data-multi-req="q<?php echo $q->id; ?>">
										<span class="box"><?php echo esc_html( $opt ); ?></span>
									</label>
								<?php endforeach; ?>
							</div>
						<?php else : ?>
							<textarea name="q<?php echo $q->id; ?>" required placeholder="پاسخ خود را بنویسید..."></textarea>
						<?php endif; ?>
					</div>
					<?php if ( $i === count( $questions ) - 1 ) : ?>
						<button type="submit" name="jsms_survey_submit" value="1" class="btn btn-primary" id="jsmsSubmit">ثبت نهایی پاسخ‌ها</button>
					<?php else : ?>
						<button type="button" class="btn btn-primary" data-next>بعدی</button>
					<?php endif; ?>
				</section>
			<?php endforeach; ?>
		</form>
	<?php endif; ?>
</div>
</div>
<?php if ( ! $done ) : ?>
<script>
(function(){
	document.documentElement.classList.add('jsms-js');
	var form  = document.getElementById('jsmsForm');
	var steps = Array.prototype.slice.call(form.querySelectorAll('.step'));
	var bar   = document.getElementById('jsmsBar');
	var label = document.getElementById('jsmsStepLabel');
	var back  = document.getElementById('jsmsBack');
	var idx   = 0;

	function faNum(n){ return String(n).replace(/\d/g, function(d){ return '۰۱۲۳۴۵۶۷۸۹'[d]; }); }

	function show(n){
		idx = n;
		steps.forEach(function(s,i){ s.classList.toggle('is-current', i === n); });
		bar.style.width = ( ( n + 1 ) / steps.length * 100 ) + '%';
		if (label) label.textContent = faNum(n + 1) + '/' + faNum(steps.length);
		if (back) back.classList.toggle('is-hidden', n === 0);
	}

	function isStepValid(stepEl){
		var multiGroups = {};
		var reqs = stepEl.querySelectorAll('[required]');
		for (var i=0; i<reqs.length; i++){
			var el = reqs[i];
			if (el.type === 'radio'){
				if (!stepEl.querySelector('input[name="'+el.name+'"]:checked')) return false;
			} else if (!el.value || !el.value.trim()){
				return false;
			}
		}
		var multiEls = stepEl.querySelectorAll('[data-multi-req]');
		if (multiEls.length){
			var group = multiEls[0].getAttribute('data-multi-req');
			if (!stepEl.querySelector('input[name="'+group+'[]"]:checked')) return false;
		}
		return true;
	}

	function refreshNextButtons(){
		steps.forEach(function(stepEl){
			var btn = stepEl.querySelector('[data-next]');
			if (btn) btn.disabled = !isStepValid(stepEl);
			var submit = stepEl.querySelector('#jsmsSubmit');
			if (submit) submit.disabled = !isStepValid(stepEl);
		});
	}

	// نمایش ستارهٔ خودکار برای پرسش‌های امتیازی.
	form.querySelectorAll('[data-rating-display]').forEach(function(disp){
		var qid = disp.getAttribute('data-rating-display');
		var stars = Array.prototype.slice.call(disp.querySelectorAll('.star'));
		form.querySelectorAll('input[name="q'+qid+'"]').forEach(function(inp){
			inp.addEventListener('change', function(){
				var n = parseInt(inp.value, 10) || 0;
				stars.forEach(function(s){ s.classList.toggle('is-on', parseInt(s.getAttribute('data-i'),10) <= n); });
			});
		});
	});

	form.addEventListener('click', function(e){
		if (e.target.closest('[data-next]') && idx < steps.length - 1){ show(idx + 1); }
	});
	if (back) back.addEventListener('click', function(){
		if (idx > 0){ show(idx - 1); }
	});
	form.addEventListener('change', refreshNextButtons);
	form.addEventListener('input', refreshNextButtons);

	refreshNextButtons();
	show(0);
})();
</script>
<?php endif; ?>
</body>
</html>
		<?php
	}
}
endif;
