<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * درخواست نظر پس از خرید + صفحه ثبت نظر + تأیید مدیر + انتشار زیر محصول.
 */
if ( ! class_exists( 'JSMS_Reviews' ) ) :

class JSMS_Reviews {

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// صفحه عمومی ثبت نظر: /?jsms_review=TOKEN
		add_action( 'init', array( $this, 'maybe_render_review_page' ) );
	}

	/* ---------------------------------------------------------------------
	 * ارسال درخواست نظر (کران)
	 * ------------------------------------------------------------------- */
	public static function scan_review_requests() {
		if ( ! jsms_get( 'review_enabled' ) ) {
			return;
		}
		global $wpdb;
		$days   = (int) jsms_get( 'review_after_days', 5 );
		$status = jsms_get( 'review_order_status', 'completed' );
		$before = strtotime( '-' . $days . ' days' );

		$orders = wc_get_orders( array(
			'limit'   => 30,
			'status'  => 'wc-' . $status,
			'orderby' => 'date',
			'order'   => 'DESC',
			'date_modified' => '<' . $before,
			'return'  => 'objects',
		) );

		foreach ( (array) $orders as $order ) {
			self::send_for_order( $order );
		}

		// یادآوری یک‌بارهٔ ۳ روزه برای کسانی که درخواست نظر برایشان رفته ولی هنوز پاسخ نداده‌اند.
		$rt = JSMS_DB::reviews_table();
		$pending = $wpdb->get_results( $wpdb->prepare(
			"SELECT order_id FROM {$rt} WHERE status='requested' AND created_at <= %s LIMIT 50",
			gmdate( 'Y-m-d H:i:s', time() - 3 * DAY_IN_SECONDS )
		) );
		foreach ( (array) $pending as $row ) {
			$order = wc_get_order( $row->order_id );
			if ( $order ) {
				self::send_for_order( $order );
			}
		}
	}

	/**
	 * ارسال درخواست نظر برای یک سفارش مشخص، دستی یا از داخل اسکن روزانه.
	 * اگر پیش‌تر درخواست رفته و مشتری هنوز پاسخ نداده، این متد نقش «یادآوری»
	 * را هم بازی می‌کند (حداکثر یک‌بار، حداقل ۳ روز بعد از درخواست اول).
	 * اگر مشتری قبلاً نظرش را ثبت کرده باشد، هرگز دوباره پیامک نمی‌رود.
	 *
	 * @param WC_Order $order
	 * @param bool     $force اگر true باشد، ساعات سکوت و فاصلهٔ زمانی یادآوری نادیده گرفته می‌شود (ارسال دستی توسط مدیر).
	 * @return array نتیجهٔ dispatch؛ کلید‌های اضافه: 'skipped' => 'already_reviewed'|'reminder_sent'|'too_soon'|'no_mobile'|'no_product'.
	 */
	public static function send_for_order( $order, $force = false ) {
		global $wpdb;
		$rt       = JSMS_DB::reviews_table();
		$order_id = $order->get_id();

		$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$rt} WHERE order_id=%d LIMIT 1", $order_id ) );

		// مشتری قبلاً نظرش را ثبت کرده (وضعیت دیگر «requested» نیست) — هرگز دوباره پیامک نرود.
		if ( $existing && 'requested' !== $existing->status ) {
			return array( 'ok' => false, 'skipped' => 'already_reviewed', 'error' => 'مشتری قبلاً نظرش را ثبت کرده — پیامک دوباره ارسال نمی‌شود.' );
		}

		$is_reminder = (bool) $existing;
		if ( $is_reminder && ! $force ) {
			$sent_count = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT COUNT(*) FROM " . JSMS_DB::logs_table() . " WHERE type='review_request' AND ref_id=%d AND status!='failed'",
				$order_id
			) );
			if ( $sent_count >= 2 ) {
				return array( 'ok' => false, 'skipped' => 'reminder_sent', 'error' => 'یادآوری این سفارش قبلاً ارسال شده است.' );
			}
			$days_since = ( time() - strtotime( $existing->created_at ) ) / DAY_IN_SECONDS;
			if ( $days_since < 3 ) {
				return array( 'ok' => false, 'skipped' => 'too_soon', 'error' => 'هنوز ۳ روز از درخواست اول نگذشته است.' );
			}
		}

		if ( $is_reminder ) {
			// یادآوری: همان مشتری/محصول/لینک قبلی.
			$mobile       = $existing->mobile;
			$product_id   = $existing->product_id;
			$product      = wc_get_product( $product_id );
			$product_name = $product ? $product->get_name() : '';
			$token        = $existing->token;
		} else {
			$mobile = JSMS_Automations::instance()->order_mobile( $order );
			if ( ! $mobile ) {
				return array( 'ok' => false, 'skipped' => 'no_mobile', 'error' => 'شمارهٔ موبایل سفارش خالی است.' );
			}
			// اولین محصول قابل نظردهی.
			$product_id = 0; $product_name = '';
			foreach ( $order->get_items() as $item ) {
				$pid = $item->get_product_id();
				if ( $pid ) {
					$product_id = $pid;
					$product_name = $item->get_name();
					break;
				}
			}
			if ( ! $product_id ) {
				return array( 'ok' => false, 'skipped' => 'no_product', 'error' => 'محصولی برای نظردهی در این سفارش پیدا نشد.' );
			}
			$token = wp_generate_password( 24, false );
		}

		$vars  = JSMS_Templates::order_vars( $order );
		$vars['product_name'] = $product_name;
		$vars['review_url']   = JSMS_Templates::shorten( add_query_arg( 'jsms_review', $token, home_url( '/' ) ) );

		// یادآوری از متنی جداگانه و متفاوت با درخواست اول استفاده می‌کند.
		$text_key = $is_reminder ? 'review_reminder_text' : 'review_text';

		$res = JSMS_Templates::dispatch( array(
			'to' => $mobile, 'user_id' => $order->get_customer_id(), 'type' => 'review_request',
			'ref_id' => $order_id, 'force' => $force,
			'mode' => jsms_get( 'review_mode', 'text' ),
			'text' => JSMS_Templates::render( jsms_get( $text_key ), $vars ),
			'pattern_id' => jsms_get( 'review_pattern' ),
			'pattern_args' => array( $vars['first_name'], $product_name, $vars['review_url'] ),
		) );

		// اگر به‌خاطر ساعات سکوت رد شد، چیزی ثبت نمی‌شود تا بعداً دوباره امتحان شود.
		if ( ! empty( $res['quiet'] ) ) {
			return $res;
		}

		if ( ! $is_reminder ) {
			$wpdb->insert( $rt, array(
				'created_at' => current_time( 'mysql' ),
				'user_id'    => $order->get_customer_id(),
				'order_id'   => $order_id,
				'product_id' => $product_id,
				'mobile'     => $mobile,
				'author'     => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
				'token'      => $token,
				'status'     => 'requested',
			) );
		}
		return $res;
	}

	/* ---------------------------------------------------------------------
	 * صفحه عمومی ثبت نظر (لینک پیامک)
	 * ------------------------------------------------------------------- */
	public function maybe_render_review_page() {
		if ( empty( $_GET['jsms_review'] ) ) {
			return;
		}
		$token = sanitize_text_field( wp_unslash( $_GET['jsms_review'] ) );
		global $wpdb;
		$rt  = JSMS_DB::reviews_table();
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$rt} WHERE token=%s", $token ) );
		if ( ! $row ) {
			wp_die( 'لینک نظر معتبر نیست یا منقضی شده است.' );
		}

		$done = false; $error = '';
		if ( ! empty( $_POST['jsms_review_submit'] ) && wp_verify_nonce( $_POST['_jsms_nonce'] ?? '', 'jsms_review_' . $token ) ) {
			$rating    = max( 1, min( 5, (int) ( $_POST['rating'] ?? 5 ) ) );
			$content   = sanitize_textarea_field( wp_unslash( $_POST['content'] ?? '' ) );
			$author    = sanitize_text_field( wp_unslash( $_POST['author'] ?? $row->author ) );
			$recommend = isset( $_POST['recommend'] ) && in_array( $_POST['recommend'], array( '0', '1' ), true ) ? (int) $_POST['recommend'] : null;
			if ( '' === $content ) {
				$error = 'لطفاً متن نظر را بنویسید.';
			} elseif ( null === $recommend ) {
				$error = 'لطفاً مشخص کنید این محصول را پیشنهاد می‌کنید یا نه.';
			} else {
				$wpdb->update( $rt, array(
					'rating' => $rating, 'content' => $content, 'author' => $author, 'recommend' => $recommend, 'status' => 'pending',
				), array( 'id' => $row->id ) );
				$row->rating    = $rating;
				$row->content   = $content;
				$row->author    = $author;
				$row->recommend = $recommend;
				$done = true;
			}
		}
		$this->render_form_html( $row, $done, $error, $token );
		exit;
	}

	private function render_form_html( $row, $done, $error, $token ) {
		$product = wc_get_product( $row->product_id );
		$pname   = $product ? $product->get_name() : 'محصول';
		$pimg    = $product ? $product->get_image( 'woocommerce_thumbnail' ) : '';
		$author  = $row->author ? $row->author : 'دوست عزیز';
		$star_path = 'm12 3.6 2.6 5.3 5.8.85-4.2 4.1 1 5.75L12 16.85 6.8 19.6l1-5.75L3.6 9.75l5.8-.85Z';
		$fa_digits = array( 1 => '۱', 2 => '۲', 3 => '۳', 4 => '۴', 5 => '۵' );
		$rate_captions = array(
			5 => 'عالی بود! 😍',
			4 => 'خوب بود 🙂',
			3 => 'در حد متوسط 😐',
			2 => 'چندان راضی نبودم 🙁',
			1 => 'اصلاً راضی نبودم 😞',
		);
		$logo_url  = JSMS_Templates::default_logo_url();
		?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="color-scheme" content="light dark">
<title>ثبت نظر شما درباره <?php echo esc_html( $pname ); ?></title>
<style>
	:root{
		--brand-400:#f4768f; --brand-500:#ed1a45; --brand-600:#be1537;
		--ink-50:#fafafa; --ink-100:#f4f4f5; --ink-200:#e4e4e7; --ink-300:#d4d4d8;
		--ink-400:#a1a1aa; --ink-500:#71717a; --ink-700:#3f3f46; --ink-800:#27272a; --ink-900:#18181b;
		--star:#f7b731;
		--bg:var(--ink-50); --card:#fff; --border:var(--ink-200); --text:var(--ink-900); --muted:var(--ink-500);
	}
	@media (prefers-color-scheme: dark){
		:root{ --bg:#000; --card:var(--ink-900); --border:var(--ink-800); --text:#fff; --muted:var(--ink-400); }
	}
	*{box-sizing:border-box}
	html,body{height:100%}
	body{font-family:'Shabnam',Tahoma,system-ui,sans-serif;background:var(--bg);margin:0;color:var(--text);min-height:100dvh;-webkit-tap-highlight-color:transparent;position:relative;overflow-x:hidden;
		display:flex;flex-direction:column;
		padding:max(16px,env(safe-area-inset-top)) max(14px,env(safe-area-inset-right)) max(16px,env(safe-area-inset-bottom)) max(14px,env(safe-area-inset-left))}
	body::before{content:'';position:fixed;inset:0;z-index:-1;background:radial-gradient(circle at 50% -10%, color-mix(in srgb, var(--brand-500) 10%, transparent), transparent 60%)}
	body::after{content:'';position:fixed;inset:0;z-index:-1;background:radial-gradient(circle at 100% 100%, color-mix(in srgb, var(--star) 8%, transparent), transparent 55%)}
	.wrap{max-width:440px;margin:0 auto;position:relative;flex:1;display:flex;flex-direction:column;width:100%}
	.card{background:var(--card);border:1px solid var(--border);border-radius:24px;box-shadow:0 20px 60px rgba(0,0,0,.1),0 2px 8px rgba(0,0,0,.04);padding:20px 22px 22px;overflow:hidden;flex:1;display:flex;flex-direction:column;min-height:0;position:relative}
	.card::before{content:'';position:absolute;top:0;inset-inline:0;height:4px;background:linear-gradient(90deg,var(--brand-400),var(--star),var(--brand-600))}
	.topbar{display:flex;align-items:center;gap:10px;margin-bottom:22px;flex:0 0 auto}
	.navback{flex:0 0 auto;width:30px;height:30px;border:1px solid var(--border);border-radius:50%;background:var(--card);color:var(--text);font-size:17px;line-height:1;cursor:pointer;display:flex;align-items:center;justify-content:center;font-family:inherit;transition:opacity .15s,border-color .15s}
	.navback:hover{border-color:var(--brand-500)}
	.navback.is-hidden{visibility:hidden}
	.step-label{font-size:11.5px;font-weight:500;color:var(--muted);white-space:nowrap;flex:0 0 auto}
	.progress{height:5px;flex:1;background:var(--ink-100);border-radius:99px;overflow:hidden}
	.progress .bar{height:100%;width:0;border-radius:99px;background:linear-gradient(90deg,var(--brand-400),var(--brand-600));transition:width .35s cubic-bezier(.22,1,.36,1)}
	.logo-wrap{width:76px;height:76px;margin:0 auto 16px;position:relative;display:flex;align-items:center;justify-content:center}
	.logo-wrap::before{content:'';position:absolute;inset:0;border-radius:20px;background:linear-gradient(135deg,var(--brand-400),var(--star));opacity:.18;transform:rotate(8deg)}
	.logo{display:block;width:60px;height:60px;border-radius:16px;object-fit:cover;box-shadow:0 6px 18px rgba(0,0,0,.14);position:relative}
	.prod{display:flex;gap:12px;align-items:center;margin-bottom:14px}
	.prod.center{justify-content:center;text-align:right}
	.prod img{width:52px;height:52px;border-radius:12px;object-fit:cover;background:var(--ink-100)}
	.prod b{font-size:14px;font-weight:500}
	.muted{color:var(--muted);font-size:12.5px;line-height:1.8}
	h1{font-size:19px;font-weight:700;margin:2px 0 6px;line-height:1.6}
	.center{text-align:center}
	form{flex:1;display:flex;flex-direction:column;min-height:0}
	.step{flex-direction:column}
	.jsms-js .step{display:none}
	.jsms-js .step.is-current{display:flex;flex:1;min-height:0;animation:stepIn .38s cubic-bezier(.22,1,.36,1)}
	.jsms-js .step.is-current .step-body{flex:1;display:flex;flex-direction:column;justify-content:center;min-height:0;overflow-y:auto}
	@keyframes stepIn{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
	.stars-row{direction:ltr;display:flex;flex-direction:row-reverse;justify-content:center;gap:4px;margin:22px 0 18px}
	.stars-row input{position:absolute;opacity:0;width:1px;height:1px}
	.stars-row label{cursor:pointer;padding:4px}
	.stars-row svg{width:38px;height:38px;fill:none;stroke:var(--ink-300);stroke-width:1.6;stroke-linejoin:round;transition:transform .15s,stroke .15s,fill .15s}
	.stars-row input:checked ~ label svg,.stars-row label:hover svg,.stars-row label:hover ~ label svg{fill:var(--star);stroke:var(--star)}
	.stars-row label:active svg{transform:scale(1.15)}

	/* --- امتیاز عددی + نمایش ستاره‌ای خودکار --- */
	.rate-numbers{display:flex;justify-content:center;gap:9px;margin:26px 0 4px}
	.rate-numbers input{position:absolute;opacity:0;width:1px;height:1px}
	.rate-numbers label{width:46px;height:46px;flex:0 0 46px;border-radius:50%;display:flex;align-items:center;justify-content:center;
		font-size:18px;font-weight:800;border:2px solid var(--border);color:var(--muted);cursor:pointer;
		transition:transform .18s cubic-bezier(.34,1.56,.64,1),border-color .15s,background .15s,color .15s,box-shadow .15s;
		font-variant-numeric:tabular-nums;background:var(--card)}
	.rate-numbers input:checked + label{background:linear-gradient(135deg,var(--brand-400),var(--brand-600));border-color:transparent;
		color:#fff;transform:scale(1.12);box-shadow:0 8px 18px color-mix(in srgb, var(--brand-500) 45%, transparent)}
	.rate-numbers label:active{transform:scale(.92)}
	.rate-caption{text-align:center;min-height:22px;font-size:13.5px;font-weight:700;color:var(--muted);margin:2px 0 6px;transition:color .15s}
	.stars-display{display:flex;justify-content:center;gap:5px;margin:14px 0 4px;pointer-events:none}
	.stars-display svg{width:24px;height:24px;fill:none;stroke:var(--ink-300);stroke-width:1.6;stroke-linejoin:round;transition:transform .25s cubic-bezier(.34,1.56,.64,1),stroke .2s,fill .2s}
	.stars-display .star.is-on svg{fill:var(--star);stroke:var(--star);transform:scale(1.08)}

	textarea{width:100%;min-height:130px;border:1px solid var(--border);background:transparent;color:var(--text);border-radius:14px;padding:13px;font-family:inherit;font-size:16px;resize:vertical;transition:border-color .15s,box-shadow .15s}
	textarea::placeholder{color:var(--muted)}
	textarea:focus{outline:none;border-color:var(--brand-500);box-shadow:0 0 0 3px color-mix(in srgb, var(--brand-500) 12%, transparent)}
	.char-counter{text-align:left;color:var(--muted);font-size:11.5px;margin-top:6px;direction:ltr}
	.choices{display:grid;gap:10px;margin:20px 0 6px}
	.choice{position:relative}
	.choice input{position:absolute;opacity:0;inset:0;width:100%;height:100%;cursor:pointer;margin:0}
	.choice .box{display:flex;align-items:center;gap:12px;border:1.5px solid var(--border);border-radius:14px;padding:14px 16px;font-size:14.5px;font-weight:500;transition:.15s}
	.choice .box .emoji{font-size:20px}
	.choice input:checked ~ .box{border-color:var(--brand-500);background:color-mix(in srgb, var(--brand-500) 8%, transparent);transform:translateY(-1px);box-shadow:0 6px 16px color-mix(in srgb, var(--brand-500) 15%, transparent)}
	.btn{width:100%;border:0;border-radius:14px;padding:15px;font-size:16px;font-weight:700;cursor:pointer;margin-top:16px;transition:.15s;font-family:inherit}
	.btn-primary{background:linear-gradient(135deg,var(--brand-400),var(--brand-600));color:#fff;box-shadow:0 10px 24px color-mix(in srgb, var(--brand-500) 30%, transparent)}
	.btn-primary:disabled{opacity:.4;cursor:not-allowed;box-shadow:none}
	.btn-primary:not(:disabled):active{transform:scale(.98)}
	.hint{color:var(--muted);font-size:12px;margin-top:8px;text-align:center}
	.err{background:rgba(237,26,69,.1);color:var(--brand-500);padding:11px 14px;border-radius:12px;margin-bottom:16px;font-size:13.5px}
	.ok-wrap{text-align:center;padding:12px 0;position:relative}
	.ok-confetti{position:absolute;inset:-10px 0 auto;height:120px;pointer-events:none;overflow:hidden}
	.ok-confetti i{position:absolute;top:-14px;width:7px;height:7px;border-radius:2px;opacity:.85;animation:confettiFall 1.4s ease-in forwards}
	@keyframes confettiFall{to{transform:translateY(120px) rotate(200deg);opacity:0}}
	.ok-icon{width:68px;height:68px;border-radius:50%;background:linear-gradient(135deg,var(--brand-400),var(--brand-600));display:flex;align-items:center;justify-content:center;
		margin:4px auto 18px;font-size:32px;box-shadow:0 12px 26px color-mix(in srgb, var(--brand-500) 35%, transparent);animation:okPop .5s cubic-bezier(.34,1.56,.64,1)}
	@keyframes okPop{from{transform:scale(0);opacity:0}to{transform:scale(1);opacity:1}}
	.ok-wrap h1{font-size:18px}
	.ok-wrap .stars-row{pointer-events:none;margin:16px 0}
	.ok-wrap .stars-row svg{width:22px;height:22px}
	.ok-wrap .stars-row .is-on svg{fill:var(--star);stroke:var(--star)}
	.ok-badge{display:inline-flex;align-items:center;gap:6px;background:var(--ink-100);color:var(--text);border-radius:99px;padding:6px 14px;font-size:12.5px;margin-top:6px}
</style>
</head>
<body>
<div class="wrap">
<div class="card">
	<?php if ( $done ) : ?>
		<div class="ok-wrap">
			<div class="ok-confetti" aria-hidden="true">
				<?php
				$confetti_colors = array( 'var(--brand-400)', 'var(--star)', 'var(--brand-600)', '#6ee7b7', '#93c5fd' );
				for ( $i = 0; $i < 16; $i++ ) :
					$left  = (int) ( $i * ( 100 / 16 ) + wp_rand( -3, 3 ) );
					$delay = number_format( wp_rand( 0, 55 ) / 100, 2 );
					$color = $confetti_colors[ $i % count( $confetti_colors ) ];
					?>
					<i style="inset-inline-start:<?php echo esc_attr( $left ); ?>%;background:<?php echo esc_attr( $color ); ?>;animation-delay:<?php echo esc_attr( $delay ); ?>s"></i>
				<?php endfor; ?>
			</div>
			<div class="ok-icon">✅</div>
			<h1>خیلی ممنونیم، <?php echo esc_html( $row->author ?: $author ); ?> 🌱</h1>
			<p class="muted">وقتی که گذاشتید برای ما خیلی ارزشمند بود. نظر شما پس از تأیید کارشناسان، زیر محصول «<?php echo esc_html( $pname ); ?>» منتشر می‌شود تا به انتخاب بهتر مشتری‌های بعدی کمک کند.</p>
			<div class="stars-row" aria-hidden="true">
				<?php for ( $i = 1; $i <= 5; $i++ ) : ?>
					<span class="<?php echo ( $i <= (int) $row->rating ) ? 'is-on' : ''; ?>"><svg viewBox="0 0 24 24"><path d="<?php echo esc_attr( $star_path ); ?>"></path></svg></span>
				<?php endfor; ?>
			</div>
			<span class="ok-badge"><?php echo ( 1 === (int) $row->recommend ) ? '👍 پیشنهاد می‌کنید' : '👎 پیشنهاد نمی‌کنید'; ?></span>
		</div>
	<?php else : ?>
		<div class="topbar">
				<button type="button" class="navback is-hidden" id="jsmsBack" aria-label="بازگشت">›</button>
				<div class="progress"><span class="bar" id="jsmsBar"></span></div>
				<span class="step-label" id="jsmsStepLabel">۱/۴</span>
			</div>
			<?php if ( $error ) : ?><div class="err"><?php echo esc_html( $error ); ?></div><?php endif; ?>

		<form method="post" id="jsmsForm">
			<?php wp_nonce_field( 'jsms_review_' . $token, '_jsms_nonce' ); ?>
			<input type="hidden" name="author" value="<?php echo esc_attr( $row->author ); ?>">

			<section class="step is-current" data-step="0">
				<div class="step-body">
					<?php if ( $logo_url ) : ?>
					<div class="logo-wrap"><img class="logo" src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"></div>
					<?php endif; ?>
					<div class="prod center"><?php echo $pimg; ?><div><b><?php echo esc_html( $pname ); ?></b></div></div>
					<h1 class="center">سلام <?php echo esc_html( $author ); ?> 👋</h1>
					<p class="muted center">امیدواریم از خریدتون راضی بوده باشید. فقط ۳۰ ثانیه وقت بذارید و نظرتون رو با ما و مشتری‌های بعدی در میون بذارید.</p>
				</div>
				<button type="button" class="btn btn-primary" data-next>بزن بریم</button>
			</section>

			<section class="step" data-step="1">
				<div class="step-body">
					<h1 class="center">به «<?php echo esc_html( $pname ); ?>» چه امتیازی می‌دید؟</h1>
					<p class="muted center">یک عدد از ۱ تا ۵ انتخاب کنید</p>
					<div class="rate-numbers" role="radiogroup" aria-label="امتیاز از ۱ تا ۵">
						<?php for ( $i = 5; $i >= 1; $i-- ) : ?>
							<input type="radio" name="rating" id="s<?php echo $i; ?>" value="<?php echo $i; ?>" data-caption="<?php echo esc_attr( $rate_captions[ $i ] ); ?>" required>
							<label for="s<?php echo $i; ?>"><?php echo esc_html( $fa_digits[ $i ] ); ?></label>
						<?php endfor; ?>
					</div>
					<div class="rate-caption" id="rateCaption">&nbsp;</div>
					<div class="stars-display" id="starsDisplay" aria-hidden="true">
						<?php for ( $i = 5; $i >= 1; $i-- ) : ?>
							<span class="star" data-i="<?php echo $i; ?>"><svg viewBox="0 0 24 24"><path d="<?php echo esc_attr( $star_path ); ?>"></path></svg></span>
						<?php endfor; ?>
					</div>
				</div>
				<button type="button" class="btn btn-primary" data-next>بعدی</button>
			</section>

			<section class="step" data-step="2">
				<div class="step-body">
					<h1>تجربه‌تون از این محصول رو برامون بنویسید</h1>
					<textarea name="content" id="jsmsContent" required placeholder="مثلاً: کیفیت جنس، بسته‌بندی، زمان ارسال..."></textarea>
					<div class="char-counter" id="jsmsCharCounter">۰ کاراکتر</div>
				</div>
				<button type="button" class="btn btn-primary" data-next>بعدی</button>
			</section>

			<section class="step" data-step="3">
				<div class="step-body">
					<h1>این محصول رو به دوستان‌تون پیشنهاد می‌کنید؟</h1>
					<div class="choices">
						<label class="choice">
							<input type="radio" name="recommend" value="1" required>
							<span class="box"><span class="emoji">👍</span> بله، پیشنهاد می‌کنم</span>
						</label>
						<label class="choice">
							<input type="radio" name="recommend" value="0" required>
							<span class="box"><span class="emoji">👎</span> نه، پیشنهاد نمی‌کنم</span>
						</label>
					</div>
				</div>
				<button type="submit" name="jsms_review_submit" value="1" class="btn btn-primary" id="jsmsSubmit">ثبت نهایی نظر</button>
			</section>
		</form>
	<?php endif; ?>
</div>
</div>
<?php if ( ! $done ) : ?>
<script>
(function(){
	document.documentElement.classList.add('jsms-js');
	var form  = document.getElementById('jsmsForm');
	var steps = Array.prototype.slice.call(form.querySelectorAll('.step'));
	var bar   = document.getElementById('jsmsBar');
	var label = document.getElementById('jsmsStepLabel');
	var back  = document.getElementById('jsmsBack');
	var idx   = 0;

	function faNum(n){ return String(n).replace(/\d/g, function(d){ return '۰۱۲۳۴۵۶۷۸۹'[d]; }); }

	function show(n){
		idx = n;
		steps.forEach(function(s,i){ s.classList.toggle('is-current', i === n); });
		bar.style.width = ( ( n + 1 ) / steps.length * 100 ) + '%';
		if (label) label.textContent = faNum(n + 1) + '/' + faNum(steps.length);
		if (back) back.classList.toggle('is-hidden', n === 0);
	}

	function isStepValid(stepEl){
		var reqs = stepEl.querySelectorAll('[required]');
		for (var i=0; i<reqs.length; i++){
			var el = reqs[i];
			if (el.type === 'radio'){
				if (!stepEl.querySelector('input[name="'+el.name+'"]:checked')) return false;
			} else if (!el.value || !el.value.trim()){
				return false;
			}
		}
		return true;
	}

	function refreshNextButtons(){
		steps.forEach(function(stepEl){
			var btn = stepEl.querySelector('[data-next]');
			if (btn) btn.disabled = !isStepValid(stepEl);
			var submit = stepEl.querySelector('#jsmsSubmit');
			if (submit) submit.disabled = !isStepValid(stepEl);
		});
	}

	// امتیاز عددی → پر شدن خودکار ستاره‌ها + کپشن پویا.
	var ratingInputs = form.querySelectorAll('input[name="rating"]');
	var starEls  = Array.prototype.slice.call(document.querySelectorAll('#starsDisplay .star'));
	var caption  = document.getElementById('rateCaption');
	function syncRating(val){
		var n = parseInt(val, 10) || 0;
		starEls.forEach(function(s){
			s.classList.toggle('is-on', parseInt(s.getAttribute('data-i'), 10) <= n);
		});
	}
	ratingInputs.forEach(function(inp){
		inp.addEventListener('change', function(){
			syncRating(inp.value);
			if (caption) caption.textContent = inp.getAttribute('data-caption') || '';
		});
	});

	// شمارندهٔ کاراکتر متن نظر.
	var content = document.getElementById('jsmsContent');
	var counter = document.getElementById('jsmsCharCounter');
	if (content && counter){
		content.addEventListener('input', function(){
			counter.textContent = faNum(content.value.length) + ' کاراکتر';
		});
	}

	form.addEventListener('click', function(e){
		if (e.target.closest('[data-next]') && idx < steps.length - 1){ show(idx + 1); }
	});
	if (back) back.addEventListener('click', function(){
		if (idx > 0){ show(idx - 1); }
	});
	form.addEventListener('change', refreshNextButtons);
	form.addEventListener('input', refreshNextButtons);

	refreshNextButtons();
	show(0);
})();
</script>
<?php endif; ?>
</body>
</html>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * تأیید مدیر → انتشار زیر محصول به‌عنوان دیدگاه ووکامرس
	 * ------------------------------------------------------------------- */
	public static function approve( $review_id ) {
		global $wpdb;
		$rt  = JSMS_DB::reviews_table();
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$rt} WHERE id=%d", $review_id ) );
		if ( ! $row || 'pending' !== $row->status ) {
			return false;
		}
		$user = $row->user_id ? get_userdata( $row->user_id ) : null;
		$comment_id = wp_insert_comment( array(
			'comment_post_ID'      => $row->product_id,
			'comment_author'       => $row->author ?: 'مشتری',
			'comment_author_email' => $user ? $user->user_email : ( 'sms' . $row->id . '@' . wp_parse_url( home_url(), PHP_URL_HOST ) ),
			'comment_content'      => $row->content,
			'comment_type'         => 'review',
			'user_id'              => $row->user_id,
			'comment_approved'     => 1,
			'comment_meta'         => array(
				'rating'   => (int) $row->rating,
				'verified' => 1,
			),
		) );
		if ( $comment_id ) {
			update_comment_meta( $comment_id, 'rating', (int) $row->rating );
			update_comment_meta( $comment_id, 'verified', 1 );
			$wpdb->update( $rt, array( 'status' => 'approved', 'comment_id' => $comment_id ), array( 'id' => $review_id ) );
			// بازمحاسبهٔ میانگین امتیاز و تعداد نظرات محصول در ووکامرس.
			if ( class_exists( 'WC_Comments' ) ) {
				WC_Comments::clear_transients( $row->product_id );
			}
			wp_update_comment_count( $row->product_id );
			return true;
		}
		return false;
	}

	public static function reject( $review_id ) {
		global $wpdb;
		$wpdb->update( JSMS_DB::reviews_table(), array( 'status' => 'rejected' ), array( 'id' => $review_id ) );
	}

	/* ---------------------------------------------------------------------
	 * خواندن پاسخ پیامکی مشتری (اختیاری – کران)
	 * ------------------------------------------------------------------- */
	public static function poll_incoming() {
		if ( ! jsms_get( 'review_incoming' ) ) {
			return;
		}
		$messages = JSMS_Gateway::get_messages( 100, 0 );
		global $wpdb;
		$rt = JSMS_DB::reviews_table();
		foreach ( (array) $messages as $msg ) {
			$from = JSMS_Gateway::normalize_mobile( $msg['from'] );
			$text = trim( (string) $msg['text'] );
			if ( ! $from || '' === $text ) {
				continue;
			}
			// کلمه لغو → لغو اشتراک.
			if ( in_array( $text, array( 'لغو', 'لغو11', 'off', 'قطع' ), true ) ) {
				JSMS_Consent::opt_out( $from );
				continue;
			}
			// آخرین درخواست نظرِ در انتظارِ این شماره.
			$row = $wpdb->get_row( $wpdb->prepare(
				"SELECT * FROM {$rt} WHERE mobile=%s AND status='requested' ORDER BY id DESC LIMIT 1", $from
			) );
			if ( ! $row ) {
				continue;
			}
			// استخراج امتیاز (اولین عدد ۱ تا ۵).
			$rating = 5;
			if ( preg_match( '/([1-5])/', JSMS_Gateway::fa_to_en( $text ), $m ) ) {
				$rating = (int) $m[1];
			}
			$wpdb->update( $rt, array(
				'rating' => $rating, 'content' => $text, 'status' => 'pending',
			), array( 'id' => $row->id ) );
		}
	}
}
endif;
