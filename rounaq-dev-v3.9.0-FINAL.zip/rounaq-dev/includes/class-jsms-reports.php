<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * نسبت‌دهی درآمد و گزارش‌گیری.
 *
 * دو روش نسبت‌دهی به‌صورت ترکیبی:
 *  ۱) کد تخفیف (دقیق): اگر سفارش با کدی که یک پیامک ساخته ثبت شود، کل درآمد آن سفارش
 *     قطعی به همان اتوماسیون نسبت داده می‌شود. (اولویت با این روش است.)
 *  ۲) پنجرهٔ زمانی (فراگیر): اگر سفارش کد نداشت، در صورتی که مشتری تا N روز پس از دریافت
 *     پیامک خرید کرده باشد، سفارش به آخرین پیامک همان شماره در آن پنجره نسبت داده می‌شود.
 *
 * برای اینکه کدهای پویا قابل‌ردیابی باشند، هنگام ساخت کد، شناسه لاگ پیامک روی متای کوپن
 * ذخیره می‌شود (توسط JSMS_Templates::dispatch از طریق قلاب jsms_coupon_generated).
 */
if ( ! class_exists( 'JSMS_Reports' ) ) :

class JSMS_Reports {

	/** پنجرهٔ زمانی پیش‌فرض نسبت‌دهی (روز). */
	public static function window_days() {
		return (int) apply_filters( 'jsms_attribution_window_days', (int) jsms_get( 'attribution_window_days', 7 ) );
	}

	/**
	 * روند ارسال روزانه در N روز اخیر.
	 * @return array [ ['d'=>'1403/05/01','sent'=>..,'failed'=>..], ... ]
	 */
	public static function daily_trend( $days = 14 ) {
		global $wpdb;
		$t   = JSMS_DB::logs_table();
		$out = array();
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT DATE(created_at) d,
			        SUM(status='sent') sent,
			        SUM(status='failed') failed
			 FROM {$t}
			 WHERE created_at >= %s
			 GROUP BY DATE(created_at) ORDER BY d ASC",
			gmdate( 'Y-m-d 00:00:00', current_time( 'timestamp' ) - $days * DAY_IN_SECONDS )
		), ARRAY_A );

		$map = array();
		foreach ( (array) $rows as $r ) {
			$map[ $r['d'] ] = $r;
		}
		// پر کردن روزهای خالی برای پیوستگی نمودار.
		for ( $i = $days - 1; $i >= 0; $i-- ) {
			$ts  = current_time( 'timestamp' ) - $i * DAY_IN_SECONDS;
			$key = gmdate( 'Y-m-d', $ts );
			$out[] = array(
				'label'  => self::fa_date( $ts ),
				'sent'   => isset( $map[ $key ] ) ? (int) $map[ $key ]['sent'] : 0,
				'failed' => isset( $map[ $key ] ) ? (int) $map[ $key ]['failed'] : 0,
			);
		}
		return $out;
	}

	/**
	 * نسبت‌دهی درآمد به تفکیک نوع اتوماسیون.
	 * @return array [ type => ['orders'=>..,'revenue'=>..,'sent'=>..,'exact'=>..,'window'=>..] ]
	 */
	public static function attribution( $days = 30 ) {
		global $wpdb;
		$t     = JSMS_DB::logs_table();
		$since = current_time( 'timestamp' ) - $days * DAY_IN_SECONDS;
		$win   = self::window_days();

		$result = array();
		$counted_orders = array(); // جلوگیری از شمارش دوبارهٔ یک سفارش.

		// تعداد ارسال هر نوع (برای نرخ تبدیل).
		$sent_rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT type, COUNT(*) c FROM {$t} WHERE status='sent' AND created_at >= %s GROUP BY type",
			gmdate( 'Y-m-d H:i:s', $since )
		), ARRAY_A );
		foreach ( (array) $sent_rows as $r ) {
			$result[ $r['type'] ] = array( 'orders' => 0, 'revenue' => 0, 'sent' => (int) $r['c'], 'exact' => 0, 'window' => 0, 'cart_link' => 0 );
		}

		// نسبت‌دهیِ سبدِ رهاشده از روی خودِ ستون order_id جدول سبدها — این لینک را
		// mark_cart_recovered() همان لحظهٔ تکمیل سفارش می‌نویسد (با تطبیق user_id یا
		// شمارهٔ *فعلیِ* سبد)، پس همیشه با چیزی که «نرخ بازگشت سبد» را محاسبه می‌کند
		// یکی است. تطبیقِ پنجرهٔ زمانی/شماره (پایین‌تر) این را نمی‌بیند چون شمارهٔ
		// ثبت‌شده در لاگِ پیامکِ سبدِ رهاشده ممکن است با شمارهٔ نهاییِ فاکتور فرق کند
		// (مثلاً مشتری موقع تکمیلِ سفارش شماره را عوض کرده) — و همین باعث می‌شد جدول
		// نسبت‌دهی برای «سبد رها شده» همیشه صفر بماند در حالی که نرخ بازگشتِ سبد صفر نبود.
		$cart_order_stage = array();
		$cart_rows = $wpdb->get_results(
			"SELECT order_id, notified FROM " . JSMS_DB::carts_table() . " WHERE order_id > 0 AND recovered = 1"
		);
		foreach ( (array) $cart_rows as $cr ) {
			$cart_order_stage[ (int) $cr->order_id ] = (int) $cr->notified >= 2 ? 'abandoned_cart_2' : 'abandoned_cart';
		}

		// عمداً فقط processing/completed را حساب نمی‌کنیم — این فروشگاه وضعیت‌های سفارشیِ
		// زیادی دارد (آماده‌سازی، بسته‌بندی، تحویل پیک/پست/تیپاکس و…) که همه یعنی سفارش
		// واقعاً قطعی/پرداخت‌شده است. هر وضعیتی به‌جز «در انتظار پرداخت»، «لغوشده»،
		// «ناموفق»، «مسترد شده» و «پیش‌نویس» را «فروش واقعی» حساب می‌کنیم.
		//
		// عمداً status=>'any' گرفته می‌شود و فیلترِ استثناها بعداً در PHP انجام می‌شود —
		// دادن آرایهٔ بزرگِ وضعیت‌های سفارشی (array_diff روی array_keys) به wc_get_orders
		// باعث می‌شد هیچ سفارشی برنگردد (این همان دلیل واقعیِ صفر بودن کامل جدول
		// نسبت‌دهی برای *همهٔ* انواع پیام بود، نه فقط نرخ تبدیل واقعاً پایین).
		// همچنین از time() (نه current_time) استفاده می‌شود چون date_created سفارش‌های
		// ووکامرس بر پایهٔ UTC واقعی است، نه زمانِ جابه‌جاشدهٔ سایتِ current_time().
		$excluded = array( 'pending', 'cancelled', 'failed', 'refunded', 'draft', 'trash' );
		$since_real_utc = time() - $days * DAY_IN_SECONDS;

		$orders = wc_get_orders( array(
			'limit'        => -1,
			'status'       => 'any',
			'date_created' => '>' . $since_real_utc,
			'return'       => 'objects',
		) );

		foreach ( (array) $orders as $order ) {
			if ( in_array( $order->get_status(), $excluded, true ) ) {
				continue;
			}
			$oid = $order->get_id();
			if ( isset( $counted_orders[ $oid ] ) ) {
				continue;
			}
			$type    = '';
			$method  = '';

			// ۰) لینکِ مستقیمِ سبدِ رهاشده (قابل‌اتکاترین روش، چون مستقل از شمارهٔ
			// تلفن است — همان user_id/سبدی که واقعاً به این سفارش تبدیل شده).
			if ( isset( $cart_order_stage[ $oid ] ) ) {
				$type   = $cart_order_stage[ $oid ];
				$method = 'cart_link';
			}

			// ۱) نسبت‌دهی دقیق با کد تخفیف.
			if ( ! $type ) foreach ( $order->get_coupon_codes() as $code ) {
				$cid = wc_get_coupon_id_by_code( $code );
				if ( ! $cid ) {
					continue;
				}
				$log_type = get_post_meta( $cid, '_jsms_source_type', true );
				if ( $log_type ) {
					$type   = $log_type;
					$method = 'exact';
					break;
				}
			}

			// ۲) نسبت‌دهی پنجرهٔ زمانی.
			if ( ! $type ) {
				$mobile = $order->get_billing_phone();
				$mobile = JSMS_Gateway::normalize_mobile( $mobile );
				if ( $mobile ) {
					// created_at جدول لاگ با current_time('mysql') ذخیره می‌شود (زمانِ
					// جابه‌جاشدهٔ سایت)، ولی get_date_created() سفارش UTC واقعی است —
					// باید هر دو به یک مبنا تبدیل شوند وگرنه پنجره چند ساعت جابه‌جا می‌شود.
					$order_ts = $order->get_date_created() ? $order->get_date_created()->getTimestamp() : 0;
					$order_ts = $order_ts ? $order_ts + ( (float) get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) : 0;
					$from     = gmdate( 'Y-m-d H:i:s', $order_ts - $win * DAY_IN_SECONDS );
					$to       = gmdate( 'Y-m-d H:i:s', $order_ts );
					$last     = $wpdb->get_var( $wpdb->prepare(
						"SELECT type FROM {$t} WHERE mobile=%s AND status='sent'
						 AND type NOT IN ('order','test','admin_alert','cashback','wallet_redeem','admin_new_order','admin_receipt','admin_low_stock')
						 AND created_at BETWEEN %s AND %s ORDER BY created_at DESC LIMIT 1",
						$mobile, $from, $to
					) );
					if ( $last ) {
						$type   = $last;
						$method = 'window';
					}
				}
			}

			if ( ! $type ) {
				continue;
			}
			if ( ! isset( $result[ $type ] ) ) {
				$result[ $type ] = array( 'orders' => 0, 'revenue' => 0, 'sent' => 0, 'exact' => 0, 'window' => 0, 'cart_link' => 0 );
			}
			$result[ $type ]['orders']  += 1;
			$result[ $type ]['revenue'] += (float) $order->get_total();
			$result[ $type ][ $method ] += 1;
			$counted_orders[ $oid ] = 1;
		}

		return $result;
	}

	/**
	 * قیف تبدیل سبد خرید رها شده: از روی جدول واقعی سبدها (نه حدس زمانی)،
	 * چند سبدِ اطلاع‌رسانی‌شده واقعاً به سفارش تبدیل شدند.
	 */
	public static function cart_funnel() {
		global $wpdb;
		$t = JSMS_DB::carts_table();
		return array(
			'stage1_sent'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE notified>=1" ),
			'stage1_recovered' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE notified>=1 AND recovered=1" ),
			'stage2_sent'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE notified>=2" ),
			'stage2_recovered' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE notified>=2 AND recovered=1" ),
		);
	}

	/**
	 * قیف تبدیل درخواست نظر: از هر لینکِ ارسال‌شده، چند نفر واقعاً فرم را پر کردند
	 * و از آن‌ها چند نظر تأیید شد.
	 */
	public static function review_funnel() {
		global $wpdb;
		$t = JSMS_DB::reviews_table();
		return array(
			'requested' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t}" ),
			'responded' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE status!='requested'" ),
			'approved'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE status='approved'" ),
		);
	}

	/**
	 * نرخ تحویل پیامک (کل و به تفکیک نوع، فقط انواعی که واقعاً شکست داشته‌اند).
	 */
	public static function delivery_stats( $days = 30 ) {
		global $wpdb;
		$t = JSMS_DB::logs_table();
		$since = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - $days * DAY_IN_SECONDS );
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE created_at >= %s", $since ) );
		$failed = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE status='failed' AND created_at >= %s", $since ) );
		$by_type = $wpdb->get_results( $wpdb->prepare(
			"SELECT type, COUNT(*) c FROM {$t} WHERE status='failed' AND created_at >= %s GROUP BY type ORDER BY c DESC",
			$since
		), ARRAY_A );
		return array(
			'total'  => $total,
			'failed' => $failed,
			'rate'   => $total ? round( ( $total - $failed ) / $total * 100, 1 ) : 100,
			'by_type_failed' => $by_type,
		);
	}

	/**
	 * میانگین ارزش سفارش (AOV) برای سفارش‌های منتسب‌شده به اتوماسیون‌ها.
	 */
	public static function average_order_value( $days = 30 ) {
		$attr = self::attribution( $days );
		$orders = 0; $revenue = 0;
		foreach ( $attr as $a ) { $orders += $a['orders']; $revenue += $a['revenue']; }
		return $orders ? round( $revenue / $orders ) : 0;
	}

	/**
	 * محصولاتی که بیشتر از همه در سبدهای رهاشده (و هنوز بازیابی‌نشده) دیده شده‌اند —
	 * سرنخ مستقیم برای اینکه کدام محصول در چک‌اوت مشتری را پشیمان می‌کند (قیمت،
	 * موجودی، هزینهٔ ارسال و…). فقط از items_json واقعیِ سبدها می‌خواند، نه حدس.
	 */
	public static function top_abandoned_products( $days = 30, $limit = 5 ) {
		global $wpdb;
		$t = JSMS_DB::carts_table();
		$since = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - $days * DAY_IN_SECONDS );
		$rows = $wpdb->get_col( $wpdb->prepare(
			"SELECT items_json FROM {$t} WHERE notified>=1 AND recovered=0 AND items_json IS NOT NULL AND created_at >= %s",
			$since
		) );
		$tally = array();
		foreach ( (array) $rows as $json ) {
			$lines = json_decode( $json, true );
			if ( ! is_array( $lines ) ) {
				continue;
			}
			foreach ( $lines as $line ) {
				$name = trim( (string) ( $line['name'] ?? '' ) );
				if ( ! $name ) {
					continue;
				}
				$tally[ $name ] = ( $tally[ $name ] ?? 0 ) + 1;
			}
		}
		arsort( $tally );
		return array_slice( $tally, 0, $limit, true );
	}

	/**
	 * ساخت فهرست پیشنهادهای عملی بر اساس دادهٔ واقعی سایت — نه توصیهٔ کلی، بلکه
	 * دقیقاً چیزی که از رفتار واقعیِ ارسال‌ها/سبدها/نظرات در همین بازه دیده می‌شود.
	 * هر آیتم: ['level' => 'good'|'warn'|'info', 'text' => '...']
	 */
	public static function insights( $days = 30 ) {
		$out = array();
		$attr = self::attribution( $days );
		$cf   = self::cart_funnel();
		$rf   = self::review_funnel();
		$dv   = self::delivery_stats( $days );
		$labels = JSMS_Admin::type_labels();

		// ۱) بهترین و ضعیف‌ترین اتوماسیون از نظر نرخ تبدیل (با حجم ارسال معنادار).
		$best = null; $worst = null;
		foreach ( $attr as $type => $r ) {
			if ( $r['sent'] < 10 ) { // حجم کم → نرخ تبدیل قابل‌اتکا نیست.
				continue;
			}
			$cr = $r['orders'] / $r['sent'] * 100;
			if ( ! $best || $cr > $best['cr'] ) { $best = array( 'type' => $type, 'cr' => $cr, 'r' => $r ); }
			if ( ! $worst || $cr < $worst['cr'] ) { $worst = array( 'type' => $type, 'cr' => $cr, 'r' => $r ); }
		}
		if ( $best && $best['cr'] > 0 ) {
			$out[] = array( 'level' => 'good', 'text' => sprintf(
				'بهترین نرخ تبدیل مربوط به «%s» است (%s٪ از %s پیامک به سفارش تبدیل شده، جمعاً %s تومان). این اتوماسیون دارد نتیجه می‌دهد — نگهش دارید و اگر امکانش هست مخاطبانش را گسترش بدهید.',
				$labels[ $best['type'] ] ?? $best['type'], round( $best['cr'], 1 ), number_format( $best['r']['sent'] ), number_format( $best['r']['revenue'] )
			) );
			if ( $worst && $worst['type'] !== $best['type'] && $worst['cr'] < 3 ) {
				$out[] = array( 'level' => 'warn', 'text' => sprintf(
					'نرخ تبدیل «%s» پایین است (%s٪ از %s پیامک). ارزش دارد متن پیام یا زمان‌بندی ارسالش را بازبینی کنید.',
					$labels[ $worst['type'] ] ?? $worst['type'], round( $worst['cr'], 1 ), number_format( $worst['r']['sent'] )
				) );
			}
		} elseif ( $best ) {
			// همهٔ اتوماسیون‌های با حجم معنادار، صفر سفارش آورده‌اند — این خودش یک هشدار
			// جدی است، نه یک «بهترین» دروغین.
			$out[] = array( 'level' => 'warn', 'text' => sprintf(
				'در این بازه، هیچ‌کدام از اتوماسیون‌ها (با حجم ارسال معنادار، مثلاً «%s» با %s پیامک) به سفارش قطعی منجر نشده‌اند. یا نسبت‌دهی درآمد این بازه را بازبینی کنید یا متن/زمان‌بندی پیام‌ها را بررسی کنید.',
				$labels[ $best['type'] ] ?? $best['type'], number_format( $best['r']['sent'] )
			) );
		}

		// ۲) سبد رها شده: مرحله ۱ در برابر مرحله ۲.
		if ( $cf['stage1_sent'] >= 10 ) {
			$rate1 = round( $cf['stage1_recovered'] / $cf['stage1_sent'] * 100, 1 );
			if ( $cf['stage2_sent'] < 1 ) {
				$out[] = array( 'level' => 'info', 'text' => sprintf(
					'مرحلهٔ ۱ سبد رها شده (%s٪ بازگشت از %s ارسال) دارد کار می‌کند، ولی مرحلهٔ ۲ (پیام تشویقی با کد تخفیف) هنوز فعال/ارسال نشده. فعال کردنش می‌تواند بخشی از همان مشتریانی که با یادآوریِ سادهٔ اول برنگشتند را با یک انگیزهٔ مالی برگرداند.',
					$rate1, number_format( $cf['stage1_sent'] )
				) );
			} else {
				$rate2 = round( $cf['stage2_recovered'] / $cf['stage2_sent'] * 100, 1 );
				if ( $rate2 > $rate1 * 1.3 ) {
					$out[] = array( 'level' => 'good', 'text' => sprintf(
						'مرحلهٔ ۲ سبد رها شده (کد تخفیف) نرخ بازگشتش (%s٪) بهتر از مرحلهٔ ۱ (%s٪) است — یعنی تخفیف واقعاً تعیین‌کننده است. شاید ارزش داشته باشد یادآوریِ اول هم زودتر برود یا لحن مشابهی بگیرد.',
						$rate2, $rate1
					) );
				}
			}
		}

		// ۳) محصول پرتکرار در سبدهای رهاشده.
		$top_products = self::top_abandoned_products( $days, 1 );
		if ( $top_products ) {
			$name = array_key_first( $top_products );
			$count = reset( $top_products );
			if ( $count >= 3 ) {
				$out[] = array( 'level' => 'warn', 'text' => sprintf(
					'محصول «%s» بیشتر از بقیه (%s بار) در سبدهای رهاشده دیده شده. ارزش دارد قیمت، موجودی، هزینهٔ ارسال یا توضیحات همین محصول را دوباره بررسی کنید — شاید همان چیزی است که مشتری را در لحظهٔ آخر منصرف می‌کند.',
					$name, number_format( $count )
				) );
			}
		}

		// ۴) نرخ پاسخ درخواست نظر.
		if ( $rf['requested'] >= 10 ) {
			$resp_rate = round( $rf['responded'] / $rf['requested'] * 100, 1 );
			if ( $resp_rate < 15 ) {
				$out[] = array( 'level' => 'warn', 'text' => sprintf(
					'فقط %s٪ از درخواست‌های ثبت نظر پاسخ گرفته‌اند (%s از %s). اگر یادآوریِ ۳ روزهٔ نظر خاموش است، فعالش کنید؛ یا زمان اولین درخواست (بعد از تحویل) را کمی جلوتر/عقب‌تر ببرید.',
					$resp_rate, number_format( $rf['responded'] ), number_format( $rf['requested'] )
				) );
			}
		}

		// ۵) نرخ کلی تحویل پیامک.
		if ( $dv['total'] >= 20 && $dv['rate'] < 90 ) {
			$out[] = array( 'level' => 'warn', 'text' => sprintf(
				'نرخ تحویل کلی پیامک‌ها در این بازه %s٪ است (%s پیامک از %s ناموفق بوده). اعتبار خط/پنل پیامکی را چک کنید — نرخ پایین تحویل مستقیماً یعنی مشتری‌هایی که اصلاً پیام شما را ندیده‌اند.',
				$dv['rate'], number_format( $dv['failed'] ), number_format( $dv['total'] )
			) );
		}

		// ۶) مشتریان غیرفعال — اگر خاموش است ولی داده نشون می‌ده مخاطب داره.
		if ( ! jsms_get( 'inactive_enabled' ) ) {
			$out[] = array( 'level' => 'info', 'text' => 'اتوماسیون «مشتریان غیرفعال» الان خاموش است. این پیام مستقیماً برای بازگرداندن خریدارانِ قبلی طراحی شده — فعال کردنش یکی از کم‌هزینه‌ترین راه‌های افزایش فروش از مخاطبانی است که از قبل شما را می‌شناسند.' );
		}

		return $out;
	}

	/**
	 * خلاصهٔ کیف‌پول/کش‌بک برای کارت داشبورد: مجموع کش‌بکِ اعطاشده، مجموع برداشت‌شده،
	 * و موجودیِ باقی‌ماندهٔ همهٔ مشتریان روی هم (که همیشه باید برابر تفاضل آن دو باشد —
	 * از خودِ دفترکل جمع زده می‌شود، نه دوباره محاسبه، تا با get_balance() هر کاربر یکی بماند).
	 */
	public static function wallet_stats( $days = 30 ) {
		global $wpdb;
		$t = JSMS_DB::wallet_table();
		$since = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - $days * DAY_IN_SECONDS );
		return array(
			'credited'    => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(amount),0) FROM {$t} WHERE type='cashback' AND created_at>=%s", $since ) ),
			'redeemed'    => (int) abs( $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(amount),0) FROM {$t} WHERE type='redeem' AND created_at>=%s", $since ) ) ),
			'outstanding' => (int) $wpdb->get_var( "SELECT COALESCE(SUM(amount),0) FROM {$t}" ),
		);
	}

	/**
	 * ارسال/درآمدِ کمپین‌ها در بازه — از همان attribution() که کد تخفیف/پنجرهٔ زمانی
	 * را قبلاً محاسبه کرده، فقط ردیف نوع «کمپین» را بیرون می‌کشد.
	 */
	public static function campaign_stats( $days = 30 ) {
		$attr = self::attribution( $days );
		return $attr['campaign'] ?? array( 'orders' => 0, 'revenue' => 0, 'sent' => 0 );
	}

	private static function fa_date( $ts ) {
		// تاریخ کوتاه میلادی؛ برای برچسب محور نمودار کافی است.
		return gmdate( 'm/d', $ts );
	}
}
endif;
