<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * تولید کد تخفیف پویا و اختصاصی برای هر گیرنده.
 * هر پیام حاوی {coupon} یک کوپن یکتای ووکامرس می‌سازد که:
 *  - یک‌بار مصرف است (usage_limit = 1)
 *  - در صورت داشتن ایمیل، فقط برای همان مشتری معتبر است
 *  - تاریخ انقضا دارد (پیش‌فرض از تنظیمات)
 * این کار امکان ردیابی دقیق و جلوگیری از لو رفتن کد را فراهم می‌کند.
 */
if ( ! class_exists( 'JSMS_Coupons' ) ) :

class JSMS_Coupons {

	/**
	 * ساخت یک کوپن با مشخصات دلخواه و برگرداندن کد آن.
	 *
	 * @param array $args {
	 *   @type float  $amount        مبلغ/درصد تخفیف.
	 *   @type string $type          'percent'|'fixed_cart'.
	 *   @type int    $expiry_days   انقضا بر اساس «چند روز از الان» (نادیده گرفته می‌شود اگر expires_at داده شود).
	 *   @type string $expires_at    انقضا با تاریخ دقیق (Y-m-d)؛ خالی = بدون انقضا/بر اساس expiry_days.
	 *   @type string $email         اگر پر باشد، کد فقط برای همین ایمیل مصرف می‌شود (کد اختصاصیِ یک مشتری).
	 *   @type int    $usage_limit   تعداد دفعات مصرفِ کل کد. ۱ = یک‌بار مصرف (پیش‌فرض). ۰ = نامحدود (برای «کد عمومی همهٔ مشتریان»).
	 *   @type bool   $individual_use اگر false باشد، همراه سایر کدهای تخفیف هم قابل استفاده است.
	 *   @type string $code          کد دلخواه؛ خالی = تولید خودکار.
	 *   @type string $prefix        پیشوند کد خودکار (وقتی $code خالی باشد).
	 *   @type string $description
	 * }
	 * @return string کد کوپن (در صورت خطا رشته خالی)
	 */
	public static function generate( $args = array() ) {
		if ( ! class_exists( 'WC_Coupon' ) ) {
			return '';
		}
		$args = wp_parse_args( $args, array(
			'amount'         => (float) jsms_get( 'coupon_amount', 10 ),
			'type'           => jsms_get( 'coupon_type', 'percent' ),
			'expiry_days'    => (int) jsms_get( 'coupon_expiry_days', 3 ),
			'expires_at'     => '',
			'email'          => '',
			'usage_limit'    => 1,
			'individual_use' => true,
			'code'           => '',
			'prefix'         => jsms_get( 'coupon_prefix', 'JL' ),
			'description'    => 'کد اختصاصی رونق',
			'source_type'    => '',
		) );

		$code = $args['code'] ? self::sanitize_code( $args['code'] ) : self::unique_code( $args['prefix'] );
		if ( '' === $code || ( $args['code'] && self::code_exists( $code ) ) ) {
			return '';
		}

		try {
			$coupon = new WC_Coupon();
			$coupon->set_code( $code );
			$coupon->set_discount_type( 'fixed_cart' === $args['type'] ? 'fixed_cart' : 'percent' );
			$coupon->set_amount( (float) $args['amount'] );
			$coupon->set_individual_use( (bool) $args['individual_use'] );
			$coupon->set_usage_limit( max( 0, (int) $args['usage_limit'] ) ); // ۰ = نامحدود در ووکامرس.
			$coupon->set_description( $args['description'] );
			if ( $args['expires_at'] ) {
				$coupon->set_date_expires( strtotime( $args['expires_at'] . ' 23:59:59' ) );
			} elseif ( $args['expiry_days'] > 0 ) {
				$coupon->set_date_expires( time() + $args['expiry_days'] * DAY_IN_SECONDS );
			}
			if ( ! empty( $args['email'] ) && is_email( $args['email'] ) ) {
				$coupon->set_email_restrictions( array( $args['email'] ) );
			}
			$coupon->save();
			// برچسب منبع برای نسبت‌دهی دقیق درآمد.
			if ( ! empty( $args['source_type'] ) ) {
				update_post_meta( $coupon->get_id(), '_jsms_source_type', sanitize_key( $args['source_type'] ) );
			}
		} catch ( Exception $e ) {
			return '';
		}
		return $code;
	}

	private static function sanitize_code( $code ) {
		return strtoupper( preg_replace( '/[^A-Za-z0-9\-]/', '', (string) $code ) );
	}

	/**
	 * ساخت کد برای یک گیرنده مشخص (ایمیل از روی کاربر استخراج می‌شود).
	 */
	public static function for_recipient( $user_id = 0, $mobile = '', $source_type = '' ) {
		$email = '';
		if ( $user_id ) {
			$u = get_userdata( $user_id );
			if ( $u ) {
				$email = $u->user_email;
			}
		}
		return self::generate( array( 'email' => $email, 'source_type' => $source_type ) );
	}

	private static function unique_code( $prefix ) {
		$prefix = preg_replace( '/[^A-Za-z0-9]/', '', (string) $prefix );
		do {
			$code = strtoupper( $prefix . wp_generate_password( 5, false, false ) );
		} while ( self::code_exists( $code ) );
		return $code;
	}

	private static function code_exists( $code ) {
		if ( function_exists( 'wc_get_coupon_id_by_code' ) ) {
			return (bool) wc_get_coupon_id_by_code( $code );
		}
		return false;
	}
}
endif;
