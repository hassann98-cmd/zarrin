<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * آپدیتِ خودکار خودمیزبان (بدون نیاز به WordPress.org). با یک فایل JSON کوچک
 * که خودتان جایی (سرور خودتان، یک ریپوی گیت‌هاب و…) میزبانی می‌کنید کار می‌کند؛
 * هر بار نسخهٔ تازه منتشر کردید، فقط همین یک فایل را به‌روز کنید — از آن به بعد
 * دکمهٔ «به‌روزرسانی» همیشگیِ خودِ وردپرس (صفحهٔ افزونه‌ها) نسخهٔ جدید را
 * دقیقاً روی همان مسیر قبلی جایگزین می‌کند، درست مثل هر افزونهٔ دیگری.
 *
 * فرمت فایل manifest.json که باید میزبانی کنید:
 * {
 *   "version": "3.6.0",
 *   "download_url": "https://example.com/downloads/rounaq-3.6.0.zip",
 *   "requires": "5.8",
 *   "tested": "6.6",
 *   "requires_php": "7.4",
 *   "last_updated": "2026-08-25",
 *   "sections": { "description": "...", "changelog": "<h4>3.6.0</h4><ul><li>...</li></ul>" }
 * }
 *
 * آدرس این manifest را در تنظیمات «تنظیمات اتصال ← به‌روزرسانی» وارد کنید.
 */
if ( ! class_exists( 'JSMS_Updater' ) ) :

class JSMS_Updater {

	const CACHE_KEY = 'jsms_update_manifest';

	public static function init() {
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'check_update' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'plugin_info' ), 20, 3 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'clear_cache' ), 10, 0 );
	}

	private static function manifest_url() {
		return trim( (string) jsms_get( 'update_manifest_url', '' ) );
	}

	private static function fetch_manifest( $force = false ) {
		$url = self::manifest_url();
		if ( ! $url ) {
			return null;
		}
		if ( ! $force ) {
			$cached = get_transient( self::CACHE_KEY );
			if ( false !== $cached ) {
				return $cached;
			}
		}
		$res = wp_remote_get( $url, array( 'timeout' => 15 ) );
		if ( is_wp_error( $res ) || 200 !== wp_remote_retrieve_response_code( $res ) ) {
			set_transient( self::CACHE_KEY, null, 15 * MINUTE_IN_SECONDS );
			return null;
		}
		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( ! is_array( $data ) || empty( $data['version'] ) || empty( $data['download_url'] ) ) {
			set_transient( self::CACHE_KEY, null, 15 * MINUTE_IN_SECONDS );
			return null;
		}
		// چک هر ۱۲ ساعت — نه هر بار که مدیر وارد پیشخوان می‌شود.
		set_transient( self::CACHE_KEY, $data, 12 * HOUR_IN_SECONDS );
		return $data;
	}

	public static function clear_cache() {
		delete_transient( self::CACHE_KEY );
	}

	/**
	 * تست فوری (بدون کش) — برای دکمهٔ «بررسی الان» در تنظیمات.
	 */
	public static function check_now() {
		$data = self::fetch_manifest( true );
		if ( ! $data ) {
			return array( 'ok' => false, 'error' => 'دریافت اطلاعات آپدیت ناموفق بود — آدرس manifest را بررسی کنید.' );
		}
		$has_update = version_compare( $data['version'], JSMS_VERSION, '>' );
		return array(
			'ok' => true,
			'has_update' => $has_update,
			'latest' => $data['version'],
			'current' => JSMS_VERSION,
		);
	}

	public static function check_update( $transient ) {
		if ( empty( $transient->checked ) ) {
			return $transient;
		}
		$data = self::fetch_manifest();
		if ( ! $data || version_compare( $data['version'], JSMS_VERSION, '<=' ) ) {
			return $transient;
		}
		$item = (object) array(
			'id'          => JSMS_BASENAME,
			'slug'        => dirname( JSMS_BASENAME ),
			'plugin'      => JSMS_BASENAME,
			'new_version' => $data['version'],
			'url'         => $data['homepage'] ?? '',
			'package'     => $data['download_url'],
			'tested'      => $data['tested'] ?? '',
			'requires'    => $data['requires'] ?? '',
			'requires_php'=> $data['requires_php'] ?? '',
		);
		$transient->response[ JSMS_BASENAME ] = $item;
		return $transient;
	}

	public static function plugin_info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || $args->slug !== dirname( JSMS_BASENAME ) ) {
			return $result;
		}
		$data = self::fetch_manifest();
		if ( ! $data ) {
			return $result;
		}
		return (object) array(
			'name'          => 'رونق',
			'slug'          => dirname( JSMS_BASENAME ),
			'version'       => $data['version'],
			'requires'      => $data['requires'] ?? '',
			'tested'        => $data['tested'] ?? '',
			'requires_php'  => $data['requires_php'] ?? '',
			'last_updated'  => $data['last_updated'] ?? '',
			'homepage'      => $data['homepage'] ?? '',
			'download_link' => $data['download_url'],
			'sections'      => $data['sections'] ?? array( 'description' => '' ),
		);
	}
}
endif;
