<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * کمپین‌های پیامکی انبوه با بخش‌بندی مشتریان و ارسال دسته‌ای.
 */
if ( ! class_exists( 'JSMS_Campaigns' ) ) :

class JSMS_Campaigns {

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_jsms_campaign_send', array( $this, 'ajax_send_batch' ) );
		add_action( 'wp_ajax_jsms_campaign_count', array( $this, 'ajax_count' ) );
	}

	/**
	 * شمارش مخاطبان برای مرحله پیش‌نمایش ویزارد.
	 */
	public function ajax_count() {
		check_ajax_referer( 'jsms_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'دسترسی غیرمجاز' );
		}
		$segment  = sanitize_key( $_POST['segment'] ?? 'customers' );
		$custom   = wp_unslash( $_POST['custom'] ?? '' );
		$days     = (int) ( $_POST['days'] ?? 0 );
		$audience = self::build_audience( $segment, $custom, $days );
		wp_send_json_success( array( 'count' => count( $audience ) ) );
	}

	/**
	 * ساخت لیست شماره‌ها بر اساس بخش انتخابی.
	 */
	public static function build_audience( $segment, $custom = '', $days = 0 ) {
		$mobiles = array();

		switch ( $segment ) {
			case 'custom':
				foreach ( preg_split( '/[\s,;\n]+/', JSMS_Gateway::fa_to_en( $custom ) ) as $line ) {
					$m = JSMS_Gateway::normalize_mobile( $line );
					if ( $m ) {
						$mobiles[ $m ] = array( 'mobile' => $m, 'user_id' => 0, 'first_name' => '' );
					}
				}
				break;

			case 'buyers':   // کسانی که حداقل یک خرید دارند
			case 'inactive': // خریداران غیرفعال از N روز پیش
				// عمداً ابتدا فقط شناسهٔ سفارش‌ها گرفته می‌شود (return=ids)، نه آبجکت کامل —
				// روی فروشگاه‌های بزرگ (دهها/صدها هزار سفارش)، نگه‌داشتن همهٔ WC_Order در
				// حافظه هم‌زمان می‌تواند به کمبود حافظه/تایم‌اوت بینجامد. سقفی هم گذاشته شده
				// تا حتی روی بزرگ‌ترین فروشگاه‌ها یک درخواست از پا نیفتد.
				$args = array(
					'limit' => 20000, 'return' => 'ids', 'orderby' => 'date', 'order' => 'DESC',
					'status' => array( 'wc-completed', 'wc-processing' ),
				);
				if ( 'inactive' === $segment && $days > 0 ) {
					$args['date_created'] = '<' . strtotime( "-{$days} days" );
				}
				$order_ids = wc_get_orders( $args );
				$auto = JSMS_Automations::instance();
				foreach ( (array) $order_ids as $order_id ) {
					$order = wc_get_order( $order_id );
					if ( ! $order ) {
						continue;
					}
					$m = $auto->order_mobile( $order );
					if ( $m && ! isset( $mobiles[ $m ] ) ) {
						if ( 'inactive' === $segment && $days > 0 && $auto->user_ordered_since( $order->get_customer_id(), $m, "-{$days} days" ) ) {
							continue;
						}
						$mobiles[ $m ] = array(
							'mobile' => $m,
							'user_id' => $order->get_customer_id(),
							'first_name' => $order->get_billing_first_name(),
						);
					}
				}
				break;

			case 'customers': // همه کاربران با نقش مشتری
			default:
				$users = get_users( array( 'role' => 'customer', 'fields' => array( 'ID' ) ) );
				$auto = JSMS_Automations::instance();
				foreach ( $users as $u ) {
					$m = $auto->user_mobile( $u->ID );
					if ( $m && ! isset( $mobiles[ $m ] ) ) {
						$vars = JSMS_Templates::user_vars( $u->ID );
						$mobiles[ $m ] = array( 'mobile' => $m, 'user_id' => $u->ID, 'first_name' => $vars['first_name'] ?? '' );
					}
				}
				break;
		}

		// حذف لغو اشتراک‌کرده‌ها.
		if ( jsms_get( 'respect_optout', 1 ) ) {
			foreach ( array_keys( $mobiles ) as $m ) {
				if ( JSMS_Consent::is_opted_out( $m ) ) {
					unset( $mobiles[ $m ] );
				}
			}
		}
		return array_values( $mobiles );
	}

	/**
	 * ارسال دسته‌ای از طریق AJAX (برای جلوگیری از تایم‌اوت).
	 */
	public function ajax_send_batch() {
		check_ajax_referer( 'jsms_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'دسترسی غیرمجاز' );
		}

		$campaign = sanitize_key( $_POST['campaign'] ?? 'c' . time() );
		$offset   = (int) ( $_POST['offset'] ?? 0 );
		$limit    = 25;
		$segment  = sanitize_key( $_POST['segment'] ?? 'customers' );
		$custom   = wp_unslash( $_POST['custom'] ?? '' );
		$days     = (int) ( $_POST['days'] ?? 0 );
		$text     = wp_unslash( $_POST['text'] ?? '' );

		$key = 'jsms_camp_' . $campaign;
		$audience = get_transient( $key );
		if ( false === $audience ) {
			$audience = self::build_audience( $segment, $custom, $days );
			set_transient( $key, $audience, HOUR_IN_SECONDS );
		}

		$total = count( $audience );
		$slice = array_slice( $audience, $offset, $limit );
		$sent  = 0; $failed = 0;

		foreach ( $slice as $person ) {
			$vars = array( 'first_name' => $person['first_name'] );
			if ( $person['user_id'] ) {
				$vars = array_merge( $vars, JSMS_Templates::user_vars( $person['user_id'] ) );
			}
			$res = JSMS_Templates::dispatch( array(
				'to' => $person['mobile'], 'user_id' => $person['user_id'], 'type' => 'campaign',
				'mode' => 'text',
				'text' => JSMS_Templates::render( $text, $vars ),
			) );
			$res['ok'] ? $sent++ : $failed++;
		}

		$next = $offset + $limit;
		$done = $next >= $total;
		if ( $done ) {
			delete_transient( $key );
		}

		wp_send_json_success( array(
			'total'  => $total,
			'offset' => $next,
			'sent'   => $sent,
			'failed' => $failed,
			'done'   => $done,
		) );
	}
}
endif;
