<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * زمان‌بندی و اجرای اسکن‌های دوره‌ای.
 */
if ( ! class_exists( 'JSMS_Cron' ) ) :

class JSMS_Cron {

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_filter( 'cron_schedules', array( $this, 'add_schedules' ) );
		add_action( 'jsms_cron_cart', array( $this, 'run_cart' ) );
		add_action( 'jsms_cron_frequent', array( $this, 'run_frequent' ) );
		add_action( 'jsms_cron_daily', array( $this, 'run_daily' ) );
		// اطمینان از زمان‌بندی در صورت نبودن.
		add_action( 'init', array( __CLASS__, 'schedule_events' ) );
	}

	public function add_schedules( $s ) {
		$s['jsms_5min']  = array( 'interval' => 5 * MINUTE_IN_SECONDS, 'display' => 'هر ۵ دقیقه (رونق)' );
		$s['jsms_15min'] = array( 'interval' => 15 * MINUTE_IN_SECONDS, 'display' => 'هر ۱۵ دقیقه (رونق)' );
		return $s;
	}

	public static function schedule_events() {
		// سبد رها شده جداگانه و هر ۵ دقیقه اجرا می‌شود — چون رزرو موجودی معمولاً هر ۵ دقیقه
		// (وقتی مهلتش تمام شود) آزاد می‌شود؛ با فاصلهٔ کران ۱۵ دقیقه‌ای ریسک داشت یادآوری
		// دیرتر از خالی‌شدن سبد برسد و اصلاً ارسال نشود.
		if ( ! wp_next_scheduled( 'jsms_cron_cart' ) ) {
			wp_schedule_event( time() + 120, 'jsms_5min', 'jsms_cron_cart' );
		}
		if ( ! wp_next_scheduled( 'jsms_cron_frequent' ) ) {
			wp_schedule_event( time() + 300, 'jsms_15min', 'jsms_cron_frequent' );
		}
		if ( ! wp_next_scheduled( 'jsms_cron_daily' ) ) {
			wp_schedule_event( time() + 600, 'daily', 'jsms_cron_daily' );
		}
	}

	public static function clear_events() {
		wp_clear_scheduled_hook( 'jsms_cron_cart' );
		wp_clear_scheduled_hook( 'jsms_cron_frequent' );
		wp_clear_scheduled_hook( 'jsms_cron_daily' );
	}

	/**
	 * قفلِ اجرا برای یک Job — جلوگیری از اجرای هم‌زمانِ دو WP-Cron روی همان Job (مثلاً
	 * وقتی ترافیک بالا باعث می‌شود دو درخواست هم‌زمان cron را trigger کنند)، که می‌توانست
	 * باعث ارسال/کوپن/کش‌بک تکراری شود. با add_option (اتمیک روی کلید یکتا) پیاده شده،
	 * دقیقاً همان الگویی که برای قفلِ کیف پول استفاده شد.
	 */
	private static function with_lock( $job, $callback ) {
		$key = 'jsms_cronlock_' . $job;
		$at  = get_option( $key );
		if ( false !== $at && ( time() - (int) $at ) > 10 * MINUTE_IN_SECONDS ) {
			delete_option( $key ); // قفلِ باقی‌مانده از یک اجرای قطع‌شده — رهایش کن.
		}
		if ( ! add_option( $key, time(), '', 'no' ) ) {
			return; // Job دیگری همین الان در حال اجراست.
		}
		try {
			$callback();
		} finally {
			delete_option( $key );
		}
	}

	/**
	 * هر ۵ دقیقه: سبد رها شده (تا از خالی‌شدن سبد به‌خاطر آزادسازی رزرو موجودی عقب نیفتد)
	 * + لغو خودکار سفارش‌های کارت‌به‌کارت منقضی‌شده.
	 */
	public function run_cart() {
		self::with_lock( 'cart', function () {
			// لغو خودکار همیشه اول اجرا می‌شود: اگر سفارشی همین حالا به مهلت لغو رسیده،
			// در دو اسکن بعدی دیگر «در انتظار پرداخت» شمرده نشود و یادآوریِ بی‌مورد نرود.
			JSMS_Automations::scan_expired_pending_orders();
			JSMS_Automations::scan_abandoned_carts();
			JSMS_Automations::scan_pending_payment_reminders();
		} );
	}

	/**
	 * اجرای مکرر: خواندن پاسخ نظرات + پیگیری ای‌بازار پست (نیازی به دقت ۵ دقیقه‌ای ندارند).
	 */
	public function run_frequent() {
		self::with_lock( 'frequent', function () {
			JSMS_Reviews::poll_incoming();
			JSMS_Ebazar::poll_statuses();
			JSMS_Automations::retry_missed_admin_alerts();
		} );
	}

	/**
	 * اجرای روزانه: مشتریان غیرفعال + درخواست نظر + هشدار اعتبار.
	 */
	public function run_daily() {
		self::with_lock( 'daily', function () {
			JSMS_Automations::scan_inactive_customers();
			JSMS_Reviews::scan_review_requests();
			JSMS_Surveys::scan_survey_requests();
			$this->check_credit();
			JSMS_DB::cleanup_old_data();
		} );
	}

	private function check_credit() {
		$threshold = (float) jsms_get( 'low_credit_threshold', 100 );
		$admin = jsms_get( 'admin_mobile' );
		if ( ! $admin || $threshold <= 0 ) {
			return;
		}
		$credit = JSMS_Gateway::get_credit();
		if ( null === $credit ) {
			return;
		}
		update_option( 'jsms_last_credit', $credit );
		if ( $credit <= $threshold && ! get_transient( 'jsms_credit_warned' ) ) {
			JSMS_Templates::dispatch( array(
				'to' => $admin, 'type' => 'admin_alert', 'mode' => 'text', 'force' => true,
				'text' => 'هشدار: اعتبار پنل پیامک شما رو به اتمام است (' . $credit . '). لطفاً شارژ کنید.',
			) );
			set_transient( 'jsms_credit_warned', 1, 12 * HOUR_IN_SECONDS );
		}
	}
}
endif;
