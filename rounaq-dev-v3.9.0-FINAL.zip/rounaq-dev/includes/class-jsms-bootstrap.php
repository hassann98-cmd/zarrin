<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * راه‌اندازی کامل افزونه: ثابت‌ها، بارگذاری کلاس‌ها، هوک‌های فعال/غیرفعال‌سازی.
 * از rounaq.php صدا زده می‌شود.
 *
 * محافظ تداخل: اگر این تابع از قبل تعریف شده باشد (مثلاً به‌خاطر نصب موازی نسخهٔ
 * فروشی کنار این نسخهٔ توسعه)، دوباره تعریفش نمی‌کنیم تا سایت با Fatal از کار نیفتد.
 */
if ( ! function_exists( 'jsms_bootstrap' ) ) :
function jsms_bootstrap( $plugin_file ) {
	$plugin_dir = dirname( $plugin_file );

	define( 'JSMS_VERSION', '3.9.0' );
	define( 'JSMS_FILE', $plugin_file );
	define( 'JSMS_PATH', trailingslashit( $plugin_dir ) );
	define( 'JSMS_URL', plugin_dir_url( $plugin_file ) );
	define( 'JSMS_BASENAME', plugin_basename( $plugin_file ) );

	/**
	 * Autoload-lite: بارگذاری کلاس‌های افزونه.
	 */
	$jsms_includes = array(
		'includes/class-jsms-db.php',
		'includes/class-jsms-gateway.php',
		'includes/class-jsms-coupons.php',
		'includes/class-jsms-templates.php',
		'includes/class-jsms-consent.php',
		'includes/class-jsms-automations.php',
		'includes/class-jsms-reviews.php',
		'includes/class-jsms-surveys.php',
		'includes/class-jsms-campaigns.php',
		'includes/class-jsms-wallet.php',
		'includes/class-jsms-reports.php',
		'includes/class-jsms-order-meta.php',
		'includes/class-jsms-ebazar.php',
		'includes/class-jsms-cron.php',
		'includes/class-jsms-updater.php',
	);
	foreach ( $jsms_includes as $jsms_inc ) {
		require_once JSMS_PATH . $jsms_inc;
	}
	JSMS_Updater::init();

	if ( is_admin() ) {
		require_once JSMS_PATH . 'admin/class-jsms-admin.php';
	}

	register_activation_hook( $plugin_file, 'jsms_activate' );
	register_deactivation_hook( $plugin_file, 'jsms_deactivate' );
}
endif; // ! function_exists( 'jsms_bootstrap' )

// محافظ تداخل: اگر (به هر دلیلی، مثلاً نصب موازی نسخهٔ فروشی کنار این نسخهٔ توسعه)
// این توابع سراسری از قبل تعریف شده باشند، دوباره تعریف‌شان نمی‌کنیم تا سایت با
// Fatal: Cannot redeclare از کار نیفتد.
if ( ! function_exists( 'jsms_activate' ) ) :

/**
 * فعال‌سازی: ساخت جداول و زمان‌بندی کران.
 */
function jsms_activate() {
	JSMS_DB::install();
	// نکته: در لحظهٔ فعال‌سازی، هوک plugins_loaded (که JSMS_Cron::instance() را صدا می‌زند
	// و فیلتر cron_schedules را ثبت می‌کند) از قبل رد شده و برای این افزونه اجرا نشده است.
	// پس باید قبل از زمان‌بندی، خودمان instance را بسازیم تا زمان‌بندی‌های سفارشی
	// (jsms_5min، jsms_15min) ثبت شده باشند — وگرنه wp_schedule_event با خطای
	// «invalid_schedule» شکست می‌خورد.
	JSMS_Cron::instance();
	JSMS_Cron::schedule_events();
	if ( false === get_option( 'jsms_settings' ) ) {
		add_option( 'jsms_settings', JSMS_Settings_Defaults() );
	}
	flush_rewrite_rules();
}

/**
 * غیرفعال‌سازی: پاک‌کردن کران‌ها.
 */
function jsms_deactivate() {
	JSMS_Cron::clear_events();
	flush_rewrite_rules();
}

/**
 * بررسی و ساخت خودکار جدول‌های جدید دیتابیس، مستقل از فعال‌سازی افزونه.
 * وقتی از طریق «جایگزینی نسخهٔ فعلی» آپدیت می‌کنیم (بدون غیرفعال/فعال‌سازی مجدد)،
 * هوک activation دوباره اجرا نمی‌شود؛ این تابع تضمین می‌کند جدول‌های جدید هر نسخه
 * (مثل jsms_shortlinks) با اولین بارگذاری صفحه ساخته شوند.
 */
function jsms_maybe_upgrade_db() {
	if ( get_option( 'jsms_db_version' ) === JSMS_VERSION ) {
		return;
	}
	JSMS_DB::install();
	update_option( 'jsms_db_version', JSMS_VERSION );
}
add_action( 'plugins_loaded', 'jsms_maybe_upgrade_db', 5 );

/**
 * مقادیر پیش‌فرض تنظیمات.
 */
function JSMS_Settings_Defaults() {
	return array(
		// اتصال
		'provider'             => 'melipayamak', // پنل پیامکی فعال: melipayamak | kavenegar | ghasedak | ippanel
		'provider_method'      => 'rest',      // rest = یوزر/پس ، console = کلید API (فقط ملی پیامک)
		'username'             => '',
		'password'             => '',
		'apikey'               => '',
		'gw_kavenegar_apikey'  => '', 'gw_kavenegar_line' => '',
		'gw_ghasedak_apikey'   => '', 'gw_ghasedak_line'  => '',
		'gw_ippanel_token'     => '', 'gw_ippanel_from'   => '',
		'gw_smsir_apikey'      => '', 'gw_smsir_line'     => '',

		// آپدیت خودکار (خودمیزبان)
		'update_manifest_url'  => 'https://jluxe.ir/wp-content/uploads/rounaq-updates/manifest.json',
		'line_number'          => '',          // خط ارسال انبوه (مثلا 50004...)
		'admin_mobile'         => '',          // شماره مدیر برای هشدارها
		'low_credit_threshold' => 100,

		// اعلان به مدیر: سفارش جدید (فقط وقتی سفارش واقعاً تأیید شده — نه در انتظار پرداخت/تأیید رسید)
		'admin_order_alert_enabled' => 0,
		'admin_order_alert_text'    => '🛎 سفارش جدید ثبت شد\nشماره: {order_id}\nمشتری: {full_name}\nموبایل: {customer_mobile}\nمبلغ: {order_total} تومان\nاقلام: {items}',
		// اعلان به مدیر: مشتری رسید کارت‌به‌کارت را ثبت کرد و منتظر بررسی است
		'admin_receipt_alert_enabled' => 0,
		'admin_receipt_alert_text'    => '📋 رسید پرداخت سفارش {order_id} ثبت شد — لطفاً بررسی و تأیید کنید.\nمشتری: {full_name}\nموبایل: {customer_mobile}\nمبلغ: {order_total} تومان',
		// اعلان به مدیر: کمبود موجودی (بر اساس آستانهٔ «کم‌موجود» ووکامرس)
		'admin_lowstock_enabled'    => 0,
		'admin_lowstock_text'       => '⚠️ موجودی «{product_name}» رو به اتمام است (باقی‌مانده: {stock_qty} عدد). لطفاً موجودی را تأمین کنید.',

		// کارت‌به‌کارت (درگاه شتاب): پیامک «در انتظار پرداخت» بلافاصله بعد از ثبت سفارش کارت‌به‌کارت
		'card_pending_enabled' => 0,
		'card_pending_text'    => '{first_name} عزیز، سفارش {order_id} شما ثبت شد و در انتظار پرداخت کارت‌به‌کارت است 💳 لطفاً مبلغ {order_total} تومان را واریز و رسید را در همین صفحه ثبت کنید: {payment_url}',
		// اگر سفارش کارت‌به‌کارت بعد از این مدت (دقیقه) هنوز در وضعیت «در انتظار پرداخت» بماند (رسیدی ثبت نشده)، خودکار لغو شود.
		'pending_expiry_enabled' => 0,
		'pending_expiry_min'     => 30,

		// یادآوری دومِ گرم‌تر برای هر سفارشِ «در انتظار پرداخت» (هر درگاهی)، درست قبل از لغوِ خودکار.
		'pending_reminder_enabled' => 0,
		'pending_reminder_min'     => 25,
		'pending_reminder_text'    => "{first_name} عزیز، هنوز چند لحظه وقت دارید؟ 💛 اگر هنوز قصد تکمیل خریدتان را دارید، از لینک زیر می‌توانید پرداخت را ادامه دهید. اگر دربارهٔ خرید یا پرداخت سؤالی دارید، همین الان پاسخگوی شما هستیم.\n{payment_url}\n{site_name}",

		// ای‌بازار پست (شرکت ملی پست) — ثبت مرسوله و پیگیری خودکار وضعیت
		'ebazar_username'            => '',
		'ebazar_password'            => '',
		'ebazar_box_size_id'         => 5,
		'ebazar_tracking_enabled'    => 0, // اسکن دوره‌ای وضعیت مرسولات فعال
		'ebazar_tracking_sms_enabled'=> 1, // با هر تغییر وضعیت، پیامک برود
		'ebazar_status_text'         => '{first_name} عزیز، وضعیت مرسولهٔ سفارش {order_id}: {ebazar_status} 📦\nکد رهگیری: {ebazar_parcel_code}\n{site_name}',

		// کد تخفیف پویا (برای متغیر {coupon} در هر پیام متنی)
		'coupon_amount'        => 10,          // مقدار تخفیف
		'coupon_type'          => 'percent',   // percent | fixed_cart
		'coupon_expiry_days'   => 3,           // انقضا (روز) - حس فوریت
		'coupon_prefix'        => 'JL',        // پیشوند کد

		// خوش‌آمدگویی
		'welcome_enabled'      => 0,
		'welcome_mode'         => 'text',      // text | pattern
		'welcome_text'         => 'به {site_name} خوش آمدید، {first_name} عزیز 🌸 مجموعه‌ای منتخب از جهیزیه و لوازم خانهٔ لوکس را برای شما فراهم کرده‌ایم. از حضورتان خرسندیم.',
		'welcome_pattern'      => '',

		// اعلان تغییر وضعیت
		'status_enabled'       => 0,
		'status_map'           => array(       // status => text (پیش‌فرض‌های آماده) — خالی = برای آن وضعیت غیرفعال
			'processing'      => '{first_name} عزیز، سفارش {order_id} شما در حال آماده‌سازی است و به‌زودی ارسال می‌شود. {site_name}',
			'completed'       => '{first_name} عزیز، سفارش {order_id} ({items}) ارسال شد 🚚 کد رهگیری: {tracking_code} پیگیری: {order_url}',
			'on-hold'         => '{first_name} عزیز، سفارش {order_id} در انتظار تأیید/پرداخت است. در صورت نیاز به راهنمایی با ما در تماس باشید. {site_name}',
			'cancelled'       => '{first_name} عزیز، سفارش {order_id} لغو شد. در صورت هرگونه سؤال پاسخگوی شما هستیم. {site_name}',
			'shetab-approval' => '{first_name} عزیز، رسید پرداخت سفارش {order_id} شما دریافت شد و در انتظار تأیید است ✅ به‌زودی نتیجه اطلاع داده می‌شود. {site_name}',
			'shipped'         => '{first_name} عزیز، سفارش {order_id} شما ارسال شد 🚚 {site_name}',
			'delivered'       => '{first_name} عزیز، سفارش {order_id} شما تحویل داده شد 🎁 امیدواریم راضی باشید. {site_name}',
			// در انتظار پرداخت عمداً پیش‌فرض ندارد — برای سفارش‌های کارت‌به‌کارت، پیامک اختصاصی
			// «در انتظار پرداخت کارت‌به‌کارت» (card_pending_text) همین نقش را ایفا می‌کند تا سفارش‌های
			// درگاه بانکی (که چند ثانیه‌ای رد می‌شوند) پیامک اضافه و بی‌مورد نگیرند.
			'pending'         => '',
			'failed'          => '',
			'refunded'        => '',
		),

		// کد پیگیری (ارسال دستی از صفحهٔ سفارش)
		'tracking_mode'        => 'text',
		'tracking_text'        => '{first_name} عزیز، سفارش {order_id} شما ارسال شد و در راه است 🚚 کد رهگیری پستی: {tracking_code} — {site_name}',
		'tracking_pattern'     => '',

		// سبد خرید رها شده (دو مرحله‌ای)
		'cart_enabled'         => 0,
		'cart_delay_min'       => 20,          // مرحله ۱: چند دقیقه بعد از رها شدن (باید کمتر از مهلت آزادسازی رزرو موجودی ووکامرس باشد)
		'cart_mode'            => 'text',
		'cart_text'            => '{first_name} عزیز، انتخاب‌های شما ({cart_items}) در سبد خرید {site_name} منتظرتان است 🛒 با یک کلیک برشون گردونید: {recover_cart_url}',
		'cart_pattern'         => '',
		// مرحله ۲: پیام تشویقی همراه کد تخفیف
		'cart_stage2_enabled'  => 0,
		'cart_delay2_min'      => 1440,        // مرحله ۲: پیش‌فرض ۲۴ ساعت بعد
		'cart_text_2'          => '{first_name} عزیز، فقط برای شما کد تخفیف {coupon} فعال شد! با یک کلیک سبدتون برمی‌گرده: {recover_cart_url} لغو۱۱',
		'cart_pattern_2'       => '',
		'cart_recovery_expiry_days' => 7,      // بعد از این تعداد روز، لینک بازیابی سبد منقضی می‌شود

		// مشتریان غیرفعال
		'inactive_enabled'     => 0,
		'inactive_days'        => 45,
		'inactive_cooldown'    => 30,          // فاصله بین دو پیام به یک نفر (روز)
		'inactive_mode'        => 'text',
		'inactive_text'        => '{first_name} عزیز، دلمان برایتان تنگ شده 🌸 با کد تخفیف {coupon} به {site_name} برگردید: {site_url} لغو۱۱',
		'inactive_pattern'     => '',

		// درخواست نظر
		'review_enabled'       => 0,
		'review_after_days'    => 5,
		'review_order_status'  => 'completed',
		'review_mode'          => 'text',
		'review_text'          => '{first_name} عزیز، تجربهٔ شما از «{product_name}» برای ما ارزشمند است 🌸 لطفاً امتیاز و نظرتان را ثبت کنید و به عروس‌های دیگر در انتخاب کمک کنید: {review_url}',
		'review_pattern'       => '',
		'review_reminder_text' => '{first_name} جان، هنوز چند لحظه وقت دارید؟ 💌 نظر شما دربارهٔ «{product_name}» واقعاً برامون ارزشمنده و فقط چند ثانیه طول می‌کشه: {review_url} 🌷',
		'review_incoming'      => 0,           // خواندن پاسخ پیامکی مشتری

		// عمومی
		'quiet_hours'          => 1,           // عدم ارسال در بازه شب
		'quiet_start'          => 22,
		'quiet_end'            => 9,
		'respect_optout'       => 1,
		'block_transactional_for_optout' => 0, // پیش‌فرض خاموش: لغوِ اشتراکِ تبلیغاتی نباید پیام‌های تراکنشی (وضعیت سفارش/پرداخت/رهگیری) را هم مسدود کند.
		'log_retention_days'   => 365, // نگهداریِ لاگ ارسال/شورت‌لینک؛ ۰ = هرگز پاک نشود.
		'attribution_window_days' => 7,

		// باشگاه مشتریان / کیف پول و کش‌بک
		'wallet_enabled'          => 0,
		'wallet_sms_enabled'      => 1,
		'cashback_trigger_status' => 'completed', // در چه وضعیتی کش‌بک داده شود
		'cashback_percent'        => 5,           // درصد پایه (سطح برنزی)
		'cashback_max'            => 0,           // سقف کش‌بک هر سفارش (۰ = بدون سقف)
		'cashback_min_order'      => 0,           // حداقل مبلغ سفارش برای دریافت کش‌بک
		'tier_silver_min'         => 10000000,    // آستانه سطح نقره‌ای (مجموع خرید)
		'tier_silver_pct'         => 7,
		'tier_gold_min'           => 30000000,    // آستانه سطح طلایی
		'tier_gold_pct'           => 10,
		'wallet_redeem_min'       => 50000,       // حداقل موجودی قابل‌برداشت
		'wallet_coupon_expiry_days' => 30,        // انقضای کد حاصل از موجودی
		'wallet_cashback_text'    => '{first_name} عزیز، {cashback} تومان به کیف پول شما در {site_name} اضافه شد 🎁 موجودی: {wallet_balance} تومان (سطح {tier})',
		'wallet_redeem_text'      => '{first_name} عزیز، کد تخفیف {coupon_code} به مبلغ {redeem_amount} تومان از موجودی کیف پول شما ساخته شد. موجودی باقی‌مانده: {wallet_balance} تومان',

		// نظرسنجی
		'survey_auto_enabled'     => 0,           // ارسال خودکار بعد از سفارش
		'survey_auto_survey_id'   => 0,           // کدام نظرسنجی خودکار ارسال شود
		'survey_after_days'       => 3,
		'survey_order_status'     => 'completed',
		'survey_default_text'     => "{first_name} عزیز، نظر شما برای ما ارزشمند است 🌸 لطفاً چند لحظه وقت بگذارید: {survey_url}\nلغو۱۱",
	);
}

/**
 * تنظیمات ذخیره‌شده را همیشه با پیش‌فرض‌ها ادغام می‌کند تا کلیدهای جدید
 * (که در تنظیمات قدیمی کاربر وجود ندارند) خودکار مقدار پیش‌فرض بگیرند.
 */
function jsms_merge_defaults( $value ) {
	if ( ! is_array( $value ) ) {
		return JSMS_Settings_Defaults();
	}
	return wp_parse_args( $value, JSMS_Settings_Defaults() );
}
add_filter( 'option_jsms_settings', 'jsms_merge_defaults' );

/**
 * دریافت یک تنظیم.
 */
function jsms_get( $key, $default = '' ) {
	$s = get_option( 'jsms_settings', array() );
	if ( ! is_array( $s ) ) {
		$s = array();
	}
	// ادغام با پیش‌فرض‌ها تا کلیدهای جدید (که در تنظیمات قدیمی ذخیره نشده‌اند) مقدار پیش‌فرض بگیرند.
	$s = wp_parse_args( $s, JSMS_Settings_Defaults() );
	if ( isset( $s[ $key ] ) && '' !== $s[ $key ] ) {
		return $s[ $key ];
	}
	return isset( $s[ $key ] ) ? $s[ $key ] : $default;
}

/**
 * بازکردن لینک‌های کوتاه‌شدهٔ پیامک (?jl=TOKEN) و هدایت به آدرس اصلی.
 */
function jsms_handle_shortlink() {
	if ( empty( $_GET['jl'] ) ) {
		return;
	}
	global $wpdb;
	$token = sanitize_text_field( wp_unslash( $_GET['jl'] ) );
	$t     = JSMS_DB::shortlinks_table();
	$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE token=%s", $token ) );
	if ( ! $row ) {
		wp_die( 'لینک نامعتبر یا منقضی‌شده است.' );
	}
	$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET hits = hits + 1 WHERE id=%d", $row->id ) );
	wp_redirect( $row->url, 302 );
	exit;
}
add_action( 'init', 'jsms_handle_shortlink', 1 );

/**
 * راه‌اندازی افزونه پس از لود شدن پلاگین‌ها.
 */
function jsms_init() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', function () {
			echo '<div class="notice notice-error"><p>افزونه <b>رونق</b> برای کار کردن به ووکامرس نیاز دارد.</p></div>';
		} );
		return;
	}
	JSMS_Automations::instance();
	JSMS_Reviews::instance();
	JSMS_Surveys::instance();
	JSMS_Campaigns::instance();
	JSMS_Wallet::instance();
	if ( is_admin() ) {
		JSMS_Order_Meta::instance();
	}
	JSMS_Cron::instance();
	JSMS_Consent::instance();
	if ( is_admin() ) {
		JSMS_Admin::instance();
	}
}
add_action( 'plugins_loaded', 'jsms_init' );

// سازگاری با HPOS ووکامرس.
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
} );

endif; // ! function_exists( 'jsms_activate' )
