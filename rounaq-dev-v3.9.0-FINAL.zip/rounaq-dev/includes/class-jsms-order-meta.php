<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ابزار صفحهٔ سفارش ووکامرس:
 *  - متاباکس «پیامک و کد پیگیری» کنار سفارش برای وارد کردن کد رهگیری و ارسال پیامک به مشتری
 *  - افزودن «ارسال کد پیگیری با پیامک» به فهرست عملیات سفارش
 * سازگار با HPOS و حالت کلاسیک.
 */
if ( ! class_exists( 'JSMS_Order_Meta' ) ) :
class JSMS_Order_Meta {

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'add_meta_boxes', array( $this, 'add_box' ) );
		add_action( 'woocommerce_process_shop_order_meta', array( $this, 'save' ), 99, 1 );
		add_filter( 'woocommerce_order_actions', array( $this, 'order_actions' ) );
		add_action( 'woocommerce_order_action_jsms_send_tracking', array( $this, 'action_send_tracking' ) );
		add_action( 'woocommerce_order_action_jsms_send_review_request', array( $this, 'action_send_review_request' ) );
	}

	private function order_screen_id() {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' )
			&& \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
			return wc_get_page_screen_id( 'shop-order' );
		}
		return 'shop_order';
	}

	public function add_box() {
		add_meta_box(
			'jsms_order_tracking',
			'پیامک و کد پیگیری (رونق)',
			array( $this, 'render' ),
			$this->order_screen_id(),
			'side',
			'high'
		);
		add_meta_box(
			'jsms_ebazar_parcel',
			'مرسولهٔ ای‌بازار پست (رونق)',
			array( $this, 'render_ebazar' ),
			$this->order_screen_id(),
			'side',
			'high'
		);
	}

	/**
	 * جعبهٔ ثبت/نمایش مرسولهٔ ای‌بازار پست برای این سفارش.
	 */
	public function render_ebazar( $post_or_order ) {
		$order = ( $post_or_order instanceof WP_Post ) ? wc_get_order( $post_or_order->ID ) : $post_or_order;
		if ( ! $order ) {
			return;
		}
		$parcel_code = $order->get_meta( '_jsms_ebazar_parcel_code' );

		if ( $parcel_code ) {
			$status_code = $order->get_meta( '_jsms_ebazar_status' );
			$labels = JSMS_Ebazar::status_labels();
			?>
			<p style="margin:4px 0"><b>کد مرسوله:</b> <span dir="ltr"><?php echo esc_html( $parcel_code ); ?></span></p>
			<?php if ( '' !== $status_code ) : ?>
				<p style="margin:4px 0"><b>آخرین وضعیت:</b> <?php echo esc_html( $labels[ (int) $status_code ] ?? $status_code ); ?></p>
			<?php else : ?>
				<p class="description">وضعیت هنوز استعلام نشده — با فعال بودن «پیگیری خودکار» در تنظیمات، خودکار به‌روز می‌شود.</p>
			<?php endif; ?>
			<?php
			return;
		}

		$province_code = JSMS_Ebazar::guess_province( $order->get_billing_state() );
		$city_code     = $province_code ? JSMS_Ebazar::guess_city( $province_code, $order->get_billing_city() ) : 0;
		$provinces     = JSMS_Ebazar::get_provinces();
		$cities        = $province_code ? JSMS_Ebazar::get_cities( $province_code ) : array();
		?>
		<div id="jsms-ebazar-box" data-order-id="<?php echo esc_attr( $order->get_id() ); ?>">
			<?php if ( empty( $provinces ) ) : ?>
				<p class="description">اتصال به ای‌بازار پست برقرار نیست — یوزرنیم/پسورد را در «تنظیمات اتصال» بررسی کنید.</p>
			<?php else : ?>
				<p style="margin:6px 0 3px"><label for="jsms-ebazar-province">استان</label></p>
				<select id="jsms-ebazar-province" class="widefat">
					<option value="0">انتخاب کنید</option>
					<?php foreach ( $provinces as $code => $name ) : ?>
						<option value="<?php echo esc_attr( $code ); ?>" <?php selected( $province_code, $code ); ?>><?php echo esc_html( $name ); ?></option>
					<?php endforeach; ?>
				</select>
				<p style="margin:10px 0 3px"><label for="jsms-ebazar-city">شهر</label></p>
				<select id="jsms-ebazar-city" class="widefat">
					<option value="0">انتخاب کنید</option>
					<?php foreach ( $cities as $id => $name ) : ?>
						<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $city_code, $id ); ?>><?php echo esc_html( $name ); ?></option>
					<?php endforeach; ?>
				</select>
				<?php if ( $city_code ) : ?>
					<p class="description">شهر بر اساس آدرس سفارش حدس زده شد؛ در صورت اشتباه بودن تغییر دهید.</p>
				<?php endif; ?>
				<button type="button" class="button button-primary" id="jsms-ebazar-submit" style="width:100%;margin-top:10px">ثبت مرسوله در ای‌بازار پست</button>
				<div id="jsms-ebazar-result" style="margin-top:8px"></div>
			<?php endif; ?>
		</div>
		<?php
	}

	public function render( $post_or_order ) {
		$order = ( $post_or_order instanceof WP_Post ) ? wc_get_order( $post_or_order->ID ) : $post_or_order;
		if ( ! $order ) {
			return;
		}
		$tracking = $order->get_meta( '_jsms_tracking' );
		$courier  = $order->get_meta( '_jsms_courier' );
		$couriers = array( 'پست پیشتاز', 'تیپاکس', 'ماهکس', 'چاپار', 'دکاپست' );
		wp_nonce_field( 'jsms_order_meta', 'jsms_order_nonce' );
		?>
		<style>
			.jsms-courier-buttons{display:flex;flex-wrap:wrap;gap:6px}
			.jsms-courier-btn{margin:0}
			.jsms-courier-btn input{position:absolute;opacity:0;width:1px;height:1px}
			.jsms-courier-btn span{display:inline-block;padding:6px 12px;border:1px solid #ddd;border-radius:999px;
				font-size:12px;cursor:pointer;background:#f6f6f7;color:#3a333f;transition:.15s}
			.jsms-courier-btn input:checked + span{background:#7a2e57;border-color:#7a2e57;color:#fff}
		</style>
		<p style="margin:8px 0 4px"><label for="jsms_tracking"><b>کد رهگیری پستی</b></label></p>
		<input type="text" id="jsms_tracking" name="jsms_tracking" value="<?php echo esc_attr( $tracking ); ?>" class="widefat" dir="ltr">

		<p style="margin:12px 0 6px"><b>شرکت حمل</b></p>
		<div class="jsms-courier-buttons">
			<?php foreach ( $couriers as $c ) : ?>
				<label class="jsms-courier-btn">
					<input type="radio" name="jsms_courier" value="<?php echo esc_attr( $c ); ?>" <?php checked( $courier, $c ); ?>>
					<span><?php echo esc_html( $c ); ?></span>
				</label>
			<?php endforeach; ?>
		</div>

		<p style="margin:14px 0 4px">
			<label><input type="checkbox" name="jsms_send_tracking" value="1"> ارسال پیامک کد پیگیری به مشتری پس از ذخیره</label>
		</p>
		<?php
	}

	public function save( $order_id ) {
		if ( ! isset( $_POST['jsms_order_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['jsms_order_nonce'] ), 'jsms_order_meta' ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			return;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$changed = false;
		if ( isset( $_POST['jsms_tracking'] ) ) {
			$order->update_meta_data( '_jsms_tracking', sanitize_text_field( wp_unslash( $_POST['jsms_tracking'] ) ) );
			$changed = true;
		}
		if ( isset( $_POST['jsms_courier'] ) ) {
			$order->update_meta_data( '_jsms_courier', sanitize_text_field( wp_unslash( $_POST['jsms_courier'] ) ) );
			$changed = true;
		}
		if ( $changed ) {
			$order->save();
		}
		if ( ! empty( $_POST['jsms_send_tracking'] ) ) {
			$res = self::send( $order_id );
			$note = ! empty( $res['ok'] )
				? 'پیامک کد پیگیری با موفقیت ارسال شد (کد رهگیری پیامک: ' . ( $res['rec_id'] ?: '-' ) . ').'
				: 'ارسال پیامک کد پیگیری ناموفق بود: ' . ( $res['error'] ?? 'خطای نامشخص' );
			$order->add_order_note( $note );
		}
	}

	public function order_actions( $actions ) {
		$actions['jsms_send_tracking'] = 'ارسال کد پیگیری با پیامک (رونق)';
		$actions['jsms_send_review_request'] = 'ارسال درخواست نظر با پیامک (رونق)';
		return $actions;
	}

	public function action_send_tracking( $order ) {
		$res = self::send( $order->get_id() );
		$order->add_order_note(
			! empty( $res['ok'] )
				? 'پیامک کد پیگیری ارسال شد.'
				: 'ارسال پیامک کد پیگیری ناموفق: ' . ( $res['error'] ?? '' )
		);
	}

	public function action_send_review_request( $order ) {
		$res = JSMS_Reviews::send_for_order( $order, true );
		$order->add_order_note(
			! empty( $res['ok'] )
				? 'پیامک درخواست نظر (دستی) ارسال شد.'
				: 'ارسال پیامک درخواست نظر ناموفق: ' . ( $res['error'] ?? '' )
		);
	}

	/**
	 * ارسال پیامک کد پیگیری برای یک سفارش.
	 */
	public static function send( $order_id ) {
		// محافظ ضدتکرار: در یک درخواست، برای یک سفارش فقط یک‌بار ارسال شود.
		static $sent = array();
		if ( isset( $sent[ $order_id ] ) ) {
			return $sent[ $order_id ];
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return array( 'ok' => false, 'error' => 'سفارش یافت نشد.' );
		}
		$mobile = JSMS_Automations::instance()->order_mobile( $order );
		if ( ! $mobile ) {
			return array( 'ok' => false, 'error' => 'شمارهٔ موبایل سفارش خالی است.' );
		}
		$vars = JSMS_Templates::order_vars( $order );
		$vars['courier'] = self::resolve_courier( $order );

		$res = JSMS_Templates::dispatch( array(
			'to'         => $mobile,
			'user_id'    => $order->get_customer_id(),
			'type'       => 'tracking',
			'ref_id'     => $order_id,
			'force'      => true,
			'mode'       => jsms_get( 'tracking_mode', 'text' ),
			'text'       => JSMS_Templates::render( jsms_get( 'tracking_text' ), $vars ),
			'pattern_id' => jsms_get( 'tracking_pattern' ),
			'pattern_args' => array( $vars['first_name'] ?? '', $vars['order_id'] ?? '', $vars['tracking_code'] ?? '' ),
		) );
		$sent[ $order_id ] = $res;
		return $res;
	}

	/**
	 * نام شرکت حمل برای پیامک: اول فیلد خودِ JLuxe، وگرنه از فیلد «شرکت پستی» موجود
	 * روی صفحهٔ سفارش (name="shipping_company_name") که تیم قبلاً با آن کار می‌کند.
	 */
	private static function resolve_courier( $order ) {
		$c = $order->get_meta( '_jsms_courier' );
		if ( $c ) {
			return $c;
		}
		$labels = array(
			'post'   => 'پست پیشتاز',
			'tipax'  => 'تیپاکس',
			'mahex'  => 'ماهکس',
			'chapar' => 'چاپار',
			'none'   => '',
		);
		foreach ( array( '_shipping_company_name', 'shipping_company_name' ) as $key ) {
			$val = $order->get_meta( $key );
			if ( $val ) {
				return $labels[ $val ] ?? $val;
			}
		}
		return '';
	}
}
endif; // ! class_exists( 'JSMS_Order_Meta' )
