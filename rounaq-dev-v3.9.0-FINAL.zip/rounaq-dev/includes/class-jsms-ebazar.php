<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * اتصال به وب‌سرویس «ای‌بازار پست» (شرکت ملی پست):
 *  - احراز هویت (token، کش‌شده)
 *  - همگام‌سازی محصولات ووکامرس با ای‌بازار پست
 *  - ثبت مرسوله برای یک سفارش (دستی، توسط مدیر)
 *  - استعلام دوره‌ای وضعیت مرسولات فعال و ارسال پیامک هنگام تغییر وضعیت
 */
if ( ! class_exists( 'JSMS_Ebazar' ) ) :

class JSMS_Ebazar {

	const BASE = 'http://svc.ebazaar-post.ir/RestApi';

	/**
	 * برچسب فارسیِ هر کد وضعیت (مستقیماً از پنل کاربری ای‌بازار پست).
	 */
	public static function status_labels() {
		return array(
			0   => 'تحت بررسی',
			1   => 'انصرافی',
			2   => 'آماده ارسال',
			3   => 'خطا در آماده‌سازی برای ارسال',
			4   => 'عدم حضور مدیر',
			5   => 'ارسال شده',
			6   => 'عدم قبول',
			7   => 'توزیع شده (تحویل داده شد)',
			8   => 'باجه معطله',
			9   => 'توقیفی',
			10  => 'پیش برگشتی',
			11  => 'برگشتی نهایی',
			12  => 'خسارتی',
			13  => 'وارد استان توزیع شده',
			14  => 'تحویل به نامه‌رسان',
			15  => 'مراجعه اول',
			16  => 'مراجعه دوم',
			17  => 'توزیع در صندوق پستی',
			18  => 'بی‌ترتیبی (کسری مرسوله)',
			19  => 'توزیع در صندوق هوشمند',
			70  => 'تأیید مالی',
			71  => 'وصول وجه',
			74  => 'منقضی شده',
			255 => 'تأیید برگشتی',
		);
	}

	/**
	 * کدهایی که وضعیت را «نهایی» می‌کنند — دیگر نیازی به استعلام دوره‌ای نیست.
	 */
	public static function is_final_status( $code ) {
		return in_array( (int) $code, array( 7, 9, 11, 12, 17, 19, 255 ), true );
	}

	/* ---------------------------------------------------------------------
	 * احراز هویت
	 * ------------------------------------------------------------------- */

	public static function get_token() {
		$cached = get_transient( 'jsms_ebazar_token' );
		if ( $cached ) {
			return $cached;
		}
		$username = jsms_get( 'ebazar_username' );
		$password = jsms_get( 'ebazar_password' );
		if ( ! $username || ! $password ) {
			return '';
		}
		$res = self::fetch_token( $username, $password );
		if ( empty( $res['access_token'] ) ) {
			return '';
		}
		$ttl = isset( $res['expires_in'] ) ? max( 60, (int) $res['expires_in'] - 120 ) : 45 * MINUTE_IN_SECONDS;
		set_transient( 'jsms_ebazar_token', $res['access_token'], $ttl );
		return $res['access_token'];
	}

	/**
	 * درخواست مستقیم توکن (برای گرفتن توکن جدید یا تست اتصال از صفحهٔ تنظیمات).
	 */
	public static function fetch_token( $username, $password ) {
		$r = wp_remote_post( self::BASE . '/token', array(
			'timeout' => 20,
			'body'    => array(
				'username'   => $username,
				'password'   => $password,
				'grant_type' => 'password',
			),
		) );
		if ( is_wp_error( $r ) ) {
			return array( 'error' => $r->get_error_message() );
		}
		$body = json_decode( wp_remote_retrieve_body( $r ), true );
		return is_array( $body ) ? $body : array( 'error' => 'پاسخ نامعتبر از سرویس.' );
	}

	/**
	 * درخواست عمومی POST با توکن؛ اگر مسیر کامل JSON ارسال نشود، بدنه JSON خواهد بود.
	 */
	private static function api_post( $path, $payload = null, $json = true ) {
		$token = self::get_token();
		if ( ! $token ) {
			return array( 'ok' => false, 'error' => 'توکن ای‌بازار پست در دسترس نیست — یوزرنیم/پسورد را در تنظیمات بررسی کنید.' );
		}
		$args = array(
			'timeout' => 25,
			'headers' => array(
				'Authorization' => 'bearer ' . $token,
				'Content-Type'  => $json ? 'application/json' : 'application/x-www-form-urlencoded',
			),
		);
		if ( null !== $payload ) {
			$args['body'] = $json ? wp_json_encode( $payload ) : $payload;
		}
		$r = wp_remote_post( self::BASE . $path, $args );
		if ( is_wp_error( $r ) ) {
			return array( 'ok' => false, 'error' => $r->get_error_message() );
		}
		$code = wp_remote_retrieve_response_code( $r );
		$body = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( 200 !== (int) $code ) {
			return array( 'ok' => false, 'error' => $body['error_description'] ?? $body['ResMsg'] ?? ( 'HTTP ' . $code ), 'raw' => $body );
		}
		return array( 'ok' => true, 'data' => $body );
	}

	/* ---------------------------------------------------------------------
	 * استان‌ها و شهرها (برای انتخاب مقصد هنگام ثبت مرسوله)
	 * ------------------------------------------------------------------- */

	public static function get_provinces() {
		$cached = get_transient( 'jsms_ebazar_provinces' );
		if ( $cached ) {
			return $cached;
		}
		$res = self::api_post( '/api/v0/BaseInfo/Province', null, true );
		if ( empty( $res['ok'] ) ) {
			return array();
		}
		$list = array();
		foreach ( (array) ( $res['data']['Data'] ?? array() ) as $row ) {
			$list[ (int) $row['Code'] ] = $row['pName'];
		}
		set_transient( 'jsms_ebazar_provinces', $list, 7 * DAY_IN_SECONDS );
		return $list;
	}

	public static function get_cities( $province_code ) {
		$key = 'jsms_ebazar_cities_' . (int) $province_code;
		$cached = get_transient( $key );
		if ( $cached ) {
			return $cached;
		}
		$token = self::get_token();
		if ( ! $token ) {
			return array();
		}
		$r = wp_remote_post( self::BASE . '/api/v0/BaseInfo/City', array(
			'timeout' => 20,
			'headers' => array(
				'Authorization' => 'bearer ' . $token,
				'Content-Type'  => 'application/x-www-form-urlencoded',
			),
			'body' => array( 'ProvinceCode' => (int) $province_code ),
		) );
		if ( is_wp_error( $r ) ) {
			return array();
		}
		$body = json_decode( wp_remote_retrieve_body( $r ), true );
		$list = array();
		foreach ( (array) ( $body['Data'] ?? array() ) as $row ) {
			$list[ (int) $row['CityID'] ] = $row['pName'];
		}
		set_transient( $key, $list, 7 * DAY_IN_SECONDS );
		return $list;
	}

	/**
	 * بهترین حدس CityID بر اساس نام شهر ثبت‌شدهٔ سفارش (تطبیق متنی، نه دقیق ۱۰۰٪).
	 * مدیر می‌تواند قبل از ثبت نهایی، شهر پیشنهادی را از لیست تغییر دهد.
	 */
	public static function guess_city( $province_code, $city_name ) {
		$cities = self::get_cities( $province_code );
		$city_name = trim( (string) $city_name );
		foreach ( $cities as $id => $name ) {
			if ( trim( $name ) === $city_name ) {
				return $id;
			}
		}
		foreach ( $cities as $id => $name ) {
			if ( false !== mb_strpos( $name, $city_name ) || false !== mb_strpos( $city_name, $name ) ) {
				return $id;
			}
		}
		return 0;
	}

	public static function guess_province( $province_name ) {
		$provinces = self::get_provinces();
		$province_name = trim( (string) $province_name );
		foreach ( $provinces as $code => $name ) {
			if ( trim( $name ) === $province_name || false !== mb_strpos( $name, $province_name ) ) {
				return $code;
			}
		}
		return 0;
	}

	/* ---------------------------------------------------------------------
	 * همگام‌سازی محصولات (پیش‌نیاز ثبت مرسوله)
	 * ------------------------------------------------------------------- */

	public static function ensure_product_registered( $product ) {
		$existing = $product->get_meta( '_jsms_ebazar_product_id' );
		if ( $existing ) {
			return $existing;
		}
		$payload = array(
			array(
				'ClientProductID' => $product->get_id(),
				'Name'            => $product->get_name(),
				'Price'           => (float) ( $product->get_price() ?: 0 ) * 10, // تومان → ریال
				'PercentDiscount' => 0,
				'Weight'          => (float) ( $product->get_weight() ?: 0.2 ),
				'Count'           => 100,
				'Enabled'         => true,
				'Visible'         => true,
				'IsStandard'      => true,
				'IsPocket'        => true,
				'Description'     => $product->get_name(),
			),
		);
		$res = self::api_post( '/api/v0/Product/Add', $payload );
		if ( empty( $res['ok'] ) ) {
			return 0;
		}
		$eid = (int) ( $res['data']['Data'][0]['EbazaarProductID'] ?? 0 );
		if ( $eid ) {
			$product->update_meta_data( '_jsms_ebazar_product_id', $eid );
			$product->save();
		}
		return $eid;
	}

	/* ---------------------------------------------------------------------
	 * ثبت مرسوله برای یک سفارش
	 * ------------------------------------------------------------------- */

	public static function create_parcel( $order_id, $city_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return array( 'ok' => false, 'error' => 'سفارش یافت نشد.' );
		}
		if ( $order->get_meta( '_jsms_ebazar_parcel_code' ) ) {
			return array( 'ok' => false, 'error' => 'قبلاً برای این سفارش مرسوله ثبت شده است.' );
		}

		$products = array();
		$total_weight = 0;
		foreach ( $order->get_items() as $item ) {
			$product = $item->get_product();
			if ( ! $product ) {
				continue;
			}
			$eid = self::ensure_product_registered( $product );
			if ( ! $eid ) {
				return array( 'ok' => false, 'error' => 'ثبت محصول «' . $product->get_name() . '» در ای‌بازار پست ناموفق بود.' );
			}
			$qty = $item->get_quantity();
			$products[] = array(
				'EbazaarProductID' => $eid,
				'Count'            => $qty,
				'DisCountPercent'  => 0,
				'Price'            => (float) $product->get_price() * 10,
			);
			$total_weight += (float) ( $product->get_weight() ?: 0.2 ) * $qty;
		}
		if ( empty( $products ) ) {
			return array( 'ok' => false, 'error' => 'محصول قابل ارسالی در این سفارش پیدا نشد.' );
		}

		$payload = array(
			array(
				'ClientOrderId'        => $order_id,
				'CityID'               => (int) $city_id,
				'ServiceType'          => 1,
				'PayType'              => 1,
				'RegisterFirstName'    => $order->get_billing_first_name(),
				'RegisterLastName'     => $order->get_billing_last_name(),
				'RegisterAddress'      => $order->get_billing_address_1(),
				'RegisterPhoneNumber'  => $order->get_billing_phone(),
				'RegisterMobile'       => $order->get_billing_phone(),
				'RegisterEmail'        => $order->get_billing_email(),
				'RegisterIp'           => '127.0.0.1',
				'RegisterPostalCode'   => $order->get_billing_postcode(),
				'DiscountAmount'       => 0,
				'PackingWeight'        => $total_weight ?: 0.5,
				'BoxSizeID'            => (int) jsms_get( 'ebazar_box_size_id', 5 ),
				'Products'             => $products,
			),
		);

		$res = self::api_post( '/api/v0/Order/AddParcel', $payload );
		if ( empty( $res['ok'] ) ) {
			return $res;
		}
		$data = $res['data']['Data'][0] ?? null;
		if ( empty( $data['ParcelCode'] ) ) {
			$err = $data['Errors'][0]['ErrorMessage'] ?? ( $res['data']['ResMsg'] ?? 'پاسخ نامعتبر از ای‌بازار پست.' );
			return array( 'ok' => false, 'error' => $err );
		}

		$order->update_meta_data( '_jsms_ebazar_parcel_code', $data['ParcelCode'] );
		$order->update_meta_data( '_jsms_ebazar_shenase', $data['Shenase'] ?? '' );
		$order->update_meta_data( '_jsms_tracking', $data['ParcelCode'] ); // برای سازگاری با {tracking_code} موجود
		$order->save();

		return array( 'ok' => true, 'parcel_code' => $data['ParcelCode'] );
	}

	/* ---------------------------------------------------------------------
	 * استعلام دورهٔ وضعیت مرسولات فعال + ارسال پیامک هنگام تغییر (کران)
	 * ------------------------------------------------------------------- */

	public static function poll_statuses() {
		if ( ! jsms_get( 'ebazar_tracking_enabled' ) ) {
			return;
		}
		global $wpdb;
		// سفارش‌های ۴۵ روز اخیر که مرسولهٔ ای‌بازار پست دارند و هنوز به وضعیت نهایی نرسیده‌اند.
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT p.ID as order_id, pc.meta_value as parcel_code
			 FROM {$wpdb->posts} p
			 INNER JOIN {$wpdb->postmeta} pc ON pc.post_id=p.ID AND pc.meta_key='_jsms_ebazar_parcel_code'
			 LEFT JOIN {$wpdb->postmeta} fin ON fin.post_id=p.ID AND fin.meta_key='_jsms_ebazar_final'
			 WHERE p.post_date >= %s AND fin.meta_value IS NULL
			 LIMIT 50",
			gmdate( 'Y-m-d H:i:s', time() - 45 * DAY_IN_SECONDS )
		) );
		if ( empty( $rows ) ) {
			return;
		}
		$codes = wp_list_pluck( $rows, 'parcel_code' );
		$by_code = array();
		foreach ( $rows as $r ) {
			$by_code[ $r->parcel_code ] = $r->order_id;
		}

		$res = self::api_post( '/api/v0/Order/ParcelStatus', $codes );
		if ( empty( $res['ok'] ) ) {
			return;
		}
		$labels = self::status_labels();
		foreach ( (array) ( $res['data']['Data'] ?? array() ) as $row ) {
			$parcel_code = $row['ParcelCode'] ?? '';
			$status_code = isset( $row['StatusCode'] ) ? (int) $row['StatusCode'] : null;
			if ( ! $parcel_code || null === $status_code || ! isset( $by_code[ $parcel_code ] ) ) {
				continue;
			}
			$order_id = $by_code[ $parcel_code ];
			$order    = wc_get_order( $order_id );
			if ( ! $order ) {
				continue;
			}
			$prev_status = $order->get_meta( '_jsms_ebazar_status' );
			if ( '' !== $prev_status && (int) $prev_status === $status_code ) {
				continue; // بدون تغییر.
			}
			$order->update_meta_data( '_jsms_ebazar_status', $status_code );
			if ( self::is_final_status( $status_code ) ) {
				$order->update_meta_data( '_jsms_ebazar_final', 1 );
			}
			$order->save();

			$description = ! empty( $row['Description'] ) ? trim( $row['Description'] ) : ( $labels[ $status_code ] ?? '' );
			if ( ! $description ) {
				continue;
			}
			self::notify_status_change( $order, $parcel_code, $status_code, $description );
		}
	}

	private static function notify_status_change( $order, $parcel_code, $status_code, $description ) {
		if ( ! jsms_get( 'ebazar_tracking_sms_enabled' ) ) {
			return;
		}
		$mobile = JSMS_Automations::instance()->order_mobile( $order );
		if ( ! $mobile ) {
			return;
		}
		$vars = JSMS_Templates::order_vars( $order );
		$vars['ebazar_status']      = $description;
		$vars['ebazar_parcel_code'] = $parcel_code;

		JSMS_Templates::dispatch( array(
			'to' => $mobile, 'user_id' => $order->get_customer_id(), 'type' => 'ebazar_status',
			'ref_id' => $order->get_id(), 'force' => true, 'mode' => 'text',
			'text' => JSMS_Templates::render( jsms_get( 'ebazar_status_text' ), $vars ),
		) );
	}
}
endif;
