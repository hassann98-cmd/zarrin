<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * مدیریت جداول دیتابیس، لاگ ارسال، صف نظرات و ردیابی سبد.
 */
if ( ! class_exists( 'JSMS_DB' ) ) :

class JSMS_DB {

	public static function logs_table() {
		global $wpdb;
		return $wpdb->prefix . 'jsms_logs';
	}
	public static function reviews_table() {
		global $wpdb;
		return $wpdb->prefix . 'jsms_reviews';
	}
	public static function carts_table() {
		global $wpdb;
		return $wpdb->prefix . 'jsms_carts';
	}
	public static function wallet_table() {
		global $wpdb;
		return $wpdb->prefix . 'jsms_wallet';
	}
	public static function shortlinks_table() {
		global $wpdb;
		return $wpdb->prefix . 'jsms_shortlinks';
	}
	public static function surveys_table() {
		global $wpdb;
		return $wpdb->prefix . 'jsms_surveys';
	}
	public static function survey_questions_table() {
		global $wpdb;
		return $wpdb->prefix . 'jsms_survey_questions';
	}
	public static function survey_responses_table() {
		global $wpdb;
		return $wpdb->prefix . 'jsms_survey_responses';
	}

	/**
	 * ساخت جداول هنگام فعال‌سازی.
	 */
	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();

		$logs = self::logs_table();
		$reviews = self::reviews_table();
		$carts = self::carts_table();

		dbDelta( "CREATE TABLE {$logs} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			mobile VARCHAR(20) NOT NULL,
			user_id BIGINT UNSIGNED DEFAULT 0,
			type VARCHAR(40) NOT NULL,
			message TEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			rec_id VARCHAR(60) NULL,
			response TEXT NULL,
			ref_id BIGINT UNSIGNED DEFAULT 0,
			PRIMARY KEY (id),
			KEY mobile (mobile),
			KEY type (type),
			KEY user_id (user_id),
			KEY created_at (created_at)
		) {$charset};" );

		dbDelta( "CREATE TABLE {$reviews} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			user_id BIGINT UNSIGNED DEFAULT 0,
			order_id BIGINT UNSIGNED DEFAULT 0,
			product_id BIGINT UNSIGNED DEFAULT 0,
			mobile VARCHAR(20) NOT NULL,
			author VARCHAR(120) NULL,
			rating TINYINT DEFAULT 0,
			content TEXT NULL,
			recommend TINYINT NULL,
			token VARCHAR(64) NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'requested',
			comment_id BIGINT UNSIGNED DEFAULT 0,
			PRIMARY KEY (id),
			KEY token (token),
			KEY status (status),
			KEY product_id (product_id)
		) {$charset};" );

		// نسخه‌های قدیمی‌تر یک UNIQUE KEY روی (user_id, cart_hash) داشتند — چون همهٔ مهمان‌ها
		// user_id=0 دارند، این کلید بین دو سبدِ مهمانِ کاملاً متفاوت که محتوایشان (به‌طور
		// تصادفی) یکسان است تصادم می‌کرد. قبل از dbDelta حذفش می‌کنیم (اگر باشد)؛ منطق
		// جلوگیری از دوباره‌کاری در سطح کد (SELECT قبل از INSERT) انجام می‌شود، نه دیتابیس.
		$table_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $carts ) );
		if ( $table_exists ) {
			$existing_indexes = $wpdb->get_col( "SHOW INDEX FROM {$carts} WHERE Key_name='user_hash'" );
			if ( $existing_indexes ) {
				$wpdb->query( "ALTER TABLE {$carts} DROP INDEX user_hash" );
			}
		}

		dbDelta( "CREATE TABLE {$carts} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED DEFAULT 0,
			guest_customer_id VARCHAR(40) NULL,
			mobile VARCHAR(20) NOT NULL,
			cart_hash VARCHAR(64) NOT NULL,
			cart_total VARCHAR(30) NULL,
			items_count INT DEFAULT 0,
			items_summary VARCHAR(190) NULL,
			items_json LONGTEXT NULL,
			token VARCHAR(64) NULL,
			order_id BIGINT UNSIGNED DEFAULT 0,
			created_at DATETIME NULL,
			updated_at DATETIME NOT NULL,
			notified TINYINT DEFAULT 0,
			recovered TINYINT DEFAULT 0,
			PRIMARY KEY (id),
			KEY user_hash (user_id, cart_hash),
			KEY guest_hash (guest_customer_id, cart_hash),
			KEY mobile (mobile),
			KEY notified (notified),
			KEY token (token)
		) {$charset};" );

		$wallet = self::wallet_table();
		dbDelta( "CREATE TABLE {$wallet} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			user_id BIGINT UNSIGNED DEFAULT 0,
			mobile VARCHAR(20) NULL,
			amount BIGINT NOT NULL DEFAULT 0,
			type VARCHAR(20) NOT NULL DEFAULT 'cashback',
			ref_id BIGINT UNSIGNED DEFAULT 0,
			note VARCHAR(190) NULL,
			PRIMARY KEY (id),
			KEY user_id (user_id),
			KEY type (type)
		) {$charset};" );

		$short = self::shortlinks_table();
		dbDelta( "CREATE TABLE {$short} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			token VARCHAR(10) NOT NULL,
			url TEXT NOT NULL,
			created_at DATETIME NOT NULL,
			hits INT UNSIGNED NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			UNIQUE KEY token (token)
		) {$charset};" );

		$surveys = self::surveys_table();
		dbDelta( "CREATE TABLE {$surveys} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			title VARCHAR(190) NOT NULL,
			intro_text TEXT NULL,
			logo_url VARCHAR(255) NULL,
			sms_text TEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'draft',
			PRIMARY KEY (id),
			KEY status (status)
		) {$charset};" );

		$squestions = self::survey_questions_table();
		dbDelta( "CREATE TABLE {$squestions} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			survey_id BIGINT UNSIGNED NOT NULL,
			sort_order INT UNSIGNED NOT NULL DEFAULT 0,
			type VARCHAR(20) NOT NULL DEFAULT 'rating',
			question_text TEXT NOT NULL,
			options TEXT NULL,
			PRIMARY KEY (id),
			KEY survey_id (survey_id)
		) {$charset};" );

		$sresponses = self::survey_responses_table();
		dbDelta( "CREATE TABLE {$sresponses} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			completed_at DATETIME NULL,
			survey_id BIGINT UNSIGNED NOT NULL,
			user_id BIGINT UNSIGNED DEFAULT 0,
			mobile VARCHAR(20) NULL,
			author VARCHAR(120) NULL,
			token VARCHAR(64) NOT NULL,
			answers LONGTEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			PRIMARY KEY (id),
			KEY token (token),
			KEY survey_id (survey_id),
			KEY status (status)
		) {$charset};" );
	}

	/**
	 * پاک‌سازی دوره‌ایِ جدول‌هایی که با گذر زمان فقط بزرگ می‌شوند و ارزش عملیاتی
	 * ندارند — لاگِ ارسال و شورت‌لینک‌ها. عمداً به جدول کیف‌پول (دفترکل مالی — حذف
	 * از آن، مجموع موجودی را خراب می‌کند)، سبدها، نظرات و نظرسنجی‌ها دست نمی‌زند چون
	 * آن‌ها برای گزارش/Attribution تاریخی هنوز ارزش دارند.
	 */
	public static function cleanup_old_data() {
		$days = (int) jsms_get( 'log_retention_days', 365 );
		if ( $days <= 0 ) {
			return; // ۰ یعنی هرگز پاک نشود.
		}
		global $wpdb;
		$before = date( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) );
		$wpdb->query( $wpdb->prepare(
			"DELETE FROM " . self::logs_table() . " WHERE created_at < %s AND status IN ('sent','failed')", $before
		) );
		$wpdb->query( $wpdb->prepare(
			"DELETE FROM " . self::shortlinks_table() . " WHERE created_at < %s", $before
		) );
	}

	/**
	 * ثبت لاگ ارسال.
	 */
	public static function log( $args ) {
		global $wpdb;
		$defaults = array(
			'created_at' => current_time( 'mysql' ),
			'mobile'     => '',
			'user_id'    => 0,
			'type'       => 'manual',
			'message'    => '',
			'status'     => 'pending',
			'rec_id'     => '',
			'response'   => '',
			'ref_id'     => 0,
		);
		$args = wp_parse_args( $args, $defaults );
		$wpdb->insert( self::logs_table(), $args );
		return $wpdb->insert_id;
	}

	public static function update_log( $id, $args ) {
		global $wpdb;
		$wpdb->update( self::logs_table(), $args, array( 'id' => $id ) );
	}

	/**
	 * آیا در بازه اخیر به این شماره از این نوع پیام رفته؟ (ضدتکرار)
	 */
	public static function already_sent( $mobile, $type, $within_seconds, $ref_id = 0 ) {
		global $wpdb;
		$since = gmdate( 'Y-m-d H:i:s', time() - $within_seconds - ( get_option( 'gmt_offset' ) * 3600 ) );
		$sql = $wpdb->prepare(
			"SELECT COUNT(*) FROM " . self::logs_table() .
			" WHERE mobile=%s AND type=%s AND status!='failed' AND created_at >= %s",
			$mobile, $type, $since
		);
		if ( $ref_id ) {
			$sql = $wpdb->prepare(
				"SELECT COUNT(*) FROM " . self::logs_table() .
				" WHERE mobile=%s AND type=%s AND ref_id=%d AND status!='failed'",
				$mobile, $type, $ref_id
			);
		}
		return (int) $wpdb->get_var( $sql ) > 0;
	}
}
endif;
