<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * درایور ملی پیامک. از دو روش پشتیبانی می‌کند:
 *   - rest    : اندپوینت کلاسیک با نام‌کاربری/رمز (rest.payamak-panel.com)
 *   - console : کنسول ملی پیامک با کلید API (console.melipayamak.com)
 * برای سازگاری با نصب‌های قبلی، کلیدهای تنظیمات بدون پیشوند هستند
 * (username, password, apikey, line_number, provider_method).
 */
if ( ! class_exists( 'JSMS_Gateway_Melipayamak' ) ) :

class JSMS_Gateway_Melipayamak extends JSMS_Gateway_Driver {

	const REST_BASE    = 'https://rest.payamak-panel.com/api/SendSMS/';
	const CONSOLE_BASE = 'https://console.melipayamak.com/api/';

	public function id() {
		return 'melipayamak';
	}

	public function label() {
		return 'ملی پیامک';
	}

	public function settings_fields() {
		return array(
			array( 'key' => 'provider_method', 'label' => 'روش اتصال', 'type' => 'select',
				'options' => array( 'rest' => 'REST کلاسیک (نام‌کاربری/رمز)', 'console' => 'کنسول (کلید API)' ) ),
			array( 'key' => 'username', 'label' => 'نام کاربری (روش REST)', 'type' => 'text' ),
			array( 'key' => 'password', 'label' => 'رمز عبور (روش REST)', 'type' => 'password' ),
			array( 'key' => 'apikey', 'label' => 'کلید API (روش کنسول)', 'type' => 'password' ),
			array( 'key' => 'line_number', 'label' => 'شمارهٔ خط ارسال', 'type' => 'text',
				'help' => 'برای متن آزاد لازم است؛ خط خدماتی فقط پترن می‌فرستد.' ),
		);
	}

	public function send_simple( $to, $text, $from = '' ) {
		$method = jsms_get( 'provider_method', 'rest' );
		$from   = $from ?: jsms_get( 'line_number' );

		if ( 'console' === $method ) {
			if ( ! jsms_get( 'apikey' ) ) {
				return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'کلید API (کنسول) تنظیم نشده است.' );
			}
			if ( ! $from ) {
				return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'برای ارسال متن آزاد باید «شماره خط ارسال» (خط عادی/غیرخدماتی) را در تنظیمات وارد کنید.' );
			}
			$url  = self::CONSOLE_BASE . 'send/advanced/' . rawurlencode( jsms_get( 'apikey' ) );
			$body = wp_json_encode( array( 'from' => $from, 'to' => array( $to ), 'text' => $text, 'udh' => '' ) );
			$res  = $this->http( $url, $body, array( 'Content-Type' => 'application/json' ) );
			if ( ! $res['ok'] ) {
				return array( 'ok' => false, 'rec_id' => '', 'raw' => $res['data'], 'error' => $res['error'] );
			}
			$rec = '';
			if ( isset( $res['data']['recIds'][0] ) ) {
				$rec = $res['data']['recIds'][0];
			} elseif ( isset( $res['data']['recId'] ) ) {
				$rec = $res['data']['recId'];
			}
			$status = isset( $res['data']['status'] ) ? $res['data']['status'] : '';
			$ok     = ( $rec && (int) $rec !== 0 );
			return array( 'ok' => $ok, 'rec_id' => (string) $rec, 'raw' => $res['data'], 'error' => $ok ? '' : ( $status ?: 'ارسال ناموفق' ) );
		}

		if ( ! jsms_get( 'username' ) || ! jsms_get( 'password' ) ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'نام کاربری/رمز عبور (روش REST) تنظیم نشده است.' );
		}
		if ( ! $from ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'برای ارسال متن آزاد باید «شماره خط ارسال» (خط عادی/غیرخدماتی) را وارد کنید. خط خدماتی فقط پترن می‌فرستد.' );
		}
		$url  = self::REST_BASE . 'SendSMS';
		$body = array(
			'username' => jsms_get( 'username' ), 'password' => jsms_get( 'password' ),
			'to' => $to, 'from' => $from, 'text' => $text, 'isflash' => 'false',
		);
		$res = $this->http( $url, $body, array() );
		if ( ! $res['ok'] ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => $res['data'], 'error' => $res['error'] );
		}
		$val    = isset( $res['data']['Value'] ) ? (string) $res['data']['Value'] : '';
		$status = isset( $res['data']['StrRetStatus'] ) ? (string) $res['data']['StrRetStatus'] : '';
		$ok  = ( ctype_digit( $val ) && strlen( $val ) >= 6 );
		$err = $ok ? '' : ( self::rest_status_message( $val ) ?: ( $status ?: ( 'ارسال نشد (کد: ' . $val . ')' ) ) );
		return array( 'ok' => $ok, 'rec_id' => $val, 'raw' => $res['data'], 'error' => $err );
	}

	public function send_pattern( $to, $body_id, $args ) {
		$method = jsms_get( 'provider_method', 'rest' );

		if ( 'console' === $method ) {
			if ( ! jsms_get( 'apikey' ) ) {
				return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'کلید API (کنسول) تنظیم نشده است.' );
			}
			$url  = self::CONSOLE_BASE . 'send/shared/' . rawurlencode( jsms_get( 'apikey' ) );
			$body = wp_json_encode( array( 'bodyId' => (int) $body_id, 'to' => $to, 'args' => array_values( $args ) ) );
			$res  = $this->http( $url, $body, array( 'Content-Type' => 'application/json' ) );
			if ( ! $res['ok'] ) {
				return array( 'ok' => false, 'rec_id' => '', 'raw' => $res['data'], 'error' => $res['error'] );
			}
			$rec = isset( $res['data']['recId'] ) ? $res['data']['recId'] : '';
			$ok  = ( $rec && (int) $rec !== 0 );
			return array( 'ok' => $ok, 'rec_id' => (string) $rec, 'raw' => $res['data'], 'error' => $ok ? '' : ( $res['data']['status'] ?? 'ارسال پترن ناموفق' ) );
		}

		if ( ! jsms_get( 'username' ) || ! jsms_get( 'password' ) ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'نام کاربری/رمز عبور (روش REST) تنظیم نشده است.' );
		}
		$url  = self::REST_BASE . 'BaseServiceNumber';
		$body = array(
			'username' => jsms_get( 'username' ), 'password' => jsms_get( 'password' ),
			'text' => implode( ';', array_map( array( 'JSMS_Gateway', 'fa_to_en' ), $args ) ),
			'to' => $to, 'bodyId' => (int) $body_id,
		);
		$res = $this->http( $url, $body, array() );
		if ( ! $res['ok'] ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => $res['data'], 'error' => $res['error'] );
		}
		$val = isset( $res['data']['Value'] ) ? (string) $res['data']['Value'] : '';
		$str = isset( $res['data']['StrRetStatus'] ) ? (string) $res['data']['StrRetStatus'] : '';
		$ok  = ( ctype_digit( $val ) && strlen( $val ) >= 6 );
		$err = $ok ? '' : ( self::rest_status_message( $val ) ?: ( $str ?: ( 'ارسال نشد (کد: ' . $val . ')' ) ) );
		return array( 'ok' => $ok, 'rec_id' => $val, 'raw' => $res['data'], 'error' => $err );
	}

	public function send_otp( $to ) {
		if ( ! jsms_get( 'apikey' ) ) {
			return array( 'ok' => false, 'code' => '', 'raw' => null, 'error' => 'کلید API کنسول تنظیم نشده است.' );
		}
		$to = JSMS_Gateway::normalize_mobile( $to );
		if ( ! $to ) {
			return array( 'ok' => false, 'code' => '', 'raw' => null, 'error' => 'شماره موبایل نامعتبر است.' );
		}
		$url = self::CONSOLE_BASE . 'send/otp/' . rawurlencode( jsms_get( 'apikey' ) );
		$res = $this->http( $url, wp_json_encode( array( 'to' => $to ) ), array( 'Content-Type' => 'application/json' ) );
		if ( ! $res['ok'] ) {
			return array( 'ok' => false, 'code' => '', 'raw' => $res['data'], 'error' => $res['error'] );
		}
		$code   = isset( $res['data']['code'] ) ? (string) $res['data']['code'] : '';
		$status = isset( $res['data']['status'] ) ? $res['data']['status'] : '';
		$ok     = ( '' !== $code );
		return array( 'ok' => $ok, 'code' => $code, 'raw' => $res['data'], 'error' => $ok ? '' : ( $status ?: 'ارسال OTP ناموفق' ) );
	}

	public function check_connection() {
		$method = jsms_get( 'provider_method', 'rest' );
		if ( 'console' === $method ) {
			if ( ! jsms_get( 'apikey' ) ) {
				return array( 'ok' => false, 'credit' => null, 'error' => 'کلید API کنسول تنظیم نشده است.' );
			}
			$url = self::CONSOLE_BASE . 'receive/credit/' . rawurlencode( jsms_get( 'apikey' ) );
			$res = $this->http( $url, wp_json_encode( array() ), array( 'Content-Type' => 'application/json' ) );
			if ( ! $res['ok'] ) {
				return array( 'ok' => false, 'credit' => null, 'error' => $res['error'] . ' — اگر رمز شما یک کلید GUID است، احتمالاً باید روش «REST کلاسیک» را انتخاب کنید نه کنسول.' );
			}
			$amount = is_array( $res['data'] ) && isset( $res['data']['amount'] ) ? (float) $res['data']['amount'] : null;
			return array( 'ok' => null !== $amount, 'credit' => $amount, 'error' => null !== $amount ? '' : 'پاسخ نامعتبر از کنسول.' );
		}
		if ( ! jsms_get( 'username' ) || ! jsms_get( 'password' ) ) {
			return array( 'ok' => false, 'credit' => null, 'error' => 'نام کاربری/رمز عبور تنظیم نشده است.' );
		}
		$url = self::REST_BASE . 'GetCredit';
		$res = $this->http( $url, array( 'username' => jsms_get( 'username' ), 'password' => jsms_get( 'password' ) ), array() );
		if ( ! $res['ok'] ) {
			return array( 'ok' => false, 'credit' => null, 'error' => $res['error'] );
		}
		$val = isset( $res['data']['Value'] ) ? $res['data']['Value'] : null;
		$rs  = isset( $res['data']['RetStatus'] ) ? (int) $res['data']['RetStatus'] : 0;
		if ( 1 === $rs || is_numeric( $val ) ) {
			return array( 'ok' => true, 'credit' => (float) $val, 'error' => '' );
		}
		$str = isset( $res['data']['StrRetStatus'] ) ? $res['data']['StrRetStatus'] : '';
		return array( 'ok' => false, 'credit' => null, 'error' => $str ?: 'نام کاربری یا رمز عبور نادرست است.' );
	}

	public function get_credit() {
		$method = jsms_get( 'provider_method', 'rest' );
		if ( 'console' === $method ) {
			$url = self::CONSOLE_BASE . 'receive/credit/' . rawurlencode( jsms_get( 'apikey' ) );
			$res = $this->http( $url, '', array(), 'GET' );
			if ( $res['ok'] && is_array( $res['data'] ) ) {
				if ( isset( $res['data']['amount'] ) ) {
					return (float) $res['data']['amount'];
				}
				if ( isset( $res['data']['credit'] ) ) {
					return (float) $res['data']['credit'];
				}
			}
			return null;
		}
		$url = self::REST_BASE . 'GetCredit';
		$res = $this->http( $url, array( 'username' => jsms_get( 'username' ), 'password' => jsms_get( 'password' ) ), array() );
		if ( $res['ok'] && isset( $res['data']['Value'] ) ) {
			return (float) $res['data']['Value'];
		}
		return null;
	}

	public function get_messages( $count = 100, $index = 0 ) {
		$out    = array();
		$method = jsms_get( 'provider_method', 'rest' );
		if ( 'console' === $method ) {
			$url = self::CONSOLE_BASE . 'receive/' . rawurlencode( jsms_get( 'apikey' ) );
			$res = $this->http( $url, wp_json_encode( array( 'count' => $count, 'index' => $index ) ), array( 'Content-Type' => 'application/json' ) );
			$rows = ( $res['ok'] && is_array( $res['data'] ) ) ? $res['data'] : array();
			foreach ( $rows as $r ) {
				$out[] = array(
					'from' => $r['from'] ?? ( $r['From'] ?? '' ),
					'text' => $r['text'] ?? ( $r['Message'] ?? '' ),
					'date' => $r['date'] ?? ( $r['DateTime'] ?? '' ),
				);
			}
			return $out;
		}
		$url = self::REST_BASE . 'GetMessages';
		$res = $this->http( $url, array(
			'username' => jsms_get( 'username' ), 'password' => jsms_get( 'password' ),
			'location' => 1, 'index' => $index, 'count' => $count,
		), array() );
		$data = $res['ok'] ? $res['data'] : array();
		$rows = isset( $data['Data'] ) ? $data['Data'] : ( isset( $data['Value'] ) ? $data['Value'] : array() );
		if ( is_string( $rows ) ) {
			$parts = explode( ';', $rows );
			foreach ( array_chunk( $parts, 4 ) as $c ) {
				if ( count( $c ) >= 3 ) {
					$out[] = array( 'from' => $c[1] ?? '', 'text' => $c[3] ?? ( $c[2] ?? '' ), 'date' => $c[2] ?? '' );
				}
			}
			return $out;
		}
		if ( is_array( $rows ) ) {
			foreach ( $rows as $r ) {
				$out[] = array(
					'from' => $r['From'] ?? ( $r['from'] ?? '' ),
					'text' => $r['Message'] ?? ( $r['text'] ?? '' ),
					'date' => $r['SendDate'] ?? ( $r['date'] ?? '' ),
				);
			}
		}
		return $out;
	}

	/** ترجمهٔ کد وضعیت ملی پیامک (روش REST کلاسیک) به پیام فارسی. */
	public static function rest_status_message( $value ) {
		$map = array(
			'0'  => 'خطا در ارسال (پارامترها را بررسی کنید).',
			'1'  => 'نام کاربری یا رمز عبور اشتباه است.',
			'2'  => 'اعتبار کافی نیست.',
			'3'  => 'محدودیت در ارسال روزانه.',
			'4'  => 'محدودیت در حجم ارسال.',
			'5'  => 'شماره فرستنده (خط ارسال) معتبر نیست.',
			'6'  => 'سامانه در حال به‌روزرسانی است.',
			'7'  => 'متن حاوی کلمهٔ فیلترشده است.',
			'9'  => 'ارسال متن آزاد از خطوط عمومی از طریق وب‌سرویس ممکن نیست؛ برای متن آزاد از خط اختصاصی (غیرخدماتی) استفاده کنید یا از پترن بهره ببرید.',
			'10' => 'کاربر موردنظر فعال نیست.',
			'11' => 'ارسال نشد؛ شمارهٔ گیرنده در «لیست سیاه» مخابرات است. برای ارسال به این شماره‌ها باید از خط خدماتی + پترن استفاده کنید (خط عادی/تبلیغاتی به لیست سیاه پیام نمی‌دهد).',
			'12' => 'مدارک شناسایی هنوز تکمیل/تأیید نشده است.',
			'14' => 'متن حاوی لینک است؛ ارسال لینک از این خط مجاز نیست.',
			'16' => 'شماره گیرنده یافت نشد.',
			'17' => 'متن پیام خالی است.',
			'35' => 'به‌دلیل مسدودی، پیام ارسال نشد.',
		);
		$v = trim( (string) $value );
		return $map[ $v ] ?? '';
	}
}
endif;
