<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * درایور کاوه‌نگار (kavenegar.com).
 * متن آزاد → sms/send.json | پترن (خط خدماتی) → verify/lookup.json با template
 * تنظیمات این پنل با پیشوند gw_kavenegar_ ذخیره می‌شود.
 */
if ( ! class_exists( 'JSMS_Gateway_Kavenegar' ) ) :

class JSMS_Gateway_Kavenegar extends JSMS_Gateway_Driver {

	const BASE = 'https://api.kavenegar.com/v1/';

	public function id() {
		return 'kavenegar';
	}

	public function label() {
		return 'کاوه‌نگار';
	}

	public function settings_fields() {
		return array(
			array( 'key' => 'gw_kavenegar_apikey', 'label' => 'API-Key', 'type' => 'password' ),
			array( 'key' => 'gw_kavenegar_line', 'label' => 'شمارهٔ خط ارسال (sender)', 'type' => 'text',
				'help' => 'برای متن آزاد لازم است.' ),
		);
	}

	private function api_key() {
		return jsms_get( 'gw_kavenegar_apikey' );
	}

	public function send_simple( $to, $text, $from = '' ) {
		if ( ! $this->api_key() ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'API-Key کاوه‌نگار تنظیم نشده است.' );
		}
		$from = $from ?: jsms_get( 'gw_kavenegar_line' );
		$url  = self::BASE . rawurlencode( $this->api_key() ) . '/sms/send.json';
		$body = array( 'receptor' => $to, 'message' => $text );
		if ( $from ) {
			$body['sender'] = $from;
		}
		$res = $this->http( $url, $body, array() );
		return $this->parse_send( $res );
	}

	public function send_pattern( $to, $body_id, $args ) {
		if ( ! $this->api_key() ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'API-Key کاوه‌نگار تنظیم نشده است.' );
		}
		// در کاوه‌نگار، «پترن» یعنی Verify Lookup: body_id همان نام قالب (template) است،
		// نه یک عدد — تا سه پارامتر (token, token2, token3) پشتیبانی می‌شود.
		$url  = self::BASE . rawurlencode( $this->api_key() ) . '/verify/lookup.json';
		$body = array( 'receptor' => $to, 'template' => (string) $body_id );
		$keys = array( 'token', 'token2', 'token3' );
		foreach ( array_values( $args ) as $i => $val ) {
			if ( isset( $keys[ $i ] ) ) {
				$body[ $keys[ $i ] ] = (string) $val;
			}
		}
		$res = $this->http( $url, $body, array() );
		return $this->parse_send( $res );
	}

	private function parse_send( $res ) {
		if ( ! $res['ok'] ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => $res['data'], 'error' => $res['error'] );
		}
		$status = $res['data']['return']['status'] ?? 0;
		$msg    = $res['data']['return']['message'] ?? '';
		if ( 200 !== (int) $status ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => $res['data'], 'error' => $msg ?: ( 'خطای کاوه‌نگار (کد ' . $status . ')' ) );
		}
		$id = $res['data']['entries'][0]['messageid'] ?? '';
		return array( 'ok' => true, 'rec_id' => (string) $id, 'raw' => $res['data'], 'error' => '' );
	}

	public function check_connection() {
		$c = $this->get_credit();
		return null !== $c
			? array( 'ok' => true, 'credit' => $c, 'error' => '' )
			: array( 'ok' => false, 'credit' => null, 'error' => 'اتصال ناموفق — API-Key را بررسی کنید.' );
	}

	public function get_credit() {
		if ( ! $this->api_key() ) {
			return null;
		}
		$url = self::BASE . rawurlencode( $this->api_key() ) . '/account/info.json';
		$res = $this->http( $url, array(), array(), 'GET' );
		if ( $res['ok'] && isset( $res['data']['entries']['remaincredit'] ) ) {
			return (float) $res['data']['entries']['remaincredit'];
		}
		return null;
	}

	public function get_messages( $count = 100, $index = 0 ) {
		if ( ! $this->api_key() || ! jsms_get( 'gw_kavenegar_line' ) ) {
			return array();
		}
		$url = self::BASE . rawurlencode( $this->api_key() ) . '/sms/receive.json';
		$res = $this->http( $url, array( 'linenumber' => jsms_get( 'gw_kavenegar_line' ), 'isread' => 0 ), array(), 'GET' );
		$out = array();
		if ( $res['ok'] && ! empty( $res['data']['entries'] ) ) {
			foreach ( $res['data']['entries'] as $r ) {
				$out[] = array( 'from' => $r['sender'] ?? '', 'text' => $r['message'] ?? '', 'date' => $r['date'] ?? '' );
			}
		}
		return $out;
	}
}
endif;
