<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * درایور sms.ir — بر اساس API فعلیِ v1 (api.sms.ir/v1)، صحت‌سنجی‌شده در برابر
 * پیاده‌سازیِ واقعیِ افزونهٔ «پیامک حرفه‌ای ووکامرس».
 */
if ( ! class_exists( 'JSMS_Gateway_SMSIR' ) ) :

class JSMS_Gateway_SMSIR extends JSMS_Gateway_Driver {

	const BASE = 'https://api.sms.ir/v1/';

	public function id() {
		return 'smsir';
	}

	public function label() {
		return 'sms.ir';
	}

	public function settings_fields() {
		return array(
			array( 'key' => 'gw_smsir_apikey', 'label' => 'API-Key', 'type' => 'password' ),
			array( 'key' => 'gw_smsir_line', 'label' => 'شمارهٔ خط ارسال', 'type' => 'text',
				'help' => 'برای متن آزاد لازم است.' ),
		);
	}

	private function api_key() {
		return jsms_get( 'gw_smsir_apikey' );
	}

	public function send_simple( $to, $text, $from = '' ) {
		if ( ! $this->api_key() ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'API-Key اس‌ام‌اس.آی‌آر تنظیم نشده است.' );
		}
		$from = $from ?: jsms_get( 'gw_smsir_line' );
		if ( ! $from ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'شمارهٔ خط ارسال تنظیم نشده است.' );
		}
		$body = wp_json_encode( array(
			'lineNumber'   => $from,
			'messageText'  => $text,
			'mobiles'      => array( $to ),
			'sendDateTime' => null,
		) );
		$headers = array( 'Content-Type' => 'application/json', 'X-API-KEY' => $this->api_key() );
		$res = $this->http( self::BASE . 'send/bulk', $body, $headers );
		if ( ! $res['ok'] ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => $res['data'], 'error' => $res['error'] );
		}
		$pack_id = $res['data']['data']['packId'] ?? '';
		if ( '' === $pack_id ) {
			$err = $res['data']['message'] ?? ( $res['data']['title'] ?? 'ارسال ناموفق (sms.ir)' );
			return array( 'ok' => false, 'rec_id' => '', 'raw' => $res['data'], 'error' => $err );
		}
		return array( 'ok' => true, 'rec_id' => (string) $pack_id, 'raw' => $res['data'], 'error' => '' );
	}

	public function send_pattern( $to, $body_id, $args ) {
		if ( ! $this->api_key() ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'API-Key اس‌ام‌اس.آی‌آر تنظیم نشده است.' );
		}
		// sms.ir متغیرهای پترن را با نام می‌خواهد (نه ترتیبی)؛ چون افزونه آرگومان‌ها
		// را ترتیبی می‌فرستد، آن‌ها را با نام‌های p1, p2, ... ثبت می‌کنیم — این
		// نام‌ها باید موقع ساخت «قالب» در پنل sms.ir دقیقاً همین‌طور تعریف شوند.
		$params = array();
		foreach ( array_values( $args ) as $i => $val ) {
			$params[] = array( 'name' => 'p' . ( $i + 1 ), 'value' => (string) $val );
		}
		$body = wp_json_encode( array(
			'templateId' => (int) $body_id,
			'parameters' => $params,
			'mobile'     => $to,
		) );
		$headers = array( 'Content-Type' => 'application/json', 'x-api-key' => $this->api_key() );
		$res = $this->http( self::BASE . 'send/verify', $body, $headers );
		if ( ! $res['ok'] ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => $res['data'], 'error' => $res['error'] );
		}
		$id = $res['data']['messageId'] ?? '';
		if ( '' === $id ) {
			$err = $res['data']['message'] ?? ( $res['data']['title'] ?? 'ارسال ناموفق (sms.ir)' );
			return array( 'ok' => false, 'rec_id' => '', 'raw' => $res['data'], 'error' => $err );
		}
		return array( 'ok' => true, 'rec_id' => (string) $id, 'raw' => $res['data'], 'error' => '' );
	}

	public function check_connection() {
		if ( ! $this->api_key() ) {
			return array( 'ok' => false, 'credit' => null, 'error' => 'API-Key تنظیم نشده است.' );
		}
		$c = $this->get_credit();
		return null !== $c
			? array( 'ok' => true, 'credit' => $c, 'error' => '' )
			: array( 'ok' => false, 'credit' => null, 'error' => 'اتصال ناموفق — API-Key را بررسی کنید.' );
	}

	public function get_credit() {
		if ( ! $this->api_key() ) {
			return null;
		}
		$headers = array( 'X-API-KEY' => $this->api_key() );
		$res = $this->http( self::BASE . 'credit', '', $headers, 'GET' );
		if ( $res['ok'] && isset( $res['data']['data'] ) && is_numeric( $res['data']['data'] ) ) {
			return (float) $res['data']['data'];
		}
		return null;
	}
}
endif;
