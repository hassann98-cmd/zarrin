<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( ! class_exists( 'JSMS_Gateway_Reference' ) ) :
class JSMS_Gateway_Reference extends JSMS_Gateway_Driver {
    private $ref_class; private $ref_id; private $ref_label;
    public function __construct( $ref_class ) { $this->ref_class=$ref_class; $this->ref_id=method_exists($ref_class,'id')?$ref_class::id():sanitize_key($ref_class); $this->ref_label=method_exists($ref_class,'name')?$ref_class::name():$this->ref_id; }
    public function id(){return $this->ref_id;} public function label(){return $this->ref_label;}
    public function settings_fields(){
        return array(
            array('key'=>'username','label'=>'نام کاربری / API Key','type'=>'text','help'=>'طبق مستندات پنل وارد کنید. در پنل‌های Token معمولاً کلید دسترسی در همین فیلد قرار می‌گیرد.'),
            array('key'=>'password','label'=>'کلمه عبور / رمز وب‌سرویس','type'=>'password','help'=>'برای پنل‌هایی که فقط Token دارند می‌تواند خالی باشد.'),
            array('key'=>'line_number','label'=>'شماره ارسال‌کننده پیامک','type'=>'text','help'=>'برای پنل‌هایی که شماره فرستنده لازم دارند وارد شود.'),
        );
    }
    private function make_gateway(){ $class=$this->ref_class; return new $class(); }
    private function result($v){
        if(is_array($v)&&isset($v['ok'])) return $v;
        if(true===$v) return array('ok'=>true,'rec_id'=>'','raw'=>$v,'error'=>'');
        if(false===$v||null===$v) return array('ok'=>false,'rec_id'=>'','raw'=>$v,'error'=>'ارسال پیامک ناموفق بود.');
        return array('ok'=>false,'rec_id'=>'','raw'=>$v,'error'=>is_scalar($v)?(string)$v:'ارسال پیامک ناموفق بود.');
    }
    private function ref_send($gw){ try{return $this->result($gw->send());}catch(Throwable $e){return array('ok'=>false,'rec_id'=>'','raw'=>null,'error'=>$e->getMessage());} }
    public function send_simple($to,$text,$from=''){
        if(substr($this->ref_class,-7)==='Pattern') return array('ok'=>false,'rec_id'=>'','raw'=>null,'error'=>'این پنل برای ارسال خدماتی/Pattern است؛ برای پیام آزاد یک پنل عادی انتخاب کنید.');
        $gw=$this->make_gateway(); $gw->mobile=array(JSMS_Gateway::normalize_mobile($to)?:$to); $gw->set_message((string)$text); return $this->ref_send($gw);
    }
    public function send_pattern($to,$body_id,$args){
        $gw=$this->make_gateway(); $lines=array('pattern:'.trim((string)$body_id)); $i=1;
        foreach((array)$args as $key=>$value){$key=is_int($key)?'var'.$i:preg_replace('/[^A-Za-z0-9_-]/','',(string)$key);if(''===$key)$key='var'.$i;$lines[]=$key.':'.str_replace(array("\r","\n"),' ',(string)$value);$i++;}
        $gw->mobile=array(JSMS_Gateway::normalize_mobile($to)?:$to); $gw->set_message(implode("\n",$lines));
        $supports=is_a($gw,'PW\\PWSMS\\Gateways\\Features\\SendPatternFeature') || $this->ref_class==='PW\\PWSMS\\Gateways\\MeliPayamak' || substr($this->ref_class,-7)==='Pattern';
        if(!$supports) return array('ok'=>false,'rec_id'=>'','raw'=>null,'error'=>'ارسال Pattern برای این پنل در نسخه مرجع پیاده‌سازی نشده است.');
        try{return method_exists($gw,'send_pattern_sms')?$this->result($gw->send_pattern_sms()):$this->result($gw->send());}catch(Throwable $e){return array('ok'=>false,'rec_id'=>'','raw'=>null,'error'=>$e->getMessage());}
    }
    public function send_otp($to){return array('ok'=>false,'code'=>'','raw'=>null,'error'=>'OTP اختصاصی برای این پنل تعریف نشده است؛ از Pattern استفاده کنید.');}
    public function check_connection(){
        $gw=$this->make_gateway(); $has=trim((string)jsms_get('username',''))!==''||trim((string)jsms_get('password',''))!=='';
        if(!$has)return array('ok'=>false,'credit'=>null,'error'=>'اطلاعات اتصال وارد نشده است.');
        if(method_exists($gw,'get_credit')){try{$c=$gw->get_credit();return array('ok'=>null!==$c,'credit'=>null!==$c?(float)$c:null,'error'=>null!==$c?'':'اتصال برقرار نشد یا اعتبار قابل دریافت نیست.');}catch(Throwable $e){return array('ok'=>false,'credit'=>null,'error'=>$e->getMessage());}}
        return array('ok'=>true,'credit'=>null,'error'=>'اطلاعات اتصال ثبت شده است. برای تأیید واقعی، پیامک تست ارسال کنید.');
    }
    public function get_credit(){ $gw=$this->make_gateway(); if(!method_exists($gw,'get_credit'))return null; try{$v=$gw->get_credit();return is_numeric($v)?(float)$v:null;}catch(Throwable $e){return null;} }
    public function get_messages($count=100,$index=0){$gw=$this->make_gateway();if(!method_exists($gw,'get_messages'))return array();try{$v=$gw->get_messages($count,$index);return is_array($v)?$v:array();}catch(Throwable $e){return array();}}
}
endif;
