<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * درایور آی‌پی‌پنل (ippanel.com) — بر اساس مستندات رسمی Edge API
 * (ippanelcom.github.io/Edge-Document). اندپوینت‌های ارسال (webservice/pattern)
 * از مستندات رسمی تأیید شده‌اند. اندپوینت اعتبار حساب مستند عمومی نداشت؛ بر
 * اساس الگوی یکسانِ بقیهٔ API (پوشش data/meta) حدس زده شده — اگر کار نکرد،
 * فقط متد get_credit در همین فایل نیاز به اصلاح دارد.
 */
if ( ! class_exists( 'JSMS_Gateway_IPPanel' ) ) :

class JSMS_Gateway_IPPanel extends JSMS_Gateway_Driver {

	const BASE = 'https://edge.ippanel.com/v1/api/';

	public function id() {
		return 'ippanel';
	}

	public function label() {
		return 'آی‌پی‌پنل';
	}

	public function settings_fields() {
		return array(
			array( 'key' => 'gw_ippanel_token', 'label' => 'توکن API (Authorization)', 'type' => 'password' ),
			array( 'key' => 'gw_ippanel_from', 'label' => 'شمارهٔ فرستنده (originator)', 'type' => 'text',
				'help' => 'به فرمت بین‌المللی، مثلاً +983000505' ),
		);
	}

	private function headers() {
		return array( 'Authorization' => jsms_get( 'gw_ippanel_token' ), 'Content-Type' => 'application/json' );
	}

	public function send_simple( $to, $text, $from = '' ) {
		if ( ! jsms_get( 'gw_ippanel_token' ) ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'توکن API آی‌پی‌پنل تنظیم نشده است.' );
		}
		$from = $from ?: jsms_get( 'gw_ippanel_from' );
		if ( ! $from ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'شمارهٔ فرستندهٔ آی‌پی‌پنل تنظیم نشده است.' );
		}
		$url  = self::BASE . 'send';
		$body = wp_json_encode( array(
			'sending_type' => 'webservice',
			'from_number'  => $from,
			'message'      => $text,
			'params'       => array( 'recipients' => array( $to ) ),
		) );
		$res = $this->http( $url, $body, $this->headers() );
		return $this->parse_send( $res );
	}

	public function send_pattern( $to, $body_id, $args ) {
		if ( ! jsms_get( 'gw_ippanel_token' ) ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'توکن API آی‌پی‌پنل تنظیم نشده است.' );
		}
		$from = jsms_get( 'gw_ippanel_from' );
		// در آی‌پی‌پنل، params یک آبجکت کلید→مقدار است، نه آرایهٔ ترتیبی؛ چون افزونه
		// آرگومان‌ها را ترتیبی می‌فرستد، آن‌ها را p1, p2, p3... نام‌گذاری می‌کنیم —
		// نام پارامترهای پترن باید موقع ساخت پترن در پنل، همین‌طور تعریف شوند.
		$params = array();
		foreach ( array_values( $args ) as $i => $val ) {
			$params[ 'p' . ( $i + 1 ) ] = (string) $val;
		}
		$url  = self::BASE . 'send';
		$body = wp_json_encode( array(
			'sending_type' => 'pattern',
			'from_number'  => $from,
			'code'         => (string) $body_id,
			'recipients'   => array( $to ),
			'params'       => $params,
		) );
		$res = $this->http( $url, $body, $this->headers() );
		return $this->parse_send( $res );
	}

	private function parse_send( $res ) {
		if ( ! $res['ok'] ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => $res['data'], 'error' => $res['error'] );
		}
		$ok  = ! empty( $res['data']['meta']['status'] );
		$msg = $res['data']['meta']['message'] ?? '';
		if ( ! $ok ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => $res['data'], 'error' => $msg ?: 'ارسال ناموفق (آی‌پی‌پنل)' );
		}
		$id = $res['data']['data']['message_outbox_ids'][0] ?? '';
		return array( 'ok' => true, 'rec_id' => (string) $id, 'raw' => $res['data'], 'error' => '' );
	}

	public function check_connection() {
		$c = $this->get_credit();
		return null !== $c
			? array( 'ok' => true, 'credit' => $c, 'error' => '' )
			: array( 'ok' => false, 'credit' => null, 'error' => 'اتصال ناموفق — توکن API را بررسی کنید.' );
	}

	public function get_credit() {
		if ( ! jsms_get( 'gw_ippanel_token' ) ) {
			return null;
		}
		$url = self::BASE . 'credit';
		$res = $this->http( $url, '', $this->headers(), 'GET' );
		if ( $res['ok'] && isset( $res['data']['data']['credit'] ) ) {
			return (float) $res['data']['data']['credit'];
		}
		return null;
	}
}
endif;
