<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * قرارداد مشترک هر «درایور» پنل پیامکی. هر پنل جدید (کاوه‌نگار، قاصدک، آی‌پی‌پنل و...)
 * باید این کلاس را extend کند و همین متدها را با API واقعی خودش پیاده‌سازی کند.
 * بقیهٔ افزونه فقط با JSMS_Gateway (کلاس نما/facade) کار می‌کند و از این جزئیات
 * بی‌خبر است — برای همین افزودن یک پنل تازه، هیچ‌جای دیگری از کد را تغییر نمی‌دهد.
 */
if ( ! class_exists( 'JSMS_Gateway_Driver' ) ) :

abstract class JSMS_Gateway_Driver {

	/** شناسهٔ یکتای این پنل — باید با کلید ارسالی در تنظیمات (`provider`) یکی باشد. */
	abstract public function id();

	/** نام نمایشیِ فارسی — همان چیزی که در تنظیمات به مدیر نشان داده می‌شود. */
	abstract public function label();

	/**
	 * ارسال پیام متنی آزاد (خط اختصاصی/غیرخدماتی).
	 * @return array{ok:bool, rec_id:string, raw:mixed, error:string}
	 */
	abstract public function send_simple( $to, $text, $from = '' );

	/**
	 * ارسال با پترن/قالب (خط خدماتی). اگر این پنل چنین قابلیتی ندارد یا هنوز
	 * پیاده‌سازی نشده، پیاده‌سازیِ پیش‌فرض یک خطای روشن برمی‌گرداند.
	 * @param array $args آرگومان‌های پترن به ترتیب.
	 * @return array{ok:bool, rec_id:string, raw:mixed, error:string}
	 */
	public function send_pattern( $to, $body_id, $args ) {
		return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'ارسال با پترن برای «' . $this->label() . '» پشتیبانی نمی‌شود.' );
	}

	/**
	 * ارسال رمز یک‌بارمصرف. اگر پنل انتخاب‌شده چنین اندپوینت جداگانه‌ای ندارد،
	 * می‌تواند این را با send_pattern/send_simple شبیه‌سازی کند.
	 * @return array{ok:bool, code:string, raw:mixed, error:string}
	 */
	public function send_otp( $to ) {
		return array( 'ok' => false, 'code' => '', 'raw' => null, 'error' => 'ارسال OTP جداگانه برای «' . $this->label() . '» پشتیبانی نمی‌شود.' );
	}

	/** @return array{ok:bool, credit:?float, error:string} */
	abstract public function check_connection();

	/** @return float|null */
	abstract public function get_credit();

	/**
	 * دریافت پیام‌های ورودی (برای خواندن پاسخ نظرات مشتری). پنل‌هایی که خط
	 * دوطرفه ندارند، آرایهٔ خالی برمی‌گردانند — بدون خطا، چون این قابلیتِ
	 * اختیاری است و نبودش نباید چیزی را بشکند.
	 * @return array لیستی از ['from'=>..., 'text'=>..., 'date'=>...]
	 */
	public function get_messages( $count = 100, $index = 0 ) {
		return array();
	}

	/**
	 * فیلدهای تنظیماتِ اختصاصیِ این پنل — برای رندر خودکار در صفحهٔ «تنظیمات اتصال».
	 * هر آیتم: ['key'=>'gw_xxx_apikey', 'label'=>'...', 'type'=>'text|password', 'help'=>'...']
	 * کلید تنظیمات باید با پیشوند gw_{id}_ شروع شود تا بین پنل‌ها تداخل نکند.
	 */
	public function settings_fields() {
		return array();
	}

	/** کمک‌کنندهٔ مشترک HTTP — همهٔ درایورها می‌توانند از این استفاده کنند. */
	protected function http( $url, $body, $headers = array(), $method = 'POST' ) {
		$args = array( 'timeout' => 25, 'headers' => $headers );
		if ( 'GET' === strtoupper( $method ) ) {
			$resp = wp_remote_get( $url, $args );
		} else {
			$args['body'] = $body;
			$resp = wp_remote_post( $url, $args );
		}
		if ( is_wp_error( $resp ) ) {
			return array( 'ok' => false, 'code' => 0, 'data' => null, 'error' => $resp->get_error_message() );
		}
		$code = wp_remote_retrieve_response_code( $resp );
		$raw  = wp_remote_retrieve_body( $resp );
		$data = json_decode( $raw, true );
		if ( null === $data ) {
			$data = $raw;
		}
		if ( $code < 200 || $code >= 300 ) {
			$detail = is_array( $data ) ? ( $data['message'] ?? ( $data['error'] ?? wp_json_encode( $data, JSON_UNESCAPED_UNICODE ) ) ) : wp_strip_all_tags( (string) $data );
			return array( 'ok' => false, 'code' => $code, 'data' => $data, 'error' => 'HTTP ' . $code . ' – ' . mb_substr( (string) $detail, 0, 300 ) );
		}
		return array( 'ok' => true, 'code' => $code, 'data' => $data, 'error' => '' );
	}
}
endif;
