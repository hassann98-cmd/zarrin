<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * درایور قاصدک (ghasedaksms.com) — بر اساس API فعلیِ v1 (gateway.ghasedaksms.com).
 * توجه: نسخهٔ قبلی این فایل بر اساس یک API قدیمی/متفاوت (ghasedak.me/v2) نوشته
 * شده بود که دیگر درست کار نمی‌کرد؛ این نسخه با کد واقعیِ افزونهٔ «پیامک حرفه‌ای
 * ووکامرس» (که این آدرس/فرمت را زنده استفاده می‌کند) صحت‌سنجی شده است.
 */
if ( ! class_exists( 'JSMS_Gateway_Ghasedak' ) ) :

class JSMS_Gateway_Ghasedak extends JSMS_Gateway_Driver {

	const BASE = 'https://gateway.ghasedaksms.com/api/v1';

	public function id() {
		return 'ghasedak';
	}

	public function label() {
		return 'قاصدک';
	}

	public function settings_fields() {
		return array(
			array( 'key' => 'gw_ghasedak_apikey', 'label' => 'API-Key', 'type' => 'password' ),
			array( 'key' => 'gw_ghasedak_line', 'label' => 'شمارهٔ خط ارسال', 'type' => 'text',
				'help' => 'برای متن آزاد لازم است.' ),
		);
	}

	private function headers() {
		return array(
			'Content-Type' => 'application/json',
			'Accept'       => 'application/json',
			'ApiKey'       => jsms_get( 'gw_ghasedak_apikey' ),
		);
	}

	public function send_simple( $to, $text, $from = '' ) {
		if ( ! jsms_get( 'gw_ghasedak_apikey' ) ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'API-Key قاصدک تنظیم نشده است.' );
		}
		$from = $from ?: jsms_get( 'gw_ghasedak_line' );
		if ( ! $from ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'شمارهٔ خط ارسال قاصدک تنظیم نشده است.' );
		}
		$body = wp_json_encode( array(
			'sendDate' => gmdate( 'c' ),
			'Sender'   => $from,
			'receptor' => $to,
			'message'  => $text,
			'checkId'  => (string) wp_rand( 1, 1000000 ),
		) );
		$res = $this->http( self::BASE . '/Send/Bulk', $body, $this->headers() );
		return $this->parse_send( $res );
	}

	public function send_pattern( $to, $body_id, $args ) {
		if ( ! jsms_get( 'gw_ghasedak_apikey' ) ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => null, 'error' => 'API-Key قاصدک تنظیم نشده است.' );
		}
		// قاصدک متغیرهای پترن را به‌صورت آرایه‌ای از {param, value} می‌خواهد، نه
		// فیلدهای مسطح — نام param باید همان چیزی باشد که موقع ساخت پترن در پنل
		// قاصدک تعریف کرده‌اید (مثلاً p1, p2, ...).
		$all_param = array();
		foreach ( array_values( $args ) as $i => $val ) {
			$all_param[] = array( 'param' => 'p' . ( $i + 1 ), 'value' => (string) $val );
		}
		$body = wp_json_encode( array(
			'template' => (string) $body_id,
			'type'     => '1',
			'receptor' => $to,
			'allparam' => $all_param,
		) );
		$res = $this->http( self::BASE . '/Send/NewOTP', $body, $this->headers() );
		return $this->parse_send( $res );
	}

	private function parse_send( $res ) {
		if ( ! $res['ok'] ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => $res['data'], 'error' => $res['error'] );
		}
		$ok = ! empty( $res['data']['isSuccess'] );
		if ( ! $ok ) {
			return array( 'ok' => false, 'rec_id' => '', 'raw' => $res['data'], 'error' => $res['data']['message'] ?? 'ارسال ناموفق (قاصدک)' );
		}
		$id = $res['data']['data']['items'][0]['messageId'] ?? '';
		return array( 'ok' => true, 'rec_id' => (string) $id, 'raw' => $res['data'], 'error' => '' );
	}

	public function check_connection() {
		if ( ! jsms_get( 'gw_ghasedak_apikey' ) || ! jsms_get( 'gw_ghasedak_line' ) ) {
			return array( 'ok' => false, 'credit' => null, 'error' => 'API-Key یا شمارهٔ خط قاصدک تنظیم نشده است.' );
		}
		// قاصدک اندپوینت عمومیِ اعتبار مستند ندارد؛ صحت اتصال را با یک ارسال آزمایشیِ
		// بی‌اثر (به شمارهٔ خودِ خط) نمی‌سنجیم تا هزینه/پیامک واقعی مصرف نشود — فقط
		// می‌گوییم اطلاعات کامل است؛ خطای واقعی هنگام اولین ارسال واقعی معلوم می‌شود.
		return array( 'ok' => true, 'credit' => null, 'error' => '' );
	}

	public function get_credit() {
		return null;
	}
}
endif;
