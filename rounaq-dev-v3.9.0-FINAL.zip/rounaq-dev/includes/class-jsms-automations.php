<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * اتوماسیون‌های اصلی رویدادمحور و اسکن‌های زمان‌بندی‌شده.
 */
if ( ! class_exists( 'JSMS_Automations' ) ) :

class JSMS_Automations {

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// خوش‌آمدگویی هنگام ثبت‌نام.
		add_action( 'woocommerce_created_customer', array( $this, 'on_new_customer' ), 20, 1 );
		add_action( 'user_register', array( $this, 'on_user_register' ), 20, 1 );

		// پیام پس از ثبت سفارش (کلاسیک + بلاک/Store API).
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'on_new_order' ), 20, 1 );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'on_new_order' ), 20, 1 );
		add_action( 'woocommerce_new_order', array( $this, 'on_new_order' ), 20, 1 );

		// اعلان تغییر وضعیت سفارش.
		add_action( 'woocommerce_order_status_changed', array( $this, 'on_status_change' ), 20, 4 );

		// اعلان به مدیر: کمبود موجودی.
		add_action( 'woocommerce_low_stock', array( $this, 'on_low_stock' ), 20, 1 );

		// ردیابی سبد خرید — هم کاربر لاگین‌شده هم مهمان (با شناسهٔ سشن خودِ ووکامرس).
		add_action( 'woocommerce_add_to_cart', array( $this, 'track_cart' ), 20 );
		add_action( 'woocommerce_cart_item_removed', array( $this, 'track_cart' ), 20 );
		add_action( 'woocommerce_cart_updated', array( $this, 'track_cart' ), 20 );

		// لایهٔ اول گرفتن شمارهٔ موبایل مهمان: هر بار ووکامرس هزینهٔ ارسال را دوباره
		// حساب می‌کند (تغییر استان/شهر/کدپستی و...)، کل فرم چک‌اوت را می‌فرستد.
		add_action( 'woocommerce_checkout_update_order_review', array( $this, 'capture_checkout_phone_from_post_data' ) );

		// لایهٔ دوم: اسکریپت مستقل خودِ پلاگین (نه قالب) روی فیلد استاندارد #billing_phone.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_checkout_phone_capture' ) );
		add_action( 'wp_ajax_jsms_capture_phone', array( $this, 'ajax_capture_phone' ) );
		add_action( 'wp_ajax_nopriv_jsms_capture_phone', array( $this, 'ajax_capture_phone' ) );

		// وقتی مهمانی که سبدش ردیابی می‌شد لاگین/ثبت‌نام کرد، سبدش به کاربر تازه متصل شود
		// (نه اینکه یک سبد جدید و جدا برای کاربر لاگین‌شده ساخته شود).
		add_action( 'wp_login', array( $this, 'merge_guest_cart_on_login' ), 10, 2 );
		add_action( 'woocommerce_created_customer', array( $this, 'merge_guest_cart_on_new_customer' ), 5, 1 );

		// وقتی مشتری از لینک پیامک وارد صفحهٔ پرداخت سفارش می‌شود، همان درگاهی که سفارش
		// از قبل با آن ثبت شده (مثلاً کارت‌به‌کارت) به‌جای اولین درگاه فهرست، از پیش انتخاب شود.
		add_action( 'template_redirect', array( $this, 'preselect_order_payment_method' ) );

		// صفحهٔ عمومی بازیابی سبد رها شده: /?jsms_recover=TOKEN
		add_action( 'init', array( $this, 'maybe_handle_recover' ) );
	}

	/* ---------------------------------------------------------------------
	 * بازیابی واقعی سبد رها شده از روی لینک پیامک
	 * ------------------------------------------------------------------- */
	public function maybe_handle_recover() {
		if ( empty( $_GET['jsms_recover'] ) ) {
			return;
		}
		$token = sanitize_text_field( wp_unslash( $_GET['jsms_recover'] ) );
		global $wpdb;
		$t   = JSMS_DB::carts_table();
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE token=%s", $token ) );
		if ( ! $row ) {
			wp_die( 'لینک بازیابی سبد نامعتبر یا منقضی شده است.' );
		}
		// انقضای توکن — یک لینک بازیابی نباید تا ابد معتبر بماند.
		$expire_days = (int) jsms_get( 'cart_recovery_expiry_days', 7 );
		if ( $row->created_at && strtotime( $row->created_at ) < time() - $expire_days * DAY_IN_SECONDS ) {
			wp_die( 'این لینک بازیابی منقضی شده است.' );
		}
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			wp_die( 'سبد خرید در دسترس نیست، لطفاً دوباره تلاش کنید.' );
		}

		$lines = $row->items_json ? json_decode( $row->items_json, true ) : array();

		// ردیف‌های قدیمی (قبل از این نسخه) اطلاعات ساختاریافته ندارند — فقط به سبد هدایت شود.
		if ( empty( $lines ) || ! is_array( $lines ) ) {
			wp_safe_redirect( function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/cart/' ) );
			exit;
		}

		$added = array();
		$removed = array();
		foreach ( $lines as $line ) {
			$product_id   = (int) ( $line['product_id'] ?? 0 );
			$variation_id = (int) ( $line['variation_id'] ?? 0 );
			$qty          = max( 1, (int) ( $line['qty'] ?? 1 ) );
			$name         = (string) ( $line['name'] ?? '' );
			$product      = $variation_id ? wc_get_product( $variation_id ) : wc_get_product( $product_id );

			if ( ! $product || ! $product->is_purchasable() || ! $product->is_in_stock() ) {
				$removed[] = $name;
				continue;
			}
			if ( $product->managing_stock() && null !== $product->get_stock_quantity() ) {
				$qty = min( $qty, (int) $product->get_stock_quantity() );
			}
			if ( $qty < 1 ) {
				$removed[] = $name;
				continue;
			}
			$variation_attrs = ( ! empty( $line['variation'] ) && is_array( $line['variation'] ) ) ? $line['variation'] : array();

			// اگر این کالا از قبل توی سبدِ فعلیِ مشتری هست (مثلاً خودش دوباره اضافه‌اش کرده)،
			// دوباره اضافه نکن — وگرنه تعدادش بدون کنترل جمع می‌شود (رفتار پیش‌فرض ووکامرس).
			$cart_id = WC()->cart->generate_cart_id( $product_id, $variation_id, $variation_attrs );
			if ( WC()->cart->find_product_in_cart( $cart_id ) ) {
				$added[] = $name;
				continue;
			}

			$added_key = WC()->cart->add_to_cart( $product_id, $qty, $variation_id, $variation_attrs );
			if ( $added_key ) {
				$added[] = $name;
			} else {
				$removed[] = $name;
			}
		}
		if ( function_exists( 'wc_clear_notices' ) ) {
			wc_clear_notices(); // پیام‌های خودکار افزودن به سبد را پاک می‌کنیم چون خودمان صفحهٔ نتیجه را می‌سازیم.
		}
		$wpdb->update( $t, array( 'recovered' => 1 ), array( 'id' => $row->id ) );

		$this->render_recover_page( $added, $removed );
		exit;
	}

	private function render_recover_page( $added, $removed ) {
		$cart_url = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/cart/' );
		?>
		<!doctype html>
		<html lang="fa" dir="rtl">
		<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>بازیابی سبد خرید</title>
		<style>
			:root{--green:#059669;--green-dark:#1a5c38;--red:#ed1944;--bg:#faf9f7;--card:#fff;--text:#1f2937;--muted:#6b7280;--line:#e5e7eb}
			*{box-sizing:border-box}
			body{font-family:Tahoma,system-ui,sans-serif;background:var(--bg);margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;color:var(--text)}
			.card{background:var(--card);border-radius:20px;box-shadow:0 12px 40px rgba(0,0,0,.08);max-width:420px;width:100%;padding:28px 24px;text-align:center}
			.icon{width:60px;height:60px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;font-size:28px;
				background:<?php echo $added ? 'linear-gradient(135deg,var(--green),var(--green-dark))' : 'var(--red)'; ?>;color:#fff}
			h1{font-size:18px;margin:0 0 10px}
			p{font-size:13.5px;color:var(--muted);line-height:1.9;margin:0 0 14px}
			.list{text-align:right;background:var(--bg);border-radius:12px;padding:12px 16px;margin:0 0 14px;font-size:13px}
			.list b{display:block;margin-bottom:6px;font-size:12.5px}
			.list.ok b{color:var(--green-dark)}
			.list.bad b{color:var(--red)}
			ul{margin:0;padding-inline-start:18px}
			.btn{display:inline-block;width:100%;background:linear-gradient(135deg,var(--green),var(--green-dark));color:#fff;text-decoration:none;
				border-radius:12px;padding:14px;font-weight:700;font-size:15px}
		</style>
		</head>
		<body>
			<div class="card">
				<div class="icon"><?php echo $added ? '🛒' : '😕'; ?></div>
				<?php if ( $added ) : ?>
					<h1>سبد خریدتان آماده شد</h1>
					<p>کالاهای موجود دوباره به سبد شما اضافه شدند (با قیمت به‌روز فعلی).</p>
					<div class="list ok"><b>✅ اضافه شد</b><ul><?php foreach ( $added as $n ) : ?><li><?php echo esc_html( $n ); ?></li><?php endforeach; ?></ul></div>
				<?php else : ?>
					<h1>متأسفانه این کالاها دیگر موجود نیستند</h1>
					<p>امکان افزودن آن‌ها به سبد خرید وجود ندارد.</p>
				<?php endif; ?>
				<?php if ( $removed ) : ?>
					<div class="list bad"><b>⚠️ دیگر موجود نیست</b><ul><?php foreach ( $removed as $n ) : ?><li><?php echo esc_html( $n ); ?></li><?php endforeach; ?></ul></div>
				<?php endif; ?>
				<a class="btn" href="<?php echo esc_url( $cart_url ); ?>"><?php echo $added ? 'مشاهدهٔ سبد خرید' : 'رفتن به فروشگاه'; ?></a>
			</div>
		</body>
		</html>
		<?php
	}

	public function preselect_order_payment_method() {
		if ( ! function_exists( 'is_wc_endpoint_url' ) || ! is_wc_endpoint_url( 'order-pay' ) ) {
			return;
		}
		global $wp;
		$order_id = isset( $wp->query_vars['order-pay'] ) ? absint( $wp->query_vars['order-pay'] ) : 0;
		if ( ! $order_id ) {
			return;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$method = $order->get_payment_method();
		if ( $method && function_exists( 'WC' ) && WC()->session ) {
			WC()->session->set( 'chosen_payment_method', $method );
		}
	}

	/* ---------------------------------------------------------------------
	 * خوش‌آمدگویی
	 * ------------------------------------------------------------------- */
	public function on_new_customer( $customer_id ) {
		$this->send_welcome( $customer_id );
	}
	public function on_user_register( $user_id ) {
		// فقط اگر از مسیر ووکامرس نیامده (جلوگیری از دوبار).
		if ( did_action( 'woocommerce_created_customer' ) ) {
			return;
		}
		$this->send_welcome( $user_id );
	}

	private function send_welcome( $user_id ) {
		if ( ! jsms_get( 'welcome_enabled' ) ) {
			return;
		}
		$mobile = $this->user_mobile( $user_id );
		if ( ! $mobile ) {
			return;
		}
		if ( JSMS_DB::already_sent( $mobile, 'welcome', 86400 ) ) {
			return;
		}
		$vars = JSMS_Templates::user_vars( $user_id );
		JSMS_Templates::dispatch( array(
			'to' => $mobile, 'user_id' => $user_id, 'type' => 'welcome', 'force' => true,
			'mode' => jsms_get( 'welcome_mode', 'text' ),
			'text' => JSMS_Templates::render( jsms_get( 'welcome_text' ), $vars ),
			'pattern_id' => jsms_get( 'welcome_pattern' ),
			'pattern_args' => array( $vars['first_name'] ?? '', get_bloginfo( 'name' ) ),
		) );
	}

	/* ---------------------------------------------------------------------
	 * پیام پس از خرید + تغییر وضعیت
	 * ------------------------------------------------------------------- */
	/**
	 * وضعیت‌هایی که هنوز سفارش را «تأییدشده» نمی‌کنند — پرداخت یا رسید هنوز
	 * در انتظار است. تا رسیدن به وضعیتی خارج از این لیست، اعلان «سفارش جدید»
	 * به مدیر ارسال نمی‌شود (مثلاً مرسولهٔ کارت‌به‌کارت که رسیدش هنوز تأیید نشده).
	 */
	private function awaiting_statuses() {
		return array( 'pending', 'on-hold', 'shetab-approval', 'checkout-draft' );
	}

	/**
	 * وضعیت‌های منفی/نهایی که هرگز نباید اعلان «سفارش جدید» را فعال کنند
	 * (سفارش لغو/ناموفق شده، نه اینکه تأیید شده باشد).
	 */
	private function negative_statuses() {
		return array( 'cancelled', 'failed', 'refunded', 'trash' );
	}

	public function on_new_order( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		if ( ! $order->get_items() ) {
			// اقلام سفارش هنوز اضافه نشده (این هوک گاهی زودتر از افزوده‌شدن محصولات فایر می‌شود)؛
			// منتظر فراخوانی بعدی (woocommerce_checkout_order_processed) می‌مانیم تا {items} خالی نرود.
			return;
		}
		if ( $order->get_meta( '_jsms_order_sent' ) ) {
			return;
		}
		// عمداً save_meta_data() نه save() کامل — این هوک گاهی از وسط چرخهٔ ذخیرهٔ خودِ
		// سفارش (مثلاً status_transition هنگام payment_complete) فایر می‌شود؛ فراخوانی
		// save() کامل از داخل آن، save بازگشتی/تودرتوی سفارش است که در HPOS بی‌ثبات است.
		$order->update_meta_data( '_jsms_order_sent', 1 );
		$order->save_meta_data();

		// این سفارش را برای ردیابی به سبد وصل کن. اگر هنوز «در انتظار پرداخت» است،
		// سبد را هنوز «بازیابی‌شده» علامت نزن — چون مشتری واقعاً پرداخت نکرده و اگر تا
		// مهلت یادآوریِ سبد رها شده هنوز پرداخت نشده باشد، باید همان یادآوری برود.
		$this->mark_cart_recovered(
			$order->get_customer_id(), $this->order_mobile( $order ), $order->get_id(),
			'pending' !== $order->get_status()
		);

		// اگر سفارش هنوز در انتظار پرداخت/تأیید رسید است (مثلاً کارت‌به‌کارت)، اعلان «سفارش جدید»
		// عقب می‌افتد تا وقتی واقعاً تأیید شود — نه همان لحظهٔ ثبت اولیه.
		if ( ! in_array( $order->get_status(), $this->awaiting_statuses(), true ) ) {
			$this->notify_admin_new_order( $order );
		}

		// سفارش کارت‌به‌کارت (درگاه شتاب) تازه ثبت شده و هنوز در انتظار پرداخت است —
		// به مشتری بگو باید کارت‌به‌کارت را انجام دهد و رسیدش را ثبت کند.
		if ( 'pending' === $order->get_status() ) {
			$this->notify_customer_card_pending( $order );
		}

		// پیامک جداگانهٔ «پس از ثبت سفارش» عمداً حذف شد — با «اعلان تغییر وضعیت سفارش»
		// (وضعیت «در حال انجام») همپوشانی داشت و باعث ارسال دوتا پیامک پشت‌سرهم می‌شد.
	}

	/**
	 * پیامک «در انتظار پرداخت کارت‌به‌کارت» — فقط برای سفارش‌های ثبت‌شده از طریق
	 * درگاه کارت‌به‌کارت شتاب (شناسهٔ درگاه: shetab)، نه پرداخت آنلاین بانکی
	 * (که خودش طی چند ثانیه یا به وضعیت «در حال انجام» می‌رود یا شکست می‌خورد).
	 */
	private function notify_customer_card_pending( $order ) {
		if ( 'shetab' !== $order->get_payment_method() ) {
			return;
		}
		if ( ! jsms_get( 'card_pending_enabled' ) ) {
			return;
		}
		$mobile = $this->order_mobile( $order );
		if ( ! $mobile ) {
			return;
		}
		if ( JSMS_DB::already_sent( $mobile, 'card_payment_started', 0, $order->get_id() ) ) {
			return;
		}
		$vars = JSMS_Templates::order_vars( $order );
		JSMS_Templates::dispatch( array(
			'to' => $mobile, 'user_id' => $order->get_customer_id(), 'type' => 'card_payment_started',
			'ref_id' => $order->get_id(), 'force' => true, 'mode' => 'text',
			'text' => JSMS_Templates::render( jsms_get( 'card_pending_text' ), $vars ),
		) );
	}

	/**
	 * اعلان به مدیر که سفارش تأیید/قطعی شده (یک‌بار، صرف‌نظر از اینکه این لحظهٔ
	 * ثبت سفارش باشد یا بعداً هنگام تأیید رسید/تغییر وضعیت).
	 */
	private function notify_admin_new_order( $order ) {
		if ( $order->get_meta( '_jsms_admin_alert_sent' ) ) {
			return;
		}
		if ( ! jsms_get( 'admin_order_alert_enabled' ) ) {
			return;
		}
		$admin = jsms_get( 'admin_mobile' );
		if ( ! $admin ) {
			return;
		}
		// اگر قبلاً با موفقیت ارسال شده، دوباره نفرست (لاگ را هم می‌بیند، نه فقط متا —
		// اگر ارسال قبلی موفق بود ولی متا به هر دلیلی ذخیره نشد، باز هم دوباره نرود).
		if ( JSMS_DB::already_sent( $admin, 'admin_new_order', 0, $order->get_id() ) ) {
			return;
		}
		// سقفِ تلاش مجدد: اگر پنل پیامکی برای این سفارش مدام پاسخِ «ناموفق» گمراه‌کننده
		// می‌دهد (پیامک واقعاً می‌رسد ولی لاگ آن را ناموفق ثبت می‌کند)، شبکهٔ ایمنیِ ۱۵
		// دقیقه‌ای این تابع بدون این سقف تا ابد هر بار دوباره پیامک واقعی می‌فرستاد.
		$attempts = (int) $order->get_meta( '_jsms_admin_alert_attempts' );
		if ( $attempts >= 5 ) {
			return;
		}
		$order->update_meta_data( '_jsms_admin_alert_attempts', $attempts + 1 );
		$order->save_meta_data();
		$vars = JSMS_Templates::order_vars( $order );
		$vars['customer_mobile'] = $this->order_mobile( $order ) ?: '—';
		$res = JSMS_Templates::dispatch( array(
			'to' => $admin, 'type' => 'admin_new_order', 'ref_id' => $order->get_id(),
			'mode' => 'text', 'force' => true,
			'text' => JSMS_Templates::render( jsms_get( 'admin_order_alert_text' ), $vars ),
		) );
		if ( ! empty( $res['ok'] ) ) {
			// متای «ارسال شد» فقط بعد از تأیید موفقیتِ واقعیِ ارسال ثبت می‌شود — نه قبلش —
			// وگرنه اگر API پیامک خطا بدهد، این هوک هیچ‌وقت دوباره تلاش نمی‌کند (چون
			// خودِ گارد بالای همین تابع فکر می‌کند قبلاً «ارسال شده»). save_meta_data()
			// نه save() کامل، چون این تابع از وسط status_transition() سفارش هم صدا زده
			// می‌شود؛ یک save() کامل و بازگشتی از اینجا دقیقاً همون چیزی بود که باعث شد
			// برای سفارش #6298 (Parsian) نه پیامک مدیر و نه پیامک وضعیت مشتری نرود.
			$order->update_meta_data( '_jsms_admin_alert_sent', 1 );
			$order->save_meta_data();
		} elseif ( false !== strpos( (string) ( $res['error'] ?? '' ), 'فیلترشده' ) ) {
			// «متن حاوی کلمهٔ فیلترشده است» یعنی پنل، متن را برای بررسی دستیِ کارشناس نگه
			// داشته — نه یک خطای گذرا. با همین متن دوباره امتحان کردن هر ۱۵ دقیقه فقط باعث
			// می‌شود چند نسخهٔ تکراری از همین پیام برای تأیید صف بکشد و بعداً چندبار واقعاً
			// برسد (دقیقاً همان چیزی که برای سفارش #6418 با کلمهٔ «آشغال» در اسم کالا افتاد)؛
			// پس دیگر تلاش مجدد نمی‌شود — سقف را همین‌جا کامل می‌کنیم.
			$order->update_meta_data( '_jsms_admin_alert_attempts', 5 );
			$order->save_meta_data();
		}
		$order->add_order_note( ! empty( $res['ok'] )
			? 'پیامک «سفارش جدید» به مدیر ارسال شد (رونق).'
			: 'ارسال پیامک «سفارش جدید» به مدیر ناموفق بود: ' . ( $res['error'] ?? 'خطای نامشخص' )
		);
	}

	/**
	 * شبکهٔ ایمنی: اگر به هر دلیل غیرمنتظره (مثلاً خطای گذرا حین ذخیرهٔ خودِ سفارش، دقیقاً
	 * مثل اتفاقی که برای سفارش #6298 افتاد) اعلان «سفارش جدید» به مدیر ارسال نشده باشد،
	 * این تابع دوباره تلاش می‌کند — تا هیچ سفارش تأییدشده‌ای بی‌صدا برای همیشه گم نشود.
	 */
	public static function retry_missed_admin_alerts() {
		$self       = self::instance();
		$exclude    = array_merge( $self->awaiting_statuses(), $self->negative_statuses() );
		$include    = array_filter( array_keys( wc_get_order_statuses() ), function ( $s ) use ( $exclude ) {
			return ! in_array( str_replace( 'wc-', '', $s ), $exclude, true );
		} );
		$orders = wc_get_orders( array(
			'limit'        => 30,
			'status'       => array_values( $include ),
			'date_created' => '>' . ( time() - 2 * DAY_IN_SECONDS ),
			'return'       => 'objects',
		) );
		foreach ( (array) $orders as $order ) {
			if ( ! $order->get_items() ) {
				continue;
			}
			// پیامک مدیر: هر دو تابع خودشان جلوی ارسال دوباره را می‌گیرند (متا/لاگ)،
			// پس فراخوانی بی‌قید‌وشرط اینجا برای سفارش‌هایی که قبلاً موفق رفته بی‌ضرر است.
			if ( jsms_get( 'admin_order_alert_enabled' ) ) {
				$self->notify_admin_new_order( $order );
			}
			// پیامک وضعیت به مشتری، برای همان وضعیتِ فعلیِ سفارش.
			$self->send_status_sms( $order, str_replace( 'wc-', '', $order->get_status() ) );
		}
	}

	/**
	 * اعلان به مدیر که مشتری رسید کارت‌به‌کارت را ثبت کرده و آماده بررسی است.
	 */
	private function notify_admin_receipt( $order ) {
		if ( ! jsms_get( 'admin_receipt_alert_enabled' ) ) {
			return;
		}
		$admin = jsms_get( 'admin_mobile' );
		if ( ! $admin ) {
			return;
		}
		if ( JSMS_DB::already_sent( $admin, 'admin_receipt', 0, $order->get_id() ) ) {
			return;
		}
		$vars = JSMS_Templates::order_vars( $order );
		$vars['customer_mobile'] = $this->order_mobile( $order ) ?: '—';
		$res = JSMS_Templates::dispatch( array(
			'to' => $admin, 'type' => 'admin_receipt', 'ref_id' => $order->get_id(),
			'mode' => 'text', 'force' => true,
			'text' => JSMS_Templates::render( jsms_get( 'admin_receipt_alert_text' ), $vars ),
		) );
		$order->add_order_note( ! empty( $res['ok'] )
			? 'پیامک «رسید کارت‌به‌کارت برای بررسی» به مدیر ارسال شد (رونق).'
			: 'ارسال پیامک «رسید کارت‌به‌کارت» به مدیر ناموفق بود: ' . ( $res['error'] ?? 'خطای نامشخص' )
		);
	}

	/**
	 * اعلان به مدیر هنگام رسیدن موجودی محصول به آستانهٔ «کم‌موجود» ووکامرس.
	 */
	public function on_low_stock( $product ) {
		if ( ! jsms_get( 'admin_lowstock_enabled' ) ) {
			return;
		}
		$admin = jsms_get( 'admin_mobile' );
		if ( ! $admin ) {
			return;
		}
		$pid = $product->get_id();
		// جلوگیری از هجوم پیامک با هر فروش؛ هر محصول حداکثر هر ۳ روز یک‌بار.
		if ( get_transient( 'jsms_lowstock_' . $pid ) ) {
			return;
		}
		$vars = array(
			'product_name' => $product->get_name(),
			'stock_qty'    => (string) $product->get_stock_quantity(),
		);
		JSMS_Templates::dispatch( array(
			'to' => $admin, 'type' => 'admin_low_stock', 'ref_id' => $pid,
			'mode' => 'text', 'force' => true,
			'text' => JSMS_Templates::render( jsms_get( 'admin_lowstock_text' ), $vars ),
		) );
		set_transient( 'jsms_lowstock_' . $pid, 1, 3 * DAY_IN_SECONDS );
	}

	public function on_status_change( $order_id, $from, $to, $order ) {
		// سفارش از حالت «در انتظار پرداخت» خارج شد (چه با پرداخت موفق، چه با لغو خودکار) —
		// حالا دیگر قطعی شد؛ سبد مربوطه را «بازیابی‌شده» علامت بزن تا یادآوری سبدِ رها شده
		// (که تا این لحظه، چون سفارش هنوز pending بود، هنوز مجاز به ارسال بود) دیگر نرود.
		if ( 'pending' === $from && 'pending' !== $to ) {
			$this->mark_cart_recovered( $order->get_customer_id(), $this->order_mobile( $order ), $order->get_id() );
		}
		// رسید کارت‌به‌کارت ثبت شد — به مدیر خبر بده برای بررسی.
		if ( 'shetab-approval' === $to ) {
			$this->notify_admin_receipt( $order );
		}
		// سفارش از حالت «در انتظار» خارج شد (رسید تأیید شد یا پرداخت انجام شد) — حالا واقعاً تأیید شده.
		if ( ! in_array( $to, $this->awaiting_statuses(), true ) && ! in_array( $to, $this->negative_statuses(), true ) ) {
			$this->notify_admin_new_order( $order );
		}
		// «در انتظار پرداخت» → «لغو شده»: یعنی مشتری تا یادآوری‌های ۱ و ۲ هم پرداخت نکرد و
		// سفارش سرِ وقت لغو شد. خودِ لغو باید انجام شود، ولی پیامک «لغو شد» ارزش بازاریابیِ
		// کمی دارد (فرصت تمام شده) — این‌جا عمداً ارسال نمی‌شود. لغوهای دستیِ مدیر از حالت‌های
		// دیگر (مثلاً «در حال پردازش») هنوز طبق روال عادی پیامک می‌گیرند.
		if ( 'pending' === $from && 'cancelled' === $to ) {
			return;
		}
		$this->send_status_sms( $order, $to );
	}

	/**
	 * ارسال پیامک تغییر وضعیت به مشتری — با جلوگیری قطعی از ارسال دوباره (بر اساس
	 * لاگ ارسال‌ها، نه فقط اعتماد به اینکه هوک فقط یک‌بار فایر می‌شود) و ثبت نتیجه
	 * (موفق/ناموفق/رد شده) در یادداشت‌های خودِ سفارش، تا از صفحهٔ سفارش هم معلوم باشد
	 * پیامک واقعاً برای مشتری رفته یا نه — بدون نیاز به سرک کشیدن به گزارش ارسال‌ها.
	 * از دو جا صدا زده می‌شود: لحظهٔ واقعی تغییر وضعیت، و اسکن جبرانیِ شبکهٔ ایمنی.
	 */
	private function send_status_sms( $order, $status ) {
		if ( ! jsms_get( 'status_enabled' ) ) {
			return;
		}
		$map = jsms_get( 'status_map', array() );
		if ( empty( $map[ $status ] ) ) {
			return;
		}
		$mobile = $this->order_mobile( $order );
		if ( ! $mobile ) {
			return;
		}
		// قبلاً برای همین سفارش و همین وضعیت با موفقیت ارسال شده — دیگر دوباره نرود.
		if ( JSMS_DB::already_sent( $mobile, 'status_' . $status, 0, $order->get_id() ) ) {
			return;
		}
		// اگر پنل پیامکی قبلاً همین متن را «فیلترشده» اعلام کرده (نگه‌داشته‌شده برای بررسی
		// دستیِ کارشناس، نه خطای گذرا)، دیگر با همان متن دوباره تلاش نکن — چون هر بار
		// همان کلمه دوباره فیلتر می‌شود و می‌تواند چند نسخهٔ تکراری از پیام برای مشتری
		// واقعاً ارسال شود (همان اتفاقی که برای پیام مدیرِ سفارش #6418 افتاد).
		if ( $order->get_meta( '_jsms_status_filtered_' . $status ) ) {
			return;
		}
		// اگر سفارش به‌خاطر عدم پرداخت لغو شده و مشتری تا این لحظه یک سفارش دیگر (موفق‌تر)
		// با همین شماره ثبت کرده، پیامک «لغو شد» نرود — چون مشتری همان لحظه خریدش را با
		// شماره سفارش دیگری با موفقیت انجام داده و دیدن «لغو شد» فقط گیجش می‌کند.
		if ( 'cancelled' === $status && $this->has_newer_successful_order( $order, $mobile ) ) {
			$order->add_order_note( 'پیامک وضعیت «لغو شده» ارسال نشد — مشتری بعداً با همین شماره سفارش دیگری با موفقیت ثبت کرده (رونق).' );
			return;
		}
		$status_label = wc_get_order_status_name( 'wc-' . $status );
		$vars = JSMS_Templates::order_vars( $order );
		$res = JSMS_Templates::dispatch( array(
			'to' => $mobile, 'user_id' => $order->get_customer_id(), 'type' => 'status_' . $status,
			'ref_id' => $order->get_id(), 'force' => true, 'mode' => 'text',
			'text' => JSMS_Templates::render( $map[ $status ], $vars ),
		) );
		if ( ! empty( $res['ok'] ) ) {
			$order->add_order_note( 'پیامک وضعیت «' . $status_label . '» برای مشتری ارسال شد (رونق).' );
		} elseif ( ! empty( $res['quiet'] ) ) {
			$order->add_order_note( 'پیامک وضعیت «' . $status_label . '» به‌خاطر ساعات سکوت ارسال نشد — بعداً دوباره تلاش می‌شود.' );
		} else {
			if ( false !== strpos( (string) ( $res['error'] ?? '' ), 'فیلترشده' ) ) {
				$order->update_meta_data( '_jsms_status_filtered_' . $status, 1 );
				$order->save_meta_data();
			}
			$order->add_order_note( 'ارسال پیامک وضعیت «' . $status_label . '» به مشتری ناموفق بود: ' . ( $res['error'] ?? 'خطای نامشخص' ) );
		}
	}

	/**
	 * آیا بعد از این سفارش، همین شماره موبایل یک سفارش دیگر ثبت کرده که خودش
	 * لغو/ناموفق نشده؟ (یعنی مشتری با تلاش بعدی موفق شده — دیگر نیازی به
	 * اطلاع‌رسانی لغو تلاش قبلی نیست.)
	 */
	private function has_newer_successful_order( $order, $mobile ) {
		$found = wc_get_orders( array(
			'limit'        => 1,
			'return'       => 'ids',
			'billing_phone'=> $mobile,
			'date_created' => '>' . $order->get_date_created()->getTimestamp(),
			'status'       => array_diff( array_keys( wc_get_order_statuses() ), array( 'wc-cancelled', 'wc-failed' ) ),
			'exclude'      => array( $order->get_id() ),
		) );
		return ! empty( $found );
	}

	/* ---------------------------------------------------------------------
	 * ردیابی و بازیابی سبد خرید رها شده
	 * ------------------------------------------------------------------- */
	public function track_cart() {
		if ( ! jsms_get( 'cart_enabled' ) || ! function_exists( 'WC' ) || ! WC()->cart ) {
			return;
		}
		$user_id  = get_current_user_id();
		$guest_id = $user_id ? '' : $this->guest_customer_id();
		if ( ! $user_id && ! $guest_id ) {
			return; // هیچ شناسهٔ پایداری در دسترس نیست (مثلاً سشن ووکامرس هنوز آماده نشده).
		}
		// شماره را فقط برای کاربر لاگین‌شده همین‌جا می‌دانیم؛ برای مهمان، شماره بعداً
		// (لحظهٔ تایپ در چک‌اوت) توسط capture_checkout_phone_*/ajax_capture_phone متصل
		// می‌شود — اینجا هرگز نباید شمارهٔ قبلاً ثبت‌شدهٔ مهمان را با رشتهٔ خالی پاک کند.
		$mobile = $user_id ? $this->user_mobile( $user_id ) : '';

		$count = WC()->cart->get_cart_contents_count();
		if ( $count < 1 ) {
			$this->delete_cart_rows( $user_id, $guest_id );
			return;
		}
		$names = array();
		$lines = array();
		foreach ( WC()->cart->get_cart() as $item ) {
			if ( empty( $item['data'] ) || ! is_object( $item['data'] ) ) {
				continue;
			}
			$product    = $item['data'];
			$names[]    = $product->get_name();
			// snapshot قیمت فقط برای نمایش توی پیامک/گزارش است — لحظهٔ بازیابی واقعی
			// همیشه از قیمت زندهٔ فعلی محصول استفاده می‌شود (رفتار استاندارد ووکامرس).
			$lines[] = array(
				'product_id'   => (int) $item['product_id'],
				'variation_id' => (int) $item['variation_id'],
				'variation'    => ! empty( $item['variation'] ) ? $item['variation'] : array(),
				'qty'          => (int) $item['quantity'],
				'name'         => $product->get_name(),
				'price_snapshot' => (float) $product->get_price(),
			);
		}
		$summary = implode( '، ', array_slice( $names, 0, 3 ) );
		if ( count( $names ) > 3 ) {
			$summary .= ' و ...';
		}
		$this->upsert_cart( $user_id, $guest_id, $mobile, WC()->cart->get_cart_hash(), WC()->cart->get_cart_contents_total(), $count, $summary, $lines );
	}

	/**
	 * شناسهٔ پایدارِ خودِ ووکامرس برای بازدیدکنندهٔ مهمان (همان چیزی که ووکامرس خودش
	 * برای نگه‌داشتن سبدِ مهمان بین درخواست‌ها استفاده می‌کند) — نه توکن/کوکی تازه.
	 */
	private function guest_customer_id() {
		if ( ! function_exists( 'WC' ) || ! WC()->session ) {
			return '';
		}
		$id = WC()->session->get_customer_id();
		return $id ? (string) $id : '';
	}

	/**
	 * لایهٔ اول گرفتن شمارهٔ مهمان: ووکامرس هر بار هزینهٔ ارسال را دوباره حساب می‌کند
	 * (تغییر استان/شهر/کدپستی/روش ارسال...)، کل دادهٔ فرم چک‌اوت (شامل billing_phone
	 * فعلی، حتی اگر آن فیلد خودش باعث این محاسبهٔ مجدد نشده باشد) را می‌فرستد.
	 */
	public function capture_checkout_phone_from_post_data( $post_data ) {
		parse_str( (string) $post_data, $data );
		$this->maybe_attach_checkout_phone( $data['billing_phone'] ?? '' );
	}

	/**
	 * لایهٔ دوم: اسکریپت مستقلِ خودِ پلاگین (assets/jsms-phone-capture.js) روی فیلد
	 * استاندارد #billing_phone گوش می‌دهد — چون تضمینی نیست خودِ تایپ‌کردن در فیلد
	 * موبایل باعث فایرشدن update_order_review بشود.
	 */
	public function enqueue_checkout_phone_capture() {
		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) ) {
			return;
		}
		wp_enqueue_script( 'jsms-phone-capture', JSMS_URL . 'assets/jsms-phone-capture.js', array(), JSMS_VERSION, true );
		wp_localize_script( 'jsms-phone-capture', 'JSMS_PHONE', array(
			'ajax'  => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'jsms_capture_phone' ),
		) );
	}

	public function ajax_capture_phone() {
		check_ajax_referer( 'jsms_capture_phone', 'nonce' );
		$this->maybe_attach_checkout_phone( $_POST['phone'] ?? '' );
		wp_send_json_success();
	}

	/**
	 * شماره را نرمال‌سازی و به سبدِ در حال ردیابی همین بازدیدکننده (کاربر یا مهمان)
	 * وصل می‌کند — فقط ستون mobile را تغییر می‌دهد؛ به created_at/notified/آیتم‌ها
	 * دست نمی‌زند تا زمان‌بندی و ضدتکرار خراب نشود.
	 */
	private function maybe_attach_checkout_phone( $raw_phone ) {
		$mobile = JSMS_Gateway::normalize_mobile( sanitize_text_field( wp_unslash( (string) $raw_phone ) ) );
		if ( ! $mobile ) {
			return;
		}
		$user_id  = get_current_user_id();
		$guest_id = $user_id ? '' : $this->guest_customer_id();
		if ( ! $user_id && ! $guest_id ) {
			return;
		}
		global $wpdb;
		$t = JSMS_DB::carts_table();
		if ( $user_id ) {
			$wpdb->update( $t, array( 'mobile' => $mobile ), array( 'user_id' => $user_id, 'recovered' => 0 ) );
		} else {
			$wpdb->update( $t, array( 'mobile' => $mobile ), array( 'guest_customer_id' => $guest_id, 'recovered' => 0 ) );
		}
	}

	/**
	 * وقتی مهمانی که سبدش ردیابی می‌شد لاگین کرد، سبد مهمان (با شناسهٔ سشن قبلی) را
	 * به کاربر تازه‌واردشده وصل می‌کند — نه اینکه یک سبد جدید و جدا برایش بسازد.
	 * شناسهٔ سشنِ قبل از لاگین از خودِ کوکی سشن ووکامرس خوانده می‌شود، چون
	 * WC()->session->get_customer_id() از این لحظه به بعد دیگر آی‌دی کاربر را برمی‌گرداند.
	 */
	public function merge_guest_cart_on_login( $user_login, $user ) {
		$this->merge_guest_cart_to_user( $user->ID );
	}

	public function merge_guest_cart_on_new_customer( $customer_id ) {
		$this->merge_guest_cart_to_user( $customer_id );
	}

	private function merge_guest_cart_to_user( $user_id ) {
		if ( empty( $_COOKIE ) || ! $user_id ) {
			return;
		}
		foreach ( $_COOKIE as $name => $value ) {
			if ( 0 !== strpos( $name, 'wp_woocommerce_session_' ) ) {
				continue;
			}
			$parts        = explode( '||', wp_unslash( (string) $value ) );
			$old_guest_id = $parts[0] ?? '';
			if ( ! $old_guest_id || (string) $old_guest_id === (string) $user_id ) {
				continue;
			}
			global $wpdb;
			$t = JSMS_DB::carts_table();
			$existing_user_cart = $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$t} WHERE user_id=%d AND notified=0 LIMIT 1", $user_id
			) );
			if ( $existing_user_cart ) {
				// کاربر از قبل سبدِ در حال ردیابیِ خودش را دارد — سبد مهمان قدیمی حذف شود تا دوتایی نشود.
				$wpdb->delete( $t, array( 'guest_customer_id' => $old_guest_id, 'notified' => 0 ) );
			} else {
				$wpdb->update( $t, array( 'user_id' => $user_id, 'guest_customer_id' => null ), array( 'guest_customer_id' => $old_guest_id ) );
			}
			break;
		}
	}

	/**
	 * @param int    $user_id   شناسهٔ کاربر لاگین‌شده (۰ برای مهمان).
	 * @param string $guest_id  شناسهٔ سشن ووکامرس برای مهمان (خالی برای کاربر لاگین‌شده).
	 */
	private function upsert_cart( $user_id, $guest_id, $mobile, $hash, $total, $count, $items_summary = '', $lines = array() ) {
		if ( ! $user_id && ! $guest_id ) {
			return;
		}
		global $wpdb;
		$t = JSMS_DB::carts_table();
		$ident_col = $user_id ? 'user_id' : 'guest_customer_id';
		$ident_val = $user_id ? $user_id : $guest_id;

		$exists_row = $wpdb->get_row( $wpdb->prepare(
			"SELECT id FROM {$t} WHERE {$ident_col}=%s AND cart_hash=%s", $ident_val, $hash
		) );

		$data = array(
			'cart_total'    => number_format( (float) $total ), 'items_count' => (int) $count,
			'items_summary' => $items_summary,
			'items_json'    => $lines ? wp_json_encode( $lines ) : null,
			'updated_at'    => current_time( 'mysql' ),
		);
		// فقط اگر شماره‌ای واقعاً داریم بازنویسی کن — وگرنه شمارهٔ قبلاً ثبت‌شدهٔ مهمان
		// (که لایهٔ گرفتن شماره جدا وصلش کرده) با رشتهٔ خالی پاک نشود.
		if ( $mobile ) {
			$data['mobile'] = $mobile;
		}

		if ( $exists_row ) {
			// محتوای سبد (بر اساس cart_hash) عوض نشده — created_at/notified/recovered دست
			// نمی‌خورند. وگرنه صرفِ بازدید از صفحهٔ سبد/چک‌اوت (که ووکامرس دوباره محاسبه‌اش
			// می‌کند و همین هوک را دوباره فایر می‌کند) کافی بود تا سبدی که پیامکش قبلاً رفته،
			// دوباره «تازه» و واجد شرایط ارسال مجدد بشود.
			$wpdb->update( $t, $data, array( 'id' => $exists_row->id ) );
			return $exists_row->id;
		}

		// سبد جدید (محتوای واقعاً متفاوت)؛ ردیف‌های قدیمی همان کاربر/مهمان که هنوز
		// اطلاع‌رسانی نشده پاک شوند.
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE {$ident_col}=%s AND notified=0", $ident_val ) );
		$data = array_merge( $data, array(
			'user_id' => $user_id, 'guest_customer_id' => $guest_id ?: null,
			'mobile'  => $mobile, 'cart_hash' => $hash,
			// حداقل ۳۲ کاراکتر و غیرقابل‌حدس — طبق الزام امنیتی لینک بازیابی.
			'token'      => wp_generate_password( 32, false ),
			'created_at' => current_time( 'mysql' ), 'notified' => 0, 'recovered' => 0,
		) );
		$wpdb->insert( $t, $data );
		return $wpdb->insert_id;
	}

	private function delete_cart_rows( $user_id, $guest_id = '' ) {
		global $wpdb;
		$t = JSMS_DB::carts_table();
		if ( $user_id ) {
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE user_id=%d AND notified=0", $user_id ) );
		} elseif ( $guest_id ) {
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE guest_customer_id=%s AND notified=0", $guest_id ) );
		}
	}

	/**
	 * سفارشی ثبت شد — سبدهای مرتبط (چه با شناسهٔ کاربر، چه مهمان، چه فقط با تطبیق
	 * شماره) دیگر «رهاشده» حساب نشوند، و برای ردیابی به همان سفارش وصل شوند.
	 *
	 * $finalize=false یعنی سفارش هنوز «در انتظار پرداخت» است — فقط شمارهٔ سفارش را
	 * برای ردیابی وصل کن، ولی recovered را ۱ نکن؛ چون مشتری هنوز واقعاً پرداخت نکرده
	 * و اگر تا مهلتِ «سبد رها شده» (مثلاً ۲۰ دقیقه) هنوز پرداخت نشده باشد، باید همان
	 * یادآوری برایش برود. با تغییر بعدیِ وضعیت (پرداخت موفق یا لغو خودکار)، از
	 * on_status_change() دوباره با finalize=true صدا زده می‌شود.
	 */
	private function mark_cart_recovered( $user_id, $mobile, $order_id = 0, $finalize = true ) {
		global $wpdb;
		$t = JSMS_DB::carts_table();
		$data = $finalize ? array( 'recovered' => 1 ) : array();
		if ( $order_id ) {
			$data['order_id'] = $order_id;
		}
		if ( empty( $data ) ) {
			return;
		}
		// عمداً فقط *یک* سبدِ رهاشده (آخرین سبدِ هنوز-بازیابی‌نشدهٔ همان کاربر/شماره) به‌روز
		// می‌شود، نه همهٔ سبدهای مطابق. مشتری‌ای که چند سبدِ رهاشدهٔ قدیمی دارد و الان یک
		// سفارش تازه می‌گذارد، نباید همهٔ آن سبدهای قدیمی را به همین یک سفارش وصل کند —
		// این «چندسبدی» باعث گزارش نادرستِ بازیابی/Attribution می‌شد.
		$sets = array();
		foreach ( $data as $col => $val ) {
			$sets[] = is_int( $val ) ? $wpdb->prepare( "{$col}=%d", $val ) : $wpdb->prepare( "{$col}=%s", $val );
		}
		$set_sql = implode( ', ', $sets );
		if ( $user_id ) {
			$wpdb->query( $wpdb->prepare(
				"UPDATE {$t} SET {$set_sql} WHERE user_id=%d AND recovered=0 ORDER BY id DESC LIMIT 1", $user_id
			) );
		}
		if ( $mobile ) {
			// حتی برای کاربر لاگین‌شده هم بر اساس شماره چک کن — سبدهای مهمانی که با همین
			// شماره (قبل از لاگین) ردیابی شده بودند هم باید بسته شوند.
			$wpdb->query( $wpdb->prepare(
				"UPDATE {$t} SET {$set_sql} WHERE mobile=%s AND recovered=0 ORDER BY id DESC LIMIT 1", $mobile
			) );
		}
	}

	/**
	 * اسکن سبدهای رها شده (توسط کران).
	 */
	public static function scan_abandoned_carts() {
		if ( ! jsms_get( 'cart_enabled' ) ) {
			return;
		}
		// مرحله اول: یادآوری ساده.
		self::run_cart_stage( 1 );
		// مرحله دوم: پیام تشویقی همراه کد تخفیف (در صورت فعال بودن).
		if ( jsms_get( 'cart_stage2_enabled' ) ) {
			self::run_cart_stage( 2 );
		}
	}

	/**
	 * اجرای یک مرحله از بازیابی سبد.
	 * ستون notified به‌عنوان شمارنده مرحله استفاده می‌شود:
	 * 0 = هنوز چیزی نرفته، 1 = مرحله اول رفته، 2 = مرحله دوم رفته (پایان).
	 */
	private static function run_cart_stage( $stage ) {
		global $wpdb;
		$t = JSMS_DB::carts_table();

		if ( 1 === $stage ) {
			$delay = (int) jsms_get( 'cart_delay_min', 60 );
			$prev  = 0;
			$text  = jsms_get( 'cart_text' );
			$mode  = jsms_get( 'cart_mode', 'text' );
			$pat   = jsms_get( 'cart_pattern' );
			$type  = 'abandoned_cart';
		} else {
			$delay = (int) jsms_get( 'cart_delay2_min', 1440 );
			$prev  = 1;
			$text  = jsms_get( 'cart_text_2' );
			$mode  = jsms_get( 'cart_mode', 'text' );
			$pat   = jsms_get( 'cart_pattern_2' );
			$type  = 'abandoned_cart_2';
		}
		// عمداً created_at (که هیچ‌وقت با آپدیت‌های غیرواقعی مثل تغییر شماره/آدرس/روش
		// ارسال دست‌خورده نمی‌شود)، نه updated_at (که با هر آپدیت جزئی جلو می‌رود).
		$threshold = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - $delay * 60 );

		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$t} WHERE notified=%d AND recovered=0 AND created_at IS NOT NULL AND created_at <= %s LIMIT 50",
			$prev, $threshold
		) );
		$self = self::instance();
		foreach ( (array) $rows as $r ) {
			// مهمانی که هنوز شماره‌اش را وارد نکرده — جایی برای ارسال نداریم؛ فعلاً رد شو
			// (recovered نشود، شاید بعداً شماره را وارد کند و چرخهٔ عادی ادامه پیدا کند).
			if ( ! $r->mobile ) {
				continue;
			}
			// اگر بعد از این زمان سفارشی داده، رد شود.
			if ( $self->user_ordered_since( $r->user_id, $r->mobile, $r->created_at ) ) {
				$wpdb->update( $t, array( 'recovered' => 1 ), array( 'id' => $r->id ) );
				continue;
			}
			// اگر این سبد به یک سفارشِ «در انتظار پرداخت» وصل است و آن سفارش از مهلتِ لغوِ
			// خودکارِ خودش (کارت‌به‌کارت یا نگه‌داریِ موجودیِ ووکامرس، هر کدام که باشد)
			// گذشته، یعنی همین الان/لحظاتی بعد لغو می‌شود — یادآوری بی‌مورد نرود.
			$linked_pending_order = $r->order_id ? wc_get_order( (int) $r->order_id ) : false;
			if ( $linked_pending_order && 'pending' === $linked_pending_order->get_status() ) {
				$deadline_min = self::order_cancel_deadline_minutes( $linked_pending_order );
				$order_age_min = ( time() - $linked_pending_order->get_date_created()->getTimestamp() ) / MINUTE_IN_SECONDS;
				if ( $deadline_min && $order_age_min >= $deadline_min ) {
					$wpdb->update( $t, array( 'recovered' => 1 ), array( 'id' => $r->id ) );
					continue;
				}
			}
			// رزرو موجودی بعد از ۳۰ دقیقه آزاد می‌شود و ممکن است سبد کاربر (بدون خرید) خالی شده باشد؛
			// قبل از ارسال یادآوری، اگر سبد کاربرِ لاگین‌شده واقعاً خالی است، پیامک بی‌مورد نرود.
			// (برای مهمان معادل قابل‌اتکایی نداریم؛ به آخرین اسنپ‌شاتِ items_json تکیه می‌کنیم.)
			// اگر این ردیف از قبل به یک سفارشِ «در انتظار پرداخت» وصل است، این چک را رد کن —
			// چک‌اوت خودِ ووکامرس سبدِ ماندگار را همان لحظهٔ ثبت سفارش خالی می‌کند (طبیعی و
			// مورد انتظار است)، و اینجا مدرک بهتری (خودِ سفارشِ پرداخت‌نشده) در دست داریم.
			if ( ! $r->order_id && $r->user_id && ! $self->cart_still_has_items( $r->user_id ) ) {
				$wpdb->update( $t, array( 'recovered' => 1 ), array( 'id' => $r->id ) );
				continue;
			}
			// برای مهمان، user_vars(0) خالی برمی‌گردد (هیچ اکانتی نیست که ازش نام بخوانیم)؛
			// یک نام عمومی بگذار تا {first_name} توی پیامک خالی/شکسته نماند.
			$vars = $r->user_id ? JSMS_Templates::user_vars( $r->user_id ) : array();
			if ( empty( $vars['first_name'] ) ) {
				$vars['first_name'] = 'مشتری';
			}
			$vars['cart_url']   = JSMS_Templates::shorten( function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/cart' ) );
			// اگر این سبد به یک سفارشِ «در انتظار پرداخت» وصل است، لینک باید همان سفارش را
			// برای تکمیل پرداخت باز کند — نه بازیابی سبد، که می‌تواند سفارش دومی بسازد و
			// دقیقاً همان مشکلِ «دو شماره سفارش برای یک خرید» را دوباره ایجاد کند.
			if ( $linked_pending_order && 'pending' === $linked_pending_order->get_status() ) {
				$vars['recover_cart_url'] = JSMS_Templates::shorten( $linked_pending_order->get_checkout_payment_url() );
			} else {
				// لینک بازیابیِ واقعی: کالاهای موجود را خودکار به سبد برمی‌گرداند (نه فقط یک لینک ساده به /cart).
				$vars['recover_cart_url'] = $r->token
					? JSMS_Templates::shorten( add_query_arg( 'jsms_recover', $r->token, home_url( '/' ) ) )
					: $vars['cart_url'];
			}
			$vars['cart_total'] = $r->cart_total;
			$vars['items_count']= $r->items_count;
			$vars['cart_items'] = $r->items_summary ?: '';
			$expire_days  = (int) jsms_get( 'cart_recovery_expiry_days', 7 );
			$expire_hours = max( 1, (int) round( ( strtotime( $r->created_at ) + $expire_days * DAY_IN_SECONDS - current_time( 'timestamp' ) ) / HOUR_IN_SECONDS ) );
			$vars['cart_expire_date'] = $expire_hours . ' ساعت آینده';

			$res = JSMS_Templates::dispatch( array(
				'to' => $r->mobile, 'user_id' => $r->user_id, 'type' => $type,
				'mode' => $mode,
				'text' => JSMS_Templates::render( $text, $vars ),
				'pattern_id' => $pat,
				'pattern_args' => array( $vars['first_name'] ?? '', $vars['recover_cart_url'] ),
				// شناسهٔ ردیف سبد (wp_jsms_carts.id) — برای اینکه بشه از گزارش ارسال‌ها
				// فهمید این پیامک برای کدام سبد رفته (کارت‌به‌کارت/سفارش هنوز وجود ندارد).
				'ref_id' => $r->id,
			) );
			// اگر به‌خاطر ساعت سکوت رد شد، دوباره تلاش می‌شود.
			if ( empty( $res['quiet'] ) ) {
				$wpdb->update( $t, array( 'notified' => $stage ), array( 'id' => $r->id ) );
			}
		}
	}

	/**
	 * لغو خودکار سفارش‌های کارت‌به‌کارت که بعد از مهلت مشخص هنوز رسیدی برایشان
	 * ثبت نشده (هنوز در وضعیت «در انتظار پرداخت» مانده‌اند). سفارش‌هایی که رسیدشان
	 * ثبت شده (وضعیت «در انتظار تایید رسید» یا بعدتر) دیگر «در انتظار پرداخت» نیستند
	 * و این پرس‌وجو اصلاً به آن‌ها کاری ندارد — لغو نمی‌شوند.
	 */
	public static function scan_expired_pending_orders() {
		if ( ! jsms_get( 'pending_expiry_enabled' ) ) {
			return;
		}
		$minutes = (int) jsms_get( 'pending_expiry_min', 30 );
		if ( $minutes <= 0 ) {
			return;
		}
		$before = strtotime( '-' . $minutes . ' minutes' );
		$orders = wc_get_orders( array(
			'limit'        => 30,
			'status'       => 'wc-pending',
			'date_created' => '<' . $before,
			'return'       => 'objects',
		) );
		foreach ( (array) $orders as $order ) {
			// فقط کارت‌به‌کارت (شتاب) — سفارش‌های درگاه بانکی مسئول خود گیت‌وی هستند.
			if ( 'shetab' !== $order->get_payment_method() || 'pending' !== $order->get_status() ) {
				continue;
			}
			$order->update_status( 'cancelled', 'لغو خودکار توسط رونق: پرداخت کارت‌به‌کارت طی ' . $minutes . ' دقیقه انجام نشد.' );
		}
	}

	/**
	 * مهلتِ لغوِ خودکارِ یک سفارشِ «در انتظار پرداخت»، بر حسب دقیقه، متناسب با درگاهش:
	 * کارت‌به‌کارت (شتاب) طبق تنظیم خودِ این افزونه، بقیهٔ درگاه‌ها (پارسیان/زرین‌پال)
	 * طبق تنظیم «نگه‌داری موجودی» خودِ ووکامرس (Hold stock). اگر عدد نامعتبر/صفر باشد،
	 * null برمی‌گردد یعنی «مهلت مشخصی نداریم، فرض نکن».
	 */
	private static function order_cancel_deadline_minutes( $order ) {
		$minutes = ( 'shetab' === $order->get_payment_method() )
			? (int) jsms_get( 'pending_expiry_min', 30 )
			: (int) get_option( 'woocommerce_hold_stock_minutes', 60 );
		return $minutes > 0 ? $minutes : null;
	}

	/**
	 * یادآوری دومِ گرم‌تر، درست قبل از اینکه سفارشِ «در انتظار پرداخت» (هر درگاهی —
	 * پارسیان، زرین‌پال یا کارت‌به‌کارت) به‌خاطر عدم پرداخت خودکار لغو شود. هدف: تلاش
	 * آخر برای زنده نگه‌داشتن همین سفارش (با لینک پرداختِ همان سفارش)، نه ساختن سفارش
	 * تازه — اولویت با احیای سفارش است، نه صرفاً اطلاع‌رسانیِ لغو شدنش.
	 */
	public static function scan_pending_payment_reminders() {
		if ( ! jsms_get( 'pending_reminder_enabled' ) ) {
			return;
		}
		$minutes = (int) jsms_get( 'pending_reminder_min', 25 );
		$text    = jsms_get( 'pending_reminder_text' );
		if ( $minutes <= 0 || ! $text ) {
			return;
		}
		$before = strtotime( '-' . $minutes . ' minutes' );
		$orders = wc_get_orders( array(
			'limit'        => 30,
			'status'       => 'wc-pending',
			'date_created' => '<' . $before,
			'return'       => 'objects',
		) );
		$self = self::instance();
		foreach ( (array) $orders as $order ) {
			if ( 'pending' !== $order->get_status() ) {
				continue;
			}
			// اگر کرون دیر اجرا شده و سفارش از مهلتِ لغوِ خودکارِ خودش گذشته، یعنی همین
			// الان یا لحظاتی دیگر لغو می‌شود — دیگر برایش یادآوری نرود (فرصتی نمانده).
			$cancel_after_min = self::order_cancel_deadline_minutes( $order );
			$age_min = ( time() - $order->get_date_created()->getTimestamp() ) / MINUTE_IN_SECONDS;
			if ( $cancel_after_min && $age_min >= $cancel_after_min ) {
				continue;
			}
			$mobile = $self->order_mobile( $order );
			if ( ! $mobile ) {
				continue;
			}
			// اگر مشتری با همین شماره از قبل سفارش تازه‌تری ثبت کرده (مثلاً از یک سبد
			// دیگر)، تمرکز باید روی همان سفارشِ جدیدتر باشد — این یکیِ قدیمی را دیگر
			// یادآوری نکن؛ خودش سرِ وقت (دقیقهٔ ۳۰) لغو می‌شود.
			if ( $self->has_newer_successful_order( $order, $mobile ) ) {
				continue;
			}
			// هر سفارش فقط یک‌بار این یادآوریِ دوم را می‌گیرد.
			if ( JSMS_DB::already_sent( $mobile, 'payment_reminder_2', 0, $order->get_id() ) ) {
				continue;
			}
			// همان محافظِ «فیلترشده» — با متن یکسان دوباره تلاش نکن (به توضیح در
			// notify_admin_new_order مراجعه کنید).
			if ( $order->get_meta( '_jsms_reminder2_filtered' ) ) {
				continue;
			}
			$vars = JSMS_Templates::order_vars( $order );
			$res  = JSMS_Templates::dispatch( array(
				'to' => $mobile, 'user_id' => $order->get_customer_id(), 'type' => 'payment_reminder_2',
				'ref_id' => $order->get_id(), 'force' => true, 'mode' => 'text',
				'text' => JSMS_Templates::render( $text, $vars ),
			) );
			if ( ! empty( $res['ok'] ) ) {
				$order->add_order_note( 'یادآوری دوم پرداخت برای مشتری ارسال شد (رونق).' );
			} elseif ( false !== strpos( (string) ( $res['error'] ?? '' ), 'فیلترشده' ) ) {
				$order->update_meta_data( '_jsms_reminder2_filtered', 1 );
				$order->save_meta_data();
			}
		}
	}

	/* ---------------------------------------------------------------------
	 * مشتریان غیرفعال (کران)
	 * ------------------------------------------------------------------- */
	public static function scan_inactive_customers() {
		if ( ! jsms_get( 'inactive_enabled' ) ) {
			return;
		}
		$days     = (int) jsms_get( 'inactive_days', 45 );
		$cooldown = (int) jsms_get( 'inactive_cooldown', 30 ) * DAY_IN_SECONDS;
		$before   = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );

		// آخرین سفارش‌های قدیمی‌تر از حد آستانه.
		$orders = wc_get_orders( array(
			'limit'        => 40,
			'orderby'      => 'date',
			'order'        => 'DESC',
			'status'       => array( 'wc-completed', 'wc-processing' ),
			'date_created' => '<' . strtotime( $before ),
			'return'       => 'objects',
		) );

		$seen = array();
		$self = self::instance();
		foreach ( (array) $orders as $order ) {
			$uid = $order->get_customer_id();
			$mobile = $self->order_mobile( $order );
			$key = $uid ?: $mobile;
			if ( ! $mobile || isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = 1;

			// اگر سفارش جدیدتری دارد، غیرفعال نیست.
			if ( $self->user_ordered_since( $uid, $mobile, $before ) ) {
				continue;
			}
			if ( JSMS_DB::already_sent( $mobile, 'inactive', $cooldown ) ) {
				continue;
			}
			$vars = $uid ? JSMS_Templates::user_vars( $uid ) : array( 'first_name' => $order->get_billing_first_name() );
			JSMS_Templates::dispatch( array(
				'to' => $mobile, 'user_id' => $uid, 'type' => 'inactive',
				'mode' => jsms_get( 'inactive_mode', 'text' ),
				'text' => JSMS_Templates::render( jsms_get( 'inactive_text' ), $vars ),
				'pattern_id' => jsms_get( 'inactive_pattern' ),
				'pattern_args' => array( $vars['first_name'] ?? '' ),
			) );
		}
	}

	/* ---------------------------------------------------------------------
	 * کمک‌کننده‌ها
	 * ------------------------------------------------------------------- */
	public function user_mobile( $user_id ) {
		$m = get_user_meta( $user_id, 'billing_phone', true );
		if ( ! $m ) {
			$m = get_user_meta( $user_id, 'digits_phone_no', true ); // سازگاری با افزونه دیجیتس
		}
		return JSMS_Gateway::normalize_mobile( $m );
	}

	public function order_mobile( $order ) {
		$m = $order->get_billing_phone();
		if ( ! $m && $order->get_customer_id() ) {
			$m = $this->user_mobile( $order->get_customer_id() );
		}
		return JSMS_Gateway::normalize_mobile( $m );
	}

	/**
	 * آیا از زمان مشخص، این مشتری یک سفارشِ واقعاً «در جریان یا موفق» ثبت کرده؟
	 * عمداً «در انتظار پرداخت» و «لغوشده/ناموفق» هر دو کنار گذاشته شده‌اند:
	 * - «در انتظار پرداخت»: مشتری هنوز خریدش را کامل نکرده — یادآوریِ سبد/پرداخت باید برود.
	 * - «لغوشده/ناموفق»: یعنی همان تلاش قبلی به جایی نرسید؛ این نباید مانعِ یادآوریِ
	 *   بعدیِ همین سبد (مثلاً پیامِ تشویقیِ ۲۴ساعته با کد تخفیف) بشود — تلاشِ قبلیِ
	 *   ناموفق، دلیلی برای تسلیم شدن نیست، دقیقاً برعکس، هدفِ همین پیام است.
	 * تنها چیزی که واقعاً باید یادآوری‌ها را ساکت کند، سفارشِ *جدیدتر و درجریان/موفق*
	 * است (مثلاً «در حال پردازش»، «تکمیل شده»، «در انتظار تایید رسید» و مشابه).
	 */
	public function user_ordered_since( $user_id, $mobile, $since ) {
		$statuses = array_diff(
			array_keys( wc_get_order_statuses() ),
			array( 'wc-pending', 'wc-cancelled', 'wc-failed' )
		);
		$args = array(
			'limit' => 1, 'return' => 'ids', 'date_created' => '>' . strtotime( $since ),
			'status' => $statuses,
		);
		if ( $user_id ) {
			$args['customer_id'] = $user_id;
		} else {
			$args['billing_phone'] = $mobile;
		}
		$found = wc_get_orders( $args );
		return ! empty( $found );
	}

	/**
	 * آیا سبد ذخیره‌شدهٔ کاربر لاگین‌شده هنوز واقعاً موردی دارد؟ (رزرو موجودی بعد از ۳۰ دقیقه
	 * آزاد می‌شود و ممکن است سبد بدون ثبت سفارش خالی شده باشد.)
	 */
	public function cart_still_has_items( $user_id ) {
		$key  = '_woocommerce_persistent_cart_' . get_current_blog_id();
		$cart = get_user_meta( $user_id, $key, true );
		return ! empty( $cart['cart'] );
	}
}
endif;
