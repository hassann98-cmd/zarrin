<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once __DIR__ . '/gateways/class-jsms-gateway-driver.php';
require_once __DIR__ . '/gateways/class-jsms-gateway-reference.php';

// Gatewayهای مرجع داخل خود رونق بسته‌بندی شده‌اند تا انتخاب پنل از هسته جدا بماند.
$jsms_ref_base = __DIR__ . '/reference-gateways/';
require_once $jsms_ref_base . 'Gateway.php';
require_once $jsms_ref_base . 'Features/SendPatternFeature.php';
require_once $jsms_ref_base . 'Helpers/Curl.php';
if ( ! function_exists( 'str_starts_with' ) ) { function str_starts_with( $haystack, $needle ) { return '' === $needle || 0 === strpos( $haystack, $needle ); } }
if ( ! function_exists( 'str_contains' ) ) { function str_contains( $haystack, $needle ) { return '' === $needle || false !== strpos( $haystack, $needle ); } }
if ( file_exists( $jsms_ref_base . 'vendor/nusoap.php' ) ) require_once $jsms_ref_base . 'vendor/nusoap.php';
foreach ( glob( $jsms_ref_base . '*.php' ) as $jsms_ref_file ) {
    $jsms_bn = basename( $jsms_ref_file );
    if ( 'Gateway.php' === $jsms_bn ) continue;
    require_once $jsms_ref_file;
}

if ( ! class_exists( 'JSMS_Gateway' ) ) :
class JSMS_Gateway {
    private static $instances = array();

    public static function drivers() {
        static $drivers = null;
        if ( null !== $drivers ) return $drivers;
        $drivers = array();
        $base = 'PW\\PWSMS\\Gateways\\Gateway';
        foreach ( get_declared_classes() as $class ) {
            if ( 'PW\\PWSMS\\Gateways\\Gateway' === $class || 'PW\\PWSMS\\Gateways\\Features\\SendPatternFeature' === $class ) continue;
            if ( is_subclass_of( $class, $base ) && method_exists( $class, 'id' ) && method_exists( $class, 'name' ) ) {
                $id = (string) $class::id();
                if ( $id ) $drivers[ $id ] = $class;
            }
        }
        // شناسه‌های قدیمی رونق برای حفظ سازگاری تنظیمات قبلی.
        $aliases = array(
            'melipayamak' => 'PW\\PWSMS\\Gateways\\MeliPayamak',
            'kavenegar'  => 'PW\\PWSMS\\Gateways\\KaveNegar',
            'ghasedak'   => 'PW\\PWSMS\\Gateways\\Ghasedak',
            'ippanel'    => 'PW\\PWSMS\\Gateways\\IPPanelToken',
            'smsir'      => 'PW\\PWSMS\\Gateways\\SMSIR',
        );
        foreach ( $aliases as $id => $class ) if ( class_exists( $class ) ) $drivers[ $id ] = $class;
        // نام داخلی مرجع melipayamak_unified است؛ در رابط رونق یک گزینه واحد «ملی پیامک» نمایش می‌دهیم.
        if ( isset( $drivers['melipayamak'] ) ) unset( $drivers['melipayamak_unified'] );
        return $drivers;
    }

    private static function driver() {
        $id = sanitize_key( jsms_get( 'provider', 'melipayamak' ) );
        $map = self::drivers();
        if ( ! isset( $map[ $id ] ) ) $id = 'melipayamak';
        if ( ! isset( self::$instances[ $id ] ) ) self::$instances[ $id ] = new JSMS_Gateway_Reference( $map[ $id ] );
        return self::$instances[ $id ];
    }
    public static function provider_labels() {
        $out=array(); foreach(self::drivers() as $id=>$class){$out[$id]=(new $class())->name();} asort($out,SORT_NATURAL|SORT_FLAG_CASE); return $out;
    }
    public static function active_settings_fields(){
        return array(
            array('key'=>'username','label'=>'نام کاربری / API Key','type'=>'text','help'=>'نام کاربری، Token یا API Key را طبق مستندات پنل وارد کنید.'),
            array('key'=>'password','label'=>'کلمه عبور / رمز وب‌سرویس','type'=>'password','help'=>'اگر پنل فقط API Key/Token دارد، این فیلد را خالی بگذارید.'),
            array('key'=>'line_number','label'=>'شماره ارسال‌کننده پیامک','type'=>'text','help'=>'شماره خط ارسال را دقیقاً طبق پنل وارد کنید.'),
        );
    }
    public static function send_simple($to,$text,$from=''){return self::driver()->send_simple($to,$text,$from);}
    public static function send_pattern($to,$body_id,$args){return self::driver()->send_pattern($to,$body_id,$args);}
    public static function send_otp($to){return self::driver()->send_otp($to);}
    public static function check_connection(){return self::driver()->check_connection();}
    public static function get_credit(){return self::driver()->get_credit();}
    public static function get_messages($count=100,$index=0){return self::driver()->get_messages($count,$index);}
    public static function normalize_mobile($mobile){
        $mobile=self::fa_to_en(trim((string)$mobile)); $mobile=preg_replace('/\D+/','',$mobile);
        if(strpos($mobile,'0098')===0)$mobile='0'.substr($mobile,4); elseif(strpos($mobile,'98')===0&&strlen($mobile)===12)$mobile='0'.substr($mobile,2); elseif(strlen($mobile)===10&&$mobile[0]==='9')$mobile='0'.$mobile;
        return (strlen($mobile)===11&&strpos($mobile,'09')===0)?$mobile:'';
    }
    public static function fa_to_en($str){return str_replace(array('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹','٠','١','٢','٣','٤','٥','٦','٧','٨','٩'),array('0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9'),$str);}
}
endif;
