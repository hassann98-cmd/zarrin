<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * موتور متغیرها + ارسال‌کننده مرکزی.
 * همه اتوماسیون‌ها از JSMS_Templates::dispatch() استفاده می‌کنند تا
 * لغو اشتراک، ساعات سکوت، لاگ و انتخاب متن/پترن یکجا مدیریت شود.
 */
if ( ! class_exists( 'JSMS_Templates' ) ) :

class JSMS_Templates {

	/**
	 * جایگذاری متغیرها در قالب.
	 */
	public static function render( $template, $vars = array() ) {
		$defaults = array(
			'site_name' => get_bloginfo( 'name' ),
			'site_url'  => home_url( '/' ),
		);
		$vars = array_merge( $defaults, $vars );
		foreach ( $vars as $k => $v ) {
			$template = str_replace( '{' . $k . '}', (string) $v, $template );
		}
		return $template;
	}

	/**
	 * متغیرهای استاندارد یک کاربر.
	 */
	public static function user_vars( $user_id ) {
		$u = get_userdata( $user_id );
		if ( ! $u ) {
			return array();
		}
		$first = get_user_meta( $user_id, 'billing_first_name', true ) ?: $u->first_name;
		$last  = get_user_meta( $user_id, 'billing_last_name', true ) ?: $u->last_name;
		return array(
			'first_name' => $first ?: $u->display_name,
			'last_name'  => $last,
			'full_name'  => trim( $first . ' ' . $last ) ?: $u->display_name,
			'username'   => $u->user_login,
		);
	}

	/**
	 * یک آدرس مقصد را طوری می‌پیچد که ابتدا از صفحهٔ ورود پیامکی خود قالب (/sign/) عبور کند.
	 * قالب Boom پارامتر «redirect» را می‌خواند؛ برای آدرس‌های کامل هم‌دامنه (http/https) بعد از
	 * ورود موفق یک ریدایرکت کامل مرورگر (window.location.href) انجام می‌دهد — لازم است چون
	 * صفحاتی مثل checkout/order-pay بخشی از روت‌های داخلی اپ SPA نیستند و باید بار کامل بگیرند
	 * (اگر مسیر نسبی بفرستیم، روتر SPA سعی می‌کند خودش هدایت کند و روی این مسیرها گم می‌شود).
	 */
	public static function sign_redirect_url( $destination_url ) {
		return add_query_arg( 'redirect', rawurlencode( $destination_url ), home_url( '/sign/' ) );
	}

	/**
	 * یک آدرس (معمولاً طولانی و با پارامترهای رمزنگاری‌شده) را به لینک کوتاه سایت تبدیل می‌کند
	 * تا متن پیامک تمیزتر و کوتاه‌تر شود. کلیک روی لینک کوتاه با ۳۰۲ به آدرس اصلی هدایت می‌شود.
	 */
	public static function shorten( $url ) {
		if ( ! $url ) {
			return $url;
		}
		global $wpdb;
		$t = JSMS_DB::shortlinks_table();
		$existing = $wpdb->get_var( $wpdb->prepare( "SELECT token FROM {$t} WHERE url=%s ORDER BY id DESC LIMIT 1", $url ) );
		if ( $existing ) {
			return home_url( '/?jl=' . $existing );
		}
		$alphabet = '23456789abcdefghjkmnpqrstuvwxyz'; // بدون کاراکترهای مشابه‌الشکل (0/O، 1/l/I).
		do {
			$token = '';
			for ( $i = 0; $i < 6; $i++ ) {
				$token .= $alphabet[ random_int( 0, strlen( $alphabet ) - 1 ) ];
			}
			$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE token=%s", $token ) );
		} while ( $exists );
		$wpdb->insert( $t, array(
			'token' => $token, 'url' => $url, 'created_at' => current_time( 'mysql' ),
		) );
		return home_url( '/?jl=' . $token );
	}

	/**
	 * متغیرهای یک سفارش ووکامرس.
	 */
	public static function order_vars( $order ) {
		if ( is_numeric( $order ) ) {
			$order = wc_get_order( $order );
		}
		if ( ! $order ) {
			return array();
		}
		// اقلام سفارش.
		$names = array();
		$product_url = '';
		foreach ( $order->get_items() as $item ) {
			$names[] = $item->get_name();
			if ( ! $product_url ) {
				$p = $item->get_product();
				if ( $p ) {
					$product_url = $p->get_permalink();
				}
			}
		}
		$product_name = $names ? $names[0] : '';
		$items        = implode( '، ', array_slice( $names, 0, 3 ) );
		if ( count( $names ) > 3 ) {
			$items .= ' و ...';
		}

		// نام کامل هر قلم + ویژگی‌های متغیر (مثلاً رنگ/سایز) و تعداد هر قلم.
		$items_full_parts = array();
		$items_qty_parts  = array();
		foreach ( $order->get_items() as $item ) {
			$name = $item->get_name();
			$qty  = (int) $item->get_quantity();
			$full = $name;
			$meta = $item->get_formatted_meta_data( '', true );
			if ( $meta ) {
				$attrs = array();
				foreach ( $meta as $m ) {
					$attrs[] = wp_strip_all_tags( $m->display_key . ': ' . $m->display_value );
				}
				if ( $attrs ) {
					$full .= ' (' . implode( '، ', $attrs ) . ')';
				}
			}
			$items_full_parts[] = $full;
			$items_qty_parts[]  = $name . ' × ' . $qty;
		}
		$all_items_full = implode( '، ', $items_full_parts );
		$all_items_qty  = implode( '، ', $items_qty_parts );

		// کد رهگیری مرسوله: از متای سفارش خوانده می‌شود (سازگار با افزونه‌های رایج) و قابل فیلتر است.
		$tracking = $order->get_meta( '_jsms_tracking' );
		foreach ( array( '_tracking_number', 'tracking_number', '_wc_shipment_tracking_items', 'postal_tracking', 'tracking_code' ) as $mk ) {
			if ( $tracking ) {
				break;
			}
			$val = $order->get_meta( $mk );
			if ( is_array( $val ) && isset( $val[0]['tracking_number'] ) ) {
				$val = $val[0]['tracking_number'];
			}
			if ( is_scalar( $val ) && $val ) {
				$tracking = $val;
			}
		}
		$tracking = apply_filters( 'jsms_order_tracking_code', $tracking, $order );

		$billing_phone = (string) $order->get_billing_phone();
		$customer_mobile = JSMS_Automations::instance()->order_mobile( $order ) ?: $billing_phone ?: '—';
		$order_status_label = wc_get_order_status_name( $order->get_status() );

		return array(
			'first_name' => $order->get_billing_first_name(),
			'last_name'  => $order->get_billing_last_name(),
			'full_name'  => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
			'order_id'   => $order->get_order_number(),
			'post_id'    => $order->get_id(),
			'order_total'=> number_format( (float) $order->get_total() ),
			'price'      => number_format( (float) $order->get_total() ),
			'order_status' => $order_status_label,
			'status'       => $order_status_label,
			'mobile'       => $customer_mobile,
			'phone'        => $billing_phone,
			'email'        => $order->get_billing_email(),
			// آدرس صفحهٔ سفارش‌های مشتری در قالب SPA سایت، از مسیر ورود پیامکی خود قالب (به‌صورت لینک کوتاه).
			'order_url'  => self::shorten( apply_filters( 'jsms_order_url', self::sign_redirect_url( home_url( '/account/?tab=orders' ) ), $order ) ),
			// آدرس پرداخت/کارت‌به‌کارت همین سفارش، از مسیر صفحهٔ ورود پیامکی خود قالب (/sign/?redirect=...)
			// تا اگر مشتری روی گوشی لاگین نبود، اول با کد یک‌بار مصرف پیامکی وارد شود و بعد مستقیم به پرداخت برسد.
			'payment_url' => self::shorten( self::sign_redirect_url( $order->get_checkout_payment_url() ) ),
			'product_name' => $product_name,
			'product_url'  => $product_url,
			'items'          => $items,
			'all_items'      => implode( '، ', $names ),
			'all_items_full' => $all_items_full,
			'all_items_qty'  => $all_items_qty,
			'count_items'    => count( $names ),
			'items_count'    => count( $names ),
			'tracking_code'  => (string) $tracking,
			'customer_mobile' => $customer_mobile,
			'payment_method'       => $order->get_payment_method_title() ?: $order->get_payment_method(),
			'payment_method_title' => $order->get_payment_method_title(),
			'shipping_method' => $order->get_shipping_method() ?: '—',
			'transaction_id'  => $order->get_transaction_id() ?: '—',
			'date'            => $order->get_date_created() ? wp_date( 'Y-m-d H:i', $order->get_date_created()->getTimestamp() ) : '—',
			'description'     => $order->get_customer_note() ?: '—',
			'customer_note'   => $order->get_customer_note() ?: '—',
			'b_first_name'    => $order->get_billing_first_name(),
			'b_last_name'     => $order->get_billing_last_name(),
			'b_company'       => $order->get_billing_company(),
			'b_country'       => $order->get_billing_country(),
			'b_state'         => $order->get_billing_state(),
			'b_city'          => $order->get_billing_city(),
			'b_address_1'     => $order->get_billing_address_1(),
			'b_address_2'     => $order->get_billing_address_2(),
			'b_postcode'      => $order->get_billing_postcode(),
			'sh_first_name'   => $order->get_shipping_first_name(),
			'sh_last_name'    => $order->get_shipping_last_name(),
			'sh_company'      => $order->get_shipping_company(),
			'sh_country'      => $order->get_shipping_country(),
			'sh_state'        => $order->get_shipping_state(),
			'sh_city'         => $order->get_shipping_city(),
			'sh_address_1'    => $order->get_shipping_address_1(),
			'sh_address_2'    => $order->get_shipping_address_2(),
			'sh_postcode'     => $order->get_shipping_postcode(),
			'discount_total'  => number_format( (float) $order->get_total_discount() ),
			'admin_order_url' => $order->get_edit_order_url(),
		);
	}

	/**
	 * آدرس لوگوی پیش‌فرض برای صفحات عمومیِ افزونه (نظرسنجی/ثبت‌نظر) — از لوگوی
	 * سفارشیِ سایت یا آیکون سایت خوانده می‌شود، نه یک آدرس ثابت وابسته به یک سایتِ خاص
	 * (افزونه قرار است روی سایت‌های مختلف نصب شود).
	 */
	public static function default_logo_url() {
		$custom = get_theme_mod( 'custom_logo' );
		if ( $custom ) {
			$src = wp_get_attachment_image_url( $custom, 'medium' );
			if ( $src ) {
				return $src;
			}
		}
		$icon = get_site_icon_url( 192 );
		return $icon ?: '';
	}

	/**
	 * آیا این نوع پیام «تراکنشی» است (دربارهٔ سفارشِ خودِ مشتری/عملیات اداری)، نه تبلیغاتی؟
	 * تراکنشی‌ها با لغوِ اشتراکِ تبلیغاتی مسدود نمی‌شوند.
	 */
	private static function is_transactional_type( $type ) {
		$type = (string) $type;
		if ( 0 === strpos( $type, 'status_' ) || 0 === strpos( $type, 'admin_' ) ) {
			return true;
		}
		$transactional = array( 'card_payment_started', 'ebazar_status', 'tracking', 'admin_alert' );
		return in_array( $type, $transactional, true );
	}

	/**
	 * ارسال یک پیام کامل با در نظر گرفتن همه قواعد.
	 *
	 * @param array $a {
	 *   to (string), user_id (int), type (string),
	 *   mode ('text'|'pattern'), text (string), pattern_id (string),
	 *   pattern_args (array), ref_id (int),
	 *   force (bool) نادیده‌گرفتن ساعات سکوت
	 * }
	 * @return array نتیجه
	 */
	public static function dispatch( $a ) {
		$a = wp_parse_args( $a, array(
			'to' => '', 'user_id' => 0, 'type' => 'manual',
			'mode' => 'text', 'text' => '', 'pattern_id' => '', 'pattern_args' => array(),
			'ref_id' => 0, 'force' => false,
		) );

		$mobile = JSMS_Gateway::normalize_mobile( $a['to'] );
		if ( ! $mobile ) {
			return array( 'ok' => false, 'error' => 'شماره موبایل نامعتبر: ' . $a['to'] );
		}

		// احترام به لغو اشتراک — فقط برای پیام‌های تبلیغاتی/بازاریابی. پیام‌های تراکنشی
		// (وضعیت سفارش، رسید، کد رهگیری، یادآوری پرداخت، اعلان‌های مدیر) با لغو اشتراکِ
		// تبلیغاتی مسدود نمی‌شوند — مشتری‌ای که تبلیغات را لغو کرده هنوز حق دارد از سفارش
		// خودش باخبر شود. اگر فروشگاهی می‌خواهد حتی این‌ها را هم مسدود کند، تنظیم
		// «block_transactional_for_optout» را فعال کند.
		$block_all = jsms_get( 'block_transactional_for_optout', 0 );
		$is_transactional = self::is_transactional_type( $a['type'] );
		if ( jsms_get( 'respect_optout', 1 ) && ( ! $is_transactional || $block_all ) && JSMS_Consent::is_opted_out( $mobile ) ) {
			return array( 'ok' => false, 'error' => 'مشتری لغو اشتراک کرده است.' );
		}

		// ساعات سکوت.
		if ( ! $a['force'] && jsms_get( 'quiet_hours', 1 ) && self::in_quiet_hours() ) {
			return array( 'ok' => false, 'error' => 'در بازه ساعات سکوت – ارسال نشد.', 'quiet' => true );
		}

		// کد تخفیف پویا: اگر متن حاوی {coupon} بود، یک کوپن یکتا برای همین گیرنده ساخته می‌شود.
		if ( 'text' === $a['mode'] && false !== strpos( (string) $a['text'], '{coupon}' ) && class_exists( 'JSMS_Coupons' ) ) {
			$code = JSMS_Coupons::for_recipient( $a['user_id'], $mobile, $a['type'] );
			$a['text'] = str_replace( '{coupon}', $code, $a['text'] );
		}

		$message = ( 'pattern' === $a['mode'] )
			? '[پترن #' . $a['pattern_id'] . '] ' . implode( ' | ', $a['pattern_args'] )
			: $a['text'];

		$log_id = JSMS_DB::log( array(
			'mobile' => $mobile, 'user_id' => $a['user_id'], 'type' => $a['type'],
			'message' => $message, 'status' => 'pending', 'ref_id' => $a['ref_id'],
		) );

		if ( 'pattern' === $a['mode'] ) {
			$res = JSMS_Gateway::send_pattern( $mobile, $a['pattern_id'], $a['pattern_args'] );
		} else {
			$res = JSMS_Gateway::send_simple( $mobile, $a['text'] );
		}

		JSMS_DB::update_log( $log_id, array(
			'status'   => $res['ok'] ? 'sent' : 'failed',
			'rec_id'   => $res['rec_id'] ?? '',
			'response' => is_scalar( $res['raw'] ?? '' ) ? (string) ( $res['raw'] ?? $res['error'] ) : wp_json_encode( $res['raw'] ?? $res['error'] ),
		) );

		$res['log_id'] = $log_id;
		return $res;
	}

	public static function in_quiet_hours() {
		$start = (int) jsms_get( 'quiet_start', 22 );
		$end   = (int) jsms_get( 'quiet_end', 9 );
		$h     = (int) current_time( 'G' );
		if ( $start === $end ) {
			return false;
		}
		if ( $start < $end ) {
			return ( $h >= $start && $h < $end );
		}
		return ( $h >= $start || $h < $end ); // بازه شبانه
	}
}
endif;
