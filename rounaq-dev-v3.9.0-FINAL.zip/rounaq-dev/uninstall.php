<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
// در صورت تمایل به حذف کامل داده‌ها، خطوط زیر را از حالت کامنت خارج کنید.
// global $wpdb;
// delete_option( 'jsms_settings' );
// delete_option( 'jsms_optout_list' );
// delete_option( 'jsms_last_credit' );
// $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}jsms_logs" );
// $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}jsms_reviews" );
// $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}jsms_carts" );
