(function ($) {
	'use strict';

	// نمایش/مخفی بلوکِ تنظیماتِ پنل پیامکی انتخاب‌شده.
	function toggleGatewayProvider() {
		var p = $('#jsms-provider-select').val() || '';
		var note = $('#jsms-active-gateway-note');
		$('.jsms-provider-block').hide();
		$('.jsms-provider-' + p).show();
		if (note.length) {
			var service = /pattern/i.test(p) || /services?/i.test(p);
			note.text(service ? 'این گزینه برای ارسال خدماتی / Pattern است. در اتوماسیون‌ها حالت «پترن» را انتخاب کنید و شناسه قالب را وارد نمایید.' : 'این پنل برای ارسال پیامک متنی عادی آماده است. در صورت پشتیبانی پنل، Pattern نیز از بخش اتوماسیون قابل استفاده است.');
			note.css('display','block');
		}
		toggleProvider();
	}
	$(document).on('change', '#jsms-provider-select', toggleGatewayProvider);
	toggleGatewayProvider();

	// نمایش/مخفی فیلدهای روش اتصال (رست/کنسول) — فقط داخل بلوک ملی‌پیامک.
	function toggleProvider() {
		var m = $('select[name="provider_method"]').val();
		$('.jsms-rest').toggle(m === 'rest');
		$('.jsms-console').toggle(m === 'console');
	}
	$(document).on('change', 'select[name="provider_method"]', toggleProvider);
	toggleProvider();

	// نمایش/مخفی متن یا پترن در جعبه اتوماسیون.
	$('.jsms-auto-box').each(function () {
		var box = $(this);
		function sync() {
			var mode = box.find('.jsms-mode').val();
			box.find('.jsms-text-row').toggle(mode === 'text');
			box.find('.jsms-pat-row').toggle(mode === 'pattern');
		}
		box.find('.jsms-mode').on('change', sync);
		sync();
	});


	// نمایش/مخفی‌کردن رمزهای اتصال بدون دست‌کاری مقدار ذخیره‌شده.
	$(document).on('click', '.jsms-password-toggle', function () {
		var btn = $(this), input = $('#' + btn.data('target'));
		if (!input.length) return;
		var visible = input.attr('type') === 'text';
		input.attr('type', visible ? 'password' : 'text');
		btn.attr('aria-label', visible ? 'نمایش رمز' : 'مخفی کردن رمز').text(visible ? 'نمایش' : 'مخفی');
	});

	// ارسال تست.
	$('#jsms-test-send').on('click', function () {
		var btn = $(this), res = $('#jsms-test-result');
		res.text('در حال بررسی اتصال...');
		$.post(JSMS.ajax, {
			action: 'jsms_test_send', nonce: JSMS.nonce,
			mobile: $('#jsms-test-mobile').val()
		}).done(function (r) {
			res.html(r.success ? '<b style="color:#2fae13">' + r.data + '</b>' : '<b style="color:#d1373f">' + r.data + '</b>');
		}).fail(function () { res.text('خطای ارتباط'); });
	});

	// بررسی نسخهٔ جدید افزونه.
	$('#jsms-check-update').on('click', function () {
		var res = $('#jsms-check-update-result');
		res.text('در حال بررسی...');
		$.post(JSMS.ajax, { action: 'jsms_check_update', nonce: JSMS.nonce })
			.done(function (r) {
				res.html(r.success ? '<b style="color:#2fae13">' + r.data + '</b>' : '<b style="color:#d1373f">' + r.data + '</b>');
			}).fail(function () { res.text('خطای ارتباط'); });
	});

	// بررسی اعتبار.
	$('#jsms-refresh-credit').on('click', function (e) {
		e.preventDefault();
		var el = $('#jsms-credit'); el.text('...');
		$.post(JSMS.ajax, { action: 'jsms_check_credit', nonce: JSMS.nonce })
			.done(function (r) { el.text(r.success ? r.data : 'خطا'); });
	});

	// تست اتصال ای‌بازار پست.
	$('#jsms-ebazar-test').on('click', function () {
		var res = $('#jsms-ebazar-test-result');
		res.text('در حال بررسی...');
		$.post(JSMS.ajax, {
			action: 'jsms_ebazar_test', nonce: JSMS.nonce,
			username: $('input[name="ebazar_username"]').val(),
			password: $('input[name="ebazar_password"]').val()
		}).done(function (r) {
			res.html(r.success ? '<b style="color:#2fae13">' + r.data + '</b>' : '<b style="color:#d1373f">' + r.data + '</b>');
		}).fail(function () { res.text('خطای ارتباط'); });
	});

	// جعبهٔ ثبت مرسولهٔ ای‌بازار پست در صفحهٔ سفارش.
	var $ebazarBox = $('#jsms-ebazar-box');
	if ($ebazarBox.length) {
		$ebazarBox.on('change', '#jsms-ebazar-province', function () {
			var province = $(this).val();
			var citySelect = $('#jsms-ebazar-city');
			citySelect.html('<option>در حال بارگذاری...</option>');
			$.post(JSMS.ajax, { action: 'jsms_ebazar_cities', nonce: JSMS.nonce, province: province })
				.done(function (r) {
					citySelect.empty().append('<option value="0">انتخاب کنید</option>');
					if (r.success) {
						$.each(r.data, function (id, name) {
							citySelect.append($('<option>').val(id).text(name));
						});
					}
				});
		});

		$ebazarBox.on('click', '#jsms-ebazar-submit', function () {
			var btn = $(this), res = $('#jsms-ebazar-result');
			var orderId = $ebazarBox.data('order-id');
			var cityId = $('#jsms-ebazar-city').val();
			if (!cityId || cityId == '0') { res.html('<b style="color:#d1373f">شهر مقصد را انتخاب کنید.</b>'); return; }
			btn.prop('disabled', true);
			res.text('در حال ثبت مرسوله...');
			$.post(JSMS.ajax, { action: 'jsms_ebazar_create_parcel', nonce: JSMS.nonce, order_id: orderId, city_id: cityId })
				.done(function (r) {
					if (r.success) {
						res.html('<b style="color:#2fae13">ثبت شد ✅ کد مرسوله: ' + r.data.parcel_code + '</b>');
					} else {
						res.html('<b style="color:#d1373f">' + r.data + '</b>');
						btn.prop('disabled', false);
					}
				}).fail(function () { res.text('خطای ارتباط'); btn.prop('disabled', false); });
		});
	}

	/* ---- ویزارد کمپین ---- */
	var $wiz = $('#jsms-wizard');
	if ($wiz.length) {
		var step = 1, campaign = null, totalSent = 0, totalFailed = 0, running = false;

		function faNum(n) {
			return String(n).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[d]; });
		}
		function segment() { return $('input[name="jsms-segment"]:checked').val(); }
		function smsParts(len) { return len === 0 ? 1 : (len <= 70 ? 1 : Math.ceil(len / 67)); }

		function goStep(n) {
			step = n;
			$('.jsms-step').attr('hidden', true).filter('[data-step="' + n + '"]').removeAttr('hidden');
			$('#jsms-steps li').each(function () {
				var s = +$(this).data('step');
				$(this).toggleClass('is-active', s === n).toggleClass('is-done', s < n);
			});
			$('html,body').animate({ scrollTop: $wiz.offset().top - 60 }, 200);
		}

		// انتخاب مخاطبان.
		$(document).on('change', 'input[name="jsms-segment"]', function () {
			var v = segment();
			$('#jsms-custom-wrap').toggle(v === 'custom');
			$('#jsms-days-wrap').toggle(v === 'inactive');
		});
		$('.jsms-choice').on('click', function () { $(this).find('input').prop('checked', true).trigger('change'); });

		// انتخاب متن آمادهٔ کمپین.
		$(document).on('click', '.jsms-tpl-chip', function () {
			$('#jsms-text').val($(this).data('tpl')).trigger('input');
			$('.jsms-tpl-chip').removeClass('is-active');
			$(this).addClass('is-active');
		});

		// شمارنده کاراکتر/پیامک.
		$('#jsms-text').on('input', function () {
			var len = $(this).val().length, parts = smsParts(len);
			$('#jsms-charcount').text(faNum(len) + ' کاراکتر');
			$('#jsms-partcount').text(faNum(parts) + ' پیامک');
		});

		// حرکت بین گام‌ها.
		$wiz.on('click', '.jsms-next', function () {
			if (step === 1 && segment() === 'custom' && !$('#jsms-custom').val().trim()) { alert('حداقل یک شماره وارد کنید.'); return; }
			if (step === 2 && !$('#jsms-text').val().trim()) { alert('متن پیام را وارد کنید.'); return; }
			var next = step + 1;
			if (next === 3) { buildPreview(); }
			goStep(next);
		});
		$wiz.on('click', '.jsms-prev', function () { goStep(step - 1); });

		// ساخت پیش‌نمایش گام ۳.
		function buildPreview() {
			var text = $('#jsms-text').val();
			var sample = text
				.replace(/\{first_name\}/g, 'زهرا')
				.replace(/\{site_name\}/g, (window.JSMS && JSMS.site_name) || 'فروشگاه')
				.replace(/\{site_url\}/g, (window.JSMS && JSMS.site_url) || '')
				.replace(/\{coupon\}/g, 'JL7K9QX');
			$('#jsms-preview-text').text(sample || '—');
			var parts = smsParts(text.length);
			$('#jsms-seg-count').text(faNum(parts));
			$('#jsms-aud-count').text('…'); $('#jsms-total-sms').text('…');
			$.post(JSMS.ajax, {
				action: 'jsms_campaign_count', nonce: JSMS.nonce,
				segment: segment(), custom: $('#jsms-custom').val(), days: $('#jsms-days').val()
			}).done(function (r) {
				var c = (r.success && r.data.count) ? r.data.count : 0;
				$('#jsms-aud-count').text(faNum(c));
				$('#jsms-total-sms').text(faNum(c * parts));
			}).fail(function () { $('#jsms-aud-count').text('خطا'); });
		}

		// ارسال دسته‌ای.
		$('#jsms-camp-start').on('click', function () {
			if (running) { return; }
			var text = $('#jsms-text').val().trim();
			if (!confirm('ارسال کمپین به مخاطبان انتخاب‌شده انجام شود؟')) { return; }
			running = true; totalSent = 0; totalFailed = 0;
			campaign = 'c' + Date.now();
			goStep(4);
			var params = { segment: segment(), custom: $('#jsms-custom').val(), days: $('#jsms-days').val(), text: text };

			function batch(offset) {
				$.post(JSMS.ajax, $.extend({ action: 'jsms_campaign_send', nonce: JSMS.nonce, campaign: campaign, offset: offset }, params))
					.done(function (r) {
						if (!r.success) { $('#jsms-camp-status').text('خطا: ' + r.data); running = false; return; }
						var d = r.data;
						totalSent += d.sent; totalFailed += d.failed;
						var pct = d.total ? Math.min(Math.round((d.offset / d.total) * 100), 100) : 100;
						$('#jsms-bar-fill').css('width', pct + '%');
						$('#jsms-camp-status').text('ارسال شده: ' + faNum(totalSent) + ' | ناموفق: ' + faNum(totalFailed) + ' | از ' + faNum(d.total));
						if (d.done) {
							$('#jsms-bar-fill').css('width', '100%');
							$('#jsms-camp-status').html('کمپین با موفقیت ارسال شد ✅ — ' + faNum(totalSent) + ' پیامک');
							running = false;
						} else { batch(d.offset); }
					})
					.fail(function () { $('#jsms-camp-status').text('خطای ارتباط با سرور'); running = false; });
			}
			batch(0);
		});
	}

})(jQuery);

/* متغیرهای پیامک: با کلیک، کد در محل مکان‌نما داخل کادر همان بخش درج می‌شود. */
jQuery(function($){
    $(document).on('click', '.jsms-shortcode-button', function(e){
        e.preventDefault();
        var $button = $(this);
        var targetId = $button.closest('.jsms-shortcode-toolbar').data('target');
        var el = document.getElementById(targetId);
        if (!el) return;

        var code = $button.data('shortcode') || '';
        var start = typeof el.selectionStart === 'number' ? el.selectionStart : el.value.length;
        var end = typeof el.selectionEnd === 'number' ? el.selectionEnd : el.value.length;

        el.value = el.value.substring(0, start) + code + el.value.substring(end);
        var caret = start + code.length;
        el.focus();
        if (typeof el.setSelectionRange === 'function') {
            el.setSelectionRange(caret, caret);
        }
        $(el).trigger('input').trigger('change');
    });
});
