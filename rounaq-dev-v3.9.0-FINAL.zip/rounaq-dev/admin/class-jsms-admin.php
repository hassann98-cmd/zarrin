<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * رابط مدیریت افزونه.
 * محافظ تداخل: اگر (مثلاً به‌خاطر نصب موازی نسخهٔ فروشی) این کلاس از قبل تعریف
 * شده باشد، دوباره تعریفش نمی‌کنیم تا سایت با Fatal از کار نیفتد.
 */
if ( ! class_exists( 'JSMS_Admin' ) ) :
class JSMS_Admin {

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'handle_forms' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'wp_ajax_jsms_test_send', array( $this, 'ajax_test_send' ) );
		add_action( 'wp_ajax_jsms_check_credit', array( $this, 'ajax_check_credit' ) );
		add_action( 'wp_ajax_jsms_ebazar_test', array( $this, 'ajax_ebazar_test' ) );
		add_action( 'wp_ajax_jsms_ebazar_cities', array( $this, 'ajax_ebazar_cities' ) );
		add_action( 'wp_ajax_jsms_ebazar_create_parcel', array( $this, 'ajax_ebazar_create_parcel' ) );
		add_action( 'wp_ajax_jsms_check_update', array( $this, 'ajax_check_update' ) );
		add_action( 'wp_dashboard_setup', array( $this, 'dashboard_widget' ) );
		add_action( 'admin_head', array( $this, 'menu_icon_css' ) );
	}

	/**
	 * اندازهٔ درست آیکونِ نوارِ منو — باید در *همهٔ* صفحات ادمین اعمال شود (نه فقط
	 * صفحات خودِ رونق)، چون خودِ منوی کناری در همه‌جا نمایش داده می‌شود؛ برای همین
	 * روی admin_head بدون شرط اجرا می‌شود، نه از طریق admin-rtl.css که فقط در
	 * صفحات رونق لود می‌شود.
	 *
	 * قانون دومِ img عمداً اضافه شده: افزونهٔ «Admin Menu Editor» (که کل منو را
	 * بازسازی می‌کند) آیکون سفارشی را با تگ <img> واقعی (نه background-image) رندر
	 * می‌کند — بدون این قانون، فایل ۳۲۰×۳۲۰ در همان اندازهٔ اصلی و غول‌پیکر روی کل
	 * ستون منو کشیده می‌شد.
	 */
	public function menu_icon_css() {
		echo '<style>
			#toplevel_page_jsms .wp-menu-image{background-size:20px 20px!important;background-position:center!important}
			#toplevel_page_jsms .wp-menu-image img,
			#toplevel_page_jsms > a > img,
			#toplevel_page_jsms img[src*="rounaq-icon"]{
				width:20px!important;height:20px!important;max-width:20px!important;max-height:20px!important;
				object-fit:cover!important;border-radius:4px;vertical-align:middle;position:static!important;
			}
		</style>';
	}

	public function ajax_check_update() {
		check_ajax_referer( 'jsms_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'دسترسی غیرمجاز' );
		}
		$res = JSMS_Updater::check_now();
		if ( ! $res['ok'] ) {
			wp_send_json_error( $res['error'] );
		}
		if ( $res['has_update'] ) {
			wp_send_json_success( 'نسخهٔ جدیدتر (' . $res['latest'] . ') موجود است ✅ برای نصب به صفحهٔ «افزونه‌ها» بروید.' );
		}
		wp_send_json_success( 'نسخهٔ فعلی (' . $res['current'] . ') به‌روز است.' );
	}

	/**
	 * ویجت خلاصهٔ آمار توی پیشخوان اصلی وردپرس — همون چیزی که توی صفحهٔ «گزارش‌ها»
	 * هست، ولی فشرده، تا مدیر بدون رفتن به منوی افزونه، سریع وضعیت رو ببینه.
	 */
	public function dashboard_widget() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		wp_add_dashboard_widget( 'jsms_dashboard_widget', 'رونق · خلاصهٔ ۳۰ روز اخیر', array( $this, 'render_dashboard_widget' ) );
	}

	public function render_dashboard_widget() {
		$days = 30;
		$attr = JSMS_Reports::attribution( $days );
		$aov  = JSMS_Reports::average_order_value( $days );
		$dv   = JSMS_Reports::delivery_stats( $days );
		$cf   = JSMS_Reports::cart_funnel();
		$insights = JSMS_Reports::insights( $days );

		$tot_orders = 0; $tot_rev = 0;
		foreach ( $attr as $a ) { $tot_orders += $a['orders']; $tot_rev += $a['revenue']; }
		$cart_rate = $cf['stage1_sent'] ? round( $cf['stage1_recovered'] / $cf['stage1_sent'] * 100, 1 ) : 0;
		?>
		<style>
			#jsms_dashboard_widget .inside{margin:0;padding:0}
			.jsms-dw{padding:0 12px 12px}
			.jsms-dw-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:12px 0}
			.jsms-dw-stat{background:#fef9ff;border:1px solid #e8e0f5;border-radius:10px;padding:10px 12px}
			.jsms-dw-stat .n{display:block;font-size:18px;font-weight:800;color:#332c66;font-variant-numeric:tabular-nums}
			.jsms-dw-stat .l{display:block;color:#8983ab;font-size:11px;margin-top:2px}
			.jsms-dw-ins{display:flex;gap:8px;align-items:flex-start;background:#fef9ff;border-radius:8px;
				padding:8px 10px;margin-top:6px;font-size:12px;line-height:1.7;color:#362f52}
			.jsms-dw-foot{margin-top:12px;text-align:left}
			.jsms-dw-foot a{color:#736ced;font-weight:700;text-decoration:none;font-size:12.5px}
		</style>
		<div class="jsms-dw">
			<div class="jsms-dw-grid">
				<div class="jsms-dw-stat"><span class="n"><?php echo number_format( $tot_orders ); ?></span><span class="l">سفارش منتسب</span></div>
				<div class="jsms-dw-stat"><span class="n"><?php echo number_format( $tot_rev ); ?></span><span class="l">درآمد منتسب (تومان)</span></div>
				<div class="jsms-dw-stat"><span class="n"><?php echo number_format( $aov ); ?></span><span class="l">میانگین ارزش سفارش</span></div>
				<div class="jsms-dw-stat"><span class="n"><?php echo esc_html( $dv['rate'] ); ?>٪</span><span class="l">نرخ تحویل پیامک</span></div>
				<div class="jsms-dw-stat"><span class="n"><?php echo esc_html( $cart_rate ); ?>٪</span><span class="l">بازگشت سبد رها شده</span></div>
				<div class="jsms-dw-stat"><span class="n"><?php echo number_format( $cf['stage1_sent'] ); ?></span><span class="l">یادآوری سبد ارسال‌شده</span></div>
			</div>
			<?php if ( ! empty( $insights[0] ) ) : ?>
				<div class="jsms-dw-ins">💡 <span><?php echo esc_html( $insights[0]['text'] ); ?></span></div>
			<?php endif; ?>
			<div class="jsms-dw-foot">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=jsms-reports' ) ); ?>">مشاهدهٔ گزارش کامل ←</a>
			</div>
		</div>
		<?php
	}

	public function ajax_ebazar_test() {
		check_ajax_referer( 'jsms_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'دسترسی غیرمجاز' );
		}
		$username = sanitize_text_field( wp_unslash( $_POST['username'] ?? '' ) );
		$password = sanitize_text_field( wp_unslash( $_POST['password'] ?? '' ) );
		if ( ! $username || ! $password ) {
			wp_send_json_error( 'یوزرنیم/پسورد را وارد کنید.' );
		}
		$res = JSMS_Ebazar::fetch_token( $username, $password );
		if ( ! empty( $res['access_token'] ) ) {
			wp_send_json_success( 'اتصال برقرار شد ✅ توکن با موفقیت دریافت شد.' );
		}
		wp_send_json_error( $res['error_description'] ?? $res['error'] ?? 'خطای نامشخص از سرویس ای‌بازار پست.' );
	}

	public function ajax_ebazar_cities() {
		check_ajax_referer( 'jsms_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'دسترسی غیرمجاز' );
		}
		$province = (int) ( $_POST['province'] ?? 0 );
		$cities = $province ? JSMS_Ebazar::get_cities( $province ) : array();
		wp_send_json_success( $cities );
	}

	public function ajax_ebazar_create_parcel() {
		check_ajax_referer( 'jsms_admin', 'nonce' );
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			wp_send_json_error( 'دسترسی غیرمجاز' );
		}
		$order_id = (int) ( $_POST['order_id'] ?? 0 );
		$city_id  = (int) ( $_POST['city_id'] ?? 0 );
		if ( ! $order_id || ! $city_id ) {
			wp_send_json_error( 'سفارش یا شهر مقصد نامعتبر است.' );
		}
		$res = JSMS_Ebazar::create_parcel( $order_id, $city_id );
		if ( ! empty( $res['ok'] ) ) {
			$order = wc_get_order( $order_id );
			if ( $order ) {
				$order->add_order_note( 'مرسولهٔ ای‌بازار پست ثبت شد. کد مرسوله: ' . $res['parcel_code'] );
			}
			wp_send_json_success( array( 'parcel_code' => $res['parcel_code'] ) );
		}
		wp_send_json_error( $res['error'] ?? 'خطای نامشخص.' );
	}

	/**
	 * تعداد نظراتی که هنوز منتظر تأیید/رد مدیر هستند.
	 */
	private function pending_reviews_count() {
		global $wpdb;
		$rt = JSMS_DB::reviews_table();
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$rt} WHERE status='pending'" );
	}

	/**
	 * آیکون اختصاصیِ نوار منوی ادمین (جایگزین dashicon عمومیِ ایمیل) — لوگوی برند رونق.
	 *
	 * عمداً یک فایل واقعی است (نه data-URI اینلاین)، چون افزونهٔ «Admin Menu Editor»
	 * (که روی این سایت نصب است و کل منوی ادمین را بازسازی می‌کند) رنگ‌های هر
	 * data-URI اینلاین را موقع بازسازی منو پاک می‌کرد و آیکون کاملاً سفید/نامرئی
	 * می‌شد؛ فایل واقعی از این مشکل مصون است.
	 */
	private static function menu_icon() {
		return JSMS_URL . 'admin/assets/rounaq-icon.png';
	}

	/**
	 * اعلان (notice) برند‌شدهٔ رونق — جایگزین اعلان خاکستریِ پیش‌فرض وردپرس.
	 * کلاس‌های notice/is-dismissible را نگه می‌داریم تا دکمهٔ بستنِ خودِ
	 * وردپرس (بدون نیاز به جاوااسکریپت اضافه) کار کند؛ فقط ظاهرش را عوض می‌کنیم.
	 */
	private static function notice_html( $type, $title, $subtitle = '' ) {
		$icon = 'success' === $type
			? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>'
			: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16h.01"/></svg>';
		ob_start();
		?>
		<div class="notice is-dismissible jsms-toast jsms-toast-<?php echo esc_attr( $type ); ?>">
			<span class="jsms-toast-ic"><?php echo $icon; // phpcs:ignore ?></span>
			<div class="jsms-toast-body">
				<b><?php echo esc_html( $title ); ?></b>
				<?php if ( $subtitle ) : ?><span><?php echo esc_html( $subtitle ); ?></span><?php endif; ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	public function menu() {
		$cap     = 'manage_woocommerce';
		$pending = $this->pending_reviews_count();
		$badge   = $pending
			? ' <span class="awaiting-mod count-' . $pending . '"><span class="pending-count">' . number_format_i18n( $pending ) . '</span></span>'
			: '';

		add_menu_page( 'رونق', 'رونق' . $badge, $cap, 'jsms', array( $this, 'page_dashboard' ), self::menu_icon(), 56 );
		add_submenu_page( 'jsms', 'داشبورد', 'داشبورد', $cap, 'jsms', array( $this, 'page_dashboard' ) );
		add_submenu_page( 'jsms', 'راهنما', '📘 راهنما', $cap, 'jsms-help', array( $this, 'page_help' ) );
		add_submenu_page( 'jsms', 'تنظیمات اتصال', 'تنظیمات اتصال', $cap, 'jsms-settings', array( $this, 'page_settings' ) );
		add_submenu_page( 'jsms', 'اتوماسیون‌ها', 'اتوماسیون‌ها', $cap, 'jsms-automations', array( $this, 'page_automations' ) );
		add_submenu_page( 'jsms', 'کمپین‌ها', 'کمپین‌ها', $cap, 'jsms-campaigns', array( $this, 'page_campaigns' ) );
		add_submenu_page( 'jsms', 'باشگاه مشتریان', 'باشگاه مشتریان', $cap, 'jsms-club', array( $this, 'page_club' ) );
		add_submenu_page( 'jsms', 'گزارش‌ها', 'گزارش‌ها', $cap, 'jsms-reports', array( $this, 'page_reports' ) );
		add_submenu_page( 'jsms', 'نظرات مشتریان', 'نظرات مشتریان' . $badge, $cap, 'jsms-reviews', array( $this, 'page_reviews' ) );
		add_submenu_page( 'jsms', 'نظرسنجی', 'نظرسنجی', $cap, 'jsms-surveys', array( $this, 'page_surveys' ) );
		add_submenu_page( 'jsms', 'کدهای تخفیف', 'کدهای تخفیف', $cap, 'jsms-coupons', array( $this, 'page_coupons' ) );
		add_submenu_page( 'jsms', 'گزارش ارسال‌ها', 'گزارش ارسال‌ها', $cap, 'jsms-logs', array( $this, 'page_logs' ) );
	}

	public function assets( $hook ) {
		$is_order_screen = in_array( $hook, array( 'post.php', 'post-new.php', 'woocommerce_page_wc-orders' ), true );
		if ( strpos( (string) $hook, 'jsms' ) === false && ! $is_order_screen ) {
			return;
		}
		wp_enqueue_style( 'jsms-admin', JSMS_URL . 'admin/assets/admin-rtl.css', array(), JSMS_VERSION );
		wp_enqueue_script( 'jsms-admin', JSMS_URL . 'admin/assets/admin.js', array( 'jquery' ), JSMS_VERSION, true );
		wp_localize_script( 'jsms-admin', 'JSMS', array(
			'ajax'  => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'jsms_admin' ),
			'site_name' => get_bloginfo( 'name' ),
			'site_url'  => home_url( '/' ),
		) );
	}

	/* ---------------------------------------------------------------------
	 * ذخیره فرم‌ها و اکشن‌ها
	 * ------------------------------------------------------------------- */
	public function handle_forms() {
		// ذخیره تنظیمات/اتوماسیون‌ها.
		if ( isset( $_POST['jsms_save'] ) && check_admin_referer( 'jsms_save', '_jsms' ) ) {
			$this->save_settings( $_POST );
			add_action( 'admin_notices', function () {
				echo self::notice_html( 'success', 'تنظیمات ذخیره شد', 'تغییرات شما با موفقیت روی سایت اعمال شد.' );
			} );
		}
		// تأیید/رد نظر.
		if ( isset( $_GET['jsms_review_action'], $_GET['rid'] ) && check_admin_referer( 'jsms_review_act' ) ) {
			$rid = (int) $_GET['rid'];
			if ( 'approve' === $_GET['jsms_review_action'] ) {
				JSMS_Reviews::approve( $rid );
			} elseif ( 'reject' === $_GET['jsms_review_action'] ) {
				JSMS_Reviews::reject( $rid );
			}
			wp_safe_redirect( admin_url( 'admin.php?page=jsms-reviews' ) );
			exit;
		}
		$this->handle_survey_forms();
		$this->handle_coupon_forms();
	}

	/**
	 * ساخت دستیِ کد تخفیف از صفحهٔ «کدهای تخفیف» — فقط رویهٔ رندر/فرم اینجاست؛
	 * منطق واقعیِ ساخت کوپن (و سازگاریِ کاملش با ووکامرس، چون از خودِ WC_Coupon
	 * استفاده می‌کند) در JSMS_Coupons::generate() است.
	 */
	private function handle_coupon_forms() {
		if ( ! isset( $_POST['jsms_coupon_create'] ) || ! check_admin_referer( 'jsms_coupon_create', '_jsms' ) ) {
			return;
		}
		$scope = sanitize_key( $_POST['scope'] ?? 'single' );
		$args = array(
			'amount'         => (float) ( $_POST['amount'] ?? 0 ),
			'type'           => 'fixed_cart' === ( $_POST['type'] ?? '' ) ? 'fixed_cart' : 'percent',
			'code'           => sanitize_text_field( wp_unslash( $_POST['code'] ?? '' ) ),
			'description'    => 'کد دستی رونق',
			'source_type'    => 'manual',
			'expires_at'     => sanitize_text_field( wp_unslash( $_POST['expires_at'] ?? '' ) ),
		);
		if ( 'shared' === $scope ) {
			$args['usage_limit']    = 0; // نامحدود — برای همهٔ مشتریان.
			$args['individual_use'] = false;
		} else {
			$limit = max( 1, (int) ( $_POST['usage_limit'] ?? 1 ) );
			$args['usage_limit']    = $limit;
			$args['individual_use'] = true;
			$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
			if ( $email ) {
				$args['email'] = $email;
			}
		}
		$code = JSMS_Coupons::generate( $args );
		add_action( 'admin_notices', function () use ( $code ) {
			if ( $code ) {
				echo self::notice_html( 'success', 'کد تخفیف ساخته شد', 'کد: ' . esc_html( $code ) );
			} else {
				echo self::notice_html( 'error', 'ساخت کد تخفیف ناموفق بود', 'شاید این کد از قبل وجود دارد — کد دیگری امتحان کنید.' );
			}
		} );
	}

	/**
	 * اکشن‌های صفحهٔ نظرسنجی — چون داده‌ها در جدول‌های جدا (نه گزینهٔ عمومی
	 * تنظیمات) هستند، جدا از save_settings() و با همان الگوی GET/POST +
	 * نانس که در بقیهٔ افزونه استفاده شده مدیریت می‌شوند.
	 */
	private function handle_survey_forms() {
		if ( isset( $_POST['jsms_survey_save'] ) && check_admin_referer( 'jsms_survey_save', '_jsms' ) ) {
			$id = (int) ( $_POST['survey_id'] ?? 0 );
			$id = JSMS_Surveys::save_survey( $id, wp_unslash( $_POST ) );
			wp_safe_redirect( admin_url( 'admin.php?page=jsms-surveys&view=edit&id=' . $id . '&saved=1' ) );
			exit;
		}
		if ( isset( $_GET['jsms_survey_action'] ) && 'delete' === $_GET['jsms_survey_action']
			&& isset( $_GET['id'] ) && check_admin_referer( 'jsms_survey_act' ) ) {
			JSMS_Surveys::delete_survey( (int) $_GET['id'] );
			wp_safe_redirect( admin_url( 'admin.php?page=jsms-surveys' ) );
			exit;
		}
		if ( isset( $_POST['jsms_question_save'] ) && check_admin_referer( 'jsms_survey_save', '_jsms' ) ) {
			$survey_id = (int) $_POST['survey_id'];
			$qid = (int) ( $_POST['question_id'] ?? 0 );
			JSMS_Surveys::save_question( $qid, $survey_id, wp_unslash( $_POST ) );
			wp_safe_redirect( admin_url( 'admin.php?page=jsms-surveys&view=edit&id=' . $survey_id ) );
			exit;
		}
		if ( isset( $_GET['jsms_survey_action'] ) && 'delete_question' === $_GET['jsms_survey_action']
			&& isset( $_GET['qid'], $_GET['id'] ) && check_admin_referer( 'jsms_survey_act' ) ) {
			JSMS_Surveys::delete_question( (int) $_GET['qid'] );
			wp_safe_redirect( admin_url( 'admin.php?page=jsms-surveys&view=edit&id=' . (int) $_GET['id'] ) );
			exit;
		}
		if ( isset( $_POST['jsms_survey_test_send'] ) && check_admin_referer( 'jsms_survey_save', '_jsms' ) ) {
			$survey_id = (int) $_POST['survey_id'];
			$mobile    = sanitize_text_field( wp_unslash( $_POST['test_mobile'] ?? '' ) );
			$res = JSMS_Surveys::send_link( $survey_id, $mobile, array( 'author' => 'مشتری آزمایشی', 'force' => true ) );
			add_action( 'admin_notices', function () use ( $res ) {
				if ( ! empty( $res['ok'] ) ) {
					echo self::notice_html( 'success', 'لینک نظرسنجی ارسال شد', 'پیامک تست با موفقیت ارسال شد.' );
				} else {
					echo self::notice_html( 'error', 'ارسال ناموفق بود', esc_html( $res['error'] ?? 'نامشخص' ) );
				}
			} );
		}
	}

	private function save_settings( $post ) {
		$s = get_option( 'jsms_settings', JSMS_Settings_Defaults() );
		// مهاجرت فقط برای پنل انتخاب‌شده؛ اطلاعات یک پنل نباید وارد پنل دیگری شود.
		$selected_provider = sanitize_key( $s['provider'] ?? 'melipayamak' );
		$legacy_map = array(
			'kavenegar' => array( 'gw_kavenegar_apikey', 'gw_kavenegar_line' ),
			'ghasedak'  => array( 'gw_ghasedak_apikey', 'gw_ghasedak_line' ),
			'ippanel'   => array( 'gw_ippanel_token', 'gw_ippanel_from' ),
			'smsir'     => array( 'gw_smsir_apikey', 'gw_smsir_line' ),
		);
		if ( isset( $legacy_map[ $selected_provider ] ) ) {
			$legacy = $legacy_map[ $selected_provider ];
			if ( empty( $s['username'] ) && ! empty( $s[ $legacy[0] ] ) ) $s['username'] = $s[ $legacy[0] ];
			if ( empty( $s['line_number'] ) && ! empty( $s[ $legacy[1] ] ) ) $s['line_number'] = $s[ $legacy[1] ];
		}
		if ( 'melipayamak' === $selected_provider && empty( $s['username'] ) && ! empty( $s['apikey'] ) ) {
			$s['username'] = $s['apikey'];
		}
		$text_keys = array(
			'welcome_text','cart_text','cart_text_2','inactive_text','review_text','review_reminder_text',
			'wallet_cashback_text','wallet_redeem_text','tracking_text','survey_default_text',
			'admin_order_alert_text','admin_lowstock_text','admin_receipt_alert_text','ebazar_status_text',
			'card_pending_text', 'pending_reminder_text',
		);
		$plain_keys = array(
			'provider','provider_method','username','password','apikey','line_number','admin_mobile',
			'gw_kavenegar_apikey','gw_kavenegar_line',
			'gw_ghasedak_apikey','gw_ghasedak_line',
			'gw_ippanel_token','gw_ippanel_from',
			'gw_smsir_apikey','gw_smsir_line',
			'update_manifest_url',
			'welcome_mode','welcome_pattern','cart_mode','cart_pattern','cart_pattern_2',
			'inactive_mode','inactive_pattern','review_mode','review_pattern','review_order_status',
			'coupon_type','coupon_prefix','cashback_trigger_status','tracking_mode','tracking_pattern',
			'ebazar_username','ebazar_password','survey_order_status','survey_auto_survey_id',
		);
		$int_keys = array(
			'low_credit_threshold','cart_delay_min','cart_delay2_min','cart_recovery_expiry_days','inactive_days','inactive_cooldown',
			'review_after_days','survey_after_days','quiet_start','quiet_end',
			'coupon_amount','coupon_expiry_days','attribution_window_days','log_retention_days',
			'cashback_percent','cashback_max','cashback_min_order',
			'tier_silver_min','tier_silver_pct','tier_gold_min','tier_gold_pct',
			'wallet_redeem_min','wallet_coupon_expiry_days',
			'ebazar_box_size_id',
			'pending_expiry_min', 'pending_reminder_min',
		);
		// چون تنظیمات/اتوماسیون‌ها/باشگاه مشتریان هر کدام فرم POST جدای خودشان را
		// دارند، هر فرم فقط باید کلیدهای بولیِ خودش را صفر/یک کند — وگرنه مثلاً
		// ذخیرهٔ صفحهٔ «اتوماسیون‌ها» چون چک‌باکس wallet_enabled را در خودش ندارد،
		// خودکار کیف‌پول/ساعات‌سکوت/پیگیری ای‌بازار را (که در صفحات دیگرند) خاموش
		// می‌کرد — یک باگ واقعیِ از-دست‌رفتن تنظیمات که با scope زیر رفع شده.
		$bool_keys_by_scope = array(
			'automations' => array(
				'welcome_enabled','status_enabled','cart_enabled','cart_stage2_enabled','inactive_enabled',
				'review_enabled','review_incoming','survey_auto_enabled',
				'admin_order_alert_enabled','admin_lowstock_enabled','admin_receipt_alert_enabled',
				'card_pending_enabled','pending_expiry_enabled','pending_reminder_enabled',
			),
			'settings' => array( 'quiet_hours','respect_optout','block_transactional_for_optout','ebazar_tracking_enabled','ebazar_tracking_sms_enabled' ),
			'club'     => array( 'wallet_enabled','wallet_sms_enabled' ),
		);
		$scope     = sanitize_key( $post['jsms_scope'] ?? '' );
		$bool_keys = $bool_keys_by_scope[ $scope ] ?? array();

		// فیلدهای اتصال اکنون مثل افزونه مرجع عمومی هستند؛ درایور هر پنل
		// username/password/line_number را با قرارداد خودش تفسیر می‌کند.
		$plain_keys = array_merge( $plain_keys, array( 'line_number' ) );

		foreach ( $plain_keys as $k ) {
			if ( ! isset( $post[ $k ] ) ) {
				continue;
			}
			$value = sanitize_text_field( wp_unslash( $post[ $k ] ) );
			// رمزهای اتصال اگر در فرم خالی ارسال شدند، مقدار ذخیره‌شده قبلی نباید
			// ناخواسته پاک شود. برای تغییر رمز، مقدار جدید را وارد کنید.
			if ( in_array( $k, array( 'password', 'apikey', 'ebazar_password', 'gw_kavenegar_apikey', 'gw_ghasedak_apikey', 'gw_ippanel_token', 'gw_smsir_apikey' ), true ) && '' === $value ) {
				continue;
			}
			$s[ $k ] = $value;
		}
		foreach ( $text_keys as $k ) {
			if ( isset( $post[ $k ] ) ) {
				$s[ $k ] = sanitize_textarea_field( wp_unslash( $post[ $k ] ) );
			}
		}
		foreach ( $int_keys as $k ) {
			if ( isset( $post[ $k ] ) ) {
				$s[ $k ] = (int) $post[ $k ];
			}
		}
		foreach ( $bool_keys as $k ) {
			$s[ $k ] = isset( $post[ $k ] ) ? 1 : 0;
		}
		// نقشه وضعیت‌ها.
		if ( isset( $post['status_map'] ) && is_array( $post['status_map'] ) ) {
			$map = array();
			foreach ( $post['status_map'] as $status => $txt ) {
				$txt = sanitize_textarea_field( wp_unslash( $txt ) );
				if ( '' !== trim( $txt ) ) {
					$map[ sanitize_key( $status ) ] = $txt;
				}
			}
			$s['status_map'] = $map;
		}
		update_option( 'jsms_settings', $s );
	}

	/**
	 * سربرگ برندشده مشترک همه صفحه‌ها.
	 */
	private function hero( $title, $subtitle = '', $extra_html = '' ) {
		?>
		<div class="jsms-hero">
			<div class="jsms-hero-brand">
				<div class="jsms-monogram"><img src="<?php echo esc_url( JSMS_URL . 'admin/assets/rounaq-icon.png' ); ?>" alt="رونق"></div>
				<div class="jsms-hero-text">
					<div class="jsms-eyebrow">رونق · نسخه <?php echo esc_html( JSMS_VERSION ); ?></div>
					<h1><?php echo esc_html( $title ); ?></h1>
					<?php if ( $subtitle ) : ?><p><?php echo esc_html( $subtitle ); ?></p><?php endif; ?>
				</div>
			</div>
			<?php if ( $extra_html ) : ?><div class="jsms-hero-aside"><?php echo $extra_html; // phpcs:ignore ?></div><?php endif; ?>
		</div>
		<?php
		$this->render_tabs();
	}

	/**
	 * نوار تب یکپارچه بین همهٔ صفحات افزونه (داشبورد/اتوماسیون‌ها/کمپین‌ها/...).
	 */
	private function render_tabs() {
		$current = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : 'jsms';
		$pending = $this->pending_reviews_count();
		$tabs = array(
			'jsms'             => 'داشبورد',
			'jsms-help'        => '📘 راهنما',
			'jsms-automations' => 'اتوماسیون‌ها',
			'jsms-campaigns'   => 'کمپین‌ها',
			'jsms-club'        => 'باشگاه مشتریان',
			'jsms-reviews'     => 'نظرات مشتریان' . ( $pending ? ' <span class="jsms-tab-badge">' . (int) $pending . '</span>' : '' ),
			'jsms-surveys'     => 'نظرسنجی',
			'jsms-coupons'     => 'کدهای تخفیف',
			'jsms-reports'     => 'گزارش‌ها',
			'jsms-logs'        => 'گزارش ارسال‌ها',
			'jsms-settings'    => 'تنظیمات اتصال',
		);
		echo '<nav class="jsms-tabs">';
		foreach ( $tabs as $slug => $label ) {
			printf(
				'<a class="jsms-tab%s" href="%s">%s</a>',
				$slug === $current ? ' is-active' : '',
				esc_url( admin_url( 'admin.php?page=' . $slug ) ),
				wp_kses( $label, array( 'span' => array( 'class' => array() ) ) )
			);
		}
		echo '</nav>';
	}

	/* ---------------------------------------------------------------------
	 * صفحه داشبورد
	 * ------------------------------------------------------------------- */
	public function page_dashboard() {
		global $wpdb;
		$t = JSMS_DB::logs_table();
		$today_sent   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE status='sent' AND created_at>=%s", date( 'Y-m-d 00:00:00' ) ) );
		$today_failed = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE status='failed' AND created_at>=%s", date( 'Y-m-d 00:00:00' ) ) );
		$pending_reviews = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . JSMS_DB::reviews_table() . " WHERE status='pending'" );
		$credit  = get_option( 'jsms_last_credit', null );
		$by_type = $wpdb->get_results( "SELECT type, COUNT(*) c FROM {$t} WHERE status='sent' GROUP BY type ORDER BY c DESC", ARRAY_A );
		$labels  = self::type_labels();

		// شش کارت کلیدیِ کسب‌وکار — همان چیزی که واقعاً به این سؤال جواب می‌دهد: «این ماه
		// چقدر واقعاً فروش/بازگشت داشتیم»، نه فقط «چند پیامک رفت».
		$attr     = JSMS_Reports::attribution( 30 );
		$cart_rev = ( $attr['abandoned_cart']['revenue'] ?? 0 ) + ( $attr['abandoned_cart_2']['revenue'] ?? 0 );
		$cf       = JSMS_Reports::cart_funnel();
		$cart_rate = $cf['stage1_sent'] ? round( $cf['stage1_recovered'] / $cf['stage1_sent'] * 100, 1 ) : 0;
		$rf       = JSMS_Reports::review_funnel();
		$camp     = JSMS_Reports::campaign_stats( 30 );
		$wallet   = JSMS_Reports::wallet_stats( 30 );
		?>
		<div class="wrap jsms-wrap is-wide">
			<?php
			$credit_html = '<div class="jsms-credit-chip"><span class="jsms-credit-label">اعتبار پنل</span><span class="jsms-credit-val" id="jsms-credit">' . ( null !== $credit ? number_format( (float) $credit ) : '—' ) . '</span><a href="#" id="jsms-refresh-credit" title="به‌روزرسانی">↻</a></div>';
			$this->hero( 'داشبورد', 'نمای کلی فروش', $credit_html );
			?>

			<div class="jsms-cards jsms-cards-6">
				<div class="jsms-card">
					<span class="jsms-ic ic-green"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 6h16v12H4z" stroke-linejoin="round"/><path d="m5 7 7 5 7-5" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
					<div><span class="n"><?php echo number_format( $cart_rev ); ?></span><span class="l">تومان درآمدِ بازیابی‌شده (۳۰ روز)</span></div>
				</div>
				<div class="jsms-card">
					<span class="jsms-ic ic-blue"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 3h2l2.4 12.4a2 2 0 0 0 2 1.6h8.2a2 2 0 0 0 2-1.6L21 8H6" stroke-linecap="round" stroke-linejoin="round"/><circle cx="9" cy="20" r="1"/><circle cx="18" cy="20" r="1"/></svg></span>
					<div><span class="n"><?php echo number_format( $cf['stage1_recovered'] ); ?></span><span class="l">سبد بازیابی‌شده (<?php echo $cart_rate; ?>٪ از <?php echo number_format( $cf['stage1_sent'] ); ?> ارسال)</span></div>
				</div>
				<div class="jsms-card warn">
					<span class="jsms-ic ic-gold"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m12 3 2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9 6.8 19.2l1-5.8L3.5 9.2l5.9-.9z" stroke-linejoin="round"/></svg></span>
					<div><span class="n"><?php echo number_format( $rf['responded'] ); ?> / <?php echo number_format( $rf['requested'] ); ?></span><span class="l">درخواست نظر: ثبت‌شده / ارسال‌شده<?php echo $pending_reviews ? ' (' . number_format( $pending_reviews ) . ' در انتظار تأیید)' : ''; ?></span></div>
				</div>
				<div class="jsms-card<?php echo $today_failed ? ' danger' : ''; ?>">
					<span class="jsms-ic ic-red"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3v9l6 3" stroke-linecap="round" stroke-linejoin="round"/><circle cx="12" cy="12" r="9"/></svg></span>
					<div><span class="n"><?php echo number_format( $today_sent ); ?></span><span class="l">پیامک امروز — موفق (<?php echo number_format( $today_failed ); ?> ناموفق)</span></div>
				</div>
				<div class="jsms-card">
					<span class="jsms-ic ic-purple"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 11l18-7-7 18-3-8-8-3z" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
					<div><span class="n"><?php echo number_format( $camp['sent'] ?? 0 ); ?></span><span class="l">ارسال کمپین (۳۰ روز) — <?php echo number_format( $camp['revenue'] ?? 0 ); ?> تومان منتسب</span></div>
				</div>
				<div class="jsms-card">
					<span class="jsms-ic ic-amber"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2" y="6" width="20" height="13" rx="2"/><path d="M2 10h20M6 15h4" stroke-linecap="round"/></svg></span>
					<div><span class="n"><?php echo number_format( $wallet['outstanding'] ); ?></span><span class="l">تومان مانده در کیف پول مشتریان (اعطا: <?php echo number_format( $wallet['credited'] ); ?> / برداشت: <?php echo number_format( $wallet['redeemed'] ); ?> در ۳۰ روز)</span></div>
				</div>
			</div>

			<div class="jsms-grid-2">
				<section class="jsms-panel">
					<h2 class="jsms-eyebrow-h">ارسال به تفکیک نوع</h2>
					<table class="jsms-table">
						<thead><tr><th>نوع پیام</th><th>تعداد</th></tr></thead>
						<tbody>
						<?php foreach ( $by_type as $r ) : ?>
							<tr><td><?php echo esc_html( $labels[ $r['type'] ] ?? $r['type'] ); ?></td><td class="num"><?php echo number_format( $r['c'] ); ?></td></tr>
						<?php endforeach; ?>
						<?php if ( empty( $by_type ) ) : ?><tr><td colspan="2" class="jsms-empty">هنوز پیامی ارسال نشده. اولین پیام آزمایشی را از پنل کناری بفرستید.</td></tr><?php endif; ?>
						</tbody>
					</table>
				</section>

				<section class="jsms-panel">
					<h2 class="jsms-eyebrow-h">ارسال آزمایشی</h2>
					<p class="jsms-muted">یک پیام تست بفرستید تا از صحت اتصال به پنل پیامکی مطمئن شوید.</p>
					<div class="jsms-test-row">
						<input type="text" id="jsms-test-mobile" placeholder="09xxxxxxxxx" class="jsms-input" inputmode="numeric">
						<button class="jsms-btn jsms-btn-primary" id="jsms-test-send">ارسال تست</button>
					</div>
					<div id="jsms-test-result" class="jsms-test-result"></div>
				</section>
			</div>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * صفحهٔ راهنما
	 * ------------------------------------------------------------------- */
	public function page_help() {
		$faq = array(
			array(
				'q' => 'شروع سریع — چه کارهایی باید انجام بدم؟',
				'a' => '۱) به «تنظیمات اتصال» بروید و پنل پیامکی خودتان را انتخاب کنید (ملی‌پیامک، کاوه‌نگار، قاصدک یا آی‌پی‌پنل) و اطلاعات اتصال (کلید API یا نام‌کاربری/رمز) را وارد کنید.<br>۲) شمارهٔ «خط ارسال» را وارد کنید (بخش بعدی همین راهنما توضیح می‌دهد کدام خط را انتخاب کنید).<br>۳) دکمهٔ «تست ارسال» را بزنید تا مطمئن شوید اتصال درست است.<br>۴) به «اتوماسیون‌ها» بروید و هرکدام از پیام‌های خودکار (سبد رها شده، مشتری غیرفعال و…) را که می‌خواهید فعال و متنشان را شخصی‌سازی کنید.',
			),
			array(
				'q' => 'خط ارسال چیست؟ کدام نوع را باید انتخاب کنم؟',
				'a' => 'خطوط پیامکی در ایران دو نوع اصلی دارند و فرقشان خیلی مهم است:<br><br>
					<b>خط عادی / غیرخدماتی (تبلیغاتی):</b> برای «متن آزاد» مناسب است — هر متنی از جمله لینک هم می‌توانید بفرستید. اما ممکن است پیامک‌های تبلیغاتی/انبوهش با تأخیر برسد یا به شماره‌های در «لیست سیاه مخابرات» (کسانی که پیامک تبلیغاتی را قبلاً لغو کرده‌اند) اصلاً نرسد.<br><br>
					<b>خط خدماتی:</b> برای پیام‌های تراکنشی (کد تأیید، وضعیت سفارش و…) است و به لیست سیاه هم می‌رسد؛ ولی خودش دو حالت دارد:<br>
					• <b>خدماتی اشتراکی</b> (چند کسب‌وکار یک خط را با هم استفاده می‌کنند): فقط اجازهٔ ارسال «پترن» (قالب از پیش تأییدشده توسط اپراتور) را دارید — <b>نمی‌توانید لینک در متن بفرستید</b> (مثلاً لینک بازیابی سبد خرید یا لینک ثبت نظر کار نخواهد کرد).<br>
					• <b>خدماتی اختصاصی</b> (فقط مال شماست): هم پترن و هم در بسیاری از پنل‌ها متن آزاد (شامل لینک) را پشتیبانی می‌کند.<br><br>
					<b>جمع‌بندی عملی:</b> اگر می‌خواهید همهٔ قابلیت‌های این افزونه (از جمله پیامک‌هایی که لینک دارند، مثل یادآوری سبد رها شده یا لینک ثبت نظر) درست کار کنند، به یک <b>خط خدماتی اختصاصی</b> یا یک <b>خط عادی/غیرخدماتی</b> نیاز دارید — نه خط خدماتی اشتراکی.',
			),
			array(
				'q' => 'متن آزاد و پترن چه فرقی دارند؟',
				'a' => '«متن آزاد» یعنی شما هر متنی (با متغیرهایی مثل نام مشتری) می‌نویسید و همان عیناً ارسال می‌شود — روی خط عادی یا خدماتی اختصاصی کار می‌کند.<br>«پترن» (یا «قالب») یعنی یک متن ثابت را از قبل در پنل پیامکی‌تان ثبت و توسط اپراتور تأیید می‌کنید (مثلاً: «{۱} عزیز، کد تأیید شما {۲} است.») و فقط جای‌خالی‌ها (نام، کد و…) را در هر ارسال پر می‌کنید. پترن روی خط خدماتی (اشتراکی یا اختصاصی) کار می‌کند و برخلاف متن آزاد، معمولاً امکان ارسال لینک در آن نیست.',
			),
			array(
				'q' => 'فقط خط خدماتی اشتراکی دارم — کدام قابلیت‌های رونق برایم کار می‌کند؟',
				'a' => 'خبر خوب: با خط خدماتی اشتراکی نمی‌توانید لینک بفرستید، ولی بیشتر پیام‌های رونق را می‌توانید با «پترن» (بدون لینک) کار بیندازید — کافی است بالای هرکدام از این‌ها، «نوع پیام» را روی «پترن» بگذارید و شناسهٔ پترنی (bodyId) را که در پنل پیامکی‌تان ساخته‌اید وارد کنید:<br>
					✅ خوش‌آمدگویی<br>
					✅ سبد خرید رها شده (مرحلهٔ ۱ — فقط بدون لینک بازگشت به سبد؛ مثلاً پترنی مثل «{۱} عزیز، سبد خریدتان منتظر است»)<br>
					✅ مشتریان غیرفعال<br>
					✅ درخواست نظر (بدون لینک ثبت نظر — فقط یک یادآوری محترمانه)<br>
					✅ کد پیگیری مرسوله (نام، شماره سفارش، کد رهگیری)<br><br>
					این‌ها فعلاً گزینهٔ پترن ندارند و با خط اشتراکی ارسال نمی‌شوند: نظرسنجی خودکار، کارت‌به‌کارت، یادآوری دوم پرداخت، اعلان تغییر وضعیت سفارش، اعلان‌های مدیر. برای این‌ها به یک خط عادی/غیرخدماتی یا خدماتیِ اختصاصی نیاز دارید.<br><br>
					💡 نکتهٔ مهم: ترتیب پارامترهایی که رونق می‌فرستد باید دقیقاً همان ترتیبی باشد که موقع ساخت پترن در پنل پیامکی‌تان تعریف کرده‌اید — کنار هر فیلد «شناسه پترن» توضیح داده کدام پارامتر در کدام جایگاه می‌رود.',
			),
			array(
				'q' => 'از کجا برای هر پنل، کلید API یا نام‌کاربری بگیرم؟',
				'a' => '<b>ملی‌پیامک:</b> در پنل کاربری خودتان (melipayamak.com) — یا از بخش «وب‌سرویس» نام‌کاربری/رمز کلاسیک، یا از console.melipayamak.com کلید API بگیرید.<br>
					<b>کاوه‌نگار:</b> در پنل کاوه‌نگار (kavenegar.com) از منوی «تنظیمات API» کلید API را کپی کنید.<br>
					<b>قاصدک:</b> در پنل قاصدک (ghasedak.me) از بخش «تنظیمات» یا «API» کلید را بردارید.<br>
					<b>آی‌پی‌پنل:</b> در پنل آی‌پی‌پنل (ippanel.com) از بخش «REST API» توکن دسترسی بگیرید.<br>
					<b>sms.ir:</b> در پنل sms.ir از بخش «وب‌سرویس» کلید API را بردارید.<br>
					در هر حالت، شمارهٔ خط ارسالتان هم از همان پنل قابل مشاهده است.',
			),
			array(
				'q' => 'هر اتوماسیون دقیقاً چه‌کاری انجام می‌دهد؟',
				'a' => '<b>خوش‌آمدگویی:</b> بلافاصله پس از ثبت‌نام مشتری.<br>
					<b>سبد خرید رها شده:</b> اگر مشتری کالایی به سبد اضافه کند ولی خرید را کامل نکند (یا سفارشی بسازد ولی پرداخت نکند)، بعد از مدت مشخص یادآوری می‌رود؛ اگر بعد از آن هم خرید نکند، مرحلهٔ دوم (معمولاً با کد تخفیف) ارسال می‌شود.<br>
					<b>یادآوری دوم پرداخت:</b> مخصوص سفارش‌هایی که ساخته شده‌اند ولی هنوز پرداخت نشده‌اند — قبل از لغو خودکار سفارش، یک یادآوری آخر با لینک پرداخت همان سفارش می‌رود.<br>
					<b>مشتریان غیرفعال:</b> کسانی که مدتی (قابل‌تنظیم) خرید نکرده‌اند را با یک پیام بازگشت (معمولاً با کد تخفیف) صدا می‌زند.<br>
					<b>درخواست نظر:</b> چند روز بعد از تحویل سفارش، لینک ثبت نظر می‌رود؛ نظر پس از تأیید شما زیر همان محصول منتشر می‌شود.<br>
					<b>کارت‌به‌کارت:</b> برای سفارش‌هایی که با کارت‌به‌کارت پرداخت می‌شوند — پیامک «در انتظار پرداخت»، اطلاع به مدیر وقتی رسید ثبت شد، و لغو خودکار اگر رسیدی ثبت نشود.<br>
					<b>اعلان‌های مدیر:</b> سفارش جدید، کمبود موجودی و رسید کارت‌به‌کارت — به شمارهٔ «موبایل مدیر» در تنظیمات اتصال.',
			),
			array(
				'q' => 'نظرسنجی چطور کار می‌کند؟',
				'a' => 'از تب «نظرسنجی» یک نظرسنجی تازه بسازید: عنوان، متن خوش‌آمد، لوگو (اختیاری) و متن پیامک دعوت را وارد کنید، بعد سوال اضافه کنید — هر سوال می‌تواند «امتیازی» (۱ تا ۵)، «چندگزینه‌ای تک‌پاسخ»، «چندگزینه‌ای چندپاسخ» یا «متنی آزاد» باشد.<br><br>
					بعد از ساخت سوال‌ها، وضعیت را «فعال» کنید. حالا می‌توانید لینک را دستی برای یک شماره تست بفرستید (پایین همان صفحهٔ ویرایش)، یا در «اتوماسیون‌ها ← نظرسنجی خودکار» فعالش کنید تا چند روز بعد از یک وضعیت سفارش (مثلاً «تکمیل‌شده») خودکار برای مشتریان ارسال شود.<br><br>
					صفحهٔ پاسخ‌دهی کاملاً مستقل از قالب سایت است (دقیقاً مثل صفحهٔ ثبت نظر) — یعنی روی هر پوستهٔ ووکامرسی‌ای که نصب باشد، بدون هیچ تنظیم اضافه‌ای کار می‌کند. پاسخ‌های مشتریان از تب «نظرسنجی ← نتایج» — هم خلاصهٔ آماری هر سوال و هم پاسخ تک‌تک افراد — قابل مشاهده است.<br><br>
					⚠️ <b>این کار حتماً به خط خدماتیِ اختصاصی نیاز دارد</b> — چون لینک نظرسنجی ({survey_url}) در متن پیامک است، از خط خدماتی اشتراکی اصلاً ارسال نمی‌شود (به سؤال «خط ارسال چیست» بالا مراجعه کنید). اگر خط اختصاصی ندارید، خط خدماتیِ اختصاصیِ شاتل را می‌توانید با داشتن نماد اعتماد الکترونیکی (اینماد) سایتتان تهیه کنید.',
			),
			array(
				'q' => 'کدهای تخفیف دستی (تب «کدهای تخفیف») چه فرقی با کد {coupon} خودکار دارند؟',
				'a' => 'متغیر <code>{coupon}</code> در متن پیامک‌ها همیشه به‌صورت خودکار یک کد یک‌بارمصرفِ مخصوصِ همان گیرنده می‌سازد. تب «کدهای تخفیف» برایتان یک ابزار دستی است تا خودتان یک کد بسازید — یا «اختصاصی» (یک‌بار مصرف، یا محدود به تعداد مشخص، حتی می‌توانید مخصوص یک ایمیل کنید)، یا «عمومی» (یک کد ثابت که همهٔ مشتریان می‌توانند هرکدام یک‌بار استفاده کنند — مثلاً برای یک مناسبت یا کمپین)، و با تاریخ انقضای دلخواه. این کدها کاملاً کوپن واقعی ووکامرس هستند و در ووکامرس ← کدهای تخفیف هم دیده می‌شوند.',
			),
			array(
				'q' => 'پیامک ارسال نمی‌شود یا به مشتری نمی‌رسد — چه چیزهایی را چک کنم؟',
				'a' => '۱) توی «گزارش ارسال‌ها» همان پیام را پیدا کنید — ستون «پاسخ سامانه» دقیقاً می‌گوید پنل پیامکی چه جوابی داده (مثلاً اعتبار ناکافی، خط نامعتبر و…).<br>
					۲) اعتبار پنل پیامکی‌تان را در «تنظیمات اتصال» یا خودِ پنل چک کنید.<br>
					۳) اگر پیام حاوی لینک است ولی از خط خدماتی اشتراکی می‌فرستید، ارسال لینک مسدود می‌شود (به سؤال «خط ارسال چیست» بالا مراجعه کنید).<br>
					۴) اگر وضعیت «ارسال شد» است ولی مشتری چیزی نگرفته، معمولاً یعنی پنل پیامکی پیام را قبول کرده ولی اپراتور (همراه‌اول/ایرانسل) بنا به دلایلی (بلک‌لیست، فیلتر محتوا) تحویل نداده — این را باید از گزارش تحویل خودِ پنل پیامکی پیگیری کنید، چون خارج از کنترل این افزونه است.',
			),
			array(
				'q' => 'آپدیت خودکار چطور کار می‌کند؟',
				'a' => 'اگر «آدرس manifest» را در «تنظیمات اتصال ← به‌روزرسانی» وارد کرده باشید، افزونه هر ۱۲ ساعت یک‌بار خودکار چک می‌کند نسخهٔ جدیدتری منتشر شده یا نه. اگر بله، دقیقاً مثل هر افزونهٔ دیگری، توی صفحهٔ «افزونه‌ها» یک اعلان به‌روزرسانی می‌بینید و با یک کلیک نصب می‌شود — نیازی به دانلود دستی یا فایل‌منیجر نیست.',
			),
		);
		?>
		<div class="wrap jsms-wrap is-wide">
			<?php $this->hero( "راهنما", "راهنمای نصب و استفاده از رونق" ); ?>
			<div class="jsms-faq">
				<?php foreach ( $faq as $item ) : ?>
					<details class="jsms-faq-item">
						<summary><?php echo esc_html( $item['q'] ); ?></summary>
						<div class="jsms-faq-a"><?php echo wp_kses_post( $item['a'] ); ?></div>
					</details>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * صفحه تنظیمات اتصال
	 * ------------------------------------------------------------------- */
	public function page_settings() {
		$s = get_option( 'jsms_settings', JSMS_Settings_Defaults() );
		?>
		<div class="wrap jsms-wrap is-wide">
			<?php $this->hero( "تنظیمات اتصال", "اتصال به پنل پیامکی، کد تخفیف پویا و ساعات سکوت" ); ?>
			<form method="post">
				<?php wp_nonce_field( 'jsms_save', '_jsms' ); ?>
				<input type="hidden" name="jsms_scope" value="settings">
				<div class="jsms-panel jsms-connection-panel" style="margin-bottom:20px">
					<div class="jsms-connection-head">
						<div>
							<span class="jsms-connection-kicker">اتصال پیامک</span>
							<h2 class="jsms-eyebrow-h">📡 وب‌سرویس پیامکی</h2>
							<p class="jsms-muted">رونق از ساختار Gateway افزونه مرجع استفاده می‌کند و بیش از ۱۱۰ پنل را با یک فرم استاندارد پوشش می‌دهد. برای پنل‌های Token، کلید دسترسی را در فیلد «نام کاربری / API Key» قرار دهید.</p>
						</div>
						<div class="jsms-gateway-count"><strong><?php echo esc_html( count( JSMS_Gateway::drivers() ) ); ?></strong><span>پنل قابل انتخاب</span></div>
					</div>
					<div class="jsms-gateway-select-wrap">
						<label for="jsms-provider-select">پنل پیامکی</label>
						<select name="provider" id="jsms-provider-select" class="jsms-gateway-select">
							<?php foreach ( JSMS_Gateway::provider_labels() as $pid => $plabel ) : ?>
								<option value="<?php echo esc_attr( $pid ); ?>" <?php selected( $s['provider'] ?? 'melipayamak', $pid ); ?>><?php echo esc_html( $plabel ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description">برای ملی پیامک، گزینه «ملی پیامک خدماتی» را برای ارسال Pattern/Body ID انتخاب کنید.</p>
					</div>

					<div class="jsms-active-gateway-note" id="jsms-active-gateway-note"></div>
					<table class="form-table jsms-connection-fields">
						<tr><th><label for="jsms-username">نام کاربری / API Key</label></th><td><input id="jsms-username" type="text" name="username" value="<?php echo esc_attr( $s['username'] ?? '' ); ?>" class="regular-text" dir="ltr" autocomplete="off"><p class="description">نام کاربری یا Token/API Key پنل را وارد کنید؛ بسته به پنل، یکی از این دو مورد استفاده می‌شود.</p></td></tr>
						<tr><th><label for="jsms-password">کلمه عبور / رمز وب‌سرویس</label></th><td><span class="jsms-password-field"><input id="jsms-password" type="password" name="password" value="<?php echo esc_attr( $s['password'] ?? '' ); ?>" class="regular-text" dir="ltr" autocomplete="new-password"><button type="button" class="jsms-password-toggle" data-target="jsms-password" aria-label="نمایش رمز">نمایش</button></span><p class="description">اگر پنل شما فقط API Key یا Token دارد، این فیلد را خالی بگذارید.</p></td></tr>
						<tr><th><label for="jsms-line-number">شماره ارسال‌کننده پیامک</label></th><td><input id="jsms-line-number" type="text" name="line_number" value="<?php echo esc_attr( $s['line_number'] ?? '' ); ?>" class="regular-text" dir="ltr"><p class="description">برای پنل‌هایی که شماره فرستنده لازم دارند وارد شود. در پنل‌های Pattern ممکن است استفاده نشود.</p></td></tr>
					</table>

					<div class="jsms-test-row jsms-connection-test-box">
						<input class="jsms-input" id="jsms-test-mobile" type="text" placeholder="شماره موبایل برای تست، مثال: 0912xxxxxxx" dir="ltr">
						<button type="button" class="jsms-btn jsms-btn-primary" id="jsms-test-send">ارسال پیامک تست</button>
						<span class="jsms-test-badge">تست واقعی ارسال</span>
					</div>
					<div id="jsms-test-result" class="jsms-test-result"></div>
					<p class="jsms-varhint">💡 برای <b>ملی پیامک خدماتی</b> از حالت Pattern در اتوماسیون استفاده کنید و Body ID قالب تأییدشده را وارد کنید. ارسال متن آزاد از خط خدماتی اشتراکی مجاز نیست.</p>
				</div>

				<table class="form-table">
					<tr><th>شماره موبایل مدیر</th><td><input type="text" name="admin_mobile" value="<?php echo esc_attr( $s['admin_mobile'] ); ?>" class="regular-text"><p class="description">برای دریافت هشدار کاهش اعتبار، سفارش جدید و کمبود موجودی (در «اتوماسیون‌ها ← اعلان‌های مدیر» فعال می‌شوند).</p></td></tr>
					<tr><th>آستانه هشدار اعتبار</th><td><input type="number" name="low_credit_threshold" value="<?php echo esc_attr( $s['low_credit_threshold'] ); ?>"></td></tr>
					<tr><th>ساعات سکوت</th><td>
						<label><input type="checkbox" name="quiet_hours" <?php checked( $s['quiet_hours'], 1 ); ?>> فعال</label>
						از ساعت <input type="number" name="quiet_start" min="0" max="23" value="<?php echo esc_attr( $s['quiet_start'] ); ?>" style="width:70px">
						تا <input type="number" name="quiet_end" min="0" max="23" value="<?php echo esc_attr( $s['quiet_end'] ); ?>" style="width:70px">
						<p class="description">پیام‌های تبلیغاتی در این بازه ارسال نمی‌شوند (پیام‌های سفارش و خوش‌آمد مستثنا هستند).</p>
					</td></tr>
					<tr><th>احترام به لغو اشتراک</th><td>
						<label><input type="checkbox" name="respect_optout" <?php checked( $s['respect_optout'], 1 ); ?>> شماره‌هایی که لغو کرده‌اند پیام‌های <b>تبلیغاتی</b> نگیرند</label><br>
						<label><input type="checkbox" name="block_transactional_for_optout" <?php checked( $s['block_transactional_for_optout'], 1 ); ?>> لغوِ اشتراک، پیام‌های <b>تراکنشی</b> (وضعیت سفارش، پرداخت، رهگیری، اعلان‌های مدیر) را هم مسدود کند</label>
						<p class="description">پیش‌فرض خاموش است — مشتری‌ای که تبلیغات را لغو کرده، همچنان باید از وضعیت سفارش خودش باخبر شود.</p>
					</td></tr>
					<tr><th>نگهداریِ لاگ‌ها</th><td>
						<input type="number" name="log_retention_days" min="0" value="<?php echo esc_attr( $s['log_retention_days'] ); ?>" style="width:90px"> روز
						<p class="description">لاگ ارسال و شورت‌لینک‌های قدیمی‌تر از این تعداد روز، هر شب خودکار پاک می‌شوند تا دیتابیس روی فروشگاه‌های پرترافیک سنگین نشود. ۰ = هرگز پاک نشود.</p>
					</td></tr>
				</table>

				<h2>🎁 کد تخفیف پویا</h2>
				<p class="description">هر پیام متنی که شامل <code>{coupon}</code> باشد، یک کد تخفیف یکتای ووکامرس برای همان مشتری می‌سازد (یک‌بار مصرف، مخصوص همان ایمیل، با انقضا).</p>
				<table class="form-table">
					<tr><th>نوع تخفیف</th><td>
						<select name="coupon_type">
							<option value="percent" <?php selected( $s['coupon_type'], 'percent' ); ?>>درصدی</option>
							<option value="fixed_cart" <?php selected( $s['coupon_type'], 'fixed_cart' ); ?>>مبلغ ثابت (تومان)</option>
						</select>
					</td></tr>
					<tr><th>مقدار تخفیف</th><td><input type="number" name="coupon_amount" value="<?php echo esc_attr( $s['coupon_amount'] ); ?>" style="width:100px"></td></tr>
					<tr><th>انقضا (روز)</th><td><input type="number" name="coupon_expiry_days" value="<?php echo esc_attr( $s['coupon_expiry_days'] ); ?>" style="width:80px"><p class="description">۰ = بدون انقضا. عدد کوچک حس فوریت ایجاد می‌کند.</p></td></tr>
					<tr><th>پیشوند کد</th><td><input type="text" name="coupon_prefix" value="<?php echo esc_attr( $s['coupon_prefix'] ); ?>" style="width:100px" placeholder="JL"></td></tr>
				</table>

				<h2>📮 ای‌بازار پست (شرکت ملی پست)</h2>
				<p class="description">ثبت مرسوله برای هر سفارش و پیگیری خودکار وضعیت آن. حساب کاربری باید دسترسی وب‌سرویس (RestApi) فعال داشته باشد.</p>
				<table class="form-table">
					<tr><th>یوزرنیم</th><td><input type="text" name="ebazar_username" value="<?php echo esc_attr( $s['ebazar_username'] ); ?>" class="regular-text" dir="ltr"></td></tr>
					<tr><th>پسورد</th><td><span class="jsms-password-field"><input id="jsms-ebazar-password" type="password" name="ebazar_password" value="<?php echo esc_attr( $s['ebazar_password'] ); ?>" class="regular-text" dir="ltr" autocomplete="new-password"><button type="button" class="jsms-password-toggle" data-target="jsms-ebazar-password" aria-label="نمایش رمز">نمایش</button></span></td></tr>
					<tr><th>شناسهٔ سایز جعبه</th><td><input type="number" name="ebazar_box_size_id" value="<?php echo esc_attr( $s['ebazar_box_size_id'] ); ?>" style="width:80px"><p class="description">پیش‌فرض ۵. لیست دقیق سایزها بعد از تست اتصال قابل مشاهده است.</p></td></tr>
					<tr><th>پیگیری خودکار وضعیت</th><td><label><input type="checkbox" name="ebazar_tracking_enabled" <?php checked( $s['ebazar_tracking_enabled'], 1 ); ?>> هر ۱۵ دقیقه وضعیت مرسولات فعال را استعلام بگیر</label></td></tr>
					<tr><th>پیامک تغییر وضعیت</th><td><label><input type="checkbox" name="ebazar_tracking_sms_enabled" <?php checked( $s['ebazar_tracking_sms_enabled'], 1 ); ?>> با هر تغییر وضعیت، به مشتری پیامک برود</label></td></tr>
					<tr class="jsms-text-row"><th>متن پیامک وضعیت</th><td>
						<textarea name="ebazar_status_text" rows="3" class="large-text"><?php echo esc_textarea( $s['ebazar_status_text'] ); ?></textarea>
						<p class="description">متغیرها: {ebazar_status} {ebazar_parcel_code} به‌علاوهٔ متغیرهای عمومی سفارش.</p>
					</td></tr>
				</table>
				<p>
					<button type="button" class="button" id="jsms-ebazar-test">تست اتصال ای‌بازار پست</button>
					<span id="jsms-ebazar-test-result" style="margin-inline-start:10px"></span>
				</p>

				<h2>🔄 به‌روزرسانی خودکار</h2>
				<p class="description">آدرسِ بررسیِ نسخهٔ جدید از قبل تنظیم شده — نیازی به هیچ کاری نیست. از این پس، هروقت نسخهٔ تازه‌ای منتشر شود، دقیقاً مثل هر افزونهٔ دیگری از همان صفحهٔ «افزونه‌ها» با یک کلیک به‌روزرسانی می‌شود (بدون فایل‌منیجر، بدون نصب دستی).</p>
				<table class="form-table">
					<tr><th>آدرس manifest بروزرسانی</th><td>
						<input type="text" name="update_manifest_url" value="<?php echo esc_attr( $s['update_manifest_url'] ?? '' ); ?>" class="regular-text" dir="ltr" placeholder="https://example.com/rounaq/manifest.json">
						<p class="description">فقط برای توسعه‌دهنده/فروشنده: اگر این افزونه را با برند/سرور دیگری منتشر می‌کنید، این آدرس را به manifest خودتان تغییر دهید.</p>
					</td></tr>
				</table>
				<p>
					<button type="button" class="button" id="jsms-check-update">بررسی الان</button>
					<span id="jsms-check-update-result" style="margin-inline-start:10px"></span>
				</p>

				<p><button class="button button-primary" name="jsms_save" value="1">ذخیره تنظیمات</button></p>
			</form>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * صفحه اتوماسیون‌ها
	 * ------------------------------------------------------------------- */
	public function page_automations() {
		$s = get_option( 'jsms_settings', JSMS_Settings_Defaults() );
		$vars_hint = 'متغیرهای قابل استفاده: ' . implode( '  ', array_map( static function ( $v ) { return $v['code']; }, $this->automation_shortcodes() ) );
		?>
		<div class="wrap jsms-wrap is-wide">
			<?php $this->hero( "اتوماسیون‌ها", "پیام‌های خودکار: خوش‌آمد، سفارش، سبد رها شده، مشتری غیرفعال و نظرات" ); ?>
			<p class="jsms-varhint"><?php echo esc_html( $vars_hint ); ?></p>
			<form method="post">
				<?php wp_nonce_field( 'jsms_save', '_jsms' ); ?>
				<input type="hidden" name="jsms_scope" value="automations">

				<?php
				$this->automation_box( 'welcome', '👋 خوش‌آمدگویی', 'پس از ثبت‌نام مشتری ارسال می‌شود.', $s );
				$this->tracking_box( $s );
				$this->automation_box( 'cart', '🛒 سبد خرید رها شده', 'اگر مشتری خرید را تکمیل نکند، بعد از مدت مشخص پیام می‌رود.', $s, false, 'cart' );
				$this->automation_box( 'inactive', '💤 مشتریان غیرفعال', 'به کسانی که مدتی خرید نکرده‌اند پیام می‌رود.', $s, false, 'inactive' );
				$this->automation_box( 'review', '⭐ درخواست نظر', 'چند روز بعد از تحویل، لینک ثبت نظر ارسال می‌شود؛ نظر پس از تأیید شما زیر محصول قرار می‌گیرد.', $s, false, 'review' );
				?>

				<div class="jsms-auto-box">
					<h2>🗳 نظرسنجی خودکار</h2>
					<p class="description">چند روز بعد از یک وضعیت مشخصِ سفارش، لینک یکی از نظرسنجی‌های شما خودکار پیامک می‌شود. برای ساخت/ویرایش خود نظرسنجی و سوالاتش، به تب «نظرسنجی» بروید.</p>
					<label class="jsms-switch"><input type="checkbox" name="survey_auto_enabled" <?php checked( $s['survey_auto_enabled'], 1 ); ?>> فعال باشد</label>
					<table class="form-table">
						<tr><th>کدام نظرسنجی</th><td>
							<select name="survey_auto_survey_id">
								<option value="0">— انتخاب کنید —</option>
								<?php foreach ( JSMS_Surveys::get_surveys() as $sv ) : ?>
									<option value="<?php echo (int) $sv->id; ?>" <?php selected( (int) $s['survey_auto_survey_id'], $sv->id ); ?>><?php echo esc_html( $sv->title ); ?> <?php echo 'active' === $sv->status ? '' : '(پیش‌نویس)'; ?></option>
								<?php endforeach; ?>
							</select>
						</td></tr>
						<tr><th>زمان ارسال</th><td>
							<input type="number" name="survey_after_days" value="<?php echo esc_attr( $s['survey_after_days'] ); ?>" style="width:70px"> روز بعد از وضعیت
							<select name="survey_order_status">
								<?php foreach ( wc_get_order_statuses() as $key => $label ) : $k = str_replace( 'wc-', '', $key ); ?>
									<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $s['survey_order_status'], $k ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
						</td></tr>
						<tr><th>متن پیش‌فرض دعوت</th><td>
							<textarea id="jsms-survey_default_text" name="survey_default_text" rows="3" class="large-text"><?php echo esc_textarea( $s['survey_default_text'] ); ?></textarea>
						<?php $this->shortcode_toolbar( 'jsms-survey_default_text' ); ?>
							<p class="description">وقتی خود نظرسنجی متن اختصاصی نداشته باشد، از همین متن استفاده می‌شود. متغیرها: {first_name} {survey_url} {site_name}</p>
						</td></tr>
					</table>
				</div>

				<div class="jsms-auto-box">
					<h2>💳 کارت‌به‌کارت (درگاه شتاب)</h2>
					<p class="description">بلافاصله بعد از ثبت سفارش با درگاه کارت‌به‌کارت (نه پرداخت آنلاین بانکی)، به مشتری پیامک «در انتظار پرداخت» می‌رود.</p>
					<label class="jsms-switch"><input type="checkbox" name="card_pending_enabled" <?php checked( $s['card_pending_enabled'], 1 ); ?>> فعال باشد</label>
					<table class="form-table"><tr><th>متن پیام</th><td>
						<textarea id="jsms-card_pending_text" name="card_pending_text" rows="3" class="large-text"><?php echo esc_textarea( $s['card_pending_text'] ); ?></textarea>
						<?php $this->shortcode_toolbar( 'jsms-card_pending_text' ); ?>
						<p class="description">متغیرها: {first_name} {order_id} {order_total} {payment_url}</p>
					</td></tr></table>
					<div style="border-top:1px dashed #ddd;margin-top:12px;padding-top:12px">
						<label class="jsms-switch"><input type="checkbox" name="pending_expiry_enabled" <?php checked( $s['pending_expiry_enabled'], 1 ); ?>> لغو خودکار سفارش‌های کارت‌به‌کارت پرداخت‌نشده</label>
						<p>اگر بعد از <input type="number" name="pending_expiry_min" value="<?php echo esc_attr( $s['pending_expiry_min'] ); ?>" style="width:80px"> دقیقه هنوز رسیدی ثبت نشده باشد (سفارش هنوز «در انتظار پرداخت» است)، خودکار لغو می‌شود و پیامک «لغو شد» (از جدول پایین) برایش می‌رود.</p>
						<p class="description">این عدد را هم‌اندازه یا کمی بیشتر از مهلت آزادسازی رزرو موجودی ووکامرس‌تان تنظیم کنید.</p>
					</div>
				</div>

				<div class="jsms-auto-box">
					<h2>⏰ یادآوری دوم پرداخت (هر درگاهی)</h2>
					<p class="description">اگر سفارش (پارسیان، زرین‌پال یا کارت‌به‌کارت) بعد از مدتی هنوز «در انتظار پرداخت» مانده باشد — درست قبل از اینکه به‌خاطر عدم پرداخت خودکار لغو شود — یک یادآوریِ گرم و مجزا با لینک پرداختِ همان سفارش می‌رود. هدف، احیای همان سفارش است، نه فقط اطلاع از لغو شدنش.</p>
					<label class="jsms-switch"><input type="checkbox" name="pending_reminder_enabled" <?php checked( $s['pending_reminder_enabled'], 1 ); ?>> فعال باشد</label>
					<p>ارسال بعد از <input type="number" name="pending_reminder_min" value="<?php echo esc_attr( $s['pending_reminder_min'] ); ?>" style="width:80px"> دقیقه از ثبت سفارش، اگر هنوز پرداخت نشده باشد.</p>
					<table class="form-table"><tr><th>متن پیام</th><td>
						<textarea id="jsms-pending_reminder_text" name="pending_reminder_text" rows="4" class="large-text"><?php echo esc_textarea( $s['pending_reminder_text'] ); ?></textarea>
						<?php $this->shortcode_toolbar( 'jsms-pending_reminder_text' ); ?>
						<p class="description">متغیرها: {first_name} {order_id} {order_total} {payment_url}</p>
					</td></tr></table>
				</div>

				<h2>📦 اعلان تغییر وضعیت سفارش</h2>
				<label><input type="checkbox" name="status_enabled" <?php checked( $s['status_enabled'], 1 ); ?>> فعال</label>
				<table class="form-table">
				<?php
				$statuses = wc_get_order_statuses();
				$map = $s['status_map'];
				foreach ( $statuses as $key => $label ) {
					$k = str_replace( 'wc-', '', $key );
					printf(
						'<tr><th>%s</th><td><textarea id="jsms-status-map-%s" name="status_map[%s]" rows="2" class="large-text" placeholder="خالی = عدم ارسال">%s</textarea>%s</td></tr>',
						esc_html( $label ), esc_attr( $k ), esc_attr( $k ), esc_textarea( $map[ $k ] ?? '' ), $this->shortcode_toolbar_html( 'jsms-status-map-' . $k )
					);
				}
				?>
				</table>

				<h2>📟 اعلان‌های مدیر</h2>
				<p class="jsms-varhint">به شمارهٔ «موبایل مدیر» (تنظیمات اتصال) ارسال می‌شود.</p>

				<div class="jsms-auto-box">
					<h2>🛎 سفارش جدید</h2>
					<p class="description">برای سفارش‌های تأییدشده (پرداخت آنلاین/COD) بلافاصله می‌رود. برای سفارش‌های در انتظار پرداخت یا در انتظار تأیید رسید کارت‌به‌کارت، تا وقتی سفارش واقعاً تأیید شود (رسید تأیید شد یا وضعیت تغییر کرد) عقب می‌افتد — نه در همان لحظهٔ ثبت اولیه.</p>
					<label class="jsms-switch"><input type="checkbox" name="admin_order_alert_enabled" <?php checked( $s['admin_order_alert_enabled'], 1 ); ?>> فعال باشد</label>
					<table class="form-table"><tr><th>متن پیام</th><td>
						<textarea id="jsms-admin_order_alert_text" name="admin_order_alert_text" rows="3" class="large-text"><?php echo esc_textarea( $s['admin_order_alert_text'] ); ?></textarea>
						<?php $this->shortcode_toolbar( 'jsms-admin_order_alert_text' ); ?>
						<p class="description">متغیرها: {order_id} {full_name} {customer_mobile} {order_total} {items}</p>
					</td></tr></table>
				</div>

				<div class="jsms-auto-box">
					<h2>🧾 رسید کارت‌به‌کارت ثبت شد</h2>
					<p class="description">وقتی مشتری در سفارش‌های کارت‌به‌کارت رسید پرداخت را ثبت می‌کند (وضعیت سفارش به «در انتظار تایید رسید» می‌رود)، به شمارهٔ مدیر پیامک می‌رود که برود بررسی و تأیید کند.</p>
					<label class="jsms-switch"><input type="checkbox" name="admin_receipt_alert_enabled" <?php checked( $s['admin_receipt_alert_enabled'], 1 ); ?>> فعال باشد</label>
					<table class="form-table"><tr><th>متن پیام</th><td>
						<textarea id="jsms-admin_receipt_alert_text" name="admin_receipt_alert_text" rows="3" class="large-text"><?php echo esc_textarea( $s['admin_receipt_alert_text'] ); ?></textarea>
						<?php $this->shortcode_toolbar( 'jsms-admin_receipt_alert_text' ); ?>
						<p class="description">متغیرها: {order_id} {full_name} {customer_mobile} {order_total}</p>
					</td></tr></table>
				</div>

				<div class="jsms-auto-box">
					<h2>⚠️ کمبود موجودی</h2>
					<p class="description">وقتی موجودی یک محصول به آستانهٔ «کم‌موجود» ووکامرس برسد، به شمارهٔ مدیر پیامک می‌رود (آستانه از ووکامرس ← تنظیمات ← موجودی قابل تغییر است).</p>
					<label class="jsms-switch"><input type="checkbox" name="admin_lowstock_enabled" <?php checked( $s['admin_lowstock_enabled'], 1 ); ?>> فعال باشد</label>
					<table class="form-table"><tr><th>متن پیام</th><td>
						<textarea id="jsms-admin_lowstock_text" name="admin_lowstock_text" rows="3" class="large-text"><?php echo esc_textarea( $s['admin_lowstock_text'] ); ?></textarea>
						<?php $this->shortcode_toolbar( 'jsms-admin_lowstock_text' ); ?>
						<p class="description">متغیرها: {product_name} {stock_qty}</p>
					</td></tr></table>
				</div>

				<p><button class="button button-primary" name="jsms_save" value="1">ذخیره همه اتوماسیون‌ها</button></p>
			</form>
		</div>
		<?php
	}

	/**
	 * جعبه تنظیمات یک اتوماسیون.
	 */

	/**
	 * فهرست کامل متغیرهای قابل استفاده در متن پیامک.
	 * کد داخل دکمه نمایش داده می‌شود و توضیح فارسی زیر آن قرار می‌گیرد.
	 */
	private function automation_shortcodes() {
		return array(
			array( 'code' => '{mobile}', 'label' => 'شماره موبایل مشتری' ),
			array( 'code' => '{phone}', 'label' => 'شماره تلفن مشتری' ),
			array( 'code' => '{email}', 'label' => 'ایمیل مشتری' ),
			array( 'code' => '{status}', 'label' => 'وضعیت سفارش' ),
			array( 'code' => '{all_items}', 'label' => 'محصولات سفارش' ),
			array( 'code' => '{all_items_full}', 'label' => 'محصولات سفارش با نام کامل و متغیرها' ),
			array( 'code' => '{all_items_qty}', 'label' => 'محصولات سفارش به‌همراه تعداد' ),
			array( 'code' => '{count_items}', 'label' => 'تعداد محصولات سفارش' ),
			array( 'code' => '{price}', 'label' => 'مبلغ سفارش' ),
			array( 'code' => '{post_id}', 'label' => 'شناسه اصلی سفارش' ),
			array( 'code' => '{order_id}', 'label' => 'شماره سفارش' ),
			array( 'code' => '{transaction_id}', 'label' => 'شماره تراکنش' ),
			array( 'code' => '{date}', 'label' => 'تاریخ سفارش' ),
			array( 'code' => '{description}', 'label' => 'توضیحات مشتری' ),
			array( 'code' => '{payment_method}', 'label' => 'روش پرداخت' ),
			array( 'code' => '{shipping_method}', 'label' => 'روش ارسال' ),
			array( 'code' => '{payment_url}', 'label' => 'لینک پرداخت' ),
			array( 'code' => '{first_name}', 'label' => 'نام مشتری' ),
			array( 'code' => '{last_name}', 'label' => 'نام خانوادگی مشتری' ),
			array( 'code' => '{full_name}', 'label' => 'نام و نام خانوادگی مشتری' ),
			array( 'code' => '{site_name}', 'label' => 'نام فروشگاه' ),
			array( 'code' => '{site_url}', 'label' => 'آدرس سایت' ),
			array( 'code' => '{order_url}', 'label' => 'لینک سفارش‌های مشتری' ),
			array( 'code' => '{product_name}', 'label' => 'نام اولین محصول سفارش' ),
			array( 'code' => '{product_url}', 'label' => 'لینک اولین محصول سفارش' ),
			array( 'code' => '{items}', 'label' => 'خلاصه محصولات سفارش' ),
			array( 'code' => '{items_count}', 'label' => 'تعداد اقلام سفارش (نام داخلی)' ),
			array( 'code' => '{tracking_code}', 'label' => 'کد رهگیری مرسوله' ),
			array( 'code' => '{customer_mobile}', 'label' => 'موبایل مشتری (نام داخلی)' ),
			array( 'code' => '{payment_method_title}', 'label' => 'عنوان روش پرداخت' ),
			array( 'code' => '{discount_total}', 'label' => 'مبلغ تخفیف سفارش' ),
			array( 'code' => '{customer_note}', 'label' => 'یادداشت مشتری (نام داخلی)' ),
			array( 'code' => '{admin_order_url}', 'label' => 'لینک مدیریت سفارش' ),
			array( 'code' => '{b_first_name}', 'label' => 'نام صورتحساب' ),
			array( 'code' => '{b_last_name}', 'label' => 'نام خانوادگی صورتحساب' ),
			array( 'code' => '{b_company}', 'label' => 'نام شرکت صورتحساب' ),
			array( 'code' => '{b_country}', 'label' => 'کشور صورتحساب' ),
			array( 'code' => '{b_state}', 'label' => 'استان صورتحساب' ),
			array( 'code' => '{b_city}', 'label' => 'شهر صورتحساب' ),
			array( 'code' => '{b_address_1}', 'label' => 'آدرس ۱ صورتحساب' ),
			array( 'code' => '{b_address_2}', 'label' => 'آدرس ۲ صورتحساب' ),
			array( 'code' => '{b_postcode}', 'label' => 'کد پستی صورتحساب' ),
			array( 'code' => '{sh_first_name}', 'label' => 'نام گیرنده حمل‌ونقل' ),
			array( 'code' => '{sh_last_name}', 'label' => 'نام خانوادگی گیرنده حمل‌ونقل' ),
			array( 'code' => '{sh_company}', 'label' => 'نام شرکت حمل‌ونقل' ),
			array( 'code' => '{sh_country}', 'label' => 'کشور حمل‌ونقل' ),
			array( 'code' => '{sh_state}', 'label' => 'استان حمل‌ونقل' ),
			array( 'code' => '{sh_city}', 'label' => 'شهر حمل‌ونقل' ),
			array( 'code' => '{sh_address_1}', 'label' => 'آدرس ۱ حمل‌ونقل' ),
			array( 'code' => '{sh_address_2}', 'label' => 'آدرس ۲ حمل‌ونقل' ),
			array( 'code' => '{sh_postcode}', 'label' => 'کد پستی حمل‌ونقل' ),
			array( 'code' => '{review_url}', 'label' => 'لینک ثبت نظر' ),
			array( 'code' => '{survey_url}', 'label' => 'لینک نظرسنجی' ),
			array( 'code' => '{cart_url}', 'label' => 'لینک سبد خرید' ),
			array( 'code' => '{recover_cart_url}', 'label' => 'لینک بازیابی سبد خرید' ),
			array( 'code' => '{cart_items}', 'label' => 'اقلام سبد رهاشده' ),
			array( 'code' => '{cart_expire_date}', 'label' => 'تاریخ انقضای سبد بازیابی' ),
			array( 'code' => '{coupon}', 'label' => 'کد تخفیف یکتا' ),
			array( 'code' => '{cashback}', 'label' => 'مبلغ بازگشت وجه کیف پول' ),
			array( 'code' => '{wallet_balance}', 'label' => 'موجودی کیف پول' ),
			array( 'code' => '{tier}', 'label' => 'سطح مشتری' ),
			array( 'code' => '{coupon_code}', 'label' => 'کد کوپن کیف پول' ),
			array( 'code' => '{redeem_amount}', 'label' => 'مبلغ برداشت از کیف پول' ),
			array( 'code' => '{stock_qty}', 'label' => 'موجودی محصول' ),
			array( 'code' => '{courier}', 'label' => 'نام شرکت حمل‌کننده' ),
		);
	}

	private function shortcode_toolbar( $target_id ) {
		echo $this->shortcode_toolbar_html( $target_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private function shortcode_toolbar_html( $target_id ) {
		$vars = $this->automation_shortcodes();
		$html  = '<details class="jsms-shortcode-accordion">';
		$html .= '<summary class="jsms-shortcode-summary">';
		$html .= '<span class="jsms-shortcode-summary-main"><span class="jsms-shortcode-summary-icon" aria-hidden="true">{ }</span>';
		$html .= '<span><strong>متغیرهای قابل استفاده</strong><small>برای درج سریع، روی متغیر موردنظر کلیک کنید</small></span></span>';
		$html .= '<span class="jsms-shortcode-summary-meta"><b>' . count( $vars ) . '</b> متغیر <span class="jsms-shortcode-chevron" aria-hidden="true">⌄</span></span>';
		$html .= '</summary>';
		$html .= '<div class="jsms-shortcode-panel">';
		$html .= '<div class="jsms-shortcode-toolbar" data-target="' . esc_attr( $target_id ) . '">';
		foreach ( $vars as $v ) {
			$html .= '<button type="button" class="jsms-shortcode-button" data-shortcode="' . esc_attr( $v['code'] ) . '" title="برای درج ' . esc_attr( $v['label'] ) . ' کلیک کنید">';
			$html .= '<span class="jsms-shortcode-code">' . esc_html( $v['code'] ) . '</span>';
			$html .= '<span class="jsms-shortcode-label">' . esc_html( $v['label'] ) . '</span>';
			$html .= '</button>';
		}
		$html .= '</div>';
		$html .= '<div class="jsms-shortcode-footnote">💡 با کلیک روی هر مورد، متغیر در محل فعلی مکان‌نما داخل کادر پیام قرار می‌گیرد.</div>';
		$html .= '</div></details>';
		return $html;
	}

	private function automation_box( $prefix, $title, $desc, $s, $simple = false, $extra = '' ) {
		$en   = $prefix . '_enabled';
		$mode = $prefix . '_mode';
		$text = $prefix . '_text';
		$pat  = $prefix . '_pattern';
		?>
		<div class="jsms-auto-box">
			<h2><?php echo esc_html( $title ); ?></h2>
			<p class="description"><?php echo esc_html( $desc ); ?></p>
			<label class="jsms-switch"><input type="checkbox" name="<?php echo $en; ?>" <?php checked( $s[ $en ], 1 ); ?>> فعال باشد</label>

			<?php if ( 'cart' === $extra ) : ?>
				<p>مرحله ۱ – ارسال یادآوری بعد از <input type="number" name="cart_delay_min" value="<?php echo esc_attr( $s['cart_delay_min'] ); ?>" style="width:80px"> دقیقه از رها شدن سبد.</p>
				<table class="form-table">
					<tr><th>نوع پیام</th><td>
						<select name="<?php echo $mode; ?>" class="jsms-mode">
							<option value="text" <?php selected( $s[ $mode ], 'text' ); ?>>متن آزاد (خط انبوه)</option>
							<option value="pattern" <?php selected( $s[ $mode ], 'pattern' ); ?>>پترن (خط خدماتی)</option>
						</select>
					</td></tr>
					<tr class="jsms-text-row"><th>متن مرحله ۱</th><td>
						<textarea id="<?php echo esc_attr( 'jsms-' . $text ); ?>" name="<?php echo $text; ?>" rows="3" class="large-text"><?php echo esc_textarea( $s[ $text ] ); ?></textarea>
						<?php $this->shortcode_toolbar( 'jsms-' . $text ); ?>
						<p class="description">💡 این پیام معمولاً شامل <code>{recover_cart_url}</code> (لینک بازگشت به سبد) است — این لینک فقط از خط عادی/غیرخدماتی یا خدماتیِ اختصاصی ارسال می‌شود؛ از خط خدماتی اشتراکی، لینک مسدود می‌شود.</p>
					</td></tr>
					<tr class="jsms-pat-row"><th>شناسه پترن (bodyId)</th><td><input type="text" name="<?php echo $pat; ?>" value="<?php echo esc_attr( $s[ $pat ] ); ?>"><p class="description">پارامترها به ترتیب: نام و سایر متغیرها.</p></td></tr>
				</table>
				<div style="border-top:1px dashed #ddd;margin-top:8px;padding-top:8px">
					<label class="jsms-switch"><input type="checkbox" name="cart_stage2_enabled" <?php checked( $s['cart_stage2_enabled'], 1 ); ?>> مرحله ۲ فعال باشد (پیام تشویقی همراه کد تخفیف)</label>
					<p>ارسال مرحله ۲ بعد از <input type="number" name="cart_delay2_min" value="<?php echo esc_attr( $s['cart_delay2_min'] ); ?>" style="width:90px"> دقیقه (۱۴۴۰ = ۲۴ ساعت) در صورت خرید نکردن.</p>
					<table class="form-table"><tr class="jsms-text-row"><th>متن مرحله ۲</th><td>
						<textarea id="jsms-cart_text_2" name="cart_text_2" rows="3" class="large-text"><?php echo esc_textarea( $s['cart_text_2'] ); ?></textarea>
						<?php $this->shortcode_toolbar( 'jsms-cart_text_2' ); ?>
						<p class="description">می‌توانید از <code>{coupon}</code> استفاده کنید تا برای هر مشتری یک کد تخفیف یکتا ساخته شود.</p>
					</td></tr></table>
				</div>
				<p style="margin-top:10px">لینک بازیابی سبد بعد از <input type="number" name="cart_recovery_expiry_days" value="<?php echo esc_attr( $s['cart_recovery_expiry_days'] ); ?>" style="width:70px"> روز منقضی می‌شود.</p>
			<?php elseif ( 'inactive' === $extra ) : ?>
				<p>بعد از <input type="number" name="inactive_days" value="<?php echo esc_attr( $s['inactive_days'] ); ?>" style="width:70px"> روز بدون خرید. فاصله بین دو پیام: <input type="number" name="inactive_cooldown" value="<?php echo esc_attr( $s['inactive_cooldown'] ); ?>" style="width:70px"> روز.</p>
			<?php elseif ( 'review' === $extra ) : ?>
				<p><input type="number" name="review_after_days" value="<?php echo esc_attr( $s['review_after_days'] ); ?>" style="width:70px"> روز بعد از وضعیت
				<select name="review_order_status">
					<?php foreach ( wc_get_order_statuses() as $key => $label ) : $k = str_replace( 'wc-', '', $key ); ?>
						<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $s['review_order_status'], $k ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select></p>
				<label><input type="checkbox" name="review_incoming" <?php checked( $s['review_incoming'], 1 ); ?>> خواندن پاسخ پیامکی مشتری به‌جای لینک (نیازمند خط دوطرفه)</label>
			<?php endif; ?>

			<?php if ( 'cart' !== $extra ) : ?>
			<table class="form-table">
				<tr><th>نوع پیام</th><td>
					<select name="<?php echo $mode; ?>" class="jsms-mode">
						<option value="text" <?php selected( $s[ $mode ], 'text' ); ?>>متن آزاد (خط انبوه)</option>
						<option value="pattern" <?php selected( $s[ $mode ], 'pattern' ); ?>>پترن (خط خدماتی)</option>
					</select>
				</td></tr>
				<tr class="jsms-text-row"><th>متن پیام<?php echo 'review' === $extra ? ' (درخواست اول)' : ''; ?></th><td><textarea id="<?php echo esc_attr( 'jsms-' . $text ); ?>" name="<?php echo $text; ?>" rows="3" class="large-text"><?php echo esc_textarea( $s[ $text ] ); ?></textarea>
						<?php $this->shortcode_toolbar( 'jsms-' . $text ); ?></td></tr>
				<tr class="jsms-pat-row"><th>شناسه پترن (bodyId)</th><td><input type="text" name="<?php echo $pat; ?>" value="<?php echo esc_attr( $s[ $pat ] ); ?>"><p class="description">پارامترها به ترتیب: نام و سایر متغیرها.</p></td></tr>
			</table>
			<?php endif; ?>

			<?php if ( 'review' === $extra ) : ?>
				<table class="form-table">
					<tr><th>متن یادآوری (۳ روز بعد)</th><td>
						<textarea id="jsms-review_reminder_text" name="review_reminder_text" rows="3" class="large-text"><?php echo esc_textarea( $s['review_reminder_text'] ); ?></textarea>
						<?php $this->shortcode_toolbar( 'jsms-review_reminder_text' ); ?>
						<p class="description">اگر مشتری بعد از درخواست اول نظر ثبت نکند، دقیقاً یک‌بار (۳ روز بعد) با این متنِ متفاوت و دوستانه‌تر یادآوری می‌شود.<br>💡 توجه: چون این پیام معمولاً <code>{review_url}</code> (لینک ثبت نظر) دارد، از خط خدماتی اشتراکی ارسال لینک ممکن نیست — به خط عادی/غیرخدماتی یا خدماتیِ اختصاصی نیاز دارید.</p>
					</td></tr>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * جعبهٔ کد پیگیری — ارسال دستی از صفحهٔ سفارش (بدون کلید فعال/غیرفعال).
	 */
	private function tracking_box( $s ) {
		?>
		<div class="jsms-auto-box">
			<h2>🚚 کد پیگیری مرسوله</h2>
			<p class="description">این پیام به‌صورت دستی از صفحهٔ هر سفارش ارسال می‌شود: در ویرایش سفارش، جعبهٔ «پیامک و کد پیگیری» را پر کنید و تیک ارسال را بزنید. همچنین از فهرست «عملیات» سفارش هم قابل ارسال است.</p>
			<table class="form-table">
				<tr><th>نوع پیام</th><td>
					<select name="tracking_mode" class="jsms-mode">
						<option value="text" <?php selected( $s['tracking_mode'], 'text' ); ?>>متن آزاد (خط انبوه)</option>
						<option value="pattern" <?php selected( $s['tracking_mode'], 'pattern' ); ?>>پترن (خط خدماتی)</option>
					</select>
				</td></tr>
				<tr class="jsms-text-row"><th>متن پیام</th><td>
					<textarea id="jsms-tracking_text" name="tracking_text" rows="3" class="large-text"><?php echo esc_textarea( $s['tracking_text'] ); ?></textarea>
					<?php $this->shortcode_toolbar( 'jsms-tracking_text' ); ?>
					<p class="description">متغیرها: {first_name} {order_id} {tracking_code} {order_url} {site_name} {courier}</p>
				</td></tr>
				<tr class="jsms-pat-row"><th>شناسه پترن (bodyId)</th><td><input type="text" name="tracking_pattern" value="<?php echo esc_attr( $s['tracking_pattern'] ); ?>"><p class="description">ترتیب پارامترها: نام، شماره سفارش، کد رهگیری.</p></td></tr>
			</table>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * صفحه کمپین‌ها
	 * ------------------------------------------------------------------- */
	/**
	 * چند متن آمادهٔ کمپین تبلیغاتی — نقطهٔ شروع سریع برای فروشندگانی که
	 * نمی‌دانند چه بنویسند؛ هرکدام از قبل با پسوند «لغو۱۱» (الزام قانونیِ
	 * لغو-اشتراکِ پیامک تبلیغاتی) ساخته شده تا کاربر یادش نرود.
	 */
	private static function campaign_templates() {
		return array(
			'کد تخفیف اختصاصی' => "{first_name} عزیز، کد تخفیف اختصاصی شما آماده است: {coupon} 🎁\nهمین حالا در {site_url} خرید کنید.\nلغو۱۱",
			'حراج فوری (فلش‌سیل)' => "⏰ فقط تا پایان امروز! حراج ویژهٔ {site_name} با تخفیف باورنکردنی آغاز شد.\n{first_name} عزیز، فرصت را از دست ندهید: {site_url}\nلغو۱۱",
			'محصول جدید' => "{first_name} عزیز، جدیدترین محصولات {site_name} رسید! 🆕\nهمین الان نگاهی بیندازید: {site_url}\nلغو۱۱",
			'مشتری وفادار / VIP' => "{first_name} عزیز، به‌پاس اعتماد شما، این کد تخفیف ویژهٔ اعضای وفادار تقدیم‌تان می‌شود: {coupon}\n{site_url}\nلغو۱۱",
			'موجودی محدود' => "{first_name} عزیز، محصولات پرطرفدار {site_name} رو به اتمام است! ⏳\nهمین امروز سفارش دهید: {site_url}\nلغو۱۱",
			'مناسبتی / تبریک' => "{first_name} عزیز، به‌این‌مناسبت، {coupon} هدیهٔ {site_name} برای شماست 🎉\n{site_url}\nلغو۱۱",
		);
	}

	public function page_campaigns() {
		?>
		<div class="wrap jsms-wrap is-wide">
			<?php $this->hero( "کمپین‌ها", "ارسال انبوه هدفمند در چهار گام ساده" ); ?>

			<ol class="jsms-steps" id="jsms-steps">
				<li class="is-active" data-step="1"><span class="jsms-step-no">۱</span><span>مخاطبان</span></li>
				<li data-step="2"><span class="jsms-step-no">۲</span><span>پیام</span></li>
				<li data-step="3"><span class="jsms-step-no">۳</span><span>پیش‌نمایش</span></li>
				<li data-step="4"><span class="jsms-step-no">۴</span><span>ارسال</span></li>
			</ol>

			<div id="jsms-wizard">
				<!-- گام ۱: مخاطبان -->
				<section class="jsms-panel jsms-step" data-step="1">
					<h2 class="jsms-eyebrow-h">مخاطبان کمپین</h2>
					<p class="jsms-muted">گروهی که این پیام را دریافت می‌کند انتخاب کنید. شماره‌های لغو اشتراک‌شده خودکار حذف می‌شوند.</p>
					<div class="jsms-choice-grid">
						<label class="jsms-choice"><input type="radio" name="jsms-segment" value="customers" checked><b>همه مشتریان</b><small>تمام کاربران دارای شماره موبایل</small></label>
						<label class="jsms-choice"><input type="radio" name="jsms-segment" value="buyers"><b>فقط خریداران</b><small>حداقل یک سفارش ثبت‌شده</small></label>
						<label class="jsms-choice"><input type="radio" name="jsms-segment" value="inactive"><b>خریداران غیرفعال</b><small>مدتی است خرید نکرده‌اند</small></label>
						<label class="jsms-choice"><input type="radio" name="jsms-segment" value="custom"><b>لیست دستی</b><small>شماره‌ها را خودتان وارد کنید</small></label>
					</div>
					<p id="jsms-days-wrap" style="display:none;margin-top:14px">غیرفعال از <input type="number" id="jsms-days" value="60" style="width:80px"> روز پیش تا امروز.</p>
					<div id="jsms-custom-wrap" style="display:none;margin-top:14px">
						<label class="jsms-field-label">شماره‌ها</label>
						<textarea id="jsms-custom" rows="4" class="large-text" placeholder="هر شماره در یک خط یا جدا با کاما"></textarea>
					</div>
					<div class="jsms-wizard-nav"><span></span><button class="jsms-btn jsms-btn-primary jsms-next">بعدی ←</button></div>
				</section>

				<!-- گام ۲: پیام -->
				<section class="jsms-panel jsms-step" data-step="2" hidden>
					<h2 class="jsms-eyebrow-h">متن پیام</h2>
					<div class="jsms-tpl-picker">
						<span class="jsms-field-label">متن‌های آماده:</span>
						<div class="jsms-tpl-list">
							<?php foreach ( self::campaign_templates() as $key => $tpl ) : ?>
								<button type="button" class="jsms-tpl-chip" data-tpl="<?php echo esc_attr( $tpl ); ?>"><?php echo esc_html( $key ); ?></button>
							<?php endforeach; ?>
						</div>
					</div>
					<textarea id="jsms-text" rows="5" class="large-text" placeholder="{first_name} عزیز، ..."></textarea>
					<div class="jsms-counter"><span id="jsms-charcount">۰ کاراکتر</span><span id="jsms-partcount">۱ پیامک</span></div>
					<p class="jsms-varhint">متغیرها: {first_name} {site_name} {site_url} {coupon}</p>
					<p class="jsms-muted"><code>{coupon}</code> برای هر گیرنده یک کد تخفیف یکتا می‌سازد. برای پیام تبلیغاتی حتماً «لغو۱۱» را در انتها بگذارید.</p>
					<div class="jsms-wizard-nav"><button class="jsms-btn jsms-prev">→ قبلی</button><button class="jsms-btn jsms-btn-primary jsms-next">بعدی ←</button></div>
				</section>

				<!-- گام ۳: پیش‌نمایش -->
				<section class="jsms-panel jsms-step" data-step="3" hidden>
					<h2 class="jsms-eyebrow-h">پیش‌نمایش و تأیید</h2>
					<div class="jsms-preview-grid">
						<div class="jsms-preview-stats">
							<div class="jsms-pstat"><span class="n" id="jsms-aud-count">…</span><span class="l">گیرنده</span></div>
							<div class="jsms-pstat"><span class="n" id="jsms-seg-count">۱</span><span class="l">پیامک برای هر نفر</span></div>
							<div class="jsms-pstat"><span class="n" id="jsms-total-sms">…</span><span class="l">مجموع پیامک</span></div>
						</div>
						<div class="jsms-phone">
							<div class="jsms-phone-top">پیش‌نمایش پیامک</div>
							<div class="jsms-bubble" id="jsms-preview-text">—</div>
						</div>
					</div>
					<p class="jsms-muted" id="jsms-preview-note">اعداد بالا تقریبی‌اند؛ متغیرها هنگام ارسال با مقادیر واقعی هر مشتری جایگزین می‌شوند.</p>
					<div class="jsms-wizard-nav"><button class="jsms-btn jsms-prev">→ قبلی</button><button class="jsms-btn jsms-btn-primary" id="jsms-camp-start">شروع ارسال</button></div>
				</section>

				<!-- گام ۴: ارسال -->
				<section class="jsms-panel jsms-step" data-step="4" hidden>
					<h2 class="jsms-eyebrow-h">در حال ارسال</h2>
					<div class="jsms-bar"><div class="jsms-bar-fill" id="jsms-bar-fill"></div></div>
					<p id="jsms-camp-status" class="jsms-muted">آماده‌سازی…</p>
				</section>
			</div>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * صفحه باشگاه مشتریان / کیف پول
	 * ------------------------------------------------------------------- */
	public function page_club() {
		global $wpdb;
		$s  = get_option( 'jsms_settings', JSMS_Settings_Defaults() );
		$wt = JSMS_DB::wallet_table();

		$members   = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM {$wt}" );
		$liability = (int) $wpdb->get_var( "SELECT COALESCE(SUM(amount),0) FROM {$wt}" );
		$paid      = (int) $wpdb->get_var( "SELECT COALESCE(SUM(amount),0) FROM {$wt} WHERE type='cashback'" );
		$top = $wpdb->get_results(
			"SELECT user_id, SUM(amount) bal FROM {$wt} GROUP BY user_id HAVING bal>0 ORDER BY bal DESC LIMIT 8", ARRAY_A
		);
		?>
		<div class="wrap jsms-wrap is-wide">
			<?php $this->hero( 'باشگاه مشتریان', 'کیف پول اعتباری، کش‌بک خودکار و سطوح وفاداری' ); ?>

			<div class="jsms-cards">
				<div class="jsms-card">
					<span class="jsms-ic ic-gold"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="7" width="18" height="12" rx="3"/><path d="M16 12h.01M3 10h13a2 2 0 0 1 2 2" stroke-linecap="round"/></svg></span>
					<div><span class="n"><?php echo number_format( $liability ); ?></span><span class="l">موجودی کل کیف پول‌ها (تومان)</span></div>
				</div>
				<div class="jsms-card">
					<span class="jsms-ic ic-green"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3v18M7 6h7a3 3 0 0 1 0 6H8a3 3 0 0 0 0 6h8" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
					<div><span class="n"><?php echo number_format( $paid ); ?></span><span class="l">مجموع کش‌بک پرداختی</span></div>
				</div>
				<div class="jsms-card">
					<span class="jsms-ic ic-blue"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="9" cy="8" r="3"/><path d="M15 8a3 3 0 1 0 0-.01M3 20a6 6 0 0 1 12 0M15 14a6 6 0 0 1 6 6" stroke-linecap="round"/></svg></span>
					<div><span class="n"><?php echo number_format( $members ); ?></span><span class="l">اعضای باشگاه</span></div>
				</div>
			</div>

			<form method="post">
				<?php wp_nonce_field( 'jsms_save', '_jsms' ); ?>
				<input type="hidden" name="jsms_scope" value="club">

				<section class="jsms-panel">
					<h2 class="jsms-eyebrow-h">کش‌بک خودکار</h2>
					<label class="jsms-switch"><input type="checkbox" name="wallet_enabled" <?php checked( $s['wallet_enabled'], 1 ); ?>> باشگاه مشتریان فعال باشد</label>
					<table class="form-table">
						<tr><th>زمان اعطای کش‌بک</th><td>
							<select name="cashback_trigger_status">
								<?php foreach ( wc_get_order_statuses() as $key => $label ) : $k = str_replace( 'wc-', '', $key ); ?>
									<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $s['cashback_trigger_status'], $k ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description">معمولاً «تکمیل‌شده» تا مطمئن شوید سفارش نهایی است.</p>
						</td></tr>
						<tr><th>حداقل مبلغ سفارش</th><td><input type="number" name="cashback_min_order" value="<?php echo esc_attr( $s['cashback_min_order'] ); ?>" style="width:140px"> تومان (۰ = بدون محدودیت)</td></tr>
						<tr><th>سقف کش‌بک هر سفارش</th><td><input type="number" name="cashback_max" value="<?php echo esc_attr( $s['cashback_max'] ); ?>" style="width:140px"> تومان (۰ = بدون سقف)</td></tr>
					</table>
				</section>

				<section class="jsms-panel">
					<h2 class="jsms-eyebrow-h">سطوح وفاداری</h2>
					<p class="jsms-muted">درصد کش‌بک بر اساس مجموع خرید مشتری تعیین می‌شود.</p>
					<table class="form-table">
						<tr><th>🥉 برنزی (پایه)</th><td>کش‌بک <input type="number" name="cashback_percent" value="<?php echo esc_attr( $s['cashback_percent'] ); ?>" style="width:70px">٪ برای همه.</td></tr>
						<tr><th>🥈 نقره‌ای</th><td>از خرید <input type="number" name="tier_silver_min" value="<?php echo esc_attr( $s['tier_silver_min'] ); ?>" style="width:140px"> تومان → کش‌بک <input type="number" name="tier_silver_pct" value="<?php echo esc_attr( $s['tier_silver_pct'] ); ?>" style="width:70px">٪</td></tr>
						<tr><th>🥇 طلایی</th><td>از خرید <input type="number" name="tier_gold_min" value="<?php echo esc_attr( $s['tier_gold_min'] ); ?>" style="width:140px"> تومان → کش‌بک <input type="number" name="tier_gold_pct" value="<?php echo esc_attr( $s['tier_gold_pct'] ); ?>" style="width:70px">٪</td></tr>
					</table>
				</section>

				<section class="jsms-panel">
					<h2 class="jsms-eyebrow-h">برداشت موجودی</h2>
					<p class="jsms-muted">مشتری موجودی را به یک کد تخفیف تبدیل می‌کند و در پرداخت اعمال می‌کند. برای نمایش کیف پول در سایت، شورت‌کد <code>[jsms_wallet]</code> را در یک برگه قرار دهید.</p>
					<table class="form-table">
						<tr><th>حداقل موجودی قابل‌برداشت</th><td><input type="number" name="wallet_redeem_min" value="<?php echo esc_attr( $s['wallet_redeem_min'] ); ?>" style="width:140px"> تومان</td></tr>
						<tr><th>انقضای کد برداشت</th><td><input type="number" name="wallet_coupon_expiry_days" value="<?php echo esc_attr( $s['wallet_coupon_expiry_days'] ); ?>" style="width:80px"> روز</td></tr>
					</table>
				</section>

				<section class="jsms-panel">
					<h2 class="jsms-eyebrow-h">پیامک‌ها</h2>
					<label class="jsms-switch"><input type="checkbox" name="wallet_sms_enabled" <?php checked( $s['wallet_sms_enabled'], 1 ); ?>> اطلاع‌رسانی پیامکی فعال باشد</label>
					<table class="form-table">
						<tr><th>پیام کش‌بک</th><td>
							<textarea name="wallet_cashback_text" rows="2" class="large-text"><?php echo esc_textarea( $s['wallet_cashback_text'] ); ?></textarea>
							<p class="description">متغیرها: {first_name} {cashback} {wallet_balance} {tier} {site_name}</p>
						</td></tr>
						<tr><th>پیام برداشت</th><td>
							<textarea name="wallet_redeem_text" rows="2" class="large-text"><?php echo esc_textarea( $s['wallet_redeem_text'] ); ?></textarea>
							<p class="description">متغیرها: {first_name} {coupon_code} {redeem_amount} {wallet_balance}</p>
						</td></tr>
					</table>
				</section>

				<?php if ( $top ) : ?>
				<section class="jsms-panel">
					<h2 class="jsms-eyebrow-h">بیشترین موجودی‌ها</h2>
					<table class="jsms-table">
						<thead><tr><th>مشتری</th><th>موجودی (تومان)</th></tr></thead>
						<tbody>
						<?php foreach ( $top as $row ) : $u = get_userdata( $row['user_id'] ); ?>
							<tr><td><?php echo esc_html( $u ? $u->display_name : ( '#' . $row['user_id'] ) ); ?></td><td class="num"><?php echo number_format( $row['bal'] ); ?></td></tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</section>
				<?php endif; ?>

				<p><button class="jsms-btn jsms-btn-primary" name="jsms_save" value="1">ذخیره باشگاه مشتریان</button></p>
			</form>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * صفحه گزارش‌ها (روند ارسال + نسبت‌دهی درآمد)
	 * ------------------------------------------------------------------- */
	public function page_reports() {
		$days   = isset( $_GET['range'] ) ? max( 7, min( 90, (int) $_GET['range'] ) ) : 30;
		$trend  = JSMS_Reports::daily_trend( min( $days, 30 ) );
		$attr   = JSMS_Reports::attribution( $days );
		$labels = self::type_labels();
		$aov    = JSMS_Reports::average_order_value( $days );
		$dv     = JSMS_Reports::delivery_stats( $days );
		$insights = JSMS_Reports::insights( $days );
		$top_products = JSMS_Reports::top_abandoned_products( $days, 5 );

		$tot_orders = 0; $tot_rev = 0;
		foreach ( $attr as $a ) { $tot_orders += $a['orders']; $tot_rev += $a['revenue']; }
		?>
		<div class="wrap jsms-wrap is-wide">
			<?php $this->hero( 'گزارش‌ها', 'روند ارسال و نسبت‌دهی درآمد هر اتوماسیون' ); ?>

			<div class="jsms-cards">
				<div class="jsms-card"><span class="jsms-ic ic-blue"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 19V5M4 19h16M8 15l3-4 3 3 4-6" stroke-linecap="round" stroke-linejoin="round"/></svg></span><div><span class="n"><?php echo number_format( $tot_orders ); ?></span><span class="l">سفارش منتسب (<?php echo esc_html( $days ); ?> روز)</span></div></div>
				<div class="jsms-card"><span class="jsms-ic ic-green"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3v18M7 6h7a3 3 0 0 1 0 6H8a3 3 0 0 0 0 6h8" stroke-linecap="round" stroke-linejoin="round"/></svg></span><div><span class="n"><?php echo number_format( $tot_rev ); ?></span><span class="l">درآمد منتسب (تومان)</span></div></div>
				<div class="jsms-card"><span class="jsms-ic ic-gold"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 12h4l3 8 4-16 3 8h4" stroke-linecap="round" stroke-linejoin="round"/></svg></span><div><span class="n"><?php echo number_format( $aov ); ?></span><span class="l">میانگین ارزش سفارش (تومان)</span></div></div>
				<div class="jsms-card"><span class="jsms-ic ic-blue"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 13l4 4L19 7" stroke-linecap="round" stroke-linejoin="round"/></svg></span><div><span class="n"><?php echo esc_html( $dv['rate'] ); ?>٪</span><span class="l">نرخ تحویل پیامک (<?php echo number_format( $dv['failed'] ); ?> ناموفق از <?php echo number_format( $dv['total'] ); ?>)</span></div></div>
				<div class="jsms-card"><span class="jsms-ic ic-gold"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2" stroke-linecap="round" stroke-linejoin="round"/></svg></span><div><span class="n"><?php echo esc_html( JSMS_Reports::window_days() ); ?> روز</span><span class="l">پنجرهٔ نسبت‌دهی زمانی</span></div></div>
			</div>

			<?php if ( $insights ) : ?>
			<section class="jsms-panel">
				<h2 class="jsms-eyebrow-h">💡 تحلیل و پیشنهاد برای فروش بیشتر</h2>
				<p class="jsms-muted">بر اساس دادهٔ واقعی همین <?php echo esc_html( $days ); ?> روز — نه یک توصیهٔ کلی.</p>
				<div class="jsms-insights">
					<?php foreach ( $insights as $ins ) :
						$icon = 'good' === $ins['level'] ? '✅' : ( 'warn' === $ins['level'] ? '⚠️' : 'ℹ️' );
						?>
						<div class="jsms-insight jsms-insight-<?php echo esc_attr( $ins['level'] ); ?>">
							<span class="jsms-insight-ic"><?php echo $icon; ?></span>
							<span class="jsms-insight-text"><?php echo esc_html( $ins['text'] ); ?></span>
						</div>
					<?php endforeach; ?>
				</div>
			</section>
			<?php endif; ?>

			<section class="jsms-panel">
				<h2 class="jsms-eyebrow-h">روند ارسال (۳۰ روز اخیر)</h2>
				<?php echo self::trend_chart( $trend ); // phpcs:ignore ?>
				<div class="jsms-legend"><span><i class="dot sent"></i> موفق</span><span><i class="dot failed"></i> ناموفق</span></div>
			</section>

			<section class="jsms-panel">
				<h2 class="jsms-eyebrow-h">نسبت‌دهی درآمد به اتوماسیون‌ها</h2>
				<p class="jsms-muted">درآمد بر اساس کد تخفیف اختصاصی هر پیام (دقیق) و در نبود کد، خرید تا <?php echo esc_html( JSMS_Reports::window_days() ); ?> روز پس از پیامک (پنجرهٔ زمانی) محاسبه شده است.</p>
				<table class="jsms-table">
					<thead><tr><th>اتوماسیون</th><th>ارسال</th><th>سفارش</th><th>نرخ تبدیل</th><th>درآمد (تومان)</th><th>روش نسبت‌دهی</th></tr></thead>
					<tbody>
					<?php
					uasort( $attr, function ( $a, $b ) { return $b['revenue'] <=> $a['revenue']; } );
					foreach ( $attr as $type => $r ) :
						if ( 0 === $r['orders'] && 0 === $r['sent'] ) { continue; }
						$cr = $r['sent'] ? round( $r['orders'] / $r['sent'] * 100, 1 ) : 0;
						?>
						<tr>
							<td><?php echo esc_html( $labels[ $type ] ?? $type ); ?></td>
							<td class="num"><?php echo number_format( $r['sent'] ); ?></td>
							<td class="num"><?php echo number_format( $r['orders'] ); ?></td>
							<td class="num"><?php echo esc_html( $cr ); ?>٪</td>
							<td class="num"><?php echo number_format( $r['revenue'] ); ?></td>
							<td><span class="jsms-tag">دقیق: <?php echo (int) $r['exact']; ?></span> <span class="jsms-tag alt">زمانی: <?php echo (int) $r['window']; ?></span><?php if ( ! empty( $r['cart_link'] ) ) : ?> <span class="jsms-tag alt">سبد: <?php echo (int) $r['cart_link']; ?></span><?php endif; ?></td>
						</tr>
					<?php endforeach; ?>
					<?php if ( empty( $attr ) ) : ?><tr><td colspan="6" class="jsms-empty">هنوز داده‌ای برای نسبت‌دهی وجود ندارد.</td></tr><?php endif; ?>
					</tbody>
				</table>
			</section>

			<?php if ( $top_products ) : ?>
			<section class="jsms-panel">
				<h2 class="jsms-eyebrow-h">پرتکرارترین محصولات در سبدهای رهاشده</h2>
				<p class="jsms-muted">محصولاتی که مشتری تا مرز خرید برده ولی نهایتاً نخریده — بالاترین ارزش برای بازبینی قیمت/موجودی/توضیحات.</p>
				<table class="jsms-table">
					<thead><tr><th>محصول</th><th>تعداد دفعات رها شدن</th></tr></thead>
					<tbody>
					<?php foreach ( $top_products as $name => $count ) : ?>
						<tr><td><?php echo esc_html( $name ); ?></td><td class="num"><?php echo number_format( $count ); ?></td></tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</section>
			<?php endif; ?>

			<?php $cf = JSMS_Reports::cart_funnel(); ?>
			<section class="jsms-panel">
				<h2 class="jsms-eyebrow-h">نرخ تبدیل سبد خرید رها شده</h2>
				<p class="jsms-muted">از روی دادهٔ واقعی سبدها (نه حدس زمانی) — چند سبدِ اطلاع‌رسانی‌شده واقعاً به سفارش تبدیل شد.</p>
				<?php
				echo self::funnel_row( 'مرحله ۱ (یادآوری ساده)', $cf['stage1_recovered'], $cf['stage1_sent'] );
				echo self::funnel_row( 'مرحله ۲ (کد تخفیف)', $cf['stage2_recovered'], $cf['stage2_sent'] );
				?>
			</section>

			<?php $rf = JSMS_Reports::review_funnel(); ?>
			<section class="jsms-panel">
				<h2 class="jsms-eyebrow-h">نرخ تبدیل درخواست نظر</h2>
				<p class="jsms-muted">از هر لینک ارسال‌شده، چند نفر واقعاً فرم را پر کردند و چند نظر در نهایت تأیید شد.</p>
				<?php
				echo self::funnel_row( 'ثبت‌شده توسط مشتری', $rf['responded'], $rf['requested'] );
				echo self::funnel_row( 'تأییدشده توسط شما', $rf['approved'], $rf['requested'] );
				?>
			</section>
		</div>
		<?php
	}

	/**
	 * یک ردیف قیف تبدیل: برچسب + نوار درصد + عدد خام.
	 */
	private static function funnel_row( $label, $part, $total ) {
		$pct = $total ? round( $part / $total * 100, 1 ) : 0;
		return '<div class="jsms-funnel-row">'
			. '<div class="jsms-funnel-label">' . esc_html( $label ) . '</div>'
			. '<div class="jsms-funnel-bar"><span style="width:' . esc_attr( min( 100, $pct ) ) . '%"></span></div>'
			. '<div class="jsms-funnel-stat">' . number_format( $part ) . ' از ' . number_format( $total ) . ' <b>(' . esc_html( $pct ) . '٪)</b></div>'
			. '</div>';
	}

	/**
	 * نمودار میله‌ای دوتایی (موفق/ناموفق) به‌صورت SVG درون‌خطی — بدون کتابخانهٔ بیرونی.
	 */
	private static function trend_chart( $trend ) {
		$w = 860; $h = 220; $pad = 30; $n = max( 1, count( $trend ) );
		$max = 1;
		foreach ( $trend as $d ) { $max = max( $max, $d['sent'] + $d['failed'] ); }
		$bw = ( $w - $pad * 2 ) / $n;
		$svg = '<svg viewBox="0 0 ' . $w . ' ' . $h . '" class="jsms-chart" preserveAspectRatio="xMidYMid meet">';
		// خطوط راهنما.
		for ( $g = 0; $g <= 4; $g++ ) {
			$y = $pad + ( $h - $pad * 2 ) * $g / 4;
			$val = round( $max * ( 4 - $g ) / 4 );
			$svg .= '<line x1="' . $pad . '" y1="' . $y . '" x2="' . ( $w - $pad ) . '" y2="' . $y . '" stroke="#e8e0f5" stroke-width="1"/>';
			$svg .= '<text x="' . ( $w - $pad + 4 ) . '" y="' . ( $y + 3 ) . '" font-size="9" fill="#8983ab">' . $val . '</text>';
		}
		$i = 0;
		foreach ( $trend as $d ) {
			$total = $d['sent'] + $d['failed'];
			$x = $pad + $i * $bw + $bw * 0.2;
			$bwi = $bw * 0.6;
			$hh = ( $h - $pad * 2 );
			$sh = $total ? $hh * $d['sent'] / $max : 0;
			$fh = $total ? $hh * $d['failed'] / $max : 0;
			$ys = $h - $pad - $sh;
			$yf = $ys - $fh;
			if ( $d['failed'] ) {
				$svg .= '<rect x="' . $x . '" y="' . $yf . '" width="' . $bwi . '" height="' . $fh . '" fill="#d1373f" rx="2"><title>' . esc_attr( $d['label'] . ' — ناموفق: ' . $d['failed'] ) . '</title></rect>';
			}
			$svg .= '<rect x="' . $x . '" y="' . $ys . '" width="' . $bwi . '" height="' . $sh . '" fill="#2fae13" rx="2"><title>' . esc_attr( $d['label'] . ' — موفق: ' . $d['sent'] ) . '</title></rect>';
			if ( 0 === $i % 3 || $i === $n - 1 ) {
				$svg .= '<text x="' . ( $x + $bwi / 2 ) . '" y="' . ( $h - $pad + 12 ) . '" font-size="8" fill="#8983ab" text-anchor="middle">' . esc_html( $d['label'] ) . '</text>';
			}
			$i++;
		}
		$svg .= '</svg>';
		return $svg;
	}

	/* ---------------------------------------------------------------------
	 * صفحه نظرات
	 * ------------------------------------------------------------------- */
	public function page_reviews() {
		global $wpdb;
		$rt = JSMS_DB::reviews_table();
		$status = isset( $_GET['st'] ) ? sanitize_key( $_GET['st'] ) : 'pending';
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$rt} WHERE status=%s ORDER BY id DESC LIMIT 100", $status ) );
		$counts = array();
		foreach ( array( 'pending','approved','rejected','requested' ) as $st ) {
			$counts[ $st ] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$rt} WHERE status=%s", $st ) );
		}
		?>
		<div class="wrap jsms-wrap is-wide">
			<?php $this->hero( "نظرات مشتریان", "دیدگاه‌های دریافتی، با تأیید شما" ); ?>
			<ul class="subsubsub">
				<li><a href="?page=jsms-reviews&st=pending" class="<?php echo $status==='pending'?'current':''; ?>">در انتظار تأیید (<?php echo $counts['pending']; ?>)</a> |</li>
				<li><a href="?page=jsms-reviews&st=approved" class="<?php echo $status==='approved'?'current':''; ?>">تأییدشده (<?php echo $counts['approved']; ?>)</a> |</li>
				<li><a href="?page=jsms-reviews&st=rejected" class="<?php echo $status==='rejected'?'current':''; ?>">ردشده (<?php echo $counts['rejected']; ?>)</a> |</li>
				<li><a href="?page=jsms-reviews&st=requested" class="<?php echo $status==='requested'?'current':''; ?>">ارسال‌شده/بی‌پاسخ (<?php echo $counts['requested']; ?>)</a></li>
			</ul>
			<table class="widefat striped">
				<thead><tr><th>محصول</th><th>نویسنده</th><th>امتیاز</th><th>پیشنهاد</th><th>متن</th><th>تاریخ</th><th>عملیات</th></tr></thead>
				<tbody>
				<?php foreach ( (array) $rows as $r ) :
					$p = wc_get_product( $r->product_id );
					$approve = wp_nonce_url( admin_url( 'admin.php?page=jsms-reviews&jsms_review_action=approve&rid=' . $r->id ), 'jsms_review_act' );
					$reject  = wp_nonce_url( admin_url( 'admin.php?page=jsms-reviews&jsms_review_action=reject&rid=' . $r->id ), 'jsms_review_act' );
				?>
					<tr>
						<td><?php echo $p ? '<a href="' . esc_url( get_permalink( $r->product_id ) ) . '" target="_blank">' . esc_html( $p->get_name() ) . '</a>' : '#' . $r->product_id; ?></td>
						<td><?php echo esc_html( $r->author ); ?></td>
						<td><?php echo $r->rating ? str_repeat( '★', $r->rating ) . str_repeat( '☆', 5 - $r->rating ) : '—'; ?></td>
						<td><?php echo isset( $r->recommend ) && '' !== $r->recommend ? ( (int) $r->recommend === 1 ? '👍' : '👎' ) : '—'; ?></td>
						<td><?php echo esc_html( $r->content ?: '—' ); ?></td>
						<td><?php echo esc_html( $r->created_at ); ?></td>
						<td>
							<?php if ( 'pending' === $r->status ) : ?>
								<a class="button button-primary button-small" href="<?php echo esc_url( $approve ); ?>">تأیید و انتشار</a>
								<a class="button button-small" href="<?php echo esc_url( $reject ); ?>">رد</a>
							<?php elseif ( 'approved' === $r->status ) : ?>
								<span style="color:#2fae13">منتشر شد</span>
							<?php else : ?>
								<?php echo esc_html( self::status_label( $r->status ) ); ?>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				<?php if ( empty( $rows ) ) : ?><tr><td colspan="7">موردی نیست.</td></tr><?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * صفحه نظرسنجی
	 * ------------------------------------------------------------------- */
	public function page_surveys() {
		$view = isset( $_GET['view'] ) ? sanitize_key( $_GET['view'] ) : 'list';
		$id   = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		if ( 'edit' === $view ) {
			$this->page_surveys_edit( $id );
		} elseif ( 'results' === $view && $id ) {
			$this->page_surveys_results( $id );
		} else {
			$this->page_surveys_list();
		}
	}

	private function page_surveys_list() {
		$surveys = JSMS_Surveys::get_surveys();
		global $wpdb;
		?>
		<div class="wrap jsms-wrap is-wide">
			<?php $this->hero( 'نظرسنجی', 'ساخت پرسش‌نامه، ارسال لینک پیامکی و مشاهدهٔ پاسخ مشتریان' ); ?>
			<p><a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=jsms-surveys&view=edit&id=0' ) ); ?>">+ نظرسنجی تازه</a></p>
			<table class="widefat striped">
				<thead><tr><th>عنوان</th><th>وضعیت</th><th>تعداد سوال</th><th>پاسخ‌های تکمیل‌شده</th><th>تاریخ ساخت</th><th>عملیات</th></tr></thead>
				<tbody>
				<?php if ( empty( $surveys ) ) : ?>
					<tr><td colspan="6">هنوز نظرسنجی‌ای نساخته‌اید.</td></tr>
				<?php endif; ?>
				<?php foreach ( $surveys as $s ) :
					$qcount = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . JSMS_DB::survey_questions_table() . ' WHERE survey_id=%d', $s->id ) );
					$rcount = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM " . JSMS_DB::survey_responses_table() . " WHERE survey_id=%d AND status='done'", $s->id ) );
					$edit_url = admin_url( 'admin.php?page=jsms-surveys&view=edit&id=' . $s->id );
					$res_url  = admin_url( 'admin.php?page=jsms-surveys&view=results&id=' . $s->id );
					$del_url  = wp_nonce_url( admin_url( 'admin.php?page=jsms-surveys&jsms_survey_action=delete&id=' . $s->id ), 'jsms_survey_act' );
					?>
					<tr>
						<td><a href="<?php echo esc_url( $edit_url ); ?>"><b><?php echo esc_html( $s->title ); ?></b></a></td>
						<td><?php echo 'active' === $s->status ? '<span style="color:#2fae13">فعال</span>' : '<span style="color:#a1a1aa">پیش‌نویس</span>'; ?></td>
						<td><?php echo (int) $qcount; ?></td>
						<td><?php echo (int) $rcount; ?></td>
						<td><?php echo esc_html( $s->created_at ); ?></td>
						<td>
							<a class="button button-small" href="<?php echo esc_url( $edit_url ); ?>">ویرایش</a>
							<a class="button button-small" href="<?php echo esc_url( $res_url ); ?>">نتایج</a>
							<a class="button button-small" style="color:#c0392b" href="<?php echo esc_url( $del_url ); ?>" onclick="return confirm('حذف این نظرسنجی و همهٔ پاسخ‌هایش؟');">حذف</a>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	private function page_surveys_edit( $id ) {
		$survey = $id ? JSMS_Surveys::get_survey( $id ) : null;
		if ( $id && ! $survey ) {
			echo '<div class="wrap"><p>نظرسنجی پیدا نشد.</p></div>';
			return;
		}
		$questions = $id ? JSMS_Surveys::get_questions( $id ) : array();
		$types = JSMS_Surveys::question_types();
		?>
		<div class="wrap jsms-wrap is-wide">
			<?php $this->hero( $survey ? 'ویرایش نظرسنجی' : 'نظرسنجی تازه', 'ساخت سؤال و ارسال لینک به مشتریان' ); ?>
			<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=jsms-surveys' ) ); ?>">← بازگشت به فهرست</a></p>

			<div class="jsms-varhint" style="margin-bottom:16px">
				⚠️ <b>ارسال لینک نظرسنجی فقط با خط خدماتیِ اختصاصی امکان‌پذیر است</b> — خط خدماتی اشتراکی اجازهٔ ارسال لینک در متن را نمی‌دهد (فقط پترن ثابت، بدون لینک). اگر خط اختصاصی ندارید، خط خدماتیِ اختصاصیِ شاتل را می‌توانید با داشتن نماد اعتماد الکترونیکی (اینماد) سایت‌تان تهیه کنید.
			</div>

			<section class="jsms-panel">
				<h2 class="jsms-eyebrow-h">مشخصات نظرسنجی</h2>
				<form method="post">
					<?php wp_nonce_field( 'jsms_survey_save', '_jsms' ); ?>
					<input type="hidden" name="survey_id" value="<?php echo (int) $id; ?>">
					<table class="form-table">
						<tr><th>عنوان</th><td><input type="text" name="title" class="regular-text" required value="<?php echo esc_attr( $survey->title ?? '' ); ?>" placeholder="مثلاً: نظرسنجی رضایت خرید"></td></tr>
						<tr><th>متن خوش‌آمد</th><td><textarea name="intro_text" rows="2" class="large-text" placeholder="سلام! فقط چند لحظه از وقتتان را می‌گیرد."><?php echo esc_textarea( $survey->intro_text ?? '' ); ?></textarea></td></tr>
						<tr><th>لوگو (اختیاری)</th><td><input type="url" name="logo_url" class="regular-text" value="<?php echo esc_attr( $survey->logo_url ?? '' ); ?>" placeholder="آدرس تصویر لوگو — خالی = لوگوی پیش‌فرض سایت"></td></tr>
						<tr><th>متن پیامک دعوت</th><td>
							<textarea name="sms_text" rows="3" class="large-text" placeholder="<?php echo esc_attr( jsms_get( 'survey_default_text' ) ); ?>"><?php echo esc_textarea( $survey->sms_text ?? '' ); ?></textarea>
							<p class="description">متغیرها: {first_name} {survey_url} {site_name} — خالی بگذارید تا از متن پیش‌فرض («تنظیمات اتصال») استفاده شود. برای پیامک تبلیغاتی/دعوت عمومی «لغو۱۱» را در انتها بگذارید.</p>
						</td></tr>
						<tr><th>وضعیت</th><td>
							<select name="status">
								<option value="draft" <?php selected( $survey->status ?? 'draft', 'draft' ); ?>>پیش‌نویس (لینک هنوز باز نیست)</option>
								<option value="active" <?php selected( $survey->status ?? 'draft', 'active' ); ?>>فعال</option>
							</select>
						</td></tr>
					</table>
					<p><button type="submit" name="jsms_survey_save" value="1" class="button button-primary">ذخیرهٔ نظرسنجی</button></p>
				</form>
			</section>

			<?php if ( $id ) : ?>
				<section class="jsms-panel">
					<h2 class="jsms-eyebrow-h">سوال‌ها (<?php echo count( $questions ); ?>)</h2>
					<?php if ( $questions ) : ?>
					<table class="widefat striped">
						<thead><tr><th>ترتیب</th><th>نوع</th><th>متن سوال</th><th>گزینه‌ها</th><th>عملیات</th></tr></thead>
						<tbody>
						<?php foreach ( $questions as $q ) :
							$opts = (array) json_decode( $q->options, true );
							$del  = wp_nonce_url( admin_url( 'admin.php?page=jsms-surveys&view=edit&id=' . $id . '&jsms_survey_action=delete_question&qid=' . $q->id ), 'jsms_survey_act' );
							?>
							<tr>
								<td><?php echo (int) $q->sort_order; ?></td>
								<td><?php echo esc_html( $types[ $q->type ] ?? $q->type ); ?></td>
								<td><?php echo esc_html( $q->question_text ); ?></td>
								<td><?php echo $opts ? esc_html( implode( '، ', $opts ) ) : '—'; ?></td>
								<td>
									<button type="button" class="button button-small jsms-q-edit-toggle" data-qid="<?php echo (int) $q->id; ?>">ویرایش</button>
									<a class="button button-small" style="color:#c0392b" href="<?php echo esc_url( $del ); ?>" onclick="return confirm('حذف این سوال؟');">حذف</a>
								</td>
							</tr>
							<tr class="jsms-q-edit-row" id="jsms-q-edit-<?php echo (int) $q->id; ?>" style="display:none">
								<td colspan="5">
									<form method="post">
										<?php wp_nonce_field( 'jsms_survey_save', '_jsms' ); ?>
										<input type="hidden" name="survey_id" value="<?php echo (int) $id; ?>">
										<input type="hidden" name="question_id" value="<?php echo (int) $q->id; ?>">
										<?php $this->survey_question_fields( $q, $types ); ?>
										<button type="submit" name="jsms_question_save" value="1" class="button button-primary button-small">ذخیرهٔ سوال</button>
									</form>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<?php endif; ?>

					<h3 class="jsms-eyebrow-h" style="margin-top:22px">+ افزودن سوال تازه</h3>
					<form method="post">
						<?php wp_nonce_field( 'jsms_survey_save', '_jsms' ); ?>
						<input type="hidden" name="survey_id" value="<?php echo (int) $id; ?>">
						<?php $this->survey_question_fields( null, $types, count( $questions ) ); ?>
						<button type="submit" name="jsms_question_save" value="1" class="button button-primary">افزودن سوال</button>
					</form>
				</section>

				<section class="jsms-panel">
					<h2 class="jsms-eyebrow-h">ارسال آزمایشی</h2>
					<p class="jsms-muted">یک لینک واقعی برای یک شماره تست ارسال کنید تا صفحهٔ نظرسنجی را خودتان ببینید.</p>
					<form method="post">
						<?php wp_nonce_field( 'jsms_survey_save', '_jsms' ); ?>
						<input type="hidden" name="survey_id" value="<?php echo (int) $id; ?>">
						<input type="text" name="test_mobile" placeholder="09xxxxxxxxx" required>
						<button type="submit" name="jsms_survey_test_send" value="1" class="button">ارسال لینک تست</button>
					</form>
				</section>

				<section class="jsms-panel">
					<h2 class="jsms-eyebrow-h">ارسال خودکار</h2>
					<p class="jsms-muted">برای ارسال خودکار این نظرسنجی بعد از تکمیل سفارش، به «تنظیمات اتصال» بروید و بخش «ارسال خودکار نظرسنجی» را فعال کنید و همین نظرسنجی را انتخاب کنید.</p>
				</section>
			<?php endif; ?>

			<script>
			(function(){
				document.querySelectorAll('.jsms-q-edit-toggle').forEach(function(btn){
					btn.addEventListener('click', function(){
						var row = document.getElementById('jsms-q-edit-' + btn.dataset.qid);
						if (row) row.style.display = row.style.display === 'none' ? '' : 'none';
					});
				});
				document.querySelectorAll('.jsms-q-type-select').forEach(function(sel){
					function sync(){
						var wrap = sel.closest('.jsms-q-fields').querySelector('.jsms-q-options-wrap');
						if (wrap) wrap.style.display = ( sel.value === 'choice_single' || sel.value === 'choice_multi' ) ? '' : 'none';
					}
					sel.addEventListener('change', sync);
					sync();
				});
			})();
			</script>
		</div>
		<?php
	}

	private function survey_question_fields( $q, $types, $default_order = 0 ) {
		$opts_text = $q ? implode( "\n", (array) json_decode( $q->options, true ) ) : '';
		?>
		<div class="jsms-q-fields" style="display:grid;gap:8px;max-width:520px;margin:8px 0">
			<label>متن سوال<br><input type="text" name="question_text" class="large-text" required value="<?php echo esc_attr( $q->question_text ?? '' ); ?>"></label>
			<label>نوع پاسخ<br>
				<select name="type" class="jsms-q-type-select">
					<?php foreach ( $types as $k => $label ) : ?>
						<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $q->type ?? 'rating', $k ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<div class="jsms-q-options-wrap">
				<label>گزینه‌ها (هرکدام در یک خط — فقط برای چندگزینه‌ای)<br>
					<textarea name="options" rows="4" class="large-text"><?php echo esc_textarea( $opts_text ); ?></textarea>
				</label>
			</div>
			<label style="max-width:140px">ترتیب<br><input type="number" name="sort_order" value="<?php echo (int) ( $q->sort_order ?? $default_order ); ?>"></label>
		</div>
		<?php
	}

	private function page_surveys_results( $id ) {
		$survey    = JSMS_Surveys::get_survey( $id );
		if ( ! $survey ) {
			echo '<div class="wrap"><p>نظرسنجی پیدا نشد.</p></div>';
			return;
		}
		$questions = JSMS_Surveys::get_questions( $id );
		$summary   = JSMS_Surveys::results_summary( $id, $questions );
		$responses = JSMS_Surveys::get_responses( $id );
		?>
		<div class="wrap jsms-wrap is-wide">
			<?php $this->hero( 'نتایج: ' . esc_html( $survey->title ), 'خلاصهٔ آماری و پاسخ تک‌تک مشتریان' ); ?>
			<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=jsms-surveys' ) ); ?>">← بازگشت به فهرست</a></p>

			<section class="jsms-panel">
				<h2 class="jsms-eyebrow-h">خلاصهٔ هر سوال</h2>
				<?php foreach ( $questions as $q ) : $sum = $summary[ $q->id ]; ?>
					<div style="margin-bottom:18px">
						<b><?php echo esc_html( $q->question_text ); ?></b>
						<?php if ( 'rating' === $q->type ) : ?>
							<p class="jsms-muted">میانگین: <b><?php echo esc_html( $sum['avg'] ?: '—' ); ?></b> از ۵ · بر اساس <?php echo (int) $sum['count']; ?> پاسخ</p>
						<?php elseif ( in_array( $q->type, array( 'choice_single', 'choice_multi' ), true ) ) : ?>
							<ul style="margin:4px 0 0 0">
								<?php foreach ( $sum['options'] as $opt => $cnt ) : ?>
									<li><?php echo esc_html( $opt ); ?>: <b><?php echo (int) $cnt; ?></b></li>
								<?php endforeach; ?>
							</ul>
						<?php else : ?>
							<p class="jsms-muted">پاسخ آزاد — در جدول پایین قابل مشاهده است.</p>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
				<?php if ( empty( $questions ) ) : ?><p class="jsms-muted">هنوز سوالی برای این نظرسنجی ساخته نشده.</p><?php endif; ?>
			</section>

			<section class="jsms-panel">
				<h2 class="jsms-eyebrow-h">پاسخ‌های تک‌تک مشتریان</h2>
				<table class="widefat striped">
					<thead><tr><th>مشتری</th><th>موبایل</th><th>وضعیت</th><th>پاسخ‌ها</th><th>تاریخ تکمیل</th></tr></thead>
					<tbody>
					<?php if ( empty( $responses ) ) : ?><tr><td colspan="5">هنوز کسی پاسخ نداده.</td></tr><?php endif; ?>
					<?php foreach ( $responses as $r ) :
						$answers = json_decode( $r->answers, true );
						?>
						<tr>
							<td><?php echo esc_html( $r->author ?: '—' ); ?></td>
							<td><?php echo esc_html( $r->mobile ); ?></td>
							<td><?php echo 'done' === $r->status ? '<span style="color:#2fae13">تکمیل‌شده</span>' : '<span style="color:#a1a1aa">در انتظار</span>'; ?></td>
							<td>
								<?php if ( is_array( $answers ) ) : ?>
									<ul style="margin:0">
									<?php foreach ( $questions as $q ) :
										if ( ! isset( $answers[ $q->id ] ) ) { continue; }
										$val = $answers[ $q->id ];
										$val = is_array( $val ) ? implode( '، ', $val ) : $val;
										?>
										<li><small class="jsms-muted"><?php echo esc_html( $q->question_text ); ?>:</small> <?php echo esc_html( $val ); ?></li>
									<?php endforeach; ?>
									</ul>
								<?php else : ?>—<?php endif; ?>
							</td>
							<td><?php echo esc_html( $r->completed_at ?: '—' ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</section>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * صفحه کدهای تخفیف
	 * ------------------------------------------------------------------- */
	public function page_coupons() {
		$q = new WP_Query( array(
			'post_type'      => 'shop_coupon',
			'posts_per_page' => 50,
			'meta_key'       => '_jsms_source_type',
			'meta_value'     => 'manual',
			'orderby'        => 'date',
			'order'          => 'DESC',
		) );
		?>
		<div class="wrap jsms-wrap is-wide">
			<?php $this->hero( 'کدهای تخفیف', 'ساخت کد تخفیف واقعیِ ووکامرس' ); ?>

			<section class="jsms-panel">
				<h2 class="jsms-eyebrow-h">ساخت کد تازه</h2>
				<form method="post">
					<?php wp_nonce_field( 'jsms_coupon_create', '_jsms' ); ?>
					<table class="form-table">
						<tr><th>نوع کد</th><td>
							<label style="display:block;margin-bottom:6px"><input type="radio" name="scope" value="single" checked> اختصاصی — یک‌بار مصرف (یا محدود به تعداد مشخص)</label>
							<label style="display:block"><input type="radio" name="scope" value="shared"> عمومی — برای همهٔ مشتریان، هرکس یک‌بار</label>
						</td></tr>
						<tr id="jsms-cp-limit-row"><th>تعداد دفعات مصرف</th><td><input type="number" name="usage_limit" value="1" min="1" style="width:100px"> (برای «اختصاصی» — معمولاً ۱)</td></tr>
						<tr id="jsms-cp-email-row"><th>مخصوص یک مشتری خاص (اختیاری)</th><td><input type="email" name="email" class="regular-text" placeholder="ایمیل مشتری — خالی = هرکس اولین‌بار استفاده کند"></td></tr>
						<tr><th>نوع تخفیف</th><td>
							<select name="type">
								<option value="percent">درصدی</option>
								<option value="fixed_cart">مبلغ ثابت (تومان)</option>
							</select>
						</td></tr>
						<tr><th>مقدار</th><td><input type="number" name="amount" required min="0" step="0.01" style="width:140px"></td></tr>
						<tr><th>کد دلخواه (اختیاری)</th><td><input type="text" name="code" class="regular-text" placeholder="خالی = تولید خودکار"></td></tr>
						<tr><th>تاریخ انقضا (اختیاری)</th><td><input type="date" name="expires_at"><p class="description">خالی = بدون انقضا.</p></td></tr>
					</table>
					<p><button type="submit" name="jsms_coupon_create" value="1" class="button button-primary">ساخت کد تخفیف</button></p>
				</form>
			</section>

			<section class="jsms-panel">
				<h2 class="jsms-eyebrow-h">کدهای ساخته‌شده از این صفحه</h2>
				<table class="widefat striped">
					<thead><tr><th>کد</th><th>نوع/مقدار</th><th>محدودیت مصرف</th><th>مصرف‌شده</th><th>انقضا</th><th>تاریخ ساخت</th></tr></thead>
					<tbody>
					<?php if ( ! $q->have_posts() ) : ?><tr><td colspan="6">هنوز کدی از این صفحه ساخته نشده.</td></tr><?php endif; ?>
					<?php foreach ( $q->posts as $p ) :
						$coupon = new WC_Coupon( $p->ID );
						$limit  = (int) $coupon->get_usage_limit();
						$expiry = $coupon->get_date_expires();
						?>
						<tr>
							<td><a href="<?php echo esc_url( get_edit_post_link( $p->ID ) ); ?>"><b><?php echo esc_html( $coupon->get_code() ); ?></b></a></td>
							<td><?php echo esc_html( 'percent' === $coupon->get_discount_type() ? $coupon->get_amount() . '٪' : number_format( (float) $coupon->get_amount() ) . ' تومان' ); ?></td>
							<td><?php echo $limit ? (int) $limit : 'نامحدود'; ?></td>
							<td><?php echo (int) $coupon->get_usage_count(); ?></td>
							<td><?php echo $expiry ? esc_html( $expiry->date_i18n( 'Y-m-d' ) ) : '—'; ?></td>
							<td><?php echo esc_html( get_the_date( 'Y-m-d H:i', $p ) ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</section>
			<script>
			(function(){
				var radios = document.querySelectorAll('input[name="scope"]');
				var limitRow = document.getElementById('jsms-cp-limit-row');
				var emailRow = document.getElementById('jsms-cp-email-row');
				function sync(){
					var shared = document.querySelector('input[name="scope"]:checked').value === 'shared';
					limitRow.style.display = shared ? 'none' : '';
					emailRow.style.display = shared ? 'none' : '';
				}
				radios.forEach(function(r){ r.addEventListener('change', sync); });
				sync();
			})();
			</script>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * صفحه گزارش
	 * ------------------------------------------------------------------- */
	public function page_logs() {
		global $wpdb;
		$t = JSMS_DB::logs_table();
		$paged = max( 1, (int) ( $_GET['paged'] ?? 1 ) );
		$per = 50; $offset = ( $paged - 1 ) * $per;
		$type = isset( $_GET['ftype'] ) ? sanitize_key( $_GET['ftype'] ) : '';
		$where = $type ? $wpdb->prepare( 'WHERE type=%s', $type ) : '';
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} {$where}" );
		$rows  = $wpdb->get_results( "SELECT * FROM {$t} {$where} ORDER BY id DESC LIMIT {$offset},{$per}" );
		$labels = self::type_labels();
		?>
		<div class="wrap jsms-wrap is-wide">
			<?php $this->hero( "گزارش ارسال‌ها", "سابقه کامل پیامک‌های ارسال‌شده و وضعیت تحویل" ); ?>
			<form method="get"><input type="hidden" name="page" value="jsms-logs">
				<select name="ftype" onchange="this.form.submit()">
					<option value="">همه انواع</option>
					<?php foreach ( $labels as $k => $l ) : ?>
						<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $type, $k ); ?>><?php echo esc_html( $l ); ?></option>
					<?php endforeach; ?>
				</select>
			</form>
			<table class="widefat striped">
				<thead><tr><th>تاریخ</th><th>موبایل</th><th>نوع</th><th>مرجع</th><th>وضعیت</th><th>متن</th><th>پاسخ سامانه</th></tr></thead>
				<tbody>
				<?php
				$order_ref_types = array( 'admin_new_order', 'admin_receipt', 'status_pending', 'status_shetab-approval', 'status_cancelled', 'status_processing', 'status_completed', 'card_pending', 'pending_expiry', 'card_payment_started', 'payment_reminder_2' );
				$cart_ref_types  = array( 'abandoned_cart', 'abandoned_cart_2' );

				// برای ردیف‌های «سبد رها شده»، اگر آن سبد از قبل به یک سفارش وصل شده
				// (مثلاً همان یادآوری‌ای که هنوز سفارش pending داشته)، شماره سفارش را هم
				// کنار شماره سبد نشان بده — وگرنه معلوم نیست «سبد #۱۲۱» مال کدام سفارشه.
				$cart_order_map = array();
				$cart_ids = array();
				foreach ( (array) $rows as $r ) {
					if ( in_array( $r->type, $cart_ref_types, true ) && $r->ref_id ) {
						$cart_ids[] = (int) $r->ref_id;
					}
				}
				if ( $cart_ids ) {
					$carts_t = JSMS_DB::carts_table();
					$ids_sql = implode( ',', array_map( 'intval', $cart_ids ) );
					$found = $wpdb->get_results( "SELECT id, order_id FROM {$carts_t} WHERE id IN ({$ids_sql}) AND order_id > 0" );
					foreach ( (array) $found as $row ) {
						$cart_order_map[ (int) $row->id ] = (int) $row->order_id;
					}
				}

				foreach ( (array) $rows as $r ) :
					$ref = '';
					if ( $r->ref_id ) {
						if ( in_array( $r->type, $order_ref_types, true ) ) {
							$ref = 'سفارش #' . (int) $r->ref_id;
						} elseif ( in_array( $r->type, $cart_ref_types, true ) ) {
							$ref = 'سبد #' . (int) $r->ref_id;
							if ( ! empty( $cart_order_map[ (int) $r->ref_id ] ) ) {
								$ref .= ' (سفارش #' . $cart_order_map[ (int) $r->ref_id ] . ')';
							}
						} else {
							$ref = '#' . (int) $r->ref_id;
						}
					}
					?>
					<tr>
						<td><?php echo esc_html( $r->created_at ); ?></td>
						<td><?php echo esc_html( $r->mobile ); ?></td>
						<td><?php echo esc_html( $labels[ $r->type ] ?? $r->type ); ?></td>
						<td><?php echo esc_html( $ref ); ?></td>
						<td><span class="jsms-st jsms-st-<?php echo esc_attr( $r->status ); ?>"><?php echo esc_html( self::status_label( $r->status ) ); ?></span></td>
						<td class="jsms-msg"><?php echo esc_html( wp_trim_words( $r->message, 14, '…' ) ); ?></td>
						<td><?php echo esc_html( wp_trim_words( (string) $r->response, 8, '…' ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				<?php if ( empty( $rows ) ) : ?><tr><td colspan="7">گزارشی نیست.</td></tr><?php endif; ?>
				</tbody>
			</table>
			<?php
			$pages = ceil( $total / $per );
			if ( $pages > 1 ) {
				echo '<div class="tablenav"><div class="tablenav-pages">';
				echo paginate_links( array(
					'base' => add_query_arg( 'paged', '%#%' ),
					'format' => '', 'current' => $paged, 'total' => $pages,
				) );
				echo '</div></div>';
			}
			?>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * AJAX
	 * ------------------------------------------------------------------- */
	public function ajax_test_send() {
		check_ajax_referer( 'jsms_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'دسترسی غیرمجاز' );
		}
		$mobile = sanitize_text_field( wp_unslash( $_POST['mobile'] ?? '' ) );
		$chk = JSMS_Gateway::check_connection();
		if ( ! $chk['ok'] ) {
			wp_send_json_error( 'اتصال برقرار نشد: ' . $chk['error'] );
		}
		$credit_txt = null !== $chk['credit'] ? number_format( (float) $chk['credit'] ) : '—';
		if ( $mobile ) {
			$res = JSMS_Templates::dispatch( array(
				'to' => $mobile, 'type' => 'test', 'mode' => 'text', 'force' => true,
				'text' => 'پیام آزمایشی از ' . get_bloginfo( 'name' ),
			) );
			if ( ! empty( $res['ok'] ) ) {
				wp_send_json_success( 'اتصال و ارسال تأیید شد ✅' . ( '—' !== $credit_txt ? ' اعتبار: ' . $credit_txt : '' ) . ' — کد رهگیری: ' . ( $res['rec_id'] ?: '-' ) );
			}
			wp_send_json_error( 'اتصال اولیه برقرار است، اما ارسال پیامک تست ناموفق بود: ' . ( $res['error'] ?? 'خطای نامشخص' ) );
		}
		wp_send_json_success( 'اطلاعات اتصال معتبر است ✅' . ( '—' !== $credit_txt ? ' اعتبار: ' . $credit_txt : '' ) . ' — برای تست واقعی، شماره موبایل را وارد و پیامک تست را ارسال کنید.' );
	}

	public function ajax_check_credit() {
		check_ajax_referer( 'jsms_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'دسترسی غیرمجاز' );
		}
		$c = JSMS_Gateway::get_credit();
		if ( null === $c ) {
			wp_send_json_error( 'خطا در دریافت اعتبار' );
		}
		update_option( 'jsms_last_credit', $c );
		wp_send_json_success( number_format( (float) $c ) );
	}

	/* --------------------------------------------------------------------- */
	public static function type_labels() {
		return array(
			'welcome' => 'خوش‌آمدگویی',
			'order' => 'پس از خرید',
			'abandoned_cart' => 'سبد رها شده',
			'abandoned_cart_2' => 'سبد رها شده (مرحله ۲)',
			'inactive' => 'مشتری غیرفعال',
			'review_request' => 'درخواست نظر',
			'survey_request' => 'دعوت به نظرسنجی',
			'campaign' => 'کمپین',
			'tracking' => 'کد پیگیری',
			'cashback' => 'کش‌بک کیف پول',
			'wallet_redeem' => 'برداشت کیف پول',
			'test' => 'آزمایشی',
			'admin_alert' => 'هشدار مدیر',
			'admin_new_order' => 'سفارش جدید (مدیر)',
			'admin_low_stock' => 'کمبود موجودی (مدیر)',
			'admin_receipt'   => 'رسید کارت‌به‌کارت (مدیر)',
			'card_payment_started' => 'در انتظار پرداخت کارت‌به‌کارت',
			'payment_reminder_2' => 'یادآوری دوم پرداخت',
			'ebazar_status'   => 'وضعیت مرسولهٔ ای‌بازار پست',
		);
	}
	public static function status_label( $s ) {
		$m = array(
			'sent' => 'ارسال شد', 'failed' => 'ناموفق', 'pending' => 'در انتظار',
			'requested' => 'ارسال‌شده', 'approved' => 'تأییدشده', 'rejected' => 'ردشده',
		);
		return $m[ $s ] ?? $s;
	}
}
endif; // ! class_exists( 'JSMS_Admin' )
