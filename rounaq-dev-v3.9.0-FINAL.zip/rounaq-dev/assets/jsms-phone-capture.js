/**
 * لایهٔ دوم گرفتن شمارهٔ مهمان در چک‌اوت — کاملاً مستقل از قالب.
 * فقط روی فیلد استانداردِ خودِ ووکامرس (#billing_phone) گوش می‌دهد و شماره را با
 * AJAX به سرور می‌فرستد؛ هیچ منطق ردیابی/تصمیم‌گیری‌ای اینجا انجام نمی‌شود —
 * فقط انتقال مقدار خام. تشخیص «سبد کدام مهمان» و ذخیره‌سازی همه سمت سرور است.
 */
(function () {
	'use strict';
	if (typeof window.JSMS_PHONE === 'undefined') {
		return;
	}

	function isPhoneish(v) {
		v = (v || '').replace(/[^0-9+]/g, '');
		return /^(\+98|0098|0)?9\d{9}$/.test(v);
	}

	function send(phone) {
		var body = new URLSearchParams();
		body.set('action', 'jsms_capture_phone');
		body.set('nonce', window.JSMS_PHONE.nonce);
		body.set('phone', phone);
		fetch(window.JSMS_PHONE.ajax, {
			method: 'POST',
			credentials: 'same-origin',
			body: body
		}).catch(function () { /* بی‌صدا نادیده گرفته شود — تلاش بعدی (submit سفارش) جبران می‌کند */ });
	}

	function bind(el) {
		if (!el || el.getAttribute('data-jsms-bound')) {
			return;
		}
		el.setAttribute('data-jsms-bound', '1');
		var fire = function () {
			if (isPhoneish(el.value)) {
				send(el.value);
			}
		};
		el.addEventListener('blur', fire);
		el.addEventListener('change', fire);
	}

	function scan() {
		bind(document.getElementById('billing_phone'));
		var byName = document.querySelector('[name="billing_phone"]');
		if (byName) {
			bind(byName);
		}
	}

	scan();
	// چک‌اوت‌های مبتنی بر AJAX ممکن است فرم را بعداً دوباره بسازند؛ با MutationObserver
	// دوباره فیلد را پیدا و به آن گوش می‌دهیم، بدون هیچ فرضی دربارهٔ ساختار قالب.
	if (window.MutationObserver) {
		new MutationObserver(scan).observe(document.body, { childList: true, subtree: true });
	}
})();
