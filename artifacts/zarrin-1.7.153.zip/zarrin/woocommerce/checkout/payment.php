<?php
/**
 * بخش پرداخت — درگاه‌های واقعیِ فعالِ ووکامرس (WC_Payment_Gateways، نه
 * لیست ثابت). طبق درخواست صریح کاربر، مرحله‌ی «نحوه پرداخت» دقیقاً ۲
 * دکمه داره: «پرداخت» (ثبت سفارش) و «بازگشت» — بازگشت باید به مرحله‌ی
 * قبل (اطلاعات ارسال) برگرده، نه مستقیم به سبد خرید؛ پس دیگه لینک
 * «بازگشت به سبد خرید»ی که تمپلیت اصلی ووکامرس این‌جا داشت رندر نمی‌شه —
 * دکمه‌ی «بازگشت»ِ واقعی توسط assets/js/woocommerce.js (که این مرحله رو
 * نمایش/مخفی می‌کنه) بیرون از #payment ساخته می‌شه.
 *
 * @see woocommerce/templates/checkout/payment.php (نسخه‌ی اصلی)
 * @version 10.9.0
 *
 * طبقِ درخواستِ صریحِ کاربر («روش‌های پرداخت توی یک کادرِ جدا سمتِ راستِ
 * صفحه، و ریسپانسیو موبایل») این‌جا دیگه داخلِ سایدبارِ باریکِ خلاصه‌سفارش
 * نیست — یک ستونِ عریضِ جدا (form-checkout.php: #jluxe-payment-column) که
 * جای فرمِ آدرس رو موقعِ مرحله‌ی «نحوه پرداخت» می‌گیره. کارتِ بیرونی
 * (border/padding/rounded) رو خودِ #jluxe-payment-column می‌ده، پس این‌جا
 * فقط محتوا (بدونِ کارتِ تودرتوی اضافه). به inc/woocommerce.php →
 * remove_action(...woocommerce_checkout_payment...) مراجعه بشه.
 *
 * طبقِ درخواستِ صریحِ بعدیِ کاربر («دکمه‌ی پرداخت رو ببر زیرِ بازگشت، سمتِ
 * چپ») بخشِ «ثبت سفارش» (شرایط/دکمه/nonce) دیگه این‌جا نیست — رفته توی
 * سایدبارِ باریکِ کنارِ «بازگشت» (jluxe_render_payment_submit() در
 * inc/woocommerce.php، صدا زده‌شده از form-checkout.php). این‌جا فقط
 * انتخابِ درگاه می‌مونه. توضیحِ ایمنیِ AJAX (چرا این جدایی خرابش نمی‌کنه)
 * در همون تابع هست.
 */

defined( 'ABSPATH' ) || exit;

if ( ! wp_doing_ajax() ) {
	do_action( 'woocommerce_review_order_before_payment' );
}
?>
<div id="payment" class="woocommerce-checkout-payment">
	<?php if ( WC()->cart && WC()->cart->needs_payment() ) : ?>
		<?php
		/*
		 * هشدارِ VPN طبقِ مرجعِ تصویریِ جدیدِ کاربر — درگاه‌های پرداختِ
		 * ایرانی معمولاً با فیلترشکنِ فعال درست کار نمی‌کنن؛ این فقط یک
		 * یادآوریِ متنیه، به هیچ منطقِ واقعیِ ووکامرس دست نمی‌زنه.
		 */
		?>
		<?php if ( jluxe_cart_checkout_option( 'checkout_payment_warning_enabled', true ) ) : ?>
			<?php $payment_warning = jluxe_cart_checkout_copy( 'checkout_payment_warning', 'در صورتی که از فیلترشکن (VPN) استفاده می‌کنید، قبل از ورود به درگاه پرداخت آن را خاموش کنید.' ); ?>
			<?php if ( '' !== trim( $payment_warning ) ) : ?>
				<?php $payment_warning_background = jluxe_cart_checkout_color( 'checkout_payment_warning_background', '#FFF8E6' ); ?>
				<?php $payment_warning_text_color = jluxe_cart_checkout_color( 'checkout_payment_warning_text_color', '#334155' ); ?>
				<div class="jluxe-checkout-vpn-note mb-4 flex items-start gap-2 rounded-xl p-4 text-small" style="--jluxe-checkout-vpn-background: <?php echo esc_attr( $payment_warning_background ); ?>; --jluxe-checkout-vpn-text-color: <?php echo esc_attr( $payment_warning_text_color ); ?>;">
					<span class="mt-0.5 shrink-0 text-warning">⚠</span>
					<span><?php echo nl2br( esc_html( $payment_warning ) ); ?></span>
				</div>
			<?php endif; ?>
		<?php endif; ?>

		<?php $payment_heading = jluxe_cart_checkout_copy( 'checkout_payment_heading', 'روش پرداخت' ); ?>
		<?php if ( '' !== trim( $payment_heading ) ) : ?>
			<p class="mb-3 text-small font-medium text-foreground"><?php echo esc_html( $payment_heading ); ?></p>
		<?php endif; ?>
		<?php
		/*
		 * هر درگاه در یک ردیفِ افقیِ مستطیلی و تمام‌عرض نمایش داده می‌شود؛
		 * فهرست تک‌ستونه در همهٔ اندازه‌ها ثابت می‌ماند تا عنوان/آیکن و
		 * کنترل انتخاب در دسکتاپ و موبایل فضای کافی داشته باشند.
		 */
		?>
		<ul class="wc_payment_methods payment_methods methods jluxe-payment-method-list" aria-label="<?php esc_attr_e( 'Payment methods', 'woocommerce' ); ?>">
			<?php
			if ( ! empty( $available_gateways ) ) {
				foreach ( $available_gateways as $gateway ) {
					wc_get_template( 'checkout/payment-method.php', array( 'gateway' => $gateway ) );
				}
			} else {
				$message = WC()->customer->get_billing_country()
					? jluxe_cart_checkout_copy( 'checkout_no_payment_methods', 'در حال حاضر روش پرداختی در دسترس نیست. لطفاً با پشتیبانی تماس بگیرید.' )
					: jluxe_cart_checkout_copy( 'checkout_payment_details_prompt', 'برای مشاهدهٔ روش‌های پرداخت، اطلاعات خود را تکمیل کنید.' );
				$message = apply_filters( 'woocommerce_no_available_payment_methods_message', $message );
				if ( is_scalar( $message ) && '' !== trim( wp_strip_all_tags( (string) $message ) ) ) {
					echo '<li>';
					wc_print_notice( (string) $message, 'notice' );
					echo '</li>';
				}
			}
			?>
		</ul>
	<?php endif; ?>
</div>
<?php
if ( ! wp_doing_ajax() ) {
	do_action( 'woocommerce_review_order_after_payment' );
}
