import { useNavPress } from "../lib/use-nav-press.js";
import { useAuthStatus } from "../lib/use-auth-status.js";
import { j as jsx } from "../lib/jsx.js";
import { r as React } from "../lib/icons.js";
import {
  getActiveMobileDrawer,
  hasMobileDrawerRegistration,
  openMobileDrawer,
  subscribeMobileDrawerState,
  toggleMobileDrawer,
} from "../lib/mobile-drawers.js";
import { g as getThemeSettings } from "../lib/theme-settings.js";
import { u as useCart } from "../lib/use-cart.js";
import { N as navIcons, H as fallbackIcon } from "../components/nav-icons.js";
import { resolveMobileNavItem, siteLink } from "../lib/mobile-nav-actions.js";
import {
  prefetchMobileHome,
  scheduleMobileHomePrefetch,
} from "../lib/mobile-home-prefetch.js";
import {
  getMobilePriceBarVisible,
  getMobilePriceBarVisibleFromEvent,
  hasExternalMobileNavigation,
  hasExternalMobileNavigationFromEvent,
} from "../lib/mobile-dock-mode.js";

const DEFAULT_ITEMS = [
  { id: "support", label: "پشتیبانی", icon: "headphones", action: "assistant", enabled: true },
  { id: "categories", label: "دسته‌ها", icon: "menu", action: "categories", enabled: true },
  { id: "home", label: "خانه", icon: "home", action: "home", enabled: true },
  { id: "account", label: "اکانت", icon: "user", action: "account", enabled: true },
  { id: "cart", label: "سبد خرید", icon: "cart", action: "cart", enabled: true },
];
function isActiveRoute(currentHref, targetHref, itemId) {
  try {
    const current = new URL(currentHref);
    const target = new URL(targetHref, current);
    if (current.origin !== target.origin) return false;
    const currentPath = current.pathname.replace(/\/+$/, "") || "/";
    const targetPath = target.pathname.replace(/\/+$/, "") || "/";
    return (
      currentPath === targetPath ||
      (itemId === "account" &&
        targetPath !== "/" &&
        currentPath.startsWith(`${targetPath}/`))
    );
  } catch {
    return false;
  }
}

function isModifiedClick(event) {
  return (
    event.defaultPrevented ||
    event.button !== 0 ||
    event.metaKey ||
    event.ctrlKey ||
    event.shiftKey ||
    event.altKey
  );
}

function FloatingMobileNav() {
  const settings = getThemeSettings();
  const mobile = settings.mobile ?? {};
  const style = mobile.nav_style ?? {};
  const isSingleProduct =
    typeof document !== "undefined" &&
    document.body?.classList.contains("single-product");
  const urls = settings.urls ?? {};
  const homeHref = siteLink(urls.home || "/", urls);
  const loggedIn = useAuthStatus();
  const pressProps = useNavPress();
  const reducedMotion =
    typeof window !== "undefined" &&
    window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;
  const animate = style.animate !== false && !reducedMotion;
  const { snapshot } = useCart();
  const [activeDrawer, setActiveDrawer] = React.useState(() =>
    typeof window === "undefined" ? null : getActiveMobileDrawer(window),
  );
  const [currentHref, setCurrentHref] = React.useState(
    typeof window === "undefined" ? "/" : window.location.href,
  );
  const [hasMobilePriceBar, setHasMobilePriceBar] = React.useState(() =>
    typeof document !== "undefined" && getMobilePriceBarVisible(document),
  );
  const [hasExternalProductNav, setHasExternalProductNav] = React.useState(
    () =>
      typeof document !== "undefined" &&
      document.body?.classList.contains("single-product") &&
      hasExternalMobileNavigation(document),
  );

  React.useEffect(
    () => subscribeMobileDrawerState(setActiveDrawer, window),
    [],
  );
  React.useEffect(() => {
    const syncMode = (event) => {
      setHasMobilePriceBar(getMobilePriceBarVisibleFromEvent(event, document));
      setHasExternalProductNav(
        document.body?.classList.contains("single-product") &&
          hasExternalMobileNavigationFromEvent(event, document),
      );
    };
    window.addEventListener("jluxe:toggle-mobile-bar", syncMode);
    window.addEventListener("pageshow", syncMode);
    // Reconcile with the DOM in case a fast tap preceded React hydration.
    syncMode();
    return () => {
      window.removeEventListener("jluxe:toggle-mobile-bar", syncMode);
      window.removeEventListener("pageshow", syncMode);
    };
  }, []);
  React.useEffect(() => {
    const syncPath = () => setCurrentHref(window.location.href);
    window.addEventListener("popstate", syncPath);
    return () => window.removeEventListener("popstate", syncPath);
  }, []);
  React.useEffect(
    () => scheduleMobileHomePrefetch(homeHref, window),
    [homeHref],
  );

  if (hasMobilePriceBar || hasExternalProductNav) return null;

  const colors = {
    background: style.background ?? "#ffffff",
    active: style.active_color ?? "#a313b9",
    icon: style.icon_color ?? "#6b7280",
    radius: style.radius ?? "22",
  };
  const shadow =
    style.shadow === "none"
      ? "none"
      : style.shadow === "strong"
        ? "0 -10px 30px -8px rgba(0,0,0,.20)"
        : style.shadow === "soft"
          ? "0 -5px 18px -7px rgba(0,0,0,.10)"
          : "0 -7px 24px -7px rgba(0,0,0,.15)";
  const radius = Math.max(12, Math.min(18, Number.parseInt(colors.radius, 10) || 18));
  const items = (mobile.floating_nav_items ?? DEFAULT_ITEMS)
    .filter((item) => item?.enabled)
    .map((item) => {
      const resolved = resolveMobileNavItem(item, {
        urls,
        shopUrl: urls.shop || settings.shopUrl,
        categoriesUrl: siteLink(settings.megaMenu?.url, urls) || urls.shop,
        assistantUrl: `${siteLink(urls.faq || "/faq", urls)}#open-ai-assistant`,
        isLoggedIn: loggedIn,
      });
      return {
        ...resolved,
        href: siteLink(resolved.href, urls),
        accountLabel:
          resolved.action === "account" &&
          (!resolved.label || resolved.label === "حساب" || resolved.label === "ورود")
            ? "حساب کاربری"
            : resolved.label,
        label:
          resolved.action === "account"
            ? !loggedIn ? "ورود" : (!resolved.label || resolved.label === "حساب" || resolved.label === "ورود") ? "حساب کاربری" : resolved.label
            : resolved.label,
      };
    });

  const handleClick = (event, item) => {
    if (isModifiedClick(event)) return;
    if (item.opensDrawer) {
      // If the lazy drawer island is absent, preserve the link's native href.
      if (!hasMobileDrawerRegistration(item.opensDrawer, window)) return;
      event.preventDefault();
      const closedSuggestions =
        typeof window.jluxeCloseSuggestedProductsModal === "function" &&
        window.jluxeCloseSuggestedProductsModal() === true;
      // A just-dismissed modal should reveal the chosen drawer even if the
      // prior drawer state is stale or its close animation is still running.
      if (closedSuggestions) openMobileDrawer(item.opensDrawer, window);
      else toggleMobileDrawer(item.opensDrawer, window, activeDrawer);
      return;
    }
    if (
      !item.targetBlank &&
      item.action !== "assistant" &&
      item.action !== "home"
    ) {
      setCurrentHref(item.href);
    }
  };

  return jsx.jsx("nav", {
    className: "jluxe-mobile-nav jluxe-mobile-nav--floating fixed inset-x-0 bottom-0 z-40 flex items-stretch border-t border-border bg-surface/95 md:hidden",
    style: {
      backgroundColor: isSingleProduct ? "hsl(var(--surface))" : colors.background,
      borderRadius: `${radius}px`,
      boxShadow: shadow,
      color: colors.icon,
      backdropFilter: isSingleProduct || style.blur === false ? "none" : "blur(14px)",
      WebkitBackdropFilter: isSingleProduct || style.blur === false ? "none" : "blur(14px)",
    },
    "aria-label": "ناوبری پایین موبایل",
    "data-jluxe-mobile-nav-dock": "",
    "data-jluxe-mobile-nav-variant": "floating",
    children: items.map((item) => {
      const drawerOpen = Boolean(
        item.opensDrawer && activeDrawer === item.opensDrawer,
      );
      const routeActive = isActiveRoute(
        currentHref,
        item.href,
        item.action === "account" ? "account" : item.id,
      );
      const active = routeActive || drawerOpen;
      const Icon = item.icon ? navIcons[item.icon] ?? fallbackIcon : null;
      const cartAction = item.action === "cart";
      const color = active ? colors.active : colors.icon;
      return jsx.jsxs(
        "a",
        {
          ...pressProps(item.id),
          href: item.href,
          onClick: (event) => handleClick(event, item),
          onPointerEnter:
            item.action === "home"
              ? () => prefetchMobileHome(homeHref, window)
              : undefined,
          onFocus:
            item.action === "home"
              ? () => prefetchMobileHome(homeHref, window)
              : undefined,
          onTouchStart:
            item.action === "home"
              ? () => prefetchMobileHome(homeHref, window)
              : undefined,
          target: item.targetBlank ? "_blank" : undefined,
          rel: item.targetBlank ? "noopener noreferrer" : undefined,
          className: "jluxe-mobile-nav-item jluxe-mobile-nav-item--floating relative flex flex-1 flex-col items-center justify-center gap-1 pt-1 text-[10.5px] font-medium",
          style: {
            color,
            transition: animate ? "color 220ms ease,transform 180ms ease" : "none",
          },
          "aria-current": routeActive ? "page" : undefined,
          ...(item.action === "account"
            ? {
                "data-jluxe-account-link": "",
                "data-jluxe-account-login-href": siteLink(urls.login || urls.home || "/", urls),
                "data-jluxe-account-dashboard-href": siteLink(urls.dashboard || urls.login || urls.home || "/", urls),
                "data-jluxe-account-logged-label": item.accountLabel || "حساب کاربری",
              }
            : {}),
          ...(item.opensDrawer
            ? {
                "aria-label": drawerOpen
                  ? item.opensDrawer === "cart"
                    ? "بستن سبد خرید"
                    : "بستن دسته‌بندی‌ها"
                  : item.label,
                "aria-haspopup": "dialog",
                "aria-expanded": drawerOpen,
                "aria-controls":
                  item.opensDrawer === "cart"
                    ? "jluxe-cart-drawer-dialog"
                    : "jluxe-category-drawer-dialog",
                "data-jluxe-drawer-toggle": item.opensDrawer,
                "data-jluxe-drawer-open": drawerOpen ? "true" : "false",
              }
            : {}),
          children: [
            jsx.jsxs("span", {
              className: "jluxe-mobile-nav-icon jluxe-mobile-nav-icon--floating relative flex size-10 items-center justify-center rounded-[15px]",
              style: {
                backgroundColor: "transparent",
                color,
                boxShadow: "none",
                transform: "none",
                transition: animate ? "color 180ms ease" : "none",
              },
              ...(cartAction ? { "data-jluxe-cart-icon-mobile": "" } : {}),
              children: [
                Icon
                  ? jsx.jsx(Icon, {
                      className: "size-[23px]",
                      "aria-hidden": true,
                    })
                  : null,
                cartAction && snapshot.itemCount > 0
                  ? jsx.jsx("span", {
                      className: "jluxe-mobile-nav-cart-count absolute -end-1 -top-1 flex size-[17px] items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground shadow-md",
                      children: snapshot.itemCount,
                    })
                  : null,
              ],
            }),
            jsx.jsx("span", {
              className: "jluxe-mobile-nav-label leading-none",
              ...(item.action === "account" ? { "data-jluxe-account-label": "" } : {}),
              children: item.label,
            }),
          ],
        },
        item.id,
      );
    }),
  });
}

export { FloatingMobileNav as default };
