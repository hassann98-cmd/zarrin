import { useNavPress } from "../lib/use-nav-press.js";
import { useAuthStatus } from "../lib/use-auth-status.js";
import { siteUrl } from "../lib/api.js";
import {
  getActiveMobileDrawer,
  hasMobileDrawerRegistration,
  openMobileDrawer,
  subscribeMobileDrawerState,
  toggleMobileDrawer,
} from "../lib/mobile-drawers.js";
import {
  isMobileNavItemActive as isActive,
  mobileNavContainerStyle,
} from "../lib/mobile-navigation.js";
import { j as jsx } from "../lib/jsx.js";
import { r as React } from "../lib/icons.js";
import { g as getThemeSettings } from "../lib/theme-settings.js";
import { u as useCart } from "../lib/use-cart.js";
import { N as navIcons, H as fallbackIcon } from "../components/nav-icons.js";
import {
  prefetchMobileHome,
  scheduleMobileHomePrefetch,
} from "../lib/mobile-home-prefetch.js";
import {
  getMobilePriceBarVisible,
  getMobilePriceBarVisibleFromEvent,
  hasExternalMobileNavigation,
  hasExternalMobileNavigationFromEvent,
} from "../lib/mobile-dock-mode.js";

const DESTINATIONS = {
  track: { href: siteUrl("track_order") },
  shop: { href: siteUrl("shop"), opensDrawer: "categories" },
  home: { href: siteUrl("home") },
  account: { href: siteUrl("dashboard") },
  cart: { href: siteUrl("cart"), opensDrawer: "cart" },
};

function isModifiedClick(event) {
  return (
    event.defaultPrevented ||
    event.button !== 0 ||
    event.metaKey ||
    event.ctrlKey ||
    event.shiftKey ||
    event.altKey
  );
}

function MobileNav() {
  const { snapshot } = useCart();
  const settings = getThemeSettings();
  const homeHref = DESTINATIONS.home.href;
  const mobile = settings.mobile ?? {};
  const style = mobile.nav_style ?? {};
  const isSingleProduct =
    typeof document !== "undefined" &&
    document.body?.classList.contains("single-product");
  const loggedIn = useAuthStatus();
  const pressProps = useNavPress();
  const [activeDrawer, setActiveDrawer] = React.useState(() =>
    typeof window === "undefined" ? null : getActiveMobileDrawer(window),
  );
  const reducedMotion =
    typeof window !== "undefined" &&
    window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;
  const animate = style.animate !== false && !reducedMotion;
  const [currentHref, setCurrentHref] = React.useState(
    typeof window === "undefined" ? "/" : window.location.href,
  );
  const [hasPriceBar, setHasPriceBar] = React.useState(() =>
    typeof document !== "undefined" && getMobilePriceBarVisible(document),
  );
  const [hasExternalProductNav, setHasExternalProductNav] = React.useState(
    () =>
      typeof document !== "undefined" &&
      document.body?.classList.contains("single-product") &&
      hasExternalMobileNavigation(document),
  );

  React.useEffect(
    () => subscribeMobileDrawerState(setActiveDrawer, window),
    [],
  );
  React.useEffect(() => {
    const syncMode = (event) => {
      setHasPriceBar(getMobilePriceBarVisibleFromEvent(event, document));
      setHasExternalProductNav(
        document.body?.classList.contains("single-product") &&
          hasExternalMobileNavigationFromEvent(event, document),
      );
    };
    window.addEventListener("jluxe:toggle-mobile-bar", syncMode);
    window.addEventListener("pageshow", syncMode);
    // The visible HTML toggle can be used before this island hydrates.
    syncMode();
    return () => {
      window.removeEventListener("jluxe:toggle-mobile-bar", syncMode);
      window.removeEventListener("pageshow", syncMode);
    };
  }, []);
  React.useEffect(() => {
    const syncPath = () => setCurrentHref(window.location.href);
    window.addEventListener("popstate", syncPath);
    return () => window.removeEventListener("popstate", syncPath);
  }, []);
  React.useEffect(
    () => scheduleMobileHomePrefetch(homeHref, window),
    [homeHref],
  );

  if (hasPriceBar || hasExternalProductNav) return null;

  const colors = {
    background: style.background ?? "#fff",
    active: style.active_color ?? "#a313b9",
    icon: style.icon_color ?? "#7a0f8a",
    iconBg: style.icon_bg ?? "#fae8fd",
    activeBg: style.active_bg ?? "#fae8fd",
    radius: style.radius ?? "22",
    height: style.height ?? "68",
  };
  const shadow =
    style.shadow === "none"
      ? "none"
      : style.shadow === "strong"
        ? "0 -10px 30px -8px rgba(0,0,0,.20)"
        : style.shadow === "soft"
          ? "0 -5px 18px -7px rgba(0,0,0,.10)"
          : "0 -7px 24px -7px rgba(0,0,0,.15)";
  const items = (mobile.nav_items ?? [])
    .filter((item) => item.enabled && DESTINATIONS[item.id])
    .map((item) => ({
      ...item,
      ...DESTINATIONS[item.id],
      href:
        item.id === "account"
          ? siteUrl(loggedIn ? "dashboard" : "login")
          : DESTINATIONS[item.id].href,
      accountLabel:
        item.id === "account" &&
        (!item.label || item.label === "حساب" || item.label === "ورود")
          ? "حساب کاربری"
          : item.label,
      label: item.id === "account"
        ? !loggedIn ? "ورود" : (!item.label || item.label === "حساب" || item.label === "ورود") ? "حساب کاربری" : item.label
        : item.label,
    }));

  return jsx.jsx("nav", {
    className: "jluxe-mobile-nav fixed inset-x-0 bottom-0 z-40 flex items-stretch border-t border-border bg-surface/95 md:hidden",
    style: {
      backgroundColor: isSingleProduct ? "hsl(var(--surface))" : colors.background,
      borderRadius: `${colors.radius}px`,
      boxShadow: shadow,
      color: colors.icon,
      backdropFilter: isSingleProduct || style.blur === false ? "none" : "blur(14px)",
      WebkitBackdropFilter: isSingleProduct || style.blur === false ? "none" : "blur(14px)",
      ...mobileNavContainerStyle(colors.height),
    },
    "aria-label": "ناوبری موبایل",
    "data-jluxe-mobile-nav-dock": "",
    children: [
      jsx.jsx("span", {
        key: "accent-rule",
        style: {
          position: "absolute",
          insetInlineStart: 0,
          insetInlineEnd: 0,
          bottom: "100%",
          height: "1px",
          background: `linear-gradient(90deg,transparent, ${colors.active}, transparent)`,
          opacity: 0.18,
        },
        "aria-hidden": true,
      }),
      ...items.map((item) => {
        const drawerOpen = Boolean(
          item.opensDrawer && activeDrawer === item.opensDrawer,
        );
        const routeActive = isActive(currentHref, item.href, item.id);
        const active = routeActive || drawerOpen;
        const Icon = item.icon ? navIcons[item.icon] ?? fallbackIcon : null;
        return jsx.jsxs(
          "a",
          {
            ...pressProps(item.id),
            href: item.href,
            onClick: (event) => {
              if (isModifiedClick(event)) return;
              if (item.opensDrawer) {
                // Without a mounted drawer island, keep normal link navigation.
                if (!hasMobileDrawerRegistration(item.opensDrawer, window)) return;
                event.preventDefault();
                const closedSuggestions =
                  typeof window.jluxeCloseSuggestedProductsModal === "function" &&
                  window.jluxeCloseSuggestedProductsModal() === true;
                // Dismissing an overlay must reveal/open the requested drawer,
                // not let stale drawer state interpret this tap as a second toggle.
                if (closedSuggestions) openMobileDrawer(item.opensDrawer, window);
                else toggleMobileDrawer(item.opensDrawer, window, activeDrawer);
              } else if (item.id !== "home") {
                setCurrentHref(item.href);
              }
            },
            onPointerEnter:
              item.id === "home"
                ? () => prefetchMobileHome(homeHref, window)
                : undefined,
            onFocus:
              item.id === "home"
                ? () => prefetchMobileHome(homeHref, window)
                : undefined,
            onTouchStart:
              item.id === "home"
                ? () => prefetchMobileHome(homeHref, window)
                : undefined,
            className: "jluxe-mobile-nav-item relative flex flex-1 flex-col items-center justify-center gap-1 pt-1 text-[10.5px] font-medium",
            style: {
              color: active ? colors.active : colors.icon,
              transition: animate
                ? "color 220ms ease,transform 180ms ease"
                : "none",
            },
            "aria-current": routeActive ? "page" : undefined,
            ...(item.id === "account"
              ? {
                  "data-jluxe-account-link": "",
                  "data-jluxe-account-login-href": siteUrl("login"),
                  "data-jluxe-account-dashboard-href": siteUrl("dashboard"),
                  "data-jluxe-account-logged-label": item.accountLabel || "حساب کاربری",
                }
              : {}),
            ...(item.opensDrawer
              ? {
                  "aria-label": drawerOpen
                    ? item.opensDrawer === "cart"
                      ? "بستن سبد خرید"
                      : "بستن دسته‌بندی‌ها"
                    : item.label,
                  "aria-haspopup": "dialog",
                  "aria-expanded": drawerOpen,
                  "aria-controls":
                    item.opensDrawer === "cart"
                      ? "jluxe-cart-drawer-dialog"
                      : "jluxe-category-drawer-dialog",
                  "data-jluxe-drawer-toggle": item.opensDrawer,
                  "data-jluxe-drawer-open": drawerOpen ? "true" : "false",
                }
              : {}),
            children: [
              jsx.jsxs("span", {
                className: "jluxe-mobile-nav-icon relative flex size-10 items-center justify-center rounded-[15px]",
                style: {
                  backgroundColor: active ? colors.activeBg : colors.iconBg,
                  color: active ? colors.active : colors.icon,
                  boxShadow: active
                    ? `0 5px 14px -8px ${colors.active}`
                    : "0 2px 10px -8px rgba(16,24,40,.18)",
                  transform: active ? "translateY(-2px)" : "translateY(0)",
                  transition: animate ? "all 220ms ease" : "none",
                },
                ...(item.id === "cart" ? { "data-jluxe-cart-icon-mobile": "" } : {}),
                children: [
                  Icon ? jsx.jsx(Icon, {
                    className: "size-[21px]",
                    "aria-hidden": true,
                  }) : null,
                  item.id === "cart" && snapshot.itemCount > 0
                    ? jsx.jsx("span", {
                        className: "absolute -end-1 -top-1 flex size-[17px] items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground shadow-md",
                        children: snapshot.itemCount,
                      })
                    : null,
                ],
              }),
              jsx.jsx("span", {
                className: "leading-none",
                ...(item.id === "account" ? { "data-jluxe-account-label": "" } : {}),
                children: item.label,
              }),
            ],
          },
          item.id,
        );
      }),
    ],
  });
}

export { MobileNav as default };
