import { CartHourglass } from "../components/cart-hourglass.js";
import { siteUrl } from "../lib/api.js";
import {
  closeMobileDrawer,
  MOBILE_DRAWER_Z_INDEX,
  registerMobileDrawer,
  setMobileDrawerScrollLock,
} from "../lib/mobile-drawers.js";
import { useDialog } from "../lib/use-dialog.js";
import { j as e } from "../lib/jsx.js";
import { r } from "../lib/icons.js";
import { r as k } from "../lib/react-dom.js";
import { g as H } from "../lib/theme-settings.js";
import { u as I } from "../lib/use-cart.js";
import { S as j } from "../icons/shopping-cart.js";
import { X as u } from "../icons/x.js";
import { T as L } from "../icons/truck.js";
import { T as _ } from "../icons/trash-2.js";
import { M as E, P as M } from "../icons/plus.js";
import { C as q } from "../icons/check.js";
import { T as R } from "../icons/tag.js";
function J() {
  var g;
  const [n, l] = r.useState(!1),
    [y, x] = r.useState(!1),
    [p, o] = r.useState(!1),
    i = r.useRef(null),
    dialogRef = r.useRef(null),
    {
      snapshot: s,
      loading: d,
      quantityPending,
      quantityKeys,
      error: cartError,
      refresh,
      updateQty: f,
      removeItem: v,
      applyCoupon: N,
      removeCoupon: w,
      couponLoading: c,
      couponError: h,
    } = I(),
    [m, b] = r.useState(""),
    shareCopyTimer = r.useRef(null),
    S = ((g = H().cart) == null ? void 0 : g.showCoupon) !== !1;
  async function shareCart(event) {
    event.stopPropagation();
    const button = event.currentTarget;
    const url = s.shareCartUrl;
    if (!url) return;
    if (typeof navigator.share === "function") {
      try {
        await navigator.share({ title: "سبد خرید پیشنهادی", url });
        return;
      } catch (error) {
        if (error?.name === "AbortError") return;
      }
    }
    let copied = false;
    try {
      if (navigator.clipboard && typeof navigator.clipboard.writeText === "function") {
        await navigator.clipboard.writeText(url);
        copied = true;
      }
    } catch {}
    if (!copied) {
      const field = document.createElement("textarea");
      field.value = url;
      field.setAttribute("readonly", "");
      field.style.position = "fixed";
      field.style.opacity = "0";
      document.body.appendChild(field);
      field.select();
      try { copied = document.execCommand("copy"); } catch {}
      field.remove();
    }
    if (!copied) return;
    const label = button.querySelector("[data-share-label]");
    if (label) {
      label.textContent = "لینک سبد کپی شد ✓";
      if (shareCopyTimer.current) window.clearTimeout(shareCopyTimer.current);
      shareCopyTimer.current = window.setTimeout(() => {
        if (label.isConnected) label.textContent = "ارسال لیست سبد برای دیگران";
      }, 2200);
    }
    if (window.matchMedia?.("(pointer: coarse)")?.matches) {
      try { window.JLuxeStorefrontUtils?.haptic?.(); } catch {}
    }
  }
  function closeDrawer() {
    closeMobileDrawer("cart", window);
  }
  useDialog(n && y, dialogRef, closeDrawer);
  return (
    r.useEffect(
      () =>
        registerMobileDrawer(
          "cart",
          {
            open: () => {
              l(!0);
              refresh();
            },
            close: () => l(!1),
          },
          window,
        ),
      [refresh],
    ),
    r.useEffect(() => {
      if (n) {
        x(!0);
        let a = !1;
        const C = requestAnimationFrame(() => {
          const T = requestAnimationFrame(() => {
            a || ((a = !0), o(!0));
          });
          i.current = T;
        });
        i.current = C;
        const z = window.setTimeout(() => {
          a || ((a = !0), o(!0));
        }, 100);
        return () => {
          (i.current !== null && cancelAnimationFrame(i.current),
            window.clearTimeout(z));
        };
      }
      o(!1);
      const exitDelay = window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches
        ? 0
        : 300;
      const t = window.setTimeout(() => x(!1), exitDelay);
      return () => window.clearTimeout(t);
    }, [n]),
    r.useEffect(() => {
      setMobileDrawerScrollLock("cart", y, window);
      return () => setMobileDrawerScrollLock("cart", !1, window);
    }, [y]),
    y
      ? k.createPortal(
          e.jsxs("div", {
            className: `fixed inset-0 ${n ? "" : "pointer-events-none"}`,
            style: { zIndex: MOBILE_DRAWER_Z_INDEX },
            "aria-hidden": !n,
            children: [
              e.jsx("div", {
                className: `jluxe-mobile-drawer-backdrop absolute inset-0 bg-foreground/50 transition-opacity duration-300 ease-out ${p ? "opacity-100" : "opacity-0"}`,
                onClick: closeDrawer,
                "aria-hidden": "true",
              }),
              e.jsxs("div", {
                className: `jluxe-mobile-drawer-panel absolute inset-y-0 left-0 flex h-full w-full max-w-sm flex-col bg-surface shadow-xl transition-transform duration-300 ease-out ${p ? "translate-x-0" : "-translate-x-full"}`,
                id: "jluxe-cart-drawer-dialog",
                role: "dialog",
                ref: dialogRef,
                "aria-modal": n ? "true" : undefined,
                "aria-label": "سبد خرید",
                children: [
                  e.jsxs("div", {
                    className:
                      "flex items-center justify-between border-b border-border p-4",
                    children: [
                      e.jsxs("h2", {
                        className:
                          "flex items-center gap-2 text-body font-bold text-foreground",
                        children: [
                          e.jsx(j, { className: "size-5", "aria-hidden": !0 }),
                          "سبد خرید",
                          s.itemCount > 0
                            ? e.jsxs("span", {
                                className:
                                  "text-caption font-normal text-text-muted",
                                children: [
                                  "(",
                                  s.itemCount.toLocaleString("fa-IR"),
                                  ")",
                                ],
                              })
                            : null,
                        ],
                      }),
                      e.jsx("button", {
                        type: "button",
                        onClick: closeDrawer,
                        "aria-label": "بستن سبد خرید",
                        className:
                          "grid size-9 place-items-center rounded-lg text-text-muted transition-all hover:bg-muted active:scale-90 active:bg-muted",
                        children: e.jsx(u, {
                          className: "size-5",
                          "aria-hidden": !0,
                        }),
                      }),
                    ],
                  }),
                  cartError
                    ? e.jsxs("div", {
                        role: "alert",
                        className: "p-4 text-small text-error",
                        children: [
                          e.jsx("p", { children: cartError }),
                          e.jsx("a", {
                            href: s.cartUrl,
                            "aria-disabled": d || undefined,
                            onClick: (event) => { if (d) event.preventDefault(); },
                            className: "underline",
                            children: "مشاهدهٔ صفحهٔ سبد خرید",
                          }),
                        ],
                      })
                    : null,
                  s.items.length > 0 && s.freeShipping && (!d || quantityPending)
                    ? e.jsxs("div", {
                        className:
                          "border-b border-border bg-muted/40 px-4 py-3",
                        children: [
                          e.jsxs("div", {
                            className:
                              "mb-2 flex items-center gap-1.5 text-caption font-medium",
                            children: [
                              e.jsx(L, {
                                className: `size-4 ${s.freeShipping.achieved ? "text-success" : "text-primary"}`,
                                "aria-hidden": !0,
                              }),
                              s.freeShipping.achieved
                                ? e.jsx("span", {
                                    className: "text-success",
                                    children: "ارسال شما رایگان شد 🎉",
                                  })
                                : e.jsxs("span", {
                                    className: "text-text-secondary",
                                    children: [
                                      "فقط ",
                                      e.jsx("bdi", {
                                        dir: "ltr",
                                        className: "font-bold text-foreground",
                                        dangerouslySetInnerHTML: {
                                          __html: s.freeShipping.remainingHtml,
                                        },
                                      }),
                                      " تا ارسال رایگان!",
                                    ],
                                  }),
                            ],
                          }),
                          e.jsx("div", {
                            className:
                              "h-1.5 overflow-hidden rounded-full bg-border",
                            children: e.jsx("div", {
                              className: `h-full rounded-full transition-all duration-500 ease-out ${s.freeShipping.achieved ? "bg-success" : "bg-primary"}`,
                              style: {
                                width: `${s.freeShipping.progressPercent}%`,
                              },
                            }),
                          }),
                        ],
                      })
                    : null,
                  e.jsx("div", {
                    className: "flex-1 overflow-y-auto p-4",
                    children:
                      d && s.items.length === 0
                        ? e.jsx(CartHourglass, {})
                        : cartError && s.items.length === 0
                          ? null
                          : s.items.length === 0
                            ? e.jsxs("div", {
                                className:
                                  "flex h-full flex-col items-center justify-center gap-3 py-12 text-center",
                                children: [
                                  e.jsx("span", {
                                    className:
                                      "grid size-16 place-items-center rounded-2xl bg-muted text-text-muted/60",
                                    children: e.jsx(j, {
                                      className: "size-8",
                                      "aria-hidden": !0,
                                    }),
                                  }),
                                  e.jsxs("div", {
                                    children: [
                                      e.jsx("p", {
                                        className:
                                          "text-small font-bold text-foreground",
                                        children: "سبد خرید شما خالی است",
                                      }),
                                      e.jsx("p", {
                                        className:
                                          "mt-1 text-caption text-text-muted",
                                        children:
                                          "هنوز محصولی اضافه نکرده‌اید.",
                                      }),
                                    ],
                                  }),
                                  e.jsx("a", {
                                    href: siteUrl("shop"),
                                    onClick: closeDrawer,
                                    className:
                                      "mt-1 rounded-xl bg-primary px-5 py-2.5 text-caption font-bold text-primary-foreground transition-all hover:bg-primary-hover active:scale-95",
                                    children: "شروع خرید",
                                  }),
                                ],
                              })
                            : e.jsx("ul", {
                                className: "flex flex-col gap-1",
                                children: s.items.map((t) =>
                                  e.jsxs(
                                    "li",
                                    {
                                      className:
                                        "flex gap-3 rounded-xl p-2 transition-colors hover:bg-muted/50",
                                      children: [
                                        e.jsx("a", {
                                          href: t.url,
                                          className:
                                            "size-16 shrink-0 overflow-hidden rounded-xl border border-border bg-muted",
                                          children: e.jsx("img", {
                                            src: t.image,
                                            alt: t.name,
                                            className: "size-full object-contain",
                                          }),
                                        }),
                                        e.jsxs("div", {
                                          className: "min-w-0 flex-1",
                                          children: [
                                            e.jsx("a", {
                                              href: t.url,
                                              className:
                                                "line-clamp-2 text-caption font-medium text-foreground hover:text-primary",
                                              children: t.name,
                                            }),
                                            t.variation
                                              ? e.jsx("p", {
                                                  className:
                                                    "mt-0.5 text-[11px] text-text-muted",
                                                  children: t.variation,
                                                })
                                              : null,
                                            e.jsxs("div", {
                                              className:
                                                "mt-1.5 flex items-center justify-between gap-2",
                                              children: [
                                                e.jsxs("div", {
                                                  className:
                                                    "flex items-center gap-1 rounded-lg border border-border",
                                                  children: [
                                                    e.jsx("button", {
                                                      type: "button",
                                                      disabled: d && !quantityPending,
                                                      onClick: () => {
                                                        window.JLuxeStorefrontUtils?.haptic?.();
                                                        f(t.key, t.qty - 1);
                                                      },
                                                      "aria-label":
                                                        "کاهش تعداد",
                                                      className:
                                                        "grid size-7 place-items-center text-text-secondary transition-all hover:bg-muted active:scale-90 active:bg-muted disabled:opacity-40 disabled:active:scale-100",
                                                      children:
                                                        t.qty <= 1
                                                          ? e.jsx(_, {
                                                              className:
                                                                "size-3.5",
                                                              "aria-hidden": !0,
                                                            })
                                                          : e.jsx(E, {
                                                              className:
                                                                "size-3.5",
                                                              "aria-hidden": !0,
                                                            }),
                                                    }),
                                                    e.jsx("span", {
                                                      className:
                                                        "w-5 text-center text-caption font-bold tabular-nums text-foreground",
                                                      children:
                                                        t.qty.toLocaleString(
                                                          "fa-IR",
                                                        ),
                                                    }),
                                                    e.jsx("button", {
                                                      type: "button",
                                                      disabled:
                                                        (d && !quantityPending) || t.qty >= t.maxQty,
                                                      onClick: () => {
                                                        window.JLuxeStorefrontUtils?.haptic?.();
                                                        f(t.key, t.qty + 1);
                                                      },
                                                      "aria-label":
                                                        "افزایش تعداد",
                                                      className:
                                                        "grid size-7 place-items-center text-text-secondary transition-all hover:bg-muted active:scale-90 active:bg-muted disabled:opacity-40 disabled:active:scale-100",
                                                      children: e.jsx(M, {
                                                        className: "size-3.5",
                                                        "aria-hidden": !0,
                                                      }),
                                                    }),
                                                  ],
                                                }),
                                                e.jsx("span", {
                                                  className:
                                                    "text-caption font-bold text-foreground",
                                                  children: quantityKeys.includes(String(t.key))
                                                    ? e.jsx(CartHourglass, {})
                                                    : e.jsx("span", { dangerouslySetInnerHTML: { __html: t.lineTotalHtml } }),
                                                }),
                                              ],
                                            }),
                                          ],
                                        }),
                                        e.jsx("button", {
                                          type: "button",
                                          disabled: d || quantityKeys.includes(String(t.key)),
                                          onClick: () => v(t.key),
                                          "aria-label": "حذف از سبد خرید",
                                          className:
                                            "grid size-7 shrink-0 place-items-center rounded-lg text-text-muted transition-all hover:bg-muted hover:text-error active:scale-90 active:bg-muted active:text-error disabled:opacity-40 disabled:active:scale-100",
                                          children: e.jsx(u, {
                                            className: "size-4",
                                            "aria-hidden": !0,
                                          }),
                                        }),
                                      ],
                                    },
                                    t.key,
                                  ),
                                ),
                              }),
                  }),
                  s.items.length > 0
                    ? e.jsxs("div", {
                        className: "border-t border-border p-4",
                        children: [
                          s.coupons.length > 0
                            ? e.jsx("ul", {
                                className: "mb-3 flex flex-col gap-1.5",
                                children: s.coupons.map((t) =>
                                  e.jsxs(
                                    "li",
                                    {
                                      className:
                                        "flex items-center justify-between gap-2 rounded-lg bg-success/10 px-3 py-2 text-caption",
                                      children: [
                                        e.jsxs("span", {
                                          className:
                                            "flex items-center gap-1.5 font-medium text-success",
                                          children: [
                                            e.jsx(q, {
                                              className: "size-3.5",
                                              "aria-hidden": !0,
                                            }),
                                            e.jsx("bdi", {
                                              dir: "ltr",
                                              children: t.code,
                                            }),
                                          ],
                                        }),
                                        e.jsxs("div", {
                                          className: "flex items-center gap-2",
                                          children: [
                                            e.jsx("span", {
                                              className: "text-text-secondary",
                                              dangerouslySetInnerHTML: {
                                                __html: t.discountHtml,
                                              },
                                            }),
                                            e.jsx("button", {
                                              type: "button",
                                              onClick: () => w(t.code),
                                              disabled: c,
                                              "aria-label": `حذف کد تخفیف ${t.code}`,
                                              className:
                                                "text-text-muted transition-colors hover:text-error disabled:opacity-40",
                                              children: e.jsx(u, {
                                                className: "size-3.5",
                                                "aria-hidden": !0,
                                              }),
                                            }),
                                          ],
                                        }),
                                      ],
                                    },
                                    t.code,
                                  ),
                                ),
                              })
                            : null,
                          S
                            ? e.jsxs(e.Fragment, {
                                children: [
                                  e.jsxs("form", {
                                    onSubmit: (t) => {
                                      t.preventDefault();
                                      const a = m.trim();
                                      a && (N(a), b(""));
                                    },
                                    className: "mb-3 flex items-center gap-2",
                                    children: [
                                      e.jsxs("div", {
                                        className: "relative flex-1",
                                        children: [
                                          e.jsx(R, {
                                            className:
                                              "pointer-events-none absolute start-3 top-1/2 size-3.5 -translate-y-1/2 text-text-muted",
                                            "aria-hidden": !0,
                                          }),
                                          e.jsx("input", {
                                            type: "text",
                                            value: m,
                                            onChange: (t) => b(t.target.value),
                                            placeholder: "کد تخفیف",
                                            disabled: c,
                                            className:
                                              "w-full rounded-lg border border-border bg-surface py-2 ps-8 pe-3 text-caption text-foreground placeholder:text-text-muted focus:border-primary focus:outline-none disabled:opacity-60",
                                          }),
                                        ],
                                      }),
                                      e.jsx("button", {
                                        type: "submit",
                                        disabled: c || !m.trim(),
                                        className:
                                          "shrink-0 rounded-lg border border-border px-3 py-2 text-caption font-medium text-text-secondary transition-colors hover:border-primary hover:text-primary disabled:opacity-40",
                                        children: "اعمال",
                                      }),
                                    ],
                                  }),
                                  h
                                    ? e.jsx("p", {
                                        className:
                                          "-mt-2 mb-3 text-[11px] text-error",
                                        children: h,
                                      })
                                    : null,
                                ],
                              })
                            : null,
                          e.jsxs("div", {
                            className:
                              "mb-1 flex items-center justify-between text-body",
                            children: [
                              e.jsx("span", {
                                className: "font-medium text-text-secondary",
                                children: "جمع کل",
                              }),
                              e.jsx("span", {
                                className: "font-bold text-foreground",
                                "aria-busy": d,
                                children: e.jsxs("span", {
                                  className: "inline-flex items-center gap-2",
                                  children: [
                                    e.jsx("span", {
                                      className: d ? "opacity-60" : undefined,
                                      title: d ? "آخرین مبلغ تأییدشده؛ در حال بررسی مبلغ جدید" : undefined,
                                      dangerouslySetInnerHTML: { __html: s.subtotalHtml },
                                    }),
                                    d ? e.jsx(CartHourglass, {}) : null,
                                  ],
                                }),
                              }),
                            ],
                          }),
                          s.discountHtml && !d
                            ? e.jsxs("div", {
                                className:
                                  "mb-3 flex items-center justify-between text-caption",
                                children: [
                                  e.jsx("span", {
                                    className: "text-text-muted",
                                    children: "تخفیف",
                                  }),
                                  e.jsx("span", {
                                    className: "font-medium text-success",
                                    dangerouslySetInnerHTML: {
                                      __html: s.discountHtml,
                                    },
                                  }),
                                ],
                              })
                            : e.jsx("div", { className: "mb-3" }),
                          e.jsx("a", {
                            href: s.cartUrl,
                            "aria-disabled": d || undefined,
                            onClick: (event) => { if (d) event.preventDefault(); },
                            className:
                              "flex h-12 items-center justify-center rounded-xl bg-primary text-button font-medium text-primary-foreground transition-colors hover:bg-primary-hover",
                            children: "مشاهده سبد خرید",
                          }),
                          s.shareCartEnabled && s.shareCartUrl
                            ? e.jsx("button", {
                                type: "button",
                                "data-jluxe-mini-cart-share": "",
                                "data-share-url": s.shareCartUrl,
                                onClick: shareCart,
                                className: "mt-2 flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-border bg-surface text-caption font-bold text-text-secondary transition-colors hover:bg-muted",
                                children: e.jsx("span", { "data-share-label": "", "aria-live": "polite", children: "ارسال لیست سبد برای دیگران" }),
                              })
                            : null,
                        ],
                      })
                    : null,
                ],
              }),
            ],
          }),
          document.body,
        )
      : null
  );
}
export { J as default };
