<?php
/**
 * چیدمانِ سومِ مستقلِ صفحهٔ محصول — طرحِ مرجعِ سه‌ستونه با گالریِ بزرگ،
 * خلاصه/ویژگی‌های پویا، جعبهٔ خرید و بخش‌های توضیحات/مشخصات/دیدگاه‌ها.
 * این فایل فقط با انتخاب «طرح سوم» از تنظیمات رندر می‌شود؛ قالب‌های پیش‌فرض
 * و کلاسیک دست‌نخورده باقی می‌مانند. قراردادهای واقعیِ ووکامرس (قیمت،
 * تنوع، افزودن به سبد، گالری و دیدگاه‌ها) همان‌جا حفظ شده‌اند.
 *
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

$rating       = (float) $product->get_average_rating();
$review_count = (int) $product->get_review_count();
$cp3_reviews_globally_enabled = ! function_exists( 'wc_reviews_enabled' ) || wc_reviews_enabled();
$cp3_product_reviews_open    = function_exists( 'comments_open' ) && comments_open( (int) $product->get_id() );
$cp3_review_form_open         = $cp3_reviews_globally_enabled && $cp3_product_reviews_open;
$cp3_review_closed_reason     = ! $cp3_reviews_globally_enabled
	? 'دیدگاه‌های محصولات در تنظیمات کلی ووکامرس غیرفعال است.'
	: 'دیدگاه این محصول در وردپرس بسته است؛ تنظیمات پیشرفتهٔ محصول و بستن خودکار دیدگاه‌ها را بررسی کنید.';

/* مشخصات: همه‌ی ویژگی‌های نمایان، با علامتِ «تنوع‌ساز» */
$cp3_specs     = array();
$cp3_variation_specs = array();
foreach ( array_filter( $product->get_attributes(), 'wc_attributes_array_filter_visible' ) as $attribute ) {
	$attribute_name = (string) $attribute->get_name();
	$raw_values     = $attribute->is_taxonomy()
		? wc_get_product_terms( $product->get_id(), $attribute_name, array( 'fields' => 'all' ) )
		: $attribute->get_options();
	$values = $attribute->is_taxonomy() ? wp_list_pluck( $raw_values, 'name' ) : $raw_values;
	$row    = array(
		'label'    => wc_attribute_label( $attribute_name ),
		'value'    => implode( '، ', $values ),
		'swatches' => jluxe_attribute_swatch_options( $attribute_name, (array) $raw_values, $product ),
	);
	if ( $attribute->get_variation() ) {
		$cp3_variation_specs[] = $row;
	} else {
		$cp3_specs[] = $row;
	}
}
$cp3_advanced_attribute_groups = jluxe_get_product_advanced_attribute_groups( (int) $product->get_id() );
$cp3_display_advanced_groups   = jluxe_get_displayable_product_specification_groups( $cp3_advanced_attribute_groups );
$cp3_has_specs                 = $cp3_advanced_attribute_groups
	? ! empty( $cp3_display_advanced_groups )
	: ( ! empty( $cp3_specs ) || ! empty( $cp3_variation_specs ) );
$cp3_additional_spec_rows       = $cp3_advanced_attribute_groups
	? jluxe_get_additional_product_specification_rows( $product, $cp3_advanced_attribute_groups )
	: array();

$jluxe_is_variable                    = $product->is_type( 'variable' );
$jluxe_is_simple                      = $product->is_type( 'simple' );
$jluxe_variation_attributes           = array();
$jluxe_available_variations           = array();
$cp3_defaults                         = array();
$cp3_default_variation_price_html     = '';
$cp3_price_placeholder                = '';
if ( $jluxe_is_variable ) {
	$jluxe_variation_attributes       = $product->get_variation_attributes();
	$jluxe_available_variations       = jluxe_available_variations_for_form( $product );
	$cp3_defaults                     = function_exists( 'jluxe_default_variation_pick' ) ? jluxe_default_variation_pick( $product ) : array();
	$cp3_default_variation_price_html = function_exists( 'jluxe_default_variable_variation_price_html' ) ? jluxe_default_variable_variation_price_html( $product, $cp3_defaults ) : '';
	$cp3_price_placeholder            = empty( $cp3_defaults ) ? 'ناموجود' : 'برای دیدن قیمت دقیق، یک تنوع را انتخاب کنید.';
	wp_enqueue_script( 'wc-add-to-cart-variation' );
}
$cp3_is_in_stock = $jluxe_is_variable ? ! empty( $cp3_defaults ) : $product->is_in_stock();
$cp3_no_available_variation = $jluxe_is_variable && empty( $cp3_defaults );

$jluxe_gallery_ids = $product->get_gallery_image_ids();
$jluxe_main_id     = $product->get_image_id();
if ( $jluxe_main_id ) {
	array_unshift( $jluxe_gallery_ids, $jluxe_main_id );
}
$jluxe_gallery_ids = array_values( array_unique( array_filter( $jluxe_gallery_ids ) ) );
if ( empty( $jluxe_gallery_ids ) ) {
	$jluxe_gallery_ids = array( 0 );
}

$cp3_breadcrumbs   = jluxe_breadcrumb_items( $product );
$cp3_short_desc    = $product->get_short_description();
$cp3_delivery_time = jluxe_get_product_delivery_time( $product );
$cp3_delivery_time_visible = jluxe_is_product_delivery_time_enabled( $product );
$cp3_faq_items   = function_exists( 'jluxe_get_product_faq_items' ) ? jluxe_get_product_faq_items( $product->get_id() ) : array();
$cp3_stock_qty   = jluxe_product_stock_quantity_for_display( $product, $jluxe_is_variable ? $cp3_defaults : null );
$cp3_stock_qty   = is_numeric( $cp3_stock_qty ) ? (int) $cp3_stock_qty : null;
$cp3_stock_warning_is_low = null !== $cp3_stock_qty && $cp3_stock_qty > 0 && $cp3_stock_qty <= 10;
$cp3_english_product_name = function_exists( 'jluxe_get_product_english_name' ) ? jluxe_get_product_english_name( $product ) : '';
$cp3_mobile_in_stock      = $cp3_is_in_stock;
$cp3_mobile_rating_fill   = (int) round( max( 0, min( 5, $rating ) ) * 20 );

$cp3_mobile_category_terms = function_exists( 'taxonomy_exists' ) && taxonomy_exists( 'product_cat' ) && function_exists( 'wc_get_product_terms' )
	? wc_get_product_terms( $product->get_id(), 'product_cat', array( 'fields' => 'all' ) )
	: array();
if ( is_wp_error( $cp3_mobile_category_terms ) ) {
	$cp3_mobile_category_terms = array();
}
$cp3_mobile_category      = ! empty( $cp3_mobile_category_terms ) ? reset( $cp3_mobile_category_terms ) : null;
$cp3_mobile_category_name = is_object( $cp3_mobile_category ) && isset( $cp3_mobile_category->name ) ? trim( (string) $cp3_mobile_category->name ) : '';
$cp3_mobile_category_link = '';
if ( '' !== $cp3_mobile_category_name && function_exists( 'get_term_link' ) ) {
	$cp3_mobile_category_url = get_term_link( $cp3_mobile_category );
	if ( ! is_wp_error( $cp3_mobile_category_url ) ) {
		$cp3_mobile_category_link = (string) $cp3_mobile_category_url;
	}
}

$cp3_mobile_brand_terms = function_exists( 'taxonomy_exists' ) && taxonomy_exists( 'product_brand' ) && function_exists( 'wc_get_product_terms' )
	? wc_get_product_terms( $product->get_id(), 'product_brand', array( 'fields' => 'all' ) )
	: array();
if ( is_wp_error( $cp3_mobile_brand_terms ) ) {
	$cp3_mobile_brand_terms = array();
}
$cp3_mobile_brand      = ! empty( $cp3_mobile_brand_terms ) ? reset( $cp3_mobile_brand_terms ) : null;
$cp3_mobile_brand_name = is_object( $cp3_mobile_brand ) && isset( $cp3_mobile_brand->name ) ? trim( (string) $cp3_mobile_brand->name ) : '';
$cp3_mobile_brand_link = '';
if ( '' !== $cp3_mobile_brand_name && function_exists( 'get_term_link' ) ) {
	$cp3_mobile_brand_url = get_term_link( $cp3_mobile_brand );
	if ( ! is_wp_error( $cp3_mobile_brand_url ) ) {
		$cp3_mobile_brand_link = (string) $cp3_mobile_brand_url;
	}
}
$cp3_mobile_back_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
if ( ! $cp3_mobile_back_url ) {
	$cp3_mobile_back_url = home_url( '/' );
}

/* خلاصه‌ی رأی‌ها: مثبت (۴–۵)، بی‌طرف (۳)، منفی (۱–۲) */
$cp3_counts = array( 'pos' => 0, 'neu' => 0, 'neg' => 0 );
foreach ( (array) $product->get_rating_counts() as $cp3_stars => $cp3_c ) {
	$cp3_stars = (int) $cp3_stars;
	if ( $cp3_stars >= 4 ) {
		$cp3_counts['pos'] += (int) $cp3_c;
	} elseif ( 3 === $cp3_stars ) {
		$cp3_counts['neu'] += (int) $cp3_c;
	} else {
		$cp3_counts['neg'] += (int) $cp3_c;
	}
}
?>
<style>
/* ====== CP3 — چیدمانِ سومِ مستقلِ طرحِ مرجع ====== */
.jluxe-cp3{background:hsl(var(--background))}
.jluxe-cp3 .cp3-bc{display:flex;flex-wrap:wrap;align-items:center;gap:6px 8px;min-width:0;padding:14px 0 6px;color:hsl(var(--text-muted));font-size:13px;line-height:1.7}
.jluxe-cp3 .cp3-bc>div{display:inline-flex;flex:0 1 auto;align-items:center;gap:6px;min-width:0;max-width:100%}
.jluxe-cp3 .cp3-bc a{min-width:0;max-width:100%;color:hsl(var(--text-secondary));overflow-wrap:anywhere;transition:color .15s}
.jluxe-cp3 .cp3-bc a:hover{color:hsl(var(--primary))}
.jluxe-cp3 .cp3-bc svg{width:14px;height:14px;flex:0 0 14px;opacity:.55}
.jluxe-cp3 .cp3-bc .is-current{flex:1 1 260px;min-width:0;max-width:100%;color:hsl(var(--foreground));font-size:12.5px;line-height:1.65;overflow-wrap:anywhere;white-space:normal}
@media(max-width:767.98px){.jluxe-cp3 .cp3-bc{gap:5px 7px;padding-top:10px;font-size:11.5px}.jluxe-cp3 .cp3-bc>div{gap:4px}.jluxe-cp3 .cp3-bc svg{width:12px;height:12px;flex-basis:12px}.jluxe-cp3 .cp3-bc .is-current{flex-basis:100%;font-size:12px;font-weight:600}}
.jluxe-cp3 .cp3-card{position:relative;background:hsl(var(--surface));border-radius:18px;box-shadow:0 3px 5px rgba(0,0,0,.05);padding:20px;margin-top:5px}
.jluxe-cp3 .cp3-grid{display:flex;flex-direction:column}
@media(min-width:768px){.jluxe-cp3 .cp3-grid{flex-direction:row}}
.jluxe-cp3 .cp3-gallery{padding-inline-end:0}
@media(min-width:768px){.jluxe-cp3 .cp3-gallery{flex:none;width:460px;padding-inline-end:40px;border-inline-end:1px dashed hsl(var(--panel-border))}}
.jluxe-cp3 .cp3-zoom{appearance:none;position:relative;height:344px;width:100%;border:0;padding:0;color:inherit;font:inherit;text-align:inherit;border-radius:30px;background:linear-gradient(180deg,hsl(var(--surface-elevated)),hsl(var(--muted)));margin-bottom:16px;display:flex;align-items:center;justify-content:center;overflow:hidden;cursor:zoom-in;box-shadow:0 1px 2px rgba(16,24,40,.05)}
.jluxe-cp3 .cp3-zoom::after{content:'';position:absolute;inset:0;border-radius:inherit;box-shadow:inset 0 0 0 1px rgba(16,24,40,.04);pointer-events:none}
@media(min-width:768px){.jluxe-cp3 .cp3-zoom{height:420px;width:420px;max-width:100%}}
.jluxe-cp3 .cp3-zoom img{width:100%;height:100%;object-fit:contain;transition:opacity .45s ease,transform .3s ease-out;will-change:transform;opacity:0}
.jluxe-cp3 .cp3-zoom img.is-loaded{opacity:1}
@media (prefers-reduced-motion: reduce){.jluxe-cp3 .cp3-zoom img{transition:none;opacity:1}}
.jluxe-cp3 .cp3-thumbs{display:flex;gap:8px;flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none;-ms-overflow-style:none;padding:2px;scroll-snap-type:x mandatory}
.jluxe-cp3 .cp3-thumbs::-webkit-scrollbar{display:none}
.jluxe-cp3 .cp3-thumb{scroll-snap-align:start;flex:none;width:96px;height:96px;border-radius:15px;background:hsl(var(--muted));padding:4px;overflow:hidden;cursor:pointer;border:2px solid transparent;transition:border-color .15s,background .15s,transform .15s,box-shadow .15s}
.jluxe-cp3 .cp3-thumb img{width:100%;height:100%;object-fit:contain;border-radius:11px}
.jluxe-cp3 .cp3-thumb:hover{background:hsl(var(--muted-foreground)/.15);transform:translateY(-2px)}
.jluxe-cp3 .cp3-thumb.is-active{border-color:hsl(var(--primary));box-shadow:0 4px 12px rgba(16,24,40,.07)}
.jluxe-cp3 .cp3-thumbsrow{display:flex;align-items:center;gap:8px}
.jluxe-cp3 .cp3-thumbs{flex:1 1 auto;min-width:0}
.jluxe-cp3 .cp3-tarrow{flex:none;width:34px;height:34px;border-radius:12px;border:1px solid hsl(var(--panel-border));background:hsl(var(--surface));color:hsl(var(--text-secondary));display:inline-flex;align-items:center;justify-content:center;cursor:pointer;transition:all .15s;font-family:inherit}
.jluxe-cp3 .cp3-tarrow:hover:not(:disabled){background:hsl(var(--primary)/.1);color:hsl(var(--primary));border-color:hsl(var(--primary)/.4)}
.jluxe-cp3 .cp3-tarrow:disabled{opacity:.3;cursor:default}
@media (prefers-reduced-motion: reduce){.jluxe-cp3 .cp3-tarrow{transition:none}}
/* باگِ واقعی (R58): display:inline-flexِ کلاس، اتریبیوتِ hidden مرورگر را خنثی می‌کند
(استایلِ نویسنده همیشه بر UA استایل مقدم است) — فلش‌ها حتی بدونِ سرریز دیده می‌شدند. */
.jluxe-cp3 .cp3-tarrow[hidden]{display:none}
@media (prefers-reduced-motion: reduce){.jluxe-cp3 .cp3-thumb{transition:none}}
.jluxe-cp3-gallery-modal{position:fixed;inset:0;z-index:99999;box-sizing:border-box;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:16px;background:hsl(var(--foreground)/.96);color:hsl(var(--surface));opacity:0;transition:opacity .22s ease}
.jluxe-cp3-gallery-modal:not(.opacity-0){opacity:1}
.jluxe-cp3-gallery-modal__top{display:flex;align-items:center;justify-content:space-between;gap:16px;width:min(100%,1200px);min-height:44px}
.jluxe-cp3-gallery-modal__counter{font-size:13px;font-variant-numeric:tabular-nums;color:hsl(var(--surface)/.82)}
.jluxe-cp3-gallery-modal__stage{display:flex;flex-direction:row;direction:ltr;align-items:center;justify-content:center;gap:12px;width:min(100%,1280px);height:min(82vh,900px);min-height:0}
.jluxe-cp3-gallery-modal__track{position:relative;display:flex;flex:1 1 auto;align-items:center;justify-content:center;align-self:stretch;min-width:0;overflow:hidden;touch-action:none}
.jluxe-cp3-gallery-modal__track img{position:absolute;inset:0;display:block;width:auto;height:auto;max-width:100%;max-height:100%;margin:auto;object-fit:contain;opacity:0;pointer-events:none;user-select:none;-webkit-user-drag:none;transform:scale(.96);transform-origin:center center;transition:opacity .18s ease,transform .15s ease-out;will-change:transform}
.jluxe-cp3-gallery-modal__track img[aria-hidden="false"]{opacity:1;pointer-events:auto;transform:translate3d(0,0,0) scale(1);cursor:zoom-in}
.jluxe-cp3-gallery-modal__track img[aria-hidden="false"][data-jluxe-zoom-scale]:not([data-jluxe-zoom-scale="1"]){cursor:grab}
.jluxe-cp3-gallery-modal__button{display:inline-flex;flex:none;align-items:center;justify-content:center;width:44px;height:44px;border:1px solid hsl(var(--surface)/.24);border-radius:14px;background:hsl(var(--surface)/.1);color:inherit;cursor:pointer;transition:background .15s ease,color .15s ease}
.jluxe-cp3-gallery-modal__button:hover{background:hsl(var(--surface)/.2)}
.jluxe-cp3-gallery-modal__button:focus-visible{outline:2px solid hsl(var(--accent));outline-offset:3px}
.jluxe-cp3-gallery-modal__close{border-color:transparent;background:transparent}
@media(max-width:767px){.jluxe-cp3-gallery-modal{gap:8px;padding:10px}.jluxe-cp3-gallery-modal__stage{gap:4px;width:100%;height:78vh;direction:ltr}.jluxe-cp3-gallery-modal__button{width:40px;height:40px;border-radius:12px}.jluxe-cp3-gallery-modal__track img{max-width:100%;max-height:100%}}
@media (prefers-reduced-motion:reduce){.jluxe-cp3-gallery-modal,.jluxe-cp3-gallery-modal__button,.jluxe-cp3-gallery-modal__track img{transition:none}}
.jluxe-cp3 .cp3-info{flex:1 1 0;min-width:min(250px,100%);padding-inline-start:0;margin-top:16px}
@media(min-width:768px){.jluxe-cp3 .cp3-info{padding-inline-start:16px;margin-top:0}}
.jluxe-cp3 .cp3-title{font-size:20px;font-weight:800;line-height:1.6;color:hsl(var(--foreground));margin:0 0 6px}
.jluxe-cp3 .cp3-meta{display:flex;align-items:center;gap:8px;font-size:12px;color:hsl(var(--text-secondary));padding-top:12px}
.jluxe-cp3 .cp3-meta svg{color:hsl(var(--primary));flex:none}
.jluxe-cp3 .cp3-meta a{color:inherit}
.jluxe-cp3 .cp3-meta a:hover{color:hsl(var(--primary))}
.jluxe-cp3 .cp3-short{font-size:13px;line-height:1.8;color:hsl(var(--text-secondary));padding-top:10px}
.jluxe-cp3 .cp3-short .cp3-short-body{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;margin:0}
.jluxe-cp3 .cp3-short.is-open .cp3-short-body{-webkit-line-clamp:unset}
.jluxe-cp3 .cp3-short-toggle{color:hsl(var(--primary));cursor:pointer;font-size:13px;margin-inline-start:6px;background:none;border:none;padding:0;font-family:inherit}
.jluxe-cp3 .cp3-short-toggle:hover{text-decoration:underline}
.jluxe-cp3 .cp3-varlabel{font-weight:700;color:hsl(var(--foreground));margin-bottom:8px}
.jluxe-cp3 .cp3-pills{display:flex;flex-wrap:wrap;gap:8px}
.jluxe-cp3 .cp3-pill{position:relative;display:inline-flex;align-items:center;min-width:64px;justify-content:center;padding:6px 14px;border-radius:14px;border:1px solid hsl(var(--panel-border));background:transparent;color:hsl(var(--foreground));font-size:14px;font-weight:500;cursor:pointer;transition:all .15s;font-family:inherit}
.jluxe-cp3 .cp3-pill--swatch{gap:8px}
.jluxe-cp3 .cp3-swatch-color,.jluxe-cp3 .cp3-swatch-image{display:inline-block;width:18px;height:18px;flex:none;border-radius:999px}
.jluxe-cp3 .cp3-swatch-color{border:1px solid rgba(15,23,42,.22);box-shadow:inset 0 0 0 1px rgba(255,255,255,.12)}
.jluxe-cp3 .cp3-swatch-image{object-fit:cover;border:1px solid rgba(15,23,42,.18)}
.jluxe-cp3 .cp3-swatch-label{line-height:1.3}
.jluxe-cp3 .cp3-pill:hover{border-color:hsl(var(--primary)/.5)}
.jluxe-cp3 .cp3-pill.is-active{border-color:hsl(var(--primary));box-shadow:0 0 0 1px hsl(var(--primary)/.18),0 3px 9px hsl(var(--primary)/.13)}
/* گزینه‌ای که ووکامرس در update_variation_values کارت می‌کند — مثل مرجع: کم‌رنگ + خط‌خورده */
.jluxe-cp3 .cp3-pill.is-disabled,.jluxe-cp3 .cp3-pill[disabled],.jluxe-cp3 .cp3-pill[aria-disabled="true"]{opacity:.45;text-decoration:line-through;cursor:not-allowed}
.jluxe-cp3 .cp3-pill.is-disabled:hover,.jluxe-cp3 .cp3-pill[disabled]:hover,.jluxe-cp3 .cp3-pill[aria-disabled="true"]:hover{border-color:hsl(var(--panel-border))}
.jluxe-cp3 .cp3-chips-label{font-weight:700;color:hsl(var(--foreground));margin-bottom:10px}
.jluxe-cp3 .cp3-chips{display:flex;gap:8px;flex-wrap:wrap;display:grid;grid-template-columns:repeat(2,minmax(0,1fr))}
.jluxe-cp3 .cp3-chip{background:hsl(var(--panel));border:1px solid hsl(var(--panel-border));border-radius:12px;padding:10px 12px;flex:0 0 calc(50% - 4px);min-width:0;max-width:none}
.jluxe-cp3 .cp3-chip small{display:block;font-size:10px;color:hsl(var(--text-muted));margin-bottom:4px}
.jluxe-cp3 .cp3-chip strong{font-size:12px;color:hsl(var(--foreground));line-height:1.6}
.jluxe-cp3 .cp3-side{padding-inline:0;margin-top:20px}
@media(min-width:768px){.jluxe-cp3 .cp3-side{width:25%;flex:none;margin-top:0;padding-inline-start:16px;position:sticky;top:calc(88px + var(--wp-admin--admin-bar--height,0px));align-self:flex-start}}
.jluxe-cp3 .cp3-sidebox{background:hsl(var(--panel));border:1px solid hsl(var(--panel-border));border-radius:20px;padding:16px;display:flex;flex-direction:column;gap:2px;font-size:12px}
.jluxe-cp3 .cp3-sidebox .cp3-sidehead{font-size:14px;font-weight:800;color:hsl(var(--foreground));margin-bottom:6px}
/* At compact desktop widths the fixed gallery + 250px details + 25% sidebar exceed the card. Keep both primary columns inside the card and move the purchase pane below. */
@media(min-width:768px) and (max-width:1199.98px){.jluxe-cp3 .cp3-grid{flex-wrap:wrap}.jluxe-cp3 .cp3-gallery{flex:0 0 42%;width:42%}.jluxe-cp3 .cp3-info{flex:1 1 58%;min-width:0}.jluxe-cp3 .cp3-side{position:static;top:auto;width:100%;flex:0 0 100%;margin-top:20px;padding-inline:0;align-self:auto}}
.jluxe-cp3 .cp3-row{display:flex;align-items:center;justify-content:space-between;padding:12px 0;font-size:13px;color:hsl(var(--text-secondary))}
.jluxe-cp3 .cp3-row .cp3-rowlab{display:inline-flex;align-items:center;gap:6px}
.jluxe-cp3 .cp3-row .cp3-rowlab svg{color:hsl(var(--primary));flex:none}
.jluxe-cp3 .cp3-row .cp3-rowval{display:flex;align-items:center;gap:4px;font-weight:600;color:hsl(var(--foreground))}
.jluxe-cp3 .cp3-row .is-ok{color:hsl(var(--success))}
.jluxe-cp3 .cp3-row .is-out{color:hsl(var(--error))}
.jluxe-cp3 .cp3-stockwarn{display:flex;align-items:center;gap:10px;background:hsl(var(--primary)/.07);color:hsl(var(--primary));border:none;border-radius:12px;padding:10px 14px;font-size:12px;font-weight:600;margin-top:8px}
.jluxe-cp3 [data-cp3-low-stock][hidden]{display:none!important}
.jluxe-cp3 .cp3-sku{color:hsl(var(--text-muted));font-size:12px;margin:14px 0}
.jluxe-cp3 .cp3-dashed{height:1px;border-bottom:1px dashed hsl(var(--panel-border));margin-bottom:12px}
.jluxe-cp3 .cp3-price{font-size:26px;font-weight:800;color:hsl(var(--foreground))}
.jluxe-cp3 .cp3-price.is-placeholder{font-size:14px;font-weight:600;line-height:1.8;color:hsl(var(--text-muted))}
.jluxe-cp3 .cp3-price del{font-size:18px;font-weight:500;color:hsl(var(--text-muted));margin-inline-end:8px;opacity:.85}
.jluxe-cp3 .cp3-price .jluxe-toman-glyph,.jluxe-sticky-cta-price .jluxe-toman-glyph{display:inline-flex;align-items:center;opacity:.75;vertical-align:middle}
.jluxe-cp3 .cp3-price .jluxe-toman-glyph svg,.jluxe-sticky-cta-price .jluxe-toman-glyph svg{display:block}
.jluxe-sticky-cta-price .jluxe-toman-glyph svg{width:14px;height:auto}
.jluxe-sticky-cta-price del{font-size:13px;font-weight:500;color:hsl(var(--text-muted));margin-inline-end:6px}
.jluxe-cp3 .cp3-price ins{text-decoration:none}
.jluxe-cp3 .cp3-addrow{display:flex;align-items:center;gap:8px;margin-top:14px}
.jluxe-cp3 .cp3-addrow .single_add_to_cart_button,.jluxe-cp3 .cp3-addrow .cp3-add-simple{flex:1;min-height:48px;display:inline-flex;align-items:center;justify-content:center;gap:8px;background:hsl(var(--primary)) !important;color:hsl(var(--primary-foreground)) !important;border:none !important;border-radius:16px !important;font-size:15px !important;font-weight:700 !important;cursor:pointer;padding:12px 16px !important;box-shadow:0 6px 16px hsl(var(--primary)/.25) !important;transition:background .15s,transform .12s;font-family:inherit;line-height:1.2;width:100% !important;max-width:100%;min-width:0;text-align:center}
.jluxe-cp3 .cp3-addrow .single_add_to_cart_button::after,.jluxe-cp3 .cp3-addrow .cp3-add-simple::after{content:'';width:18px;height:18px;flex:none;background:currentColor;-webkit-mask:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none'%3E%3Cpath d='M12 5v14M5 12h14' stroke='black' stroke-width='2.4' stroke-linecap='round'/%3E%3C/svg%3E") no-repeat center/contain;mask:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none'%3E%3Cpath d='M12 5v14M5 12h14' stroke='black' stroke-width='2.4' stroke-linecap='round'/%3E%3C/svg%3E") no-repeat center/contain}
.jluxe-cp3 .cp3-addrow .single_add_to_cart_button:hover{background:hsl(var(--primary-hover))}
.jluxe-cp3 .cp3-addrow .single_add_to_cart_button:disabled{opacity:.5;cursor:not-allowed}
.jluxe-cp3 .cp3-qty{display:flex;align-items:center;gap:8px;margin-top:12px;font-size:12px;color:hsl(var(--text-secondary))}
.jluxe-cp3 .cp3-qty .quantity input{width:76px;min-height:44px;text-align:center;border:1px solid hsl(var(--panel-border));border-radius:12px;background:hsl(var(--surface));color:hsl(var(--foreground));font-family:inherit}
.jluxe-cp3 .cp3-fabs{display:flex;gap:10px;margin-top:16px}
.jluxe-cp3 .cp3-fab{width:40px;height:40px;border-radius:10px;background:hsl(var(--panel));border:1px solid hsl(var(--panel-border));color:hsl(var(--primary));display:inline-flex;align-items:center;justify-content:center;cursor:pointer;transition:transform .12s,background .15s}
.jluxe-cp3 .cp3-fab:hover{background:hsl(var(--primary)/.1)}
.jluxe-cp3 .cp3-fab:active{transform:scale(.95)}
.jluxe-cp3 .cp3-fab.cp3-heart:hover,.jluxe-cp3 .cp3-fab.cp3-heart[aria-pressed="true"]{color:#e0405f}
/* بلاکِ پیش‌فرضِ ووکامرس برای محصولاتِ متغیر — بازنویسیِ کاملِ چیدمان در
ناحیهٔ خرید: کلاس‌های real وو (single_variation_wrap / variations_button /
quantity / single_add_to_cart_button) با اولویت و !important به‌شکلِ
ردیفِ مرتبِ [تعداد | دکمه] درمی‌آیند؛ قلب کنارِ دکمه‌های cp3-fabs می‌ماند.
float و اندازه‌های خودِ وو خنثی می‌شوند تا با هیچ افزونه‌ای هم به‌هم نریزد. */
.jluxe-cp3 .cp3-addrow .woocommerce-variation,.jluxe-cp3 .cp3-addrow .woocommerce-variation-price,.jluxe-cp3 .cp3-addrow .woocommerce-variation-availability{display:none !important}
.jluxe-cp3 .cp3-addrow .single_variation_wrap{flex:1 1 auto;min-width:0;margin:0 !important;display:flex;flex-direction:column}
.jluxe-cp3 .cp3-addrow .woocommerce-variation-add-to-cart{display:flex !important;align-items:center;gap:8px;flex:1 1 auto;min-width:0;float:none !important;margin:0 !important;flex-wrap:nowrap !important}
.jluxe-cp3 .cp3-addrow .woocommerce-variation-add-to-cart::before{display:none !important}
/* استپرِ تعداد، کامپوننتِ خودِ پوسته است (quantity-input.php: .quantity.jluxe-qty
با دکمه‌های − / +). ظاهر و رنگ‌های خودش حفظ می‌شوند؛ فقط در چیدمانِ دسکتاپ،
ارتفاع و اندازهٔ کنترل‌ها با دکمهٔ ۴۸پیکسلی هماهنگ می‌شود. */
.jluxe-cp3 .cp3-addrow .quantity{float:none !important;margin:0 !important;flex:none}
.jluxe-cp3 .cp3-addrow .woocommerce-variation-add-to-cart .jluxe-qty{box-sizing:border-box;height:48px !important;min-height:48px;border-radius:999px}
.jluxe-cp3 .cp3-addrow .woocommerce-variation-add-to-cart .jluxe-qty [data-jluxe-qty-step]{box-sizing:border-box;width:34px;height:44px;min-height:44px}
.jluxe-cp3 .cp3-addrow .woocommerce-variation-add-to-cart .jluxe-qty input.qty{box-sizing:border-box;width:32px;min-width:32px;height:44px;min-height:44px}
.jluxe-cp3 .cp3-addrow.is-simple form.cart{display:flex;flex:1 1 0;flex-direction:column;gap:8px;min-width:0;width:100%;margin:0 !important}
@media(min-width:768px){.jluxe-cp3 .cp3-addrow .quantity{display:flex !important}.jluxe-cp3 .cp3-addrow .woocommerce-variation-add-to-cart-disabled .quantity{display:none !important}}
@media(max-width:767px){.jluxe-cp3 .cp3-addrow{display:none !important}.jluxe-cp3 .cp3-addrow.is-simple{display:flex !important;align-items:flex-end}}
@media(min-width:1280px){
.jluxe-cp3 .cp3-addrow.is-simple form.cart{flex:1 1 auto;flex-direction:row;align-items:center;gap:6px;min-width:0;width:auto}
.jluxe-cp3 .cp3-addrow.is-simple form.cart .jluxe-simple-qty-row{box-sizing:border-box;flex:0 0 auto;min-height:48px;gap:0;padding:4px;border:1px solid hsl(var(--panel-border));border-radius:14px;background:hsl(var(--surface))}
.jluxe-cp3 .cp3-addrow.is-simple form.cart .jluxe-simple-qty-label{display:none}
.jluxe-cp3 .cp3-addrow.is-simple form.cart .jluxe-simple-qty-controls{gap:0}
.jluxe-cp3 .cp3-addrow.is-simple form.cart button.jluxe-simple-qty-step{box-sizing:border-box;flex:0 0 28px;width:28px;min-width:28px;max-width:28px;height:36px;min-height:36px;max-height:36px}
.jluxe-cp3 .cp3-addrow.is-simple form.cart .jluxe-simple-qty-controls input.qty{box-sizing:border-box;flex:0 0 32px;width:32px;min-width:32px;max-width:32px;height:32px;min-height:32px;padding:0}
.jluxe-cp3 .cp3-addrow.is-simple form.cart .single_add_to_cart_button{box-sizing:border-box;flex:1 1 auto !important;width:auto !important;min-width:0;min-height:48px;height:48px;margin:0 !important;padding:8px 6px !important;font-size:12px !important;gap:4px;white-space:nowrap}
.jluxe-cp3 .cp3-addrow.is-simple form.cart .single_add_to_cart_button::after{display:none}
.jluxe-cp3 .cp3-addrow.is-simple .jluxe-simple-add-label-full{display:none}
.jluxe-cp3 .cp3-addrow.is-simple .jluxe-simple-add-label-short{display:inline}
.jluxe-cp3 .cp3-addrow .woocommerce-variation-add-to-cart{gap:6px}
.jluxe-cp3 .cp3-addrow .woocommerce-variation-add-to-cart .jluxe-qty [data-jluxe-qty-step]{width:32px}
.jluxe-cp3 .cp3-addrow .woocommerce-variation-add-to-cart .jluxe-qty input.qty{width:32px;min-width:32px}
.jluxe-cp3 .cp3-addrow .woocommerce-variation-add-to-cart .single_add_to_cart_button{box-sizing:border-box;min-height:48px;height:48px;padding:8px 4px !important;font-size:11px !important;gap:4px}
.jluxe-cp3 .cp3-addrow .woocommerce-variation-add-to-cart .single_add_to_cart_button::after{width:14px;height:14px}
}
.jluxe-cp3 .cp3-addrow .woocommerce-variation-add-to-cart .single_add_to_cart_button{float:none !important;flex:1 1 auto !important;width:auto;max-width:100%;min-width:0;display:inline-flex !important;align-items:center;justify-content:center;gap:8px}
.jluxe-cp3 .cp3-addrow .woocommerce-variation-add-to-cart .single_add_to_cart_button::after{content:'';width:18px;height:18px;flex:none;background:currentColor;-webkit-mask:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none'%3E%3Cpath d='M12 5v14M5 12h14' stroke='black' stroke-width='2.4' stroke-linecap='round'/%3E%3C/svg%3E") no-repeat center/contain;mask:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none'%3E%3Cpath d='M12 5v14M5 12h14' stroke='black' stroke-width='2.4' stroke-linecap='round'/%3E%3C/svg%3E") no-repeat center/contain}
.jluxe-cp3 .cp3-addrow .woocommerce-variation-add-to-cart.woocommerce-variation-add-to-cart-disabled .single_add_to_cart_button{opacity:.5;cursor:not-allowed;pointer-events:none}
/* پیامِ «هیچ تنوعی با این ترکیب هم‌خوانی ندارد» که ووکامرس بعد از .single_variation تزریق می‌کند */
.jluxe-cp3 .cp3-addrow .wc-no-matching-variations{margin:8px 0 0;padding:8px 14px;border-radius:10px;background:hsl(var(--primary)/.06);border:1px dashed hsl(var(--primary)/.35);color:hsl(var(--foreground));font-size:12.5px;line-height:1.9;display:flex;float:none !important}
.jluxe-cp3 .cp3-side .woocommerce-variation-price,.jluxe-cp3 .cp3-side .woocommerce-variation-availability{display:none}
/* نوارِ چسبانِ بخش‌ها */
.jluxe-cp3 .cp3-nav{position:sticky;z-index:30;top:calc(var(--jluxe-product-nav-top,0px) + 6px);display:flex;align-items:center;justify-content:space-between;gap:12px;background:hsl(var(--surface)/.92);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1px solid hsl(var(--panel-border));border-radius:20px;padding:10px 12px;box-shadow:0 8px 30px rgba(0,0,0,.08);margin-top:32px}
.jluxe-cp3 .cp3-nav-cur{display:flex;flex-direction:column;gap:2px;min-width:96px}
.jluxe-cp3 .cp3-nav-cur small{font-size:10px;color:hsl(var(--text-muted))}
.jluxe-cp3 .cp3-nav-cur strong{font-size:15px;font-weight:800;color:hsl(var(--foreground))}
.jluxe-cp3 .cp3-nav-arrows{display:flex;gap:2px}
.jluxe-cp3 .cp3-nav-arrows button{height:26px;width:26px;border:none;background:none;color:hsl(var(--text-muted));border-radius:8px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center}
.jluxe-cp3 .cp3-nav-arrows button:hover:not(:disabled){background:hsl(var(--primary)/.1);color:hsl(var(--primary))}
.jluxe-cp3 .cp3-nav-arrows button:disabled{opacity:.3;cursor:default}
.jluxe-cp3 .cp3-tabs{display:flex;gap:4px;overflow-x:auto;scrollbar-width:none}
.jluxe-cp3 .cp3-tabs::-webkit-scrollbar{display:none}
.jluxe-cp3 .cp3-tab{white-space:nowrap;border:none;background:none;border-radius:12px;padding:8px 14px;font-size:13px;font-weight:500;color:hsl(var(--text-muted));cursor:pointer;transition:all .2s;font-family:inherit}
.jluxe-cp3 .cp3-tab:hover{color:hsl(var(--foreground))}
.jluxe-cp3 .cp3-tab.is-active{background:transparent;color:hsl(var(--primary));font-weight:700}
/* بخش‌های شماره‌دار */
.jluxe-cp3 .cp3-sec{margin-top:20px;scroll-margin-top:calc(var(--jluxe-product-nav-top,0px) + 6px + 60px + 12px)}
.jluxe-cp3 .cp3-faq.cp3-sec{margin-top:0}
.jluxe-cp3 .cp3-sechead{display:flex;align-items:center;gap:12px;margin-bottom:12px}
.jluxe-cp3 .cp3-num{display:inline-flex;align-items:center;color:hsl(var(--primary));font-size:15px;font-weight:800;line-height:1}
.jluxe-cp3 .cp3-sechead h3{font-size:18px;font-weight:800;color:hsl(var(--foreground));margin:0}
.jluxe-cp3 .cp3-sechead .line{height:1px;flex:1;background:linear-gradient(to left,hsl(var(--panel-border)),transparent)}
.jluxe-cp3 .cp3-panelcard{border:1px solid hsl(var(--panel-border));background:hsl(var(--surface));border-radius:22px;box-shadow:0 2px 14px rgba(0,0,0,.04);padding:20px}
@media(min-width:768px){.jluxe-cp3 .cp3-panelcard{padding:28px}}
.jluxe-cp3 .cp3-descwrap{position:relative;max-height:600px;overflow:hidden}
.jluxe-cp3 .cp3-descwrap.is-open{max-height:none}
.jluxe-cp3 .cp3-descfade{position:absolute;inset-inline:0;bottom:0;height:128px;background:linear-gradient(to top,hsl(var(--surface)) 20%,hsl(var(--surface)/.95) 55%,transparent);display:flex;align-items:flex-end;justify-content:center;padding-bottom:16px}
.jluxe-cp3 .cp3-descwrap.is-open .cp3-descfade{display:none}
.jluxe-cp3 .cp3-descbtn{display:inline-flex;align-items:center;gap:8px;background:hsl(var(--primary));color:hsl(var(--primary-foreground));border:none;border-radius:16px;padding:10px 24px;font-size:14px;font-weight:500;cursor:pointer;box-shadow:0 8px 20px hsl(var(--primary)/.3);font-family:inherit}
.jluxe-cp3 .cp3-descbody{color:hsl(var(--text-secondary));line-height:2;font-size:14px;text-align:justify}
.jluxe-cp3 .cp3-descbody h2,.jluxe-cp3 .cp3-descbody h3{color:hsl(var(--foreground))}
.jluxe-cp3 .cp3-descbody img{max-width:100%;height:auto;border-radius:16px}
.jluxe-cp3 .cp3-descbody table{width:100%;border-collapse:collapse}
.jluxe-cp3 .cp3-descbody td,.jluxe-cp3 .cp3-descbody th{border:1px solid hsl(var(--panel-border));padding:8px 12px}
/* جدول مشخصات */
.jluxe-cp3 .cp3-specgroup{border:1px solid hsl(var(--panel-border));border-radius:16px;overflow:hidden;margin-bottom:20px}
.jluxe-cp3 .cp3-specgroup:last-child{margin-bottom:0}
.jluxe-cp3 .cp3-specgroup-head{display:flex;align-items:center;gap:10px;background:linear-gradient(to left,hsl(var(--primary)/.1),transparent);padding:12px 20px}
.jluxe-cp3 .cp3-specgroup-head .dot{width:6px;height:16px;border-radius:99px;background:hsl(var(--primary))}
.jluxe-cp3 .cp3-specgroup-head h4{font-size:15px;font-weight:800;color:hsl(var(--foreground));margin:0}
.jluxe-cp3 .cp3-specrow{display:flex;align-items:baseline;justify-content:space-between;gap:24px;padding:13px 20px;border-top:1px solid hsl(var(--panel-border));font-size:14px;transition:background .15s}
.jluxe-cp3 .cp3-specrow:first-of-type{border-top:none}
.jluxe-cp3 .cp3-specrow:hover{background:hsl(var(--panel)/.6)}
.jluxe-cp3 .cp3-specrow .k{color:hsl(var(--text-muted));flex:none}
.jluxe-cp3 .cp3-specrow .v{color:hsl(var(--foreground));font-weight:500;text-align:end}
/* خلاصه‌ی امتیاز دیدگاه‌ها */
.jluxe-cp3 .cp3-rate{display:grid;grid-template-columns:1fr;gap:20px;border:1px solid hsl(var(--panel-border));border-radius:24px;padding:24px;margin-bottom:20px}
@media(min-width:768px){.jluxe-cp3 .cp3-rate{grid-template-columns:1fr 220px}}
.jluxe-cp3 .cp3-rate-score{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;border-radius:16px;background:linear-gradient(135deg,#fff8ec,#fff3e6);padding:24px 0}
.jluxe-cp3 .cp3-rate-score .score{font-size:48px;font-weight:900;color:hsl(var(--foreground));line-height:1}
.jluxe-cp3 .cp3-rate-score .stars{color:var(--jluxe-rating-color);letter-spacing:2px;font-size:15px}
.jluxe-cp3 .cp3-rate-score .of{font-size:12px;color:hsl(var(--text-muted))}
.jluxe-cp3 .cp3-rate-bars{display:flex;flex-direction:column;justify-content:center;gap:12px}
.jluxe-cp3 .cp3-ratebar{display:flex;align-items:center;gap:12px;font-size:13px}
.jluxe-cp3 .cp3-ratebar .lbl{flex:none;font-weight:700}
.jluxe-cp3 .cp3-ratebar .lbl i{font-style:normal;font-weight:500;font-size:11px;color:hsl(var(--text-muted))}
.jluxe-cp3 .cp3-ratebar .track{height:10px;flex:1;border-radius:99px;background:hsl(var(--panel));overflow:hidden}
.jluxe-cp3 .cp3-ratebar .fill{height:100%;border-radius:99px}
.jluxe-cp3 .cp3-ratebar .pct{flex:none;font-size:12px;color:hsl(var(--text-muted))}
.jluxe-cp3 .cp3-ratebar.pos .fill{background:#10b981}
.jluxe-cp3 .cp3-ratebar.pos .lbl{color:#047857}
.jluxe-cp3 .cp3-ratebar.neu .fill{background:#fbbf24}
.jluxe-cp3 .cp3-ratebar.neu .lbl{color:#b45309}
.jluxe-cp3 .cp3-ratebar.neg .fill{background:#f43f5e}
.jluxe-cp3 .cp3-ratebar.neg .lbl{color:#be123c}
.jluxe-cp3 .cp3-reviewtoolbar{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1fr);align-items:center;gap:12px;margin-bottom:16px}
.jluxe-cp3 .cp3-sortsel{grid-column:2;justify-self:center;display:inline-flex;align-items:center;justify-content:center;gap:2px;background:hsl(var(--panel));border:1px solid hsl(var(--panel-border));border-radius:999px;padding:4px}
.jluxe-cp3 .cp3-reviewtoolbar .cp3-reviewbtn{grid-column:3;justify-self:end}
.jluxe-cp3 .cp3-sortsel button{border:1px solid transparent;background:none;border-radius:999px;padding:7px 14px;font-size:12px;color:hsl(var(--text-muted));cursor:pointer;transition:all .15s;font-family:inherit}
.jluxe-cp3 .cp3-sortsel button:hover{color:hsl(var(--foreground))}
.jluxe-cp3 .cp3-sortsel button.is-active{background:hsl(var(--surface));border-color:hsl(var(--panel-border));color:hsl(var(--foreground));font-weight:700}
.jluxe-cp3 .cp3-wishline{display:inline-flex;align-items:center;gap:6px;background:none;border:none;padding:0;color:hsl(var(--foreground));font-size:12px;cursor:pointer;font-family:inherit}
.jluxe-cp3 .cp3-wishline svg{color:hsl(var(--primary))}
.jluxe-cp3 .cp3-wishline:hover,.jluxe-cp3 .cp3-wishline[aria-pressed="true"]{color:#e0405f}
.jluxe-cp3 .cp3-reviewbtn{display:inline-flex;align-items:center;gap:8px;background:hsl(var(--primary));color:hsl(var(--primary-foreground));border:none;border-radius:999px;padding:10px 20px;font-size:14px;font-weight:500;cursor:pointer;text-decoration:none;font-family:inherit}
.jluxe-cp3 .cp3-reviewbtn:hover{opacity:.9}
.jluxe-cp3 .cp3-reviewbtn.is-disabled{opacity:.55;cursor:not-allowed}
/* کارتِ خلاصه‌ی هوش مصنوعی — هم‌زبان با مرجع (بنفش، آیکونِ چپ) */
.jluxe-cp3 .jluxe-ai-review-summary{display:flex;flex-direction:row-reverse;gap:12px;align-items:flex-start;padding:20px;margin-bottom:20px;border:1px solid #ede9fe;border-radius:24px;background:linear-gradient(135deg,#f5f3ff,#fdf4ff)}
.jluxe-cp3 .jluxe-ai-review-summary-icon{background:linear-gradient(135deg,#8b5cf6,#d946ef);color:#fff;border-radius:16px;width:44px;height:44px}
.jluxe-cp3 .jluxe-ai-review-summary-badge{color:hsl(var(--foreground));font-weight:800;font-size:15px}
.jluxe-cp3 .jluxe-ai-review-summary-sub{display:block;color:#7c3aed;font-size:12px;margin:2px 0 8px}
.jluxe-cp3 .jluxe-ai-review-summary-body{flex:1 1 0%;min-width:0}
.jluxe-cp3 .jluxe-ai-review-summary-text{font-size:14px;line-height:1.9;color:hsl(var(--text-secondary))}
/* R66: دیدگاه‌ها — کارت‌های جمع‌وجورِ ۱۶px (استایل کامل در storefront.css) */
/* سوالات متداول */
.jluxe-cp3 .cp3-faq{border:1px solid hsl(var(--panel-border));background:hsl(var(--surface));border-radius:24px;padding:20px;box-shadow:0 8px 28px -18px rgba(0,0,0,.2)}
.jluxe-cp3 .cp3-faq-head{display:flex;align-items:center;justify-content:flex-start;gap:14px;margin-bottom:16px;direction:rtl}
.jluxe-cp3 .cp3-faq-head .cp3-faq-title-row{display:flex;align-items:center;gap:12px;direction:rtl}
.jluxe-cp3 .cp3-faq-head .ic{width:44px;height:44px;flex:none;border:1px solid hsl(var(--primary)/.15);border-radius:15px;background:linear-gradient(145deg,hsl(var(--primary)/.14),hsl(var(--primary)/.05));color:hsl(var(--primary));display:inline-flex;align-items:center;justify-content:center;box-shadow:0 5px 14px hsl(var(--primary)/.08)}
.jluxe-cp3 .cp3-faq-head .ic svg{width:25px;height:25px}
.jluxe-cp3 .cp3-faq-head h3{font-size:20px;font-weight:800;color:hsl(var(--foreground));margin:0}
.jluxe-cp3 .cp3-faq-head .cp3-faq-subtitle{display:block;padding-inline-start:56px;margin-top:5px;font-size:13px;color:hsl(var(--text-muted))}
.jluxe-cp3 .cp3-faq-list{background:hsl(var(--panel));border-radius:20px;padding:4px 18px}
.jluxe-cp3 .cp3-faq-item{border-bottom:1px solid hsl(var(--panel-border))}
.jluxe-cp3 .cp3-faq-item:last-child{border-bottom:none}
.jluxe-cp3 .cp3-faq-item summary{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:16px 4px;font-size:14px;font-weight:600;color:hsl(var(--foreground));cursor:pointer;list-style:none;transition:color .2s ease,background .2s ease}
.jluxe-cp3 .cp3-faq-item summary::-webkit-details-marker{display:none}
.jluxe-cp3 .cp3-faq-item summary .chev{transform:rotate(-90deg);transition:transform .22s ease,color .22s ease;color:hsl(var(--text-muted))}
.jluxe-cp3 .cp3-faq-item summary:hover,.jluxe-cp3 .cp3-faq-item[open] summary{color:hsl(var(--primary))}
.jluxe-cp3 .cp3-faq-item[open] summary .chev{transform:rotate(90deg);color:hsl(var(--primary))}
.jluxe-cp3 .cp3-faq-item .a{padding:0 4px 16px;font-size:14px;line-height:2;color:hsl(var(--text-secondary))}
/* محصولات مرتبط */
.jluxe-cp3 .cp3-relhead{display:flex;align-items:center;gap:14px;margin:32px 0 8px}
.jluxe-cp3 .cp3-relhead .ic{width:48px;height:48px;border-radius:12px;background:hsl(var(--surface));border:1px solid hsl(var(--panel-border));color:hsl(var(--primary));display:inline-flex;align-items:center;justify-content:center}
.jluxe-cp3 .cp3-relhead h3{font-size:22px;font-weight:800;color:hsl(var(--foreground));margin:0}
/* R85 — یک ردیفِ افقیِ اسلایدی (بدونِ شکستن به خطِ بعد) با فلشِ قبلی/بعدی.
   ۴ کارت در دسکتاپ، ۳ در تبلت، ۲ در موبایل؛ بقیه با اسکرول/فلش دیده می‌شوند. */
.jluxe-cp3 .cp3-relhead{flex-wrap:wrap}
.jluxe-cp3 .cp3-relnav{display:flex;gap:8px;margin-inline-start:auto}
.jluxe-cp3 .cp3-relnav[hidden]{display:none}
.jluxe-cp3 .cp3-relbtn{display:inline-flex;align-items:center;justify-content:center;width:38px;height:38px;border-radius:9999px;border:1px solid hsl(var(--panel-border));background:hsl(var(--surface));color:hsl(var(--foreground));cursor:pointer;transition:border-color .2s,color .2s,opacity .2s}
@media (hover:hover){.jluxe-cp3 .cp3-relbtn:hover:not(:disabled){border-color:hsl(var(--primary)/.55);color:hsl(var(--primary))}}
.jluxe-cp3 .cp3-relbtn:focus-visible{outline:2px solid hsl(var(--primary));outline-offset:2px}
.jluxe-cp3 .cp3-relbtn:disabled{opacity:.35;cursor:default}
.jluxe-cp3 .cp3-related ul.products{display:flex !important;flex-wrap:nowrap !important;grid-template-columns:none !important;gap:12px;overflow-x:auto;overflow-y:hidden;overscroll-behavior-x:contain;scroll-snap-type:x proximity;scroll-behavior:smooth;margin:16px 0 0 !important;padding:4px 2px 10px !important;list-style:none;scrollbar-width:none;-ms-overflow-style:none}
.jluxe-cp3 .cp3-related ul.products::-webkit-scrollbar{display:none}
.jluxe-cp3 .cp3-related ul.products li.product{flex:0 0 calc((100% - 12px)/2) !important;width:auto !important;max-width:none !important;scroll-snap-align:start;float:none !important;margin:0 !important;background:linear-gradient(180deg,hsl(var(--surface)),hsl(var(--panel)/.5));border:1px solid hsl(var(--panel-border));border-radius:24px;overflow:hidden;padding:12px !important}
@media(min-width:768px){.jluxe-cp3 .cp3-related ul.products li.product{flex-basis:calc((100% - 24px)/3) !important}}
@media(min-width:1024px){.jluxe-cp3 .cp3-related ul.products li.product{flex-basis:calc((100% - 36px)/4) !important}}
@media (prefers-reduced-motion: reduce){.jluxe-cp3 .cp3-related ul.products{scroll-behavior:auto}}
.jluxe-cp3 .cp3-related ul.products li.product img{border-radius:18px;background:hsl(var(--surface-elevated));transition:transform .7s ease}
@media (prefers-reduced-motion: no-preference){.jluxe-cp3 .cp3-related ul.products li.product:hover img{transform:scale(1.06)}}
.jluxe-cp3 .cp3-related .woocommerce-loop-product__title{font-size:13px !important;font-weight:500 !important;color:hsl(var(--text-secondary)) !important;padding:0 4px}
.jluxe-cp3 .cp3-related .price{padding:0 4px}
.jluxe-cp3 .cp3-related .button{display:none}
/* R212 mobile gallery controls: clear hit areas, measured spacing and visible focus without changing the theme palette. */
@media (max-width:767.98px){
	.jluxe-cp3 .cp3-zoom{height:auto;aspect-ratio:1/1;margin-bottom:12px;border-radius:24px;touch-action:pan-y pinch-zoom}
	.jluxe-cp3 .cp3-thumbsrow{gap:8px}
	.jluxe-cp3 .cp3-thumbs{gap:8px;padding:4px 2px;scroll-padding-inline:6px;overscroll-behavior-x:contain;-webkit-overflow-scrolling:touch}
	.jluxe-cp3 .cp3-thumb{box-sizing:border-box;flex:0 0 72px;width:72px;height:72px;padding:3px;border-radius:16px}
	.jluxe-cp3 .cp3-thumb img{border-radius:12px}
	.jluxe-cp3 .cp3-thumb:focus-visible{outline:2px solid hsl(var(--primary));outline-offset:2px}
	.jluxe-cp3 .cp3-tarrow{box-sizing:border-box;flex:0 0 44px;width:44px;height:44px;min-width:44px;min-height:44px;border-radius:9999px;box-shadow:0 4px 12px hsl(var(--foreground)/.08);touch-action:manipulation;-webkit-tap-highlight-color:transparent;transition:transform .18s ease,border-color .18s ease,color .18s ease,box-shadow .18s ease,opacity .18s ease}
	.jluxe-cp3 .cp3-tarrow svg{width:20px;height:20px;transition:transform .18s ease}
	.jluxe-cp3 .cp3-tarrow:active:not(:disabled){transform:scale(.95)}
	.jluxe-cp3 .cp3-tarrow:focus-visible{outline:2px solid hsl(var(--primary));outline-offset:3px}
	.jluxe-cp3 .cp3-tarrow:disabled{opacity:.42;box-shadow:none}
	.jluxe-cp3-gallery-modal__stage{gap:8px}
	.jluxe-cp3-gallery-modal__button,.jluxe-cp3-gallery-modal__close{box-sizing:border-box;width:44px;height:44px;min-width:44px;min-height:44px;display:inline-flex;align-items:center;justify-content:center;border-radius:9999px;touch-action:manipulation;-webkit-tap-highlight-color:transparent;transition:transform .18s ease,border-color .18s ease,color .18s ease,background-color .18s ease,box-shadow .18s ease}
	.jluxe-cp3-gallery-modal__button:active,.jluxe-cp3-gallery-modal__close:active{transform:scale(.95)}
	.jluxe-cp3-gallery-modal__button:focus-visible,.jluxe-cp3-gallery-modal__close:focus-visible{outline:2px solid hsl(var(--accent));outline-offset:3px}
}
@media (max-width:767.98px) and (hover:hover) and (pointer:fine){
	.jluxe-cp3 .cp3-tarrow:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 6px 16px hsl(var(--foreground)/.12)}
	.jluxe-cp3-gallery-modal__button:hover,.jluxe-cp3-gallery-modal__close:hover{transform:translateY(-1px)}
}
@media (max-width:767.98px) and (prefers-reduced-motion:reduce){
	.jluxe-cp3 .cp3-tarrow,.jluxe-cp3 .cp3-tarrow svg,.jluxe-cp3 .cp3-thumb,.jluxe-cp3-gallery-modal,.jluxe-cp3-gallery-modal__button,.jluxe-cp3-gallery-modal__track img{transition:none}
	.jluxe-cp3 .cp3-tarrow:hover:not(:disabled),.jluxe-cp3 .cp3-tarrow:active:not(:disabled),.jluxe-cp3 .cp3-thumb:hover,.jluxe-cp3-gallery-modal__button:hover,.jluxe-cp3-gallery-modal__button:active,.jluxe-cp3-gallery-modal__close:hover,.jluxe-cp3-gallery-modal__close:active{transform:none}
}

/* Independent presentation for the selectable third product layout. */
.jluxe-product-reference .reference-key-features{margin-top:18px;padding-top:16px;border-top:1px solid hsl(var(--panel-border))}
.jluxe-product-reference .reference-key-features h2{margin:0 0 10px;color:hsl(var(--foreground));font-size:14px;font-weight:800}
.jluxe-product-reference .reference-key-features__grid{display:flex;flex-wrap:wrap;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
.jluxe-product-reference .reference-key-feature{flex:0 0 calc(50% - 4px);min-width:0;border:1px solid hsl(var(--panel-border));border-radius:12px;background:hsl(var(--panel));padding:9px 11px}
.jluxe-product-reference .reference-key-feature span{display:block;margin-bottom:4px;color:hsl(var(--text-muted));font-size:10px;line-height:1.5}
.jluxe-product-reference .reference-key-feature strong{display:block;color:hsl(var(--foreground));font-size:12px;font-weight:700;line-height:1.7;overflow-wrap:anywhere}

.jluxe-product-reference .reference-mobile-variation-option{margin-top:16px}

/* The desktop reference composition remains intact; these hooks are only shown on phones. */
.jluxe-product-reference .reference-mobile-gallery-actions,
.jluxe-product-reference .reference-mobile-gallery-dots,
.jluxe-product-reference .reference-mobile-taxonomy,
.jluxe-product-reference .reference-mobile-english-name,
.jluxe-product-reference .reference-mobile-product-meta,
.jluxe-product-reference .reference-mobile-stock-warning,
.jluxe-product-reference .reference-mobile-rating,
.jluxe-product-reference .reference-mobile-actions{display:none}
@media(max-width:767.98px){
	.jluxe-cp3 .cp3-reviewtoolbar{grid-template-columns:minmax(0,1fr);justify-items:center;gap:10px}
	.jluxe-cp3 .cp3-sortsel{grid-column:1;max-width:100%;flex-wrap:wrap;border-radius:18px}
	.jluxe-cp3 .cp3-sortsel button{padding-inline:8px}
	.jluxe-cp3 .cp3-reviewtoolbar .cp3-reviewbtn{grid-column:1;justify-self:center}
	.jluxe-product-reference>.mx-auto{box-sizing:border-box;width:100%;max-width:none;padding:0}
	.jluxe-product-reference .cp3-bc{display:none}
	.jluxe-product-reference .cp3-card{margin:0;padding:0;border-radius:0;background:transparent;box-shadow:none}
	.jluxe-product-reference .cp3-grid{gap:0}
	.jluxe-product-reference .cp3-gallery{position:relative;flex:none;width:100%;padding:0;overflow:hidden;background:hsl(var(--surface-elevated))}
	.jluxe-product-reference .cp3-zoom{height:auto;aspect-ratio:1/1;margin:0;border-radius:0;background:hsl(var(--surface-elevated));box-shadow:none}
	.jluxe-product-reference .cp3-zoom::after{border-radius:0;box-shadow:none}
	.jluxe-product-reference .cp3-thumbsrow{display:none}
	.jluxe-product-reference .reference-mobile-gallery-actions{position:absolute;z-index:3;inset-block-start:calc(env(safe-area-inset-top,0px) + 12px);inset-inline:14px;display:flex;align-items:center;justify-content:space-between;gap:12px;direction:rtl}
	.jluxe-product-reference .reference-mobile-gallery-actions__cluster{display:flex;align-items:center;gap:9px}
	.jluxe-product-reference .reference-mobile-gallery-button{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;min-width:44px;min-height:44px;border:1px solid hsl(var(--panel-border)/.7);border-radius:999px;background:hsl(var(--surface)/.9);color:hsl(var(--foreground));box-shadow:0 5px 18px hsl(var(--foreground)/.1);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);text-decoration:none;touch-action:manipulation;transition:transform .16s ease,background-color .16s ease,color .16s ease}
	.jluxe-product-reference .reference-mobile-gallery-button svg{width:19px;height:19px}
	.jluxe-product-reference .reference-mobile-gallery-button[aria-pressed="true"]{color:hsl(var(--error))}
	.jluxe-product-reference .reference-mobile-gallery-button:active{transform:scale(.95)}
	.jluxe-product-reference .reference-mobile-gallery-button:focus-visible{outline:2px solid hsl(var(--primary));outline-offset:3px}
	.jluxe-product-reference .reference-mobile-gallery-dots{position:absolute;z-index:3;left:50%;bottom:14px;display:flex;align-items:center;justify-content:center;gap:6px;max-width:calc(100% - 32px);overflow-x:auto;padding:7px 10px;border:1px solid hsl(var(--panel-border)/.45);border-radius:999px;background:hsl(var(--surface)/.74);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);direction:ltr;transform:translateX(-50%);scrollbar-width:none}
	.jluxe-product-reference .reference-mobile-gallery-dots::-webkit-scrollbar{display:none}
	.jluxe-product-reference .reference-mobile-gallery-dot{box-sizing:border-box;flex:0 0 7px;width:7px;height:7px;min-width:7px;min-height:7px;padding:0;border:0;border-radius:999px;background:hsl(var(--text-muted)/.45);transition:flex-basis .18s ease,background-color .18s ease}
	.jluxe-product-reference .reference-mobile-gallery-dot.is-active{flex-basis:20px;background:hsl(var(--primary))}
	.jluxe-product-reference .cp3-info{position:relative;z-index:2;box-sizing:border-box;width:100%;min-width:0;margin:-28px 0 0;padding:18px 18px 20px;border:1px solid hsl(var(--panel-border)/.65);border-bottom:0;border-radius:28px 28px 0 0;background:hsl(var(--surface));box-shadow:0 -8px 26px hsl(var(--foreground)/.07)}
	.jluxe-product-reference .reference-mobile-taxonomy{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0 0 10px}
	.jluxe-product-reference .reference-mobile-taxonomy__pill{display:inline-flex;align-items:center;gap:6px;min-height:30px;padding:4px 10px;border:1px solid hsl(var(--panel-border));border-radius:999px;background:hsl(var(--panel));color:hsl(var(--text-secondary));font-size:11px;font-weight:700;line-height:1.5;text-decoration:none}
	.jluxe-product-reference .reference-mobile-taxonomy__pill--brand{border-color:hsl(var(--primary)/.18);background:hsl(var(--primary)/.07);color:hsl(var(--primary))}
	.jluxe-product-reference .reference-mobile-taxonomy__pill:focus-visible{outline:2px solid hsl(var(--primary));outline-offset:2px}
	.jluxe-product-reference .cp3-title{margin:0;color:hsl(var(--foreground));font-size:21px;font-weight:850;line-height:1.65;overflow-wrap:anywhere}
	.jluxe-product-reference .reference-mobile-english-name{display:block;margin:1px 0 0;color:hsl(var(--text-muted));font-size:12px;line-height:1.6;text-align:right;direction:ltr;overflow-wrap:anywhere}
	.jluxe-product-reference .reference-mobile-product-meta{display:flex;flex-wrap:wrap;align-items:center;gap:7px 12px;margin-top:12px;color:hsl(var(--text-secondary));font-size:12px;line-height:1.8}
	.jluxe-product-reference .reference-mobile-meta-item{display:inline-flex;align-items:center;gap:5px;min-width:0}
	.jluxe-product-reference .reference-mobile-stock{font-weight:750}
	.jluxe-product-reference .reference-mobile-stock.is-in-stock{color:hsl(var(--success))}
	.jluxe-product-reference .reference-mobile-stock.is-out-of-stock{color:hsl(var(--error))}
	.jluxe-product-reference .reference-mobile-stock svg,.jluxe-product-reference .reference-mobile-meta-item svg{flex:none;width:15px;height:15px}
	.jluxe-product-reference .reference-mobile-meta-item bdi{overflow-wrap:anywhere}
	.jluxe-product-reference .reference-mobile-meta-item--delivery{min-height:30px;padding:4px 10px;border:1px solid hsl(var(--primary)/.2);border-radius:999px;background:hsl(var(--primary)/.07);color:hsl(var(--primary));font-weight:750;line-height:1.5}
	.jluxe-product-reference .reference-mobile-delivery-label{color:hsl(var(--text-secondary));font-weight:650}
	.jluxe-product-reference .reference-mobile-meta-item--delivery bdi{color:hsl(var(--primary));font-weight:800}
	.jluxe-product-reference .reference-mobile-stock-warning{display:flex;align-items:center;gap:8px;margin-top:9px;padding:9px 11px;border:1px solid hsl(var(--warning)/.25);border-radius:12px;background:hsl(var(--warning)/.08);color:hsl(var(--text-secondary));font-size:12px;font-weight:700;line-height:1.7}
	.jluxe-product-reference .reference-mobile-variation-options{margin:12px 0 10px;padding:12px 13px;border:1px solid hsl(var(--primary)/.16);border-radius:18px;background:linear-gradient(145deg,hsl(var(--surface)),hsl(var(--panel)/.62));box-shadow:0 4px 14px hsl(var(--foreground)/.035)}
	.jluxe-product-reference .reference-mobile-variation-options .reference-mobile-variation-option{margin-top:12px}
	.jluxe-product-reference .reference-mobile-variation-options .reference-mobile-variation-option:first-child{margin-top:0}
	.jluxe-product-reference .reference-mobile-variation-options .cp3-varlabel{margin-bottom:8px;color:hsl(var(--foreground));font-weight:750}
	.jluxe-product-reference .reference-mobile-variation-options .cp3-pills{gap:10px}
	.jluxe-product-reference .reference-mobile-stock-warning svg{flex:none;width:17px;height:17px;color:hsl(var(--warning-strong))}
	.jluxe-product-reference .reference-mobile-rating{display:flex;flex-wrap:wrap;align-items:center;gap:7px;margin-top:12px;color:hsl(var(--text-secondary));font-size:12px;line-height:1.7}
	.jluxe-product-reference .reference-mobile-rating a{color:inherit;text-decoration:none}
	.jluxe-product-reference .reference-mobile-rating a:hover{color:hsl(var(--primary))}
	.jluxe-product-reference .reference-mobile-rating-score{font-weight:800;color:hsl(var(--foreground))}
	.jluxe-product-reference .reference-mobile-stars{position:relative;display:inline-block;min-width:82px;color:hsl(var(--panel-border));font-size:16px;line-height:1;letter-spacing:1px;direction:ltr;white-space:nowrap}
	.jluxe-product-reference .reference-mobile-stars::before{content:'★★★★★'}
	.jluxe-product-reference .reference-mobile-stars::after{position:absolute;inset-block-start:0;left:0;width:var(--reference-rating-fill,0%);overflow:hidden;color:var(--jluxe-rating-color);content:'★★★★★';white-space:nowrap}
	.jluxe-product-reference .reference-mobile-actions{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-top:15px}
	.jluxe-product-reference .reference-mobile-action{box-sizing:border-box;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;min-width:0;min-height:58px;padding:7px 5px;border:1px solid hsl(var(--panel-border));border-radius:14px;background:hsl(var(--panel));color:hsl(var(--text-secondary));font-size:11px;font-weight:700;line-height:1.4;text-align:center;text-decoration:none;touch-action:manipulation;transition:border-color .16s ease,color .16s ease,background-color .16s ease}
	.jluxe-product-reference .reference-mobile-actions.no-specs{grid-template-columns:repeat(2,minmax(0,1fr))}
	.jluxe-product-reference .reference-mobile-action svg{width:18px;height:18px;flex:none;color:hsl(var(--primary))}
	.jluxe-product-reference .reference-mobile-action:hover{border-color:hsl(var(--primary)/.35);background:hsl(var(--primary)/.06);color:hsl(var(--foreground))}
	.jluxe-product-reference .reference-mobile-action:focus-visible{outline:2px solid hsl(var(--primary));outline-offset:2px}
	.jluxe-product-reference .reference-mobile-rating+.reference-mobile-actions,.jluxe-product-reference .reference-mobile-actions:first-child{margin-top:15px}
	.jluxe-product-reference .cp3-wishline-row,.jluxe-product-reference .reference-legacy-review-meta{display:none}
	.jluxe-product-reference .cp3-side{width:100%;margin:0;padding:0}
	.jluxe-product-reference .cp3-sidebox{display:none}
	.jluxe-product-reference .cp3-side .cp3-sku,.jluxe-product-reference .cp3-side .cp3-dashed,.jluxe-product-reference .cp3-side .cp3-fabs{display:none}
	.jluxe-product-reference .cp3-side [data-jluxe-buybox-surface]{display:flex;flex-direction:column;align-items:stretch;gap:12px;margin:0;padding:15px 18px;border:1px solid hsl(var(--panel-border));border-radius:18px;background:hsl(var(--surface));box-shadow:0 3px 14px hsl(var(--foreground)/.06)}
	.jluxe-product-reference .cp3-side .cp3-price{width:100%;font-size:20px;line-height:1.6}
	.jluxe-product-reference .cp3-side .cp3-price.is-placeholder{font-size:12px}
	.jluxe-product-reference .cp3-side .cp3-addrow{display:flex!important;width:100%;margin:0}
	.jluxe-product-reference .cp3-side .cp3-addrow .single_add_to_cart_button,.jluxe-product-reference .cp3-side .cp3-addrow .cp3-add-simple{min-height:48px;border-radius:14px!important}
	.jluxe-product-reference .cp3-side .jluxe-stock-alert-trigger{margin:0}
	body.jluxe-has-sticky-cta .jluxe-product-reference .cp3-side .cp3-price,
	body.jluxe-has-sticky-cta .jluxe-product-reference .cp3-side .cp3-addrow{display:none!important}
	body.jluxe-has-sticky-cta .jluxe-product-reference .cp3-side [data-jluxe-buybox-surface]{display:flex;flex-direction:column;gap:0;margin:0;padding:0;border:0;border-radius:0;background:transparent;box-shadow:none}
	.jluxe-product-reference .cp3-nav{display:block;margin-top:24px;padding:6px;border-radius:999px}
	.jluxe-product-reference .cp3-nav-cur,.jluxe-product-reference .cp3-nav-arrows{display:none}
	.jluxe-product-reference .cp3-tabs{display:flex;flex-wrap:wrap;justify-content:center;gap:6px;width:100%;padding:0;overflow:visible;overscroll-behavior-x:auto;scroll-snap-type:none}
	.jluxe-product-reference .cp3-tab{flex:0 1 auto;min-height:44px;padding:9px 12px;border-radius:999px;background:transparent;text-align:center}
	.jluxe-product-reference .cp3-tab.is-active{background:hsl(var(--primary));color:hsl(var(--primary-foreground));font-weight:750}
	.jluxe-product-reference .cp3-tab:focus-visible{outline:2px solid hsl(var(--primary));outline-offset:2px}
	.jluxe-product-reference .cp3-sec{scroll-margin-top:calc(var(--jluxe-product-nav-top,0px) + 62px)}
	.jluxe-product-reference .cp3-panelcard{padding:16px;border-radius:18px}
}
</style>

<div id="product-<?php the_ID(); ?>" <?php wc_product_class( 'jluxe-cp3 jluxe-product-reference', $product ); ?> data-jluxe-layout="reference" data-jluxe-mobile-layout="<?php echo esc_attr( ( jluxe_get_theme_settings()['product_page']['mobile_layout'] ?? 'standard' ) === 'layered' ? 'layered' : 'standard' ); ?>" data-jluxe-product-id="<?php echo esc_attr( (string) $product->get_id() ); ?>" data-jluxe-product-in-stock="<?php echo $cp3_is_in_stock ? 'true' : 'false'; ?>">
	<div class="mx-auto w-full max-w-[1320px] px-3 md:px-4 py-2">

		<nav aria-label="مسیر صفحه" class="cp3-bc">
			<?php
			$cp3_bc_items   = $cp3_breadcrumbs;
			$cp3_last_label = (string) end( $cp3_bc_items )[0];
			array_pop( $cp3_bc_items );
			foreach ( $cp3_bc_items as $cp3_bc ) :
				?>
				<div class="flex items-center gap-2">
					<a href="<?php echo esc_url( (string) $cp3_bc[1] ); ?>"><?php echo esc_html( (string) $cp3_bc[0] ); ?></a>
					<svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M15 6s-6 4.419-6 6s6 6 6 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
				</div>
			<?php endforeach; ?>
			<span class="is-current"><?php echo esc_html( $cp3_last_label ); ?></span>
		</nav>
		<?php jluxe_print_breadcrumb_jsonld( $product ); ?>

		<?php if ( $jluxe_is_variable ) : ?>
			<?php $cp3_variations_json = wc_esc_json( wp_json_encode( $jluxe_available_variations ) ); ?>
			<form class="variations_form cart" action="<?php echo esc_url( apply_filters( 'woocommerce_add_to_cart_form_action', $product->get_permalink() ) ); ?>" method="post" enctype="multipart/form-data" data-product_id="<?php echo absint( $product->get_id() ); ?>" data-product_variations="<?php echo $cp3_variations_json; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" data-cp3-low-stock-initial-quantity="<?php echo null !== $cp3_stock_qty ? esc_attr( (string) $cp3_stock_qty ) : ''; ?>">
		<?php endif; ?>

		<div class="cp3-card">
			<div class="cp3-grid" data-jluxe-layer-stage>

				<!-- گالری -->
				<div class="cp3-gallery" data-cp3-gallery data-jluxe-gallery data-jluxe-gallery-current="0" data-jluxe-gallery-modal-id="jluxe-product-gallery-modal">
					<button type="button" class="cp3-zoom" data-cp3-zoom-box data-jluxe-gallery-open-current aria-label="نمایش تصویر محصول به‌صورت تمام‌صفحه">
						<?php
						$cp3_main_size   = 'large';
						$cp3_main_sizes  = jluxe_single_product_image_sizes( 'reference' );
						$cp3_main_image  = jluxe_get_responsive_attachment_image( (int) $jluxe_gallery_ids[0], $cp3_main_size, $cp3_main_sizes );
						$cp3_main_url    = $cp3_main_image['src'];
						?>
						<img src="<?php echo esc_url( $cp3_main_url ?: wc_placeholder_img_src( $cp3_main_size ) ); ?>"<?php echo jluxe_responsive_image_attributes( $cp3_main_image ); ?> alt="<?php echo esc_attr( $product->get_name() ); ?>" data-cp3-zoom-img data-no-lazy="1" loading="eager" fetchpriority="high" />
					</button>
					<div class="reference-mobile-gallery-actions" role="group" aria-label="اقدام‌های محصول">
						<a class="reference-mobile-gallery-button" href="<?php echo esc_url( $cp3_mobile_back_url ); ?>" aria-label="بازگشت به فروشگاه">
							<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m9 18 6-6-6-6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
						</a>
						<div class="reference-mobile-gallery-actions__cluster">
							<button type="button" class="reference-mobile-gallery-button" data-jluxe-share aria-label="اشتراک‌گذاری محصول">
								<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 16V4m0 0L7.5 8.5M12 4l4.5 4.5M5 14v5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
							</button>
							<button type="button" class="reference-mobile-gallery-button" data-jluxe-wishlist-toggle="<?php echo esc_attr( (string) $product->get_id() ); ?>" data-jluxe-wishlist-inactive-label="افزودن به علاقه‌مندی‌ها" data-jluxe-wishlist-active-label="حذف از علاقه‌مندی‌ها" aria-pressed="false" aria-label="افزودن به علاقه‌مندی‌ها">
								<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20.1 4.9a5.4 5.4 0 0 0-7.6 0L12 5.4l-.5-.5a5.4 5.4 0 0 0-7.6 7.6l.5.5L12 20.6l7.6-7.6.5-.5a5.4 5.4 0 0 0 0-7.6Z" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
							</button>
						</div>
					</div>
					<?php if ( count( $jluxe_gallery_ids ) > 1 ) : ?>
						<div class="cp3-thumbsrow">
							<button type="button" class="cp3-tarrow" data-cp3-thumbs-prev aria-label="تصاویر قبلی" disabled><svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m9 6 6 6-6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
							<div class="cp3-thumbs">
							<?php foreach ( $jluxe_gallery_ids as $cp3_i => $cp3_att ) : ?>
								<?php $cp3_thumb_image = jluxe_get_responsive_attachment_image( (int) $cp3_att, 'jluxe-uncropped-320', '96px' ); ?>
								<button type="button" class="cp3-thumb<?php echo 0 === $cp3_i ? ' is-active' : ''; ?>" data-cp3-thumb data-jluxe-gallery-open="<?php echo esc_attr( (string) $cp3_i ); ?>" data-full="<?php echo esc_url( wp_get_attachment_image_url( $cp3_att, 'full' ) ?: '' ); ?>" aria-label="نمایش عکس <?php echo esc_attr( (string) ( $cp3_i + 1 ) ); ?>" aria-pressed="<?php echo 0 === $cp3_i ? 'true' : 'false'; ?>">
									<img src="<?php echo esc_url( $cp3_thumb_image['src'] ?: wc_placeholder_img_src( 'medium' ) ); ?>"<?php echo jluxe_responsive_image_attributes( $cp3_thumb_image ); ?> alt="" loading="lazy" />
								</button>
							<?php endforeach; ?>
						</div>
							<button type="button" class="cp3-tarrow" data-cp3-thumbs-next aria-label="تصاویر بعدی"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m15 18-6-6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
						</div>
					<?php endif; ?>
					<?php if ( count( $jluxe_gallery_ids ) > 1 ) : ?>
						<div class="reference-mobile-gallery-dots" role="group" aria-label="انتخاب تصویر محصول">
							<?php foreach ( $jluxe_gallery_ids as $cp3_dot_i => $cp3_dot_att ) : ?>
								<?php $cp3_dot_full = $cp3_dot_att ? wp_get_attachment_image_url( $cp3_dot_att, 'full' ) : wc_placeholder_img_src( 'full' ); ?>
								<button type="button" class="reference-mobile-gallery-dot<?php echo 0 === $cp3_dot_i ? ' is-active' : ''; ?>" data-cp3-thumb data-reference-gallery-index="<?php echo esc_attr( (string) $cp3_dot_i ); ?>" data-full="<?php echo esc_url( $cp3_dot_full ?: wc_placeholder_img_src( 'full' ) ); ?>" aria-label="نمایش تصویر <?php echo esc_attr( jluxe_fa_digits( (string) ( $cp3_dot_i + 1 ) ) ); ?>" aria-pressed="<?php echo 0 === $cp3_dot_i ? 'true' : 'false'; ?>"></button>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
				</div>

				<div id="jluxe-product-gallery-modal" class="jluxe-cp3-gallery-modal hidden opacity-0" data-jluxe-gallery-modal data-jluxe-gallery-modal-current="0" role="dialog" aria-modal="true" aria-label="گالری تصاویر محصول" aria-hidden="true" tabindex="-1">
					<div class="jluxe-cp3-gallery-modal__top">
						<span class="jluxe-cp3-gallery-modal__counter" data-jluxe-gallery-modal-counter>۱ / <?php echo esc_html( jluxe_fa_digits( (string) count( $jluxe_gallery_ids ) ) ); ?></span>
						<button type="button" class="jluxe-cp3-gallery-modal__button jluxe-cp3-gallery-modal__close" data-jluxe-gallery-modal-close aria-label="بستن گالری"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>
					</div>
					<div class="jluxe-cp3-gallery-modal__stage">
						<?php if ( count( $jluxe_gallery_ids ) > 1 ) : ?>
							<button type="button" class="jluxe-cp3-gallery-modal__button" data-jluxe-gallery-modal-prev aria-label="تصویر قبلی"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m14 6-6 6 6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
						<?php endif; ?>
						<div class="jluxe-cp3-gallery-modal__track" data-jluxe-gallery-modal-track>
							<?php foreach ( $jluxe_gallery_ids as $cp3_modal_i => $cp3_modal_att ) : ?>
								<?php
								$cp3_modal_image = $cp3_modal_att ? jluxe_get_responsive_attachment_image( (int) $cp3_modal_att, 'full', '90vw' ) : array( 'src' => '', 'srcset' => '', 'sizes' => '90vw' );
								$cp3_modal_full  = $cp3_modal_image['src'];
								$cp3_modal_alt   = $cp3_modal_att ? get_post_meta( $cp3_modal_att, '_wp_attachment_image_alt', true ) : '';
								?>
								<img data-jluxe-gallery-modal-image data-src="<?php echo esc_url( $cp3_modal_full ?: wc_placeholder_img_src( 'full' ) ); ?>"<?php echo jluxe_responsive_image_attributes( $cp3_modal_image, 'data-' ); ?> alt="<?php echo esc_attr( $cp3_modal_alt ?: $product->get_name() ); ?>" aria-hidden="true" draggable="false" />
							<?php endforeach; ?>
						</div>
						<?php if ( count( $jluxe_gallery_ids ) > 1 ) : ?>
							<button type="button" class="jluxe-cp3-gallery-modal__button" data-jluxe-gallery-modal-next aria-label="تصویر بعدی"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m10 6 6 6-6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
						<?php endif; ?>
					</div>
				</div>

				<!-- اطلاعات -->
				<div class="cp3-info">
					<?php if ( '' !== $cp3_mobile_category_name || '' !== $cp3_mobile_brand_name ) : ?>
						<div class="reference-mobile-taxonomy" aria-label="دسته‌بندی و برند محصول">
							<?php if ( '' !== $cp3_mobile_category_name ) : ?>
								<?php if ( '' !== $cp3_mobile_category_link ) : ?>
									<a class="reference-mobile-taxonomy__pill" href="<?php echo esc_url( $cp3_mobile_category_link ); ?>"><?php echo esc_html( $cp3_mobile_category_name ); ?></a>
								<?php else : ?>
									<span class="reference-mobile-taxonomy__pill"><?php echo esc_html( $cp3_mobile_category_name ); ?></span>
								<?php endif; ?>
							<?php endif; ?>
							<?php if ( '' !== $cp3_mobile_brand_name ) : ?>
								<?php if ( '' !== $cp3_mobile_brand_link ) : ?>
									<a class="reference-mobile-taxonomy__pill reference-mobile-taxonomy__pill--brand" href="<?php echo esc_url( $cp3_mobile_brand_link ); ?>" rel="tag"><?php echo esc_html( $cp3_mobile_brand_name ); ?></a>
								<?php else : ?>
									<span class="reference-mobile-taxonomy__pill reference-mobile-taxonomy__pill--brand"><?php echo esc_html( $cp3_mobile_brand_name ); ?></span>
								<?php endif; ?>
							<?php endif; ?>
						</div>
					<?php endif; ?>

					<h1 class="cp3-title"><?php the_title(); ?></h1>
					<?php if ( '' !== $cp3_english_product_name ) : ?>
						<p class="reference-mobile-english-name" lang="en" dir="ltr"><?php echo esc_html( $cp3_english_product_name ); ?></p>
					<?php endif; ?>
					<?php if ( function_exists( 'jluxe_render_product_trust_badges' ) ) { jluxe_render_product_trust_badges( (int) $product->get_id(), 'mt-3' ); } ?>

					<div class="reference-mobile-product-meta<?php echo $jluxe_is_simple ? ' reference-simple-product-meta' : ''; ?>" data-reference-product-meta>
						<span class="reference-mobile-meta-item reference-mobile-stock <?php echo $cp3_mobile_in_stock ? 'is-in-stock' : 'is-out-of-stock'; ?>" data-reference-stock-status="<?php echo $cp3_mobile_in_stock ? 'in-stock' : 'out-of-stock'; ?>">
							<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.7"/><path d="m8.5 12.2 2.4 2.4 4.6-5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
							<?php echo esc_html( $cp3_mobile_in_stock ? 'موجود' : 'ناموجود' ); ?>
						</span>
						<?php if ( $jluxe_is_simple && $cp3_mobile_in_stock && null !== $cp3_stock_qty && ! $cp3_stock_warning_is_low ) : ?>
							<span class="reference-mobile-meta-item reference-mobile-stock-count" data-jluxe-stock-count><span>موجودی:</span><bdi data-jluxe-stock-quantity><?php echo esc_html( jluxe_fa_digits( (string) $cp3_stock_qty ) ); ?></bdi><span>عدد</span></span>
						<?php endif; ?>
						<?php if ( $product->get_sku() ) : ?>
							<span class="reference-mobile-meta-item" data-reference-sku><span>کد محصول:</span><bdi dir="ltr"><?php echo esc_html( $product->get_sku() ); ?></bdi></span>
						<?php endif; ?>
						<?php if ( $cp3_delivery_time_visible && '' !== $cp3_delivery_time ) : ?>
							<span class="reference-mobile-meta-item reference-mobile-meta-item--delivery" data-jluxe-delivery-time-row><span class="reference-mobile-delivery-label">زمان ارسال:</span><bdi data-jluxe-delivery-time><?php echo esc_html( $cp3_delivery_time ); ?></bdi></span>
						<?php endif; ?>
					</div>
					<?php if ( $jluxe_is_variable || ( $cp3_mobile_in_stock && $cp3_stock_warning_is_low ) ) : ?>
						<div class="reference-mobile-stock-warning" data-reference-low-stock data-cp3-low-stock<?php echo $cp3_stock_warning_is_low ? '' : ' hidden="hidden"'; ?> aria-live="polite" aria-atomic="true">
							<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 8v5m0 4h.01M10.3 3.86 2.9 17a2 2 0 0 0 1.74 3h14.72a2 2 0 0 0 1.74-3l-7.36-13.14a2 2 0 0 0-3.44 0Z" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
							<span><bdi data-cp3-stock-quantity><?php echo $cp3_stock_warning_is_low ? esc_html( jluxe_fa_digits( $cp3_stock_qty ) ) : ''; ?></bdi> عدد موجود</span>
						</div>
					<?php endif; ?>
					<?php if ( $jluxe_is_variable && ! empty( $jluxe_variation_attributes ) ) : ?>
						<div class="reference-mobile-variation-options" data-reference-variation-options>
						<?php
						/* دو باگِ واقعیِ گزارش‌شده این‌جا رفع می‌شود:
						 * ۱) get_variation_attributes() برای ویژگی‌های تاکسونومی «نامک»
						 *    (مثل cochek) را برمی‌گرداند، نه نامِ نمایشیِ ترم (مثل «کوچک») —
						 *    پس با get_term_by نامِ واقعیِ ترم چاپ می‌شود.
						 * ۲) ممکن است گزینه‌هایی در فهرست باشند که هیچ تنوعِ واقعیِ
						 *    ساخته‌شده‌ای پشتشان نیست؛ همان منبعِ data-product_variations
						 *    فیلترشان می‌کند تا کلیک روی قرصِ بی‌تنوع، دکمهٔ خرید را
						 *    گمراه نکند (همان قراردادِ سواچ‌های چیدمانِ پیش‌فرض). */
						$cp3_valid_options = array();
						foreach ( (array) $jluxe_available_variations as $cp3_variation ) {
							foreach ( (array) ( $cp3_variation['attributes'] ?? array() ) as $cp3_attr_key => $cp3_attr_value ) {
								$cp3_valid_name = jluxe_normalize_variable_attribute_name( (string) $cp3_attr_key );
								if ( '' === (string) $cp3_attr_value ) {
									$cp3_valid_options[ $cp3_valid_name ]['*'] = true;
								} else {
									$cp3_valid_options[ $cp3_valid_name ][ (string) $cp3_attr_value ] = true;
								}
							}
						}
						$cp3_option_label = static function ( string $cp3_value, string $cp3_name ) use ( $product ): string {
							return jluxe_attribute_option_label( $cp3_value, $cp3_name, $product );
						};
						?>
						<?php $cp3_attr_keys = array_keys( $jluxe_variation_attributes ); ?>
						<?php /* R138: پیش‌فرض‌های مؤثر در بالای قالب یک‌بار محاسبه و بین گزینه‌ها و قیمت مشترک شده‌اند. */ ?>
						<?php foreach ( $jluxe_variation_attributes as $cp3_attr_name => $cp3_attr_options ) : ?>
							<?php
							/* R65: تنوعِ ناموجود غیرقابلِ انتخاب — همان قراردادِ سواچ‌ها؛
							   گزینهٔ فقط-ناموجود با is-disabled رندر می‌شود (حذف نمی‌شود). */
							$cp3_stocky_options = array();
							foreach ( (array) $jluxe_available_variations as $cp3_stocky_variation ) {
								if ( function_exists( 'jluxe_variable_variation_is_available' ) ? ! jluxe_variable_variation_is_available( $cp3_stocky_variation ) : empty( $cp3_stocky_variation['is_in_stock'] ) ) {
									continue;
								}
								foreach ( (array) ( $cp3_stocky_variation['attributes'] ?? array() ) as $cp3_stocky_key => $cp3_stocky_value ) {
									$cp3_stocky_name = jluxe_normalize_variable_attribute_name( (string) $cp3_stocky_key );
									if ( '' === (string) $cp3_stocky_value ) {
										$cp3_stocky_options[ $cp3_stocky_name ]['*'] = true;
									} else {
										$cp3_stocky_options[ $cp3_stocky_name ][ (string) $cp3_stocky_value ] = true;
									}
								}
							}

							$cp3_attr_name     = jluxe_normalize_variable_attribute_name( (string) $cp3_attr_name );
							$cp3_attr_slug      = sanitize_title( $cp3_attr_name );
							$cp3_attr_prompt    = jluxe_variable_attribute_prompt( $cp3_attr_name );
							$cp3_attr_is_color  = jluxe_is_color_attribute( $cp3_attr_name );
							$cp3_default_pick   = isset( $cp3_defaults[ $cp3_attr_name ] ) ? (string) $cp3_defaults[ $cp3_attr_name ] : '';
							if ( ! empty( $cp3_valid_options[ $cp3_attr_name ] ) && empty( $cp3_valid_options[ $cp3_attr_name ]['*'] ) ) {
								$cp3_attr_options = array_values( array_filter( (array) $cp3_attr_options, fn( $cp3_opt ) => isset( $cp3_valid_options[ $cp3_attr_name ][ (string) $cp3_opt ] ) ) );
							}
							$cp3_default_label = '';
							if ( '' !== $cp3_default_pick ) {
								foreach ( (array) $cp3_attr_options as $cp3_default_option ) {
									$cp3_default_option = (string) $cp3_default_option;
									if ( $cp3_default_option === $cp3_default_pick || rawurldecode( $cp3_default_option ) === rawurldecode( $cp3_default_pick ) ) {
										$cp3_default_label = $cp3_option_label( $cp3_default_option, $cp3_attr_name );
										break;
									}
								}
							}
							?>
							<div class="reference-mobile-variation-option" data-jluxe-variation-group="<?php echo esc_attr( $cp3_attr_slug ); ?>">
								<div class="cp3-varlabel"><?php echo esc_html( $cp3_attr_prompt ); ?> <span data-jluxe-variation-selected aria-live="polite" aria-atomic="true"><?php echo esc_html( $cp3_default_label ); ?></span></div>
								<div class="cp3-pills" data-cp3-pills="<?php echo esc_attr( $cp3_attr_slug ); ?>">
									<?php foreach ( $cp3_attr_options as $cp3_opt ) : ?>
										<?php $cp3_opt = (string) $cp3_opt; ?>
										<?php
											$cp3_oos = $cp3_no_available_variation || ( empty( $cp3_stocky_options[ $cp3_attr_name ]['*'] ) && ! empty( $cp3_valid_options[ $cp3_attr_name ] ) && empty( $cp3_stocky_options[ $cp3_attr_name ][ $cp3_opt ] ) );
										?>
										<?php
											$cp3_opt_label       = $cp3_option_label( $cp3_opt, $cp3_attr_name );
											$cp3_is_default_pick = '' !== $cp3_default_pick && ( (string) $cp3_opt === $cp3_default_pick || rawurldecode( (string) $cp3_opt ) === rawurldecode( $cp3_default_pick ) );
											$cp3_opt_swatch_html = jluxe_classic_variation_swatch_html( $cp3_opt, $cp3_attr_name, $cp3_opt_label, $cp3_attr_is_color, $cp3_oos, $cp3_is_default_pick );
										?>
										<?php if ( '' !== $cp3_opt_swatch_html ) : ?>
											<?php echo $cp3_opt_swatch_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper emits escaped button and swatch markup. ?>
										<?php else : ?>
											<button type="button" class="cp3-pill<?php echo $cp3_oos ? ' is-disabled' : ''; ?><?php echo ( ! $cp3_oos && $cp3_is_default_pick ) ? ' is-active' : ''; ?>" data-value="<?php echo esc_attr( $cp3_opt ); ?>"<?php echo $cp3_oos ? ' disabled="disabled" aria-disabled="true" title="' . esc_attr( $cp3_opt_label . ' (ناموجود)' ) . '"' : ''; ?>><?php echo esc_html( $cp3_opt_label ); ?></button>
										<?php endif; ?>
									<?php endforeach; ?>
								</div>
								<div class="variations">
								<select name="attribute_<?php echo esc_attr( $cp3_attr_slug ); ?>" data-attribute_name="attribute_<?php echo esc_attr( $cp3_attr_slug ); ?>" data-show_option_none="yes" data-cp3-select="<?php echo esc_attr( $cp3_attr_slug ); ?>" style="position:absolute;width:1px;height:1px;opacity:0;pointer-events:none" aria-label="<?php echo esc_attr( $cp3_attr_prompt ); ?>">
									<option value=""><?php echo esc_html( $cp3_attr_prompt ); ?></option>
									<?php foreach ( $cp3_attr_options as $cp3_opt ) : ?>
										<?php $cp3_opt = (string) $cp3_opt; ?>
										<option value="<?php echo esc_attr( $cp3_opt ); ?>"<?php echo ( '' !== $cp3_default_pick && ( (string) $cp3_opt === $cp3_default_pick || rawurldecode( (string) $cp3_opt ) === rawurldecode( $cp3_default_pick ) ) ) ? ' selected' : ''; ?>><?php echo esc_html( $cp3_option_label( $cp3_opt, $cp3_attr_name ) ); ?></option>
									<?php endforeach; ?>
								</select>
								</div>
							</div>
						<?php endforeach; ?>
						</div>
					<?php endif; ?>

					<?php jluxe_render_product_notice( $product ); ?>

						<?php if ( $review_count > 0 ) : ?>
							<div class="reference-mobile-rating" aria-label="امتیاز <?php echo esc_attr( jluxe_fa_digits( number_format_i18n( $rating, 1 ) ) ); ?> از ۵ بر اساس <?php echo esc_attr( jluxe_fa_digits( $review_count ) ); ?> دیدگاه">
								<span class="reference-mobile-stars" style="--reference-rating-fill:<?php echo esc_attr( (string) $cp3_mobile_rating_fill ); ?>%" aria-hidden="true"></span>
								<strong class="reference-mobile-rating-score"><?php echo esc_html( jluxe_fa_digits( number_format_i18n( $rating, 1 ) ) ); ?></strong>
								<a href="#sec-reviews"><?php echo esc_html( jluxe_fa_digits( $review_count ) ); ?> دیدگاه</a>
							</div>
						<?php endif; ?>
					<div class="reference-mobile-actions<?php echo ( $cp3_has_specs ) ? ' has-specs' : ' no-specs'; ?>" role="group" aria-label="میانبرهای محصول">
						<a class="reference-mobile-action" href="#sec-desc">
							<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 4.5A2.5 2.5 0 0 1 7.5 2H20v18H7.5A2.5 2.5 0 0 0 5 22V4.5Zm0 0V22m4-15h7m-7 4h7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
							<span>توضیحات</span>
						</a>
						<?php if ( $cp3_has_specs ) : ?>
							<a class="reference-mobile-action" href="#sec-specs">
								<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M8 5h12M8 12h12M8 19h12M3.5 5h.01M3.5 12h.01M3.5 19h.01" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
								<span>مشخصات</span>
							</a>
						<?php endif; ?>
						<a class="reference-mobile-action" href="#sec-reviews">
							<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20 11.5a7.5 7.5 0 0 1-7.5 7.5H8l-4 2v-5.5A7.5 7.5 0 1 1 20 11.5Z" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 11h8M8 14h5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
							<span>دیدگاه‌ها</span>
						</a>
					</div>

					<div class="cp3-meta cp3-wishline-row">
						<button type="button" class="cp3-wishline" data-jluxe-wishlist-toggle="<?php echo esc_attr( (string) $product->get_id() ); ?>" aria-pressed="false">
							<svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M19.463 3.994c-2.682-1.645-5.023-.982-6.429.074c-.576.433-.864.65-1.034.65s-.458-.217-1.034-.65C9.56 3.012 7.219 2.349 4.537 3.994C1.018 6.153.222 13.274 8.34 19.284C9.886 20.427 10.659 21 12 21s2.114-.572 3.66-1.717c8.118-6.008 7.322-13.13 3.803-15.289" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
							<span>۱۰۰٪ شاید این محصول را هم پسندید</span>
						</button>
					</div>

					<?php if ( $review_count > 0 ) : ?>
						<div class="cp3-meta reference-legacy-review-meta">
							<svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m13.728 3.444l1.76 3.549c.24.494.88.968 1.42 1.058l3.189.535c2.04.343 2.52 1.835 1.05 3.307l-2.48 2.5c-.42.423-.65 1.24-.52 1.825l.71 3.095c.56 2.45-.73 3.397-2.88 2.117l-2.99-1.785c-.54-.322-1.43-.322-1.98 0L8.019 21.43c-2.14 1.28-3.44.322-2.88-2.117l.71-3.095c.13-.585-.1-1.402-.52-1.825l-2.48-2.5C1.39 10.42 1.86 8.929 3.899 8.586l3.19-.535c.53-.09 1.17-.564 1.41-1.058l1.76-3.549c.96-1.925 2.52-1.925 3.47 0" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
							<a href="#sec-reviews"><?php echo esc_html( jluxe_fa_digits( $review_count ) ); ?> نظر</a>
						</div>
					<?php endif; ?>

						<?php if ( '' !== trim( (string) $cp3_short_desc ) ) : ?>
							<div class="cp3-short" data-cp3-short>
								<div class="cp3-short-body jluxe-product-description-content"><?php echo jluxe_wrap_product_description_tables( wp_kses_post( wpautop( $cp3_short_desc ) ) ); ?></div>
								<button type="button" class="cp3-short-toggle" data-cp3-short-toggle aria-expanded="false">مشاهده همه</button>
							</div>
						<?php endif; ?>

						<?php $reference_key_features = jluxe_product_key_feature_cards( $product ); ?>
						<?php if ( $reference_key_features ) : ?>
							<section class="reference-key-features" aria-labelledby="reference-key-features-title">
								<h2 id="reference-key-features-title">ویژگی‌های محصول</h2>
								<div class="reference-key-features__grid">
									<?php foreach ( $reference_key_features as $reference_feature ) : ?>
										<div class="reference-key-feature" data-jluxe-key-feature="<?php echo esc_attr( $reference_feature['name'] ); ?>">
											<span><?php echo esc_html( $reference_feature['label'] ); ?></span>
											<strong><?php echo esc_html( $reference_feature['value'] ); ?></strong>
										</div>
									<?php endforeach; ?>
								</div>
							</section>
						<?php endif; ?>


				</div>

				<!-- جعبه‌ی خرید -->
				<div class="cp3-side" data-jluxe-product-buybox>
					<div data-jluxe-buybox-surface>
					<div class="cp3-sidebox">
						<div class="cp3-sidehead">مشخصات</div>
						<?php if ( $cp3_delivery_time_visible && '' !== $cp3_delivery_time ) : ?>
							<div class="cp3-row" data-jluxe-delivery-time-row>
								<span class="cp3-rowlab"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M3 7h11v11H3zM14 11h4l3 3v4h-7z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><circle cx="7.5" cy="18" r="1.5" stroke="currentColor" stroke-width="1.5"/><circle cx="17.5" cy="18" r="1.5" stroke="currentColor" stroke-width="1.5"/></svg>زمان ارسال</span>
								<span class="cp3-rowval" style="color:hsl(var(--primary))" data-jluxe-delivery-time><?php echo esc_html( $cp3_delivery_time ); ?></span>
							</div>
						<?php endif; ?>
						<div class="cp3-row">
							<span class="cp3-rowlab is-ok"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.5"/><path d="m8.5 12.2 2.4 2.4 4.6-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>وضعیت موجودی</span>
							<?php if ( $cp3_is_in_stock ) : ?>
								<span class="cp3-rowval is-ok">موجود</span>
							<?php else : ?>
								<span class="cp3-rowval is-out">ناموجود</span>
							<?php endif; ?>
						</div>
						<?php if ( $jluxe_is_simple && $cp3_is_in_stock && null !== $cp3_stock_qty && ! $cp3_stock_warning_is_low ) : ?>
							<div class="cp3-row" data-jluxe-stock-count>
								<span class="cp3-rowlab">موجودی انبار</span>
								<span class="cp3-rowval is-ok"><bdi data-jluxe-stock-quantity><?php echo esc_html( jluxe_fa_digits( (string) $cp3_stock_qty ) ); ?></bdi> عدد</span>
							</div>
						<?php endif; ?>
						<?php if ( $jluxe_is_variable || $cp3_stock_warning_is_low ) : ?>
							<div class="cp3-stockwarn" data-cp3-low-stock<?php echo $cp3_stock_warning_is_low ? '' : ' hidden="hidden"'; ?> aria-live="polite" aria-atomic="true">
								<svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 9V14M12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12C21 16.9706 16.9706 21 12 21ZM12.0498 17V17.1L11.9502 17.1002V17H12.0498Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
								<span>فقط <bdi data-cp3-stock-quantity><?php echo $cp3_stock_warning_is_low ? esc_html( jluxe_fa_digits( $cp3_stock_qty ) ) : ''; ?></bdi> عدد موجود است</span>
							</div>
						<?php endif; ?>
					</div>

					<?php if ( $product->get_sku() ) : ?>
						<div class="cp3-sku">کد محصول: <?php echo esc_html( $product->get_sku() ); ?></div>
					<?php endif; ?>
					<div class="cp3-dashed max-md:hidden" aria-hidden="true"></div>

					<div class="cp3-price<?php echo ( $jluxe_is_variable && '' === $cp3_default_variation_price_html ) ? ' is-placeholder' : ''; ?>" data-cp3-price<?php if ( $jluxe_is_variable ) : ?> data-cp3-empty-text="<?php echo esc_attr( $cp3_price_placeholder ); ?>" aria-live="polite" aria-atomic="true"<?php endif; ?>>
						<?php if ( $jluxe_is_variable ) : ?>
							<?php if ( '' !== $cp3_default_variation_price_html ) : ?>
								<?php echo $cp3_default_variation_price_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Price helper returns WooCommerce price HTML sanitized with the theme's narrow SVG allowlist. ?>
							<?php else : ?>
								<?php echo esc_html( $cp3_price_placeholder ); ?>
							<?php endif; ?>
						<?php else : ?>
							<?php echo jluxe_price_kses( jluxe_reference_price_html( $product->get_price_html() ) ); ?>
						<?php endif; ?>
					</div>

					<div class="cp3-addrow<?php echo $jluxe_is_simple ? ' is-simple' : ''; ?>">
						<?php if ( $jluxe_is_variable ) : ?>
							<div class="single_variation_wrap">
							<?php if ( ! empty( $cp3_defaults ) ) : ?>
							<?php do_action( 'woocommerce_before_single_variation' ); ?>
							<?php do_action( 'woocommerce_single_variation' ); ?>
							<?php do_action( 'woocommerce_after_single_variation' ); ?>
							<?php endif; ?>
							</div>
						<?php else : ?>
							<?php woocommerce_template_single_add_to_cart(); ?>
						<?php endif; ?>
					</div>
					<?php if ( function_exists( 'jluxe_render_stock_alert_trigger' ) ) { jluxe_render_stock_alert_trigger( $product ); } ?>

					<div class="cp3-fabs">
						<button type="button" class="cp3-fab cp3-heart" data-jluxe-wishlist-toggle="<?php echo esc_attr( (string) $product->get_id() ); ?>" data-jluxe-wishlist-inactive-label="افزودن به علاقه‌مندی‌ها" data-jluxe-wishlist-active-label="حذف از علاقه‌مندی‌ها" aria-pressed="false" aria-label="افزودن به علاقه‌مندی‌ها">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M19.463 3.994c-2.682-1.645-5.023-.982-6.429.074c-.576.433-.864.65-1.034.65s-.458-.217-1.034-.65C9.56 3.012 7.219 2.349 4.537 3.994C1.018 6.153.222 13.274 8.34 19.284C9.886 20.427 10.659 21 12 21s2.114-.572 3.66-1.717c8.118-6.008 7.322-13.13 3.803-15.289" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
						</button>
						<button type="button" class="cp3-fab" data-jluxe-share aria-label="اشتراک‌گذاری">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M10.002 3c-2.947.032-4.591.22-5.684 1.312C3 5.63 3 7.752 3 11.997s0 6.366 1.318 7.685S7.76 21 12.003 21s6.366 0 7.685-1.319c1.093-1.092 1.28-2.737 1.312-5.685M14 3h4c1.414 0 2.121 0 2.56.44C21 3.878 21 4.585 21 6v4m-1-6l-9 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
						</button>
						<a class="cp3-fab" href="#sec-reviews" aria-label="دیدگاه‌ها">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M21 21H4.6c-.56 0-.84 0-1.054-.109a1 1 0 0 1-.437-.437C3 20.24 3 19.96 3 19.4V3m17 5l-3.919 4.183a.5.5 0 0 1-.612.085L11.53 9.268a.5.5 0 0 0-.612.085L7 13.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
						</a>
					</div>
					</div>
				</div>
			</div>
		</div>

		<?php if ( $jluxe_is_variable ) : ?>
		</form>
		<?php endif; ?>
		<?php if ( function_exists( 'jluxe_render_stock_alert_dialog' ) ) { jluxe_render_stock_alert_dialog( $product ); } ?>

		<div class="jluxe-product-detail-layout cp3-details-layout" data-jluxe-buybox-range>
		<div class="cp3-details-main" data-jluxe-product-detail-main>
		<!-- نوارِ چسبانِ بخش‌ها -->
		<div class="cp3-nav" data-cp3-nav>
			<div class="cp3-nav-cur">
				<small>پرش به قسمت</small>
				<strong data-cp3-nav-label>توضیحات</strong>
			</div>
			<nav class="cp3-tabs" aria-label="بخش‌های صفحه محصول">
				<button type="button" class="cp3-tab is-active" data-cp3-tab="sec-desc">توضیحات</button>
				<?php if ( $cp3_has_specs ) : ?>
					<button type="button" class="cp3-tab" data-cp3-tab="sec-specs">مشخصات</button>
				<?php endif; ?>
				<button type="button" class="cp3-tab" data-cp3-tab="sec-reviews">دیدگاه‌ها</button>
				<?php if ( ! empty( $cp3_faq_items ) ) : ?>
					<button type="button" class="cp3-tab" data-cp3-tab="faq">سوالات متداول</button>
				<?php endif; ?>
			</nav>
			<div class="cp3-nav-arrows">
				<button type="button" data-cp3-nav-prev aria-label="بخش قبلی" disabled>
					<svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m18 15-6-6-6 6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
				</button>
				<button type="button" data-cp3-nav-next aria-label="بخش بعدی">
					<svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m6 9 6 6 6-6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
				</button>
			</div>
		</div>

		<div class="mt-5 flex flex-col gap-5">
			<!-- ۱) توضیحات -->
			<section id="sec-desc" class="cp3-sec" data-cp3-section="توضیحات">
				<div class="cp3-sechead">
					<span class="cp3-num" dir="ltr">1</span>
					<h3>توضیحات</h3>
					<span class="line" aria-hidden="true"></span>
				</div>
				<div class="cp3-panelcard">
					<div class="cp3-descwrap" data-cp3-descwrap>
						<div class="cp3-descbody jluxe-product-description-content"><?php the_content(); ?></div>
						<div class="cp3-descfade">
							<button type="button" class="cp3-descbtn" data-cp3-descbtn aria-expanded="false">
								<span>مشاهده بیشتر</span>
								<svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M19 9l-7 7-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
							</button>
						</div>
					</div>
				</div>
			</section>

			<!-- ۲) مشخصات -->
			<?php if ( $cp3_has_specs ) : ?>
			<section id="sec-specs" class="cp3-sec" data-cp3-section="مشخصات">
				<div class="cp3-sechead">
					<span class="cp3-num" dir="ltr">2</span>
					<h3>مشخصات</h3>
					<span class="line" aria-hidden="true"></span>
				</div>
				<div class="cp3-panelcard">
					<?php if ( $cp3_display_advanced_groups ) : ?>
						<?php echo jluxe_render_grouped_product_specifications( $cp3_display_advanced_groups, $cp3_additional_spec_rows ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper escapes all labels/values and emits only sanitized swatches. ?>
					<?php else : ?>
						<?php if ( ! empty( $cp3_specs ) ) : ?>
							<div class="cp3-specgroup">
								<div class="cp3-specgroup-head">
									<span class="dot" aria-hidden="true"></span>
									<h4>مشخصات فنی</h4>
								</div>
								<?php foreach ( $cp3_specs as $cp3_spec ) : ?>
									<div class="cp3-specrow">
										<span class="k"><?php echo esc_html( $cp3_spec['label'] ); ?></span>
										<span class="v"><?php if ( ! empty( $cp3_spec['swatches'] ) ) : ?><?php echo jluxe_render_attribute_swatches_html( $cp3_spec['swatches'], $cp3_spec['label'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper emits escaped swatch markup. ?><?php else : ?><?php echo esc_html( $cp3_spec['value'] ); ?><?php endif; ?></span>
									</div>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
						<?php if ( ! empty( $cp3_variation_specs ) ) : ?>
							<div class="cp3-specgroup">
								<div class="cp3-specgroup-head">
									<span class="dot" aria-hidden="true"></span>
									<h4>سایر مشخصات</h4>
								</div>
								<?php foreach ( $cp3_variation_specs as $cp3_spec ) : ?>
									<div class="cp3-specrow">
										<span class="k"><?php echo esc_html( $cp3_spec['label'] ); ?></span>
										<span class="v"><?php if ( ! empty( $cp3_spec['swatches'] ) ) : ?><?php echo jluxe_render_attribute_swatches_html( $cp3_spec['swatches'], $cp3_spec['label'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper emits escaped swatch markup. ?><?php else : ?><?php echo esc_html( $cp3_spec['value'] ); ?><?php endif; ?></span>
									</div>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
					<?php endif; ?>
				</div>
			</section>
			<?php endif; ?>

			<!-- ۳) دیدگاه‌ها -->
			<section id="sec-reviews" class="cp3-sec" data-cp3-section="دیدگاه‌ها">
				<div class="cp3-sechead">
					<span class="cp3-num" dir="ltr">3</span>
					<h3>دیدگاه‌ها</h3>
					<span class="line" aria-hidden="true"></span>
				</div>
				<div class="jluxe-reviews jluxe-panel mt-6">
					<?php if ( $review_count > 0 ) : ?>
						<div class="cp3-rate">
							<div class="cp3-rate-bars">
								<?php
								$cp3_total = max( 1, $review_count );
								foreach ( array(
									'pos' => array( 'مثبت', $cp3_counts['pos'] ),
									'neu' => array( 'بی‌طرف', $cp3_counts['neu'] ),
									'neg' => array( 'منفی', $cp3_counts['neg'] ),
								) as $cp3_key => $cp3_bar ) :
									$cp3_pct = (int) round( $cp3_bar[1] * 100 / $cp3_total );
									?>
									<div class="cp3-ratebar <?php echo esc_attr( $cp3_key ); ?>">
										<span class="lbl"><?php echo esc_html( $cp3_bar[0] ); ?> <i dir="ltr">(<?php echo esc_html( jluxe_fa_digits( $cp3_bar[1] ) ); ?>)</i></span>
										<div class="track"><div class="fill" style="width:<?php echo esc_attr( (string) $cp3_pct ); ?>%"></div></div>
										<span class="pct"><?php echo esc_html( jluxe_fa_digits( $cp3_pct ) ); ?>٪</span>
									</div>
								<?php endforeach; ?>
							</div>
							<div class="cp3-rate-score">
								<div class="score"><?php echo esc_html( jluxe_fa_digits( number_format_i18n( $rating, 1 ) ) ); ?></div>
								<div class="stars" dir="ltr" aria-hidden="true">★★★★★</div>
								<div class="of">از <?php echo esc_html( jluxe_fa_digits( $review_count ) ); ?> دیدگاه</div>
							</div>
						</div>
					<?php endif; ?>
				<?php jluxe_render_review_insights( (int) $product->get_id() ); ?>
				<div class="cp3-reviewtoolbar">
					<div class="cp3-sortsel" role="group" aria-label="مرتب‌سازی دیدگاه‌ها" data-cp3-sort>
						<button type="button" class="is-active" data-sort="newest" aria-pressed="true">جدیدترین</button>
						<button type="button" data-sort="best" aria-pressed="false">بیشترین امتیاز</button>
						<button type="button" data-sort="worst" aria-pressed="false">کمترین امتیاز</button>
					</div>
					<?php if ( $cp3_review_form_open ) : ?>
						<a class="cp3-reviewbtn" href="#review_form_wrapper" data-jluxe-review-modal>
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 20h9M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
							ثبت دیدگاه
						</a>
					<?php else : ?>
						<span class="cp3-reviewbtn is-disabled" aria-disabled="true" title="<?php echo esc_attr( $cp3_review_closed_reason ); ?>">
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 20h9M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
							ثبت دیدگاه بسته است
						</span>
					<?php endif; ?>
				</div>
				<?php
				/* امتیازِ هر دیدگاه (متای استانداردِ ووکامرس) به‌شکل کلاس می‌آید تا مرتب‌سازیِ سمتِ مرورگر ممکن باشد */
				add_filter( 'comment_class', function ( array $classes, $cp3_class, $cp3_comment_id ) {
					$cp3_rating = (int) get_comment_meta( (int) $cp3_comment_id, 'rating', true );
					if ( $cp3_rating > 0 ) { $classes[] = 'jluxe-rating-' . $cp3_rating; }
					return $classes;
				}, 10, 3 );
				comments_template();
				?>
				</div>
			</section>

			<!-- سوالات متداول -->
			<?php if ( ! empty( $cp3_faq_items ) ) : ?>
				<section id="faq" class="cp3-faq cp3-sec" data-cp3-section="سوالات متداول" aria-labelledby="cp3-faq-title" dir="rtl">
					<div class="cp3-faq-head">
						<div>
							<div class="cp3-faq-title-row">
								<span class="ic" aria-hidden="true">
									<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M9.6 9a2.5 2.5 0 1 1 4.6 1.4c-.8 1-2.2 1.2-2.2 2.6"/><path d="M12 16.5h.01"/></svg>
								</span>
								<h3 id="cp3-faq-title">سوالات متداول</h3>
							</div>
							<span class="cp3-faq-subtitle">شاید سوال تو هم باشه</span>
						</div>
					</div>
					<div class="cp3-faq-list">
					<?php foreach ( $cp3_faq_items as $cp3_faq ) : ?>
						<?php
						$cp3_q = trim( (string) ( $cp3_faq['question'] ?? '' ) );
						$cp3_a = trim( (string) ( $cp3_faq['answer'] ?? '' ) );
						if ( '' === $cp3_q || '' === $cp3_a ) { continue; }
						?>
						<details class="cp3-faq-item">
							<summary>
								<span><?php echo esc_html( $cp3_q ); ?></span>
								<svg class="chev" width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M15.5 19l-7-7 7-7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
							</summary>
							<div class="a"><?php echo esc_html( $cp3_a ); ?></div>
						</details>
					<?php endforeach; ?>
					</div>
				</section>
			<?php endif; ?>
		</div>
		</div>
		<div data-jluxe-buybox-rail aria-hidden="true"></div>
		</div>

		<!-- محصولات مرتبط -->
		<?php
		$cp3_related_args = apply_filters(
			'woocommerce_output_related_products_args',
			array(
				'posts_per_page' => 4,
				'columns'        => 4,
			)
		);
		?>
		<div class="cp3-related" data-cp3-related>
			<div class="cp3-relhead">
				<span class="ic" aria-hidden="true">
					<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M2.5 7.5v6c0 3.771 0 5.657 1.172 6.828S6.729 21.5 10.5 21.5h3c3.771 0 5.657 0 6.828-1.172S21.5 17.271 21.5 13.5v-6M3.87 5.315L2.5 7.5h19l-1.252-2.087c-.854-1.423-1.28-2.134-1.969-2.524c-.687-.389-1.517-.389-3.176-.389h-6.15c-1.623 0-2.435 0-3.113.375c-.678.376-1.109 1.064-1.97 2.44M12 7.5v-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
				</span>
				<h3>محصولات مرتبط</h3>
				<div class="cp3-relnav" data-cp3-rel-nav hidden>
					<button type="button" class="cp3-relbtn" data-cp3-rel-prev aria-label="محصول قبلی">
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M9 5l7 7-7 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
					</button>
					<button type="button" class="cp3-relbtn" data-cp3-rel-next aria-label="محصول بعدی">
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
					</button>
				</div>
			</div>
			<?php woocommerce_output_related_products(); ?>
		</div>
		<?php if ( function_exists( 'jluxe_render_recent_products_panel' ) ) { jluxe_render_recent_products_panel( 'product' ); } ?>

		<div style="height:70px" aria-hidden="true"></div>
	</div>
</div>
<?php
/* R60 — باگِ واقعیِ گزارش‌شده («بعد از افزودن به سبد، محصولاتِ پیشنهادی را نمایش نمی‌دهد»):
مودالِ «اضافه خرید» (R47) فقط در تمپلیتِ modern رندر می‌شد؛ چیدمانِ classic
(پیش‌فرضِ سایت) markup را هرگز نداشت → window.jluxeOpenSuggestedProductsModal
تعریف نمی‌شد و بعدِ افزودنِ موفقِ AJAX هیچ مودالی باز نمی‌شد. همان گاردِ
تمپلیتِ modern، این‌جا هم بیرونِ <form> (بعد از بستنِ آن در بالا): */
if ( $product->is_purchasable() && function_exists( 'jluxe_render_suggested_products_modal' ) ) {
	jluxe_render_suggested_products_modal( $product );
}
?>
<?php jluxe_render_sticky_add_to_cart( $product, true ); ?>

<script>
( function () {
	'use strict';
	var root = document.querySelector( '.jluxe-cp3' );
	if ( ! root ) { return; }

	/* گالری: تامبنیل + زومِ زیر موس */
	var gallery = root.querySelector( '[data-cp3-gallery]' );
	var zoomBox = root.querySelector( '[data-cp3-zoom-box]' );
	var zoomImg = root.querySelector( '[data-cp3-zoom-img]' );
	var motionOk = ! window.matchMedia || ! window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	function cp3MarkLoaded() { if ( zoomImg ) { zoomImg.classList.add( 'is-loaded' ); } }
	if ( zoomImg ) {
		if ( zoomImg.complete && zoomImg.naturalWidth ) { cp3MarkLoaded(); }
		zoomImg.addEventListener( 'load', cp3MarkLoaded );
	}
	function selectGalleryImage( galleryIndex, activeControl ) {
		var imageThumb = root.querySelector( '.cp3-thumb[data-jluxe-gallery-open="' + String( galleryIndex ) + '"]' );
		if ( ! imageThumb ) { return false; }
		root.querySelectorAll( '[data-cp3-thumb]' ).forEach( function ( thumb ) {
			var thumbIndex = parseInt( thumb.getAttribute( 'data-reference-gallery-index' ) || thumb.getAttribute( 'data-jluxe-gallery-open' ), 10 );
			var selected = thumbIndex === galleryIndex;
			thumb.classList.toggle( 'is-active', selected );
			thumb.setAttribute( 'aria-pressed', selected ? 'true' : 'false' );
		} );
		if ( gallery ) { gallery.setAttribute( 'data-jluxe-gallery-current', String( galleryIndex ) ); }
		if ( activeControl && typeof activeControl.scrollIntoView === 'function' ) {
			activeControl.scrollIntoView( { behavior: motionOk ? 'smooth' : 'auto', block: 'nearest', inline: 'nearest' } );
		}
		if ( zoomImg && imageThumb.getAttribute( 'data-full' ) ) {
			zoomImg.classList.remove( 'is-loaded' );
			zoomImg.removeAttribute( 'srcset' );
			zoomImg.removeAttribute( 'sizes' );
			zoomImg.src = imageThumb.getAttribute( 'data-full' );
			if ( zoomImg.complete && zoomImg.naturalWidth ) { cp3MarkLoaded(); }
		}
		return true;
	}
	root.querySelectorAll( '[data-cp3-thumb]' ).forEach( function ( thumb ) {
		thumb.addEventListener( 'click', function () {
			var galleryIndex = parseInt( thumb.getAttribute( 'data-reference-gallery-index' ) || thumb.getAttribute( 'data-jluxe-gallery-open' ), 10 );
			if ( ! isNaN( galleryIndex ) ) { selectGalleryImage( galleryIndex, thumb ); }
		} );
	} );
	if ( zoomBox && gallery && zoomImg ) {
		var touchStart = null;
		var suppressGalleryOpenUntil = 0;
		zoomBox.addEventListener( 'touchstart', function ( event ) {
			var point = event.touches && event.touches[0];
			if ( point ) { touchStart = { x: point.clientX, y: point.clientY }; }
		}, { passive: true } );
		zoomBox.addEventListener( 'touchend', function ( event ) {
			var point = event.changedTouches && event.changedTouches[0];
			if ( ! touchStart || ! point ) { touchStart = null; return; }
			var deltaX = point.clientX - touchStart.x;
			var deltaY = point.clientY - touchStart.y;
			touchStart = null;
			if ( Math.abs( deltaX ) < 48 || Math.abs( deltaX ) < Math.abs( deltaY ) * 1.25 ) { return; }
			var imageCount = root.querySelectorAll( '.cp3-thumb[data-jluxe-gallery-open]' ).length;
			if ( imageCount < 2 ) { return; }
			var currentIndex = parseInt( gallery.getAttribute( 'data-jluxe-gallery-current' ), 10 ) || 0;
			var nextIndex = ( currentIndex + ( deltaX < 0 ? 1 : -1 ) + imageCount ) % imageCount;
			if ( selectGalleryImage( nextIndex ) ) {
				suppressGalleryOpenUntil = Date.now() + 450;
			}
		}, { passive: true } );
		zoomBox.addEventListener( 'touchcancel', function () { touchStart = null; }, { passive: true } );
		zoomBox.addEventListener( 'click', function ( event ) {
			if ( Date.now() < suppressGalleryOpenUntil ) {
				event.preventDefault();
				event.stopImmediatePropagation();
			}
		}, true );
	}
	if ( zoomBox && zoomImg && motionOk ) {
		zoomBox.addEventListener( 'mousemove', function ( e ) {
			var rect = zoomBox.getBoundingClientRect();
			var x = ( ( e.clientX - rect.left ) / rect.width ) * 100;
			var y = ( ( e.clientY - rect.top ) / rect.height ) * 100;
			zoomImg.style.transformOrigin = x + '% ' + y + '%';
			zoomImg.style.transform = 'scale(1.8)';
		} );
		zoomBox.addEventListener( 'mouseleave', function () {
			zoomImg.style.transform = 'scale(1)';
		} );
	}

	/* قرص‌های تنوع ↔ سلکتِ واقعی ووکامرس */
	root.querySelectorAll( '[data-cp3-pills]' ).forEach( function ( pillGroup ) {
		var slug = pillGroup.getAttribute( 'data-cp3-pills' );
		var select = root.querySelector( 'select[data-cp3-select="' + slug + '"]' );
		if ( ! select ) { return; }
		function sync( value ) {
			pillGroup.querySelectorAll( '.cp3-pill' ).forEach( function ( pill ) {
				pill.classList.toggle( 'is-active', pill.getAttribute( 'data-value' ) === value );
			} );
		}
		pillGroup.querySelectorAll( '.cp3-pill' ).forEach( function ( pill ) {
			pill.addEventListener( 'click', function () {
				var v = pill.getAttribute( 'data-value' );
				// گزینه‌ای که ووکامرس فیلتر کرده (option.disabled / حذف‌شده) انتخاب نمی‌شود — دقیقاً مثل خودِ select.
				var opt = select.querySelector( 'option[value="' + String( v ).replace( /\\/g, '\\\\' ).replace( /"/g, '\\"' ) + '"]' );
				if ( ! opt || opt.disabled ) { return; }
				select.value = v;
				sync( select.value );
				select.dispatchEvent( new Event( 'change', { bubbles: true } ) );
			} );
		} );
		select.addEventListener( 'change', function () { sync( select.value ); } );
	} );

	/* priceBox و found_variation در assets/js/woocommerce.js به‌صورت مشترک bind می‌شوند. */

	/* فلش‌های چپ/راستِ نوارِ تامبنیل: برای تصاویری که در عرضِ صفحه جا نمی‌شوند.
	در RTL مرورگر scrollLeft منفی است؛ قدرمطلقِ آن مختصاتِ جهت‌بی‌طرف می‌دهد. */
	var thumbsStrip = root.querySelector( '.cp3-thumbs' );
	var thumbsRow = root.querySelector( '.cp3-thumbsrow' );
	if ( thumbsStrip && thumbsRow ) {
		var tPrev = thumbsRow.querySelector( '[data-cp3-thumbs-prev]' );
		var tNext = thumbsRow.querySelector( '[data-cp3-thumbs-next]' );
		var tMax = function () { return Math.max( 0, thumbsStrip.scrollWidth - thumbsStrip.clientWidth ); };
		var tPos = function () { return Math.abs( thumbsStrip.scrollLeft ); };
		var tUpdate = function () {
			var over = tMax() > 2;
			if ( tPrev ) { tPrev.hidden = ! over; }
			if ( tNext ) { tNext.hidden = ! over; }
			if ( ! over ) { return; }
			if ( tPrev ) { tPrev.disabled = tPos() <= 2; }
			if ( tNext ) { tNext.disabled = tPos() >= tMax() - 2; }
		};
		var tGo = function ( dir ) {
			var rtl = ! ( window.getComputedStyle && getComputedStyle( thumbsStrip ).direction !== 'rtl' );
			var amount = Math.max( 120, thumbsStrip.clientWidth * 0.8 ) * dir;
			thumbsStrip.scrollBy( { left: rtl ? -amount : amount, behavior: motionOk ? 'smooth' : 'auto' } );
		};
		if ( tPrev ) { tPrev.addEventListener( 'click', function () { tGo( -1 ); } ); }
		if ( tNext ) { tNext.addEventListener( 'click', function () { tGo( 1 ); } ); }
		thumbsStrip.addEventListener( 'scroll', function () { window.requestAnimationFrame( tUpdate ); }, { passive: true } );
		window.addEventListener( 'resize', tUpdate );
		tUpdate();
	}

	/* نوارِ چسبانِ بخش‌ها: اسکرول‌اسپای + قبلی/بعدی */
	var nav = root.querySelector( '[data-cp3-nav]' );
	if ( nav ) {
		var sections = Array.prototype.slice.call( root.querySelectorAll( '[data-cp3-section]' ) );
		var tabs = Array.prototype.slice.call( nav.querySelectorAll( '.cp3-tab' ) );
		var label = nav.querySelector( '[data-cp3-nav-label]' );
		var prev = nav.querySelector( '[data-cp3-nav-prev]' );
		var next = nav.querySelector( '[data-cp3-nav-next]' );
		var current = 0;
		function setActive( index ) {
			current = Math.max( 0, Math.min( sections.length - 1, index ) );
			tabs.forEach( function ( tab, i ) {
				tab.classList.toggle( 'is-active', i === current );
			} );
			if ( label ) { label.textContent = sections[ current ].getAttribute( 'data-cp3-section' ); }
			if ( prev ) { prev.disabled = current === 0; }
			if ( next ) { next.disabled = current === sections.length - 1; }
		}
		function goTo( index ) {
			var target = sections[ Math.max( 0, Math.min( sections.length - 1, index ) ) ];
			if ( target && target.scrollIntoView ) { target.scrollIntoView( { behavior: 'smooth', block: 'start' } ); }
		}
		tabs.forEach( function ( tab ) {
			tab.addEventListener( 'click', function () {
				goTo( sections.findIndex( function ( s ) { return s.id === tab.getAttribute( 'data-cp3-tab' ); } ) );
			} );
		} );
		if ( prev ) { prev.addEventListener( 'click', function () { goTo( current - 1 ); } ); }
		if ( next ) { next.addEventListener( 'click', function () { goTo( current + 1 ); } ); }
		if ( 'IntersectionObserver' in window ) {
			var spy = new IntersectionObserver( function ( entries ) {
				entries.forEach( function ( entry ) {
					if ( entry.isIntersecting ) {
						setActive( sections.findIndex( function ( s ) { return s === entry.target; } ) );
					}
				} );
			}, { rootMargin: '-40% 0px -55% 0px' } );
			sections.forEach( function ( s ) { spy.observe( s ); } );
		}
		setActive( 0 );
	}

	/* «مشاهده بیشتر» توضیحات + خلاصه‌ی کوتاه */
	var descWrap = root.querySelector( '[data-cp3-descwrap]' );
	var descBtn = root.querySelector( '[data-cp3-descbtn]' );
	if ( descWrap && descBtn ) {
		descBtn.addEventListener( 'click', function () {
			var open = descWrap.classList.toggle( 'is-open' );
			descBtn.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
			descBtn.querySelector( 'span' ).textContent = open ? 'نمایش کمتر' : 'مشاهده بیشتر';
		} );
	}
	var shortBox = root.querySelector( '[data-cp3-short]' );
	var shortBtn = root.querySelector( '[data-cp3-short-toggle]' );
	if ( shortBox && shortBtn ) {
		var shortBody = shortBox.querySelector( '.cp3-short-body' );
		// متنِ کوتاه که clamp نمی‌شود به دکمه نیاز ندارد — باگِ واقعی:
		// دکمهٔ «مشاهده همه» حتی برای توضیحِ یک‌خطی نشان داده می‌شد.
		if ( shortBody && shortBody.scrollHeight <= shortBody.clientHeight + 2 ) {
			shortBtn.hidden = true;
		}
		shortBtn.addEventListener( 'click', function () {
			var open = shortBox.classList.toggle( 'is-open' );
			shortBtn.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
			shortBtn.textContent = open ? 'بستن' : 'مشاهده همه';
		} );
	}

	/* مرتب‌سازیِ دیدگاه‌ها: جدیدترین = ترتیبِ سرور؛ امتیاز از کلاسِ jluxe-rating-N (متای ووکامرس) */
	var sortsel = root.querySelector( '[data-cp3-sort]' );
	if ( sortsel ) {
		var sortList = root.querySelector( '.commentlist' );
		var sortBtns = Array.prototype.slice.call( sortsel.querySelectorAll( 'button[data-sort]' ) );
		sortBtns.forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				sortBtns.forEach( function ( b ) {
					b.classList.toggle( 'is-active', b === btn );
					b.setAttribute( 'aria-pressed', b === btn ? 'true' : 'false' );
				} );
				var mode = btn.getAttribute( 'data-sort' );
				if ( ! sortList || 'newest' === mode || ! sortList.children.length ) { return; }
				var ratingOf = function ( el ) {
					var m = ( el.className || '' ).match( /jluxe-rating-(\d+)/ );
					return m ? parseInt( m[1], 10 ) : -1;
				};
				var items = Array.prototype.slice.call( sortList.children ).filter( function ( el ) { return 1 === el.nodeType; } );
				items.sort( function ( a, b ) {
					var d = ratingOf( a ) - ratingOf( b );
					return 'best' === mode ? -d : d;
				} );
				items.forEach( function ( el ) { sortList.appendChild( el ); } );
			} );
		} );
	}
}() );
</script>
