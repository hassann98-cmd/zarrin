import { j as e } from "../lib/jsx.js";
import { c as S, r as c } from "../lib/icons.js";
import { c as g } from "../lib/utils.js";
import { B as N } from "../components/button.js";
import { C as z } from "../icons/chevron-down.js";
import { P as _ } from "../components/product-card.js";
import { C as P } from "../icons/chevron-right.js";
import { C as I } from "../icons/chevron-left.js";
import { X as R } from "../icons/x.js";
import "../icons/heart.js";
import "../icons/shopping-cart.js";
/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const B = S("SlidersHorizontal", [
    ["line", { x1: "21", x2: "14", y1: "4", y2: "4", key: "obuewd" }],
    ["line", { x1: "10", x2: "3", y1: "4", y2: "4", key: "1q6298" }],
    ["line", { x1: "21", x2: "12", y1: "12", y2: "12", key: "1iu8h1" }],
    ["line", { x1: "8", x2: "3", y1: "12", y2: "12", key: "ntss68" }],
    ["line", { x1: "21", x2: "16", y1: "20", y2: "20", key: "14d8ph" }],
    ["line", { x1: "12", x2: "3", y1: "20", y2: "20", key: "m0wm8r" }],
    ["line", { x1: "14", x2: "14", y1: "2", y2: "6", key: "14e1ph" }],
    ["line", { x1: "8", x2: "8", y1: "10", y2: "14", key: "1i6ji0" }],
    ["line", { x1: "16", x2: "16", y1: "18", y2: "22", key: "1lctlv" }],
  ]),
  w = c.forwardRef(({ className: a, error: i = !1, children: d, ...l }, n) =>
    e.jsxs("div", {
      className: "relative",
      children: [
        e.jsx("select", {
          className: g(
            "flex h-10 w-full appearance-none rounded-md border bg-surface px-3 pe-9 text-body text-foreground transition-colors",
            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2",
            "disabled:cursor-not-allowed disabled:opacity-50",
            i
              ? "border-error focus-visible:ring-error"
              : "border-border focus-visible:ring-primary",
            a,
          ),
          "aria-invalid": i || void 0,
          ref: n,
          ...l,
          children: d,
        }),
        e.jsx(z, {
          className:
            "pointer-events-none absolute end-3 top-1/2 size-4 -translate-y-1/2 text-text-muted",
          "aria-hidden": !0,
        }),
      ],
    }),
  );
w.displayName = "Select";
function o(a) {
  const i = `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400"><rect width="400" height="400" fill="hsl(${a} 40% 88%)"/><rect x="140" y="140" width="120" height="120" rx="12" fill="hsl(${a} 35% 70%)"/></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(i)}`;
}
const L = [
    {
      id: 1,
      href: "#",
      image: o(340),
      name: "سرویس ۱۲ پارچه رومیزی گلدار طرح سلطنتی",
      brand: "زرین",
      price: 485e4,
      salePrice: 399e4,
      rating: 4.6,
      reviewCount: 128,
      stock: "in_stock",
      isNew: !0,
    },
    {
      id: 2,
      href: "#",
      image: o(9),
      name: "ست حوله ۶ تکه پنبه‌ای رنگ کرم",
      brand: "خواب آرام",
      price: 125e4,
      salePrice: 99e4,
      rating: 4.9,
      reviewCount: 302,
      stock: "in_stock",
    },
    {
      id: 3,
      href: "#",
      image: o(61),
      name: "روتختی دونفره طرح مخمل‌کاری‌شده",
      brand: "استیل البرز",
      price: 34e5,
      rating: 3.8,
      reviewCount: 12,
      stock: "out_of_stock",
    },
    {
      id: 4,
      href: "#",
      image: o(220),
      name: "پتو دونفره پشمی طرح‌دار سنگین",
      brand: "خواب آرام",
      price: 21e5,
      rating: 4.2,
      reviewCount: 54,
      stock: "in_stock",
      isVariable: !0,
    },
    {
      id: 5,
      href: "#",
      image: o(186),
      name: "روبالشی ساتن طرح گلدار (۲ عددی)",
      brand: "زرین",
      price: 68e4,
      rating: 4.1,
      reviewCount: 19,
      stock: "in_stock",
    },
    {
      id: 6,
      href: "#",
      image: o(280),
      name: "ملحفه یک‌نفره پنبه‌ای رنگ سفید",
      brand: "استیل البرز",
      price: 95e4,
      salePrice: 76e4,
      rating: 4.7,
      reviewCount: 88,
      stock: "low_stock",
    },
    {
      id: 7,
      href: "#",
      image: o(20),
      name: "سرویس خواب عروس ۸ تکه دو نفره لوکس",
      brand: "زرین",
      price: 72e5,
      rating: 5,
      reviewCount: 6,
      stock: "in_stock",
      isNew: !0,
    },
    {
      id: 8,
      href: "#",
      image: o(9),
      name: "کوسن دکوری مخمل طرح‌دار",
      brand: "خواب آرام",
      price: 42e4,
      rating: 3.5,
      reviewCount: 31,
      stock: "in_stock",
    },
  ],
  A = ["زرین", "خواب آرام", "استیل البرز"],
  O = ["سرمه‌ای", "کرم", "طوسی", "صورتی"];
function k({
  selectedBrands: a,
  toggleBrand: i,
  selectedAttrs: d,
  toggleAttr: l,
  inStockOnly: n,
  setInStockOnly: m,
}) {
  return e.jsxs("div", {
    className: "flex flex-col gap-6",
    children: [
      e.jsxs("div", {
        children: [
          e.jsx("h3", {
            className: "text-label text-foreground",
            children: "برند",
          }),
          e.jsx("ul", {
            className: "mt-3 flex flex-col gap-2",
            children: A.map((r) =>
              e.jsx(
                "li",
                {
                  children: e.jsxs("label", {
                    className:
                      "flex items-center gap-2 text-small text-text-secondary",
                    children: [
                      e.jsx("input", {
                        type: "checkbox",
                        checked: a.includes(r),
                        onChange: () => i(r),
                        className:
                          "size-4 rounded border-border accent-primary",
                      }),
                      r,
                    ],
                  }),
                },
                r,
              ),
            ),
          }),
        ],
      }),
      e.jsxs("div", {
        children: [
          e.jsx("h3", {
            className: "text-label text-foreground",
            children: "رنگ",
          }),
          e.jsx("div", {
            className: "mt-3 flex flex-wrap gap-2",
            children: O.map((r) =>
              e.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => l(r),
                  "aria-pressed": d.includes(r),
                  className: g(
                    "rounded-lg border px-3 py-1.5 text-caption transition-colors",
                    d.includes(r)
                      ? "border-primary bg-primary/5 text-primary"
                      : "border-border text-text-secondary hover:border-primary/50",
                  ),
                  children: r,
                },
                r,
              ),
            ),
          }),
        ],
      }),
      e.jsxs("div", {
        children: [
          e.jsx("h3", {
            className: "text-label text-foreground",
            children: "قیمت (تومان)",
          }),
          e.jsxs("div", {
            className: "mt-3 flex items-center gap-2",
            children: [
              e.jsx("input", {
                type: "number",
                placeholder: "از",
                className:
                  "h-9 w-full rounded-md border border-border bg-surface px-2 text-small",
              }),
              e.jsx("span", { className: "text-text-muted", children: "—" }),
              e.jsx("input", {
                type: "number",
                placeholder: "تا",
                className:
                  "h-9 w-full rounded-md border border-border bg-surface px-2 text-small",
              }),
            ],
          }),
        ],
      }),
      e.jsxs("label", {
        className: "flex items-center gap-2 text-small text-text-secondary",
        children: [
          e.jsx("input", {
            type: "checkbox",
            checked: n,
            onChange: (r) => m(r.target.checked),
            className: "size-4 rounded border-border accent-primary",
          }),
          "فقط کالاهای موجود",
        ],
      }),
    ],
  });
}
function J() {
  const [a, i] = c.useState("newest"),
    [d, l] = c.useState(!1),
    [n, m] = c.useState([]),
    [r, C] = c.useState([]),
    [u, y] = c.useState(!1),
    [x, h] = c.useState(1),
    j = (t) => m((s) => (s.includes(t) ? s.filter((f) => f !== t) : [...s, t])),
    v = (t) => C((s) => (s.includes(t) ? s.filter((f) => f !== t) : [...s, t])),
    p = L.filter(
      (t) =>
        !(
          (u && t.stock === "out_of_stock") ||
          (n.length > 0 && (!t.brand || !n.includes(t.brand)))
        ),
    ),
    b = 3;
  return e.jsxs("div", {
    className: "mx-auto w-full max-w-[1296px] px-4 py-6",
    children: [
      e.jsxs("nav", {
        "aria-label": "مسیر صفحه",
        className: "flex items-center gap-2 text-caption text-text-muted",
        children: [
          e.jsx("a", {
            href: "/",
            className: "hover:text-foreground",
            children: "صفحه اصلی",
          }),
          e.jsx("span", { children: "/" }),
          e.jsx("span", {
            className: "text-text-secondary",
            children: "سرویس خواب",
          }),
        ],
      }),
      e.jsxs("div", {
        className: "mt-3",
        children: [
          e.jsx("h1", {
            className: "text-h1 text-foreground",
            children: "سرویس خواب",
          }),
          e.jsx("p", {
            className: "mt-2 max-w-2xl text-small text-text-secondary",
            children:
              "روتختی، ملحفه، روبالشی و پتو با پارچه‌ی درجه‌یک — مناسب جهیزیه عروس و استفاده‌ی روزمره.",
          }),
          e.jsxs("p", {
            className: "mt-1 text-caption text-text-muted",
            children: [p.length.toLocaleString("fa-IR"), " کالا"],
          }),
        ],
      }),
      e.jsxs("div", {
        className:
          "mt-6 flex items-center justify-between gap-3 border-b border-border pb-4",
        children: [
          e.jsxs(N, {
            variant: "outline",
            size: "sm",
            className: "gap-2 lg:hidden",
            onClick: () => l(!0),
            children: [
              e.jsx(B, { className: "size-4", "aria-hidden": !0 }),
              "فیلترها",
            ],
          }),
          e.jsxs("div", {
            className: "me-auto flex items-center gap-2 lg:me-0 lg:ms-auto",
            children: [
              e.jsx("label", {
                htmlFor: "sort",
                className: "text-small text-text-secondary",
                children: "مرتب‌سازی:",
              }),
              e.jsxs(w, {
                id: "sort",
                value: a,
                onChange: (t) => i(t.target.value),
                className: "w-40",
                children: [
                  e.jsx("option", { value: "newest", children: "جدیدترین" }),
                  e.jsx("option", {
                    value: "popularity",
                    children: "پرفروش‌ترین",
                  }),
                  e.jsx("option", {
                    value: "price-asc",
                    children: "ارزان‌ترین",
                  }),
                  e.jsx("option", {
                    value: "price-desc",
                    children: "گران‌ترین",
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        className: "mt-6 grid gap-8 lg:grid-cols-[220px_1fr]",
        children: [
          e.jsx("aside", {
            className: "hidden lg:block",
            children: e.jsx(k, {
              selectedBrands: n,
              toggleBrand: j,
              selectedAttrs: r,
              toggleAttr: v,
              inStockOnly: u,
              setInStockOnly: y,
            }),
          }),
          e.jsxs("div", {
            children: [
              e.jsx("div", {
                className:
                  "grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-4",
                children: p.map((t) => e.jsx(_, { product: t }, t.id)),
              }),
              e.jsxs("nav", {
                "aria-label": "صفحه‌بندی",
                className: "mt-8 flex items-center justify-center gap-2",
                children: [
                  e.jsx("button", {
                    type: "button",
                    onClick: () => h((t) => Math.max(1, t - 1)),
                    disabled: x === 1,
                    "aria-label": "صفحه‌ی قبل",
                    className:
                      "flex size-9 items-center justify-center rounded-md border border-border text-text-secondary disabled:opacity-40",
                    children: e.jsx(P, {
                      className: "size-4",
                      "aria-hidden": !0,
                    }),
                  }),
                  Array.from({ length: b }).map((t, s) =>
                    e.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => h(s + 1),
                        "aria-current": x === s + 1,
                        className: g(
                          "flex size-9 items-center justify-center rounded-md border text-small",
                          x === s + 1
                            ? "border-primary bg-primary text-primary-foreground"
                            : "border-border text-text-secondary",
                        ),
                        children: (s + 1).toLocaleString("fa-IR"),
                      },
                      s,
                    ),
                  ),
                  e.jsx("button", {
                    type: "button",
                    onClick: () => h((t) => Math.min(b, t + 1)),
                    disabled: x === b,
                    "aria-label": "صفحه‌ی بعد",
                    className:
                      "flex size-9 items-center justify-center rounded-md border border-border text-text-secondary disabled:opacity-40",
                    children: e.jsx(I, {
                      className: "size-4",
                      "aria-hidden": !0,
                    }),
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      d
        ? e.jsxs("div", {
            className: "fixed inset-0 z-40 lg:hidden",
            children: [
              e.jsx("button", {
                type: "button",
                "aria-label": "بستن فیلترها",
                onClick: () => l(!1),
                className: "absolute inset-0 bg-black/40",
              }),
              e.jsxs("div", {
                className:
                  "absolute inset-x-0 bottom-0 max-h-[80vh] overflow-y-auto rounded-t-2xl bg-surface p-5",
                children: [
                  e.jsxs("div", {
                    className:
                      "flex items-center justify-between border-b border-border pb-3",
                    children: [
                      e.jsx("h2", {
                        className: "text-h3 text-foreground",
                        children: "فیلترها",
                      }),
                      e.jsx("button", {
                        type: "button",
                        onClick: () => l(!1),
                        "aria-label": "بستن",
                        className:
                          "flex size-8 items-center justify-center rounded-full text-text-secondary hover:bg-muted",
                        children: e.jsx(R, {
                          className: "size-5",
                          "aria-hidden": !0,
                        }),
                      }),
                    ],
                  }),
                  e.jsx("div", {
                    className: "mt-4",
                    children: e.jsx(k, {
                      selectedBrands: n,
                      toggleBrand: j,
                      selectedAttrs: r,
                      toggleAttr: v,
                      inStockOnly: u,
                      setInStockOnly: y,
                    }),
                  }),
                  e.jsxs(N, {
                    className: "mt-6 w-full",
                    onClick: () => l(!1),
                    children: [
                      "اعمال فیلتر (",
                      p.length.toLocaleString("fa-IR"),
                      " کالا)",
                    ],
                  }),
                ],
              }),
            ],
          })
        : null,
    ],
  });
}
export { J as default };
