import { siteUrl } from "../lib/api.js";
import { j as e } from "../lib/jsx.js";
import { c as q, r as i } from "../lib/icons.js";
import { c as h } from "../lib/utils.js";
import { B as g } from "../components/button.js";
import { P as $, M as B } from "../icons/plus.js";
import { T as D } from "../icons/trash-2.js";
import { C as S } from "../icons/chevron-right.js";
import { C as F } from "../icons/chevron-left.js";
import { T as _ } from "../icons/tag.js";
import { T as Q } from "../icons/truck.js";
import { C as V } from "../icons/chevron-down.js";
import { S as A } from "../icons/search.js";
/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const v = q("CircleCheck", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }],
]);
/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const U = q("Monitor", [
  [
    "rect",
    { width: "20", height: "14", x: "2", y: "3", rx: "2", key: "48i651" },
  ],
  ["line", { x1: "8", x2: "16", y1: "21", y2: "21", key: "1svkeh" }],
  ["line", { x1: "12", x2: "12", y1: "17", y2: "21", key: "vw1qmm" }],
]);
function G(l) {
  const d = `<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><rect width="200" height="200" fill="hsl(${l} 40% 88%)"/><rect x="60" y="60" width="80" height="80" rx="12" fill="hsl(${l} 35% 70%)"/></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(d)}`;
}
const H = [
    {
      id: "c1",
      name: "سرویس ۱۲ پارچه رومیزی گلدار طرح سلطنتی",
      variant: "رنگ: سرمه‌ای",
      image: G(340),
      price: 399e4,
      qty: 1,
    },
  ],
  T = [
    { id: "cart", label: "بررسی سبد خرید", icon: U },
    { id: "shipping", label: "اطلاعات ارسال", icon: Q },
    { id: "payment", label: "نحوه پرداخت", icon: _ },
    { id: "done", label: "پایان خرید", icon: v },
  ],
  R = [
    { id: "post", label: "پست پیشتاز", subtitle: "اقتصادی" },
    { id: "tipax", label: "تیپاکس", subtitle: "سریع‌تر، هزینه بالا" },
    { id: "chapar", label: "چاپار", subtitle: "مناسب مرسوله‌های حجیم" },
  ],
  J = [
    {
      id: "parsian",
      label: "پرداخت پارسیان",
      description: "پرداخت امن با تمام کارت‌های شتاب از طریق درگاه پارسیان",
    },
    {
      id: "zarinpal",
      label: "پرداخت امن زرین‌پال",
      description: "پرداخت امن با تمام کارت‌های شتاب از طریق درگاه زرین‌پال",
    },
    {
      id: "card-to-card",
      label: "انتقال بصورت کارت به کارت",
      description:
        "پس از کلیک بر دکمه پرداخت و تکمیل خرید، به صفحه ثبت جزئیات پرداخت و بارگذاری تصویر رسید هدایت خواهید شد.",
    },
  ];
function p(l) {
  return `${l.toLocaleString("fa-IR")} تومان`;
}
function K({ activeStep: l }) {
  const d = T.findIndex((a) => a.id === l);
  return e.jsx("nav", {
    "aria-label": "مراحل خرید",
    className: "flex items-center justify-center gap-1 py-6 sm:gap-3",
    children: T.map((a, m) => {
      const o = a.icon,
        u = m < d,
        c = m === d;
      return e.jsxs(
        "div",
        {
          className: "flex items-center gap-1 sm:gap-3",
          children: [
            m > 0
              ? e.jsx("span", {
                  className: "h-px w-3 bg-border sm:w-16",
                  "aria-hidden": !0,
                })
              : null,
            e.jsxs("div", {
              className: "flex w-12 flex-col items-center gap-1.5 sm:w-auto",
              children: [
                e.jsx("div", {
                  className: h(
                    "flex size-9 shrink-0 items-center justify-center rounded-full border-2 sm:size-11",
                    u
                      ? "border-success bg-success text-white"
                      : c
                        ? "border-primary text-primary"
                        : "border-border text-text-muted",
                  ),
                  children: e.jsx(o, {
                    className: "size-4 sm:size-5",
                    "aria-hidden": !0,
                  }),
                }),
                e.jsx("span", {
                  className: h(
                    "text-center text-[10px] leading-tight sm:whitespace-nowrap sm:text-caption",
                    c ? "font-medium text-foreground" : "text-text-muted",
                  ),
                  children: a.label,
                }),
              ],
            }),
          ],
        },
        a.id,
      );
    }),
  });
}
const W = [
    { value: "tehran", label: "تهران" },
    { value: "isfahan", label: "اصفهان" },
    { value: "razavi", label: "خراسان رضوی" },
  ],
  X = [{ value: "center", label: "مرکز استان" }];
function L({ value: l, onChange: d, options: a, placeholder: m }) {
  var C;
  const [o, u] = i.useState(!1),
    [c, j] = i.useState(""),
    f = i.useRef(null);
  i.useEffect(() => {
    if (!o) return;
    function r(z) {
      f.current && !f.current.contains(z.target) && (u(!1), j(""));
    }
    return (
      document.addEventListener("mousedown", r),
      () => document.removeEventListener("mousedown", r)
    );
  }, [o]);
  const y = (C = a.find((r) => r.value === l)) == null ? void 0 : C.label,
    w = c.trim() ? a.filter((r) => r.label.includes(c.trim())) : a;
  return e.jsxs("div", {
    className: "relative",
    ref: f,
    children: [
      e.jsxs("button", {
        type: "button",
        onClick: () => u((r) => !r),
        className: h(
          "flex h-[50px] w-full items-center justify-between rounded-2xl border px-5 text-small transition-colors",
          o ? "border-primary" : "border-border",
          y ? "text-foreground" : "text-text-muted",
        ),
        children: [
          e.jsx(V, {
            className: h(
              "size-4 shrink-0 text-text-muted transition-transform",
              o && "rotate-180",
            ),
            "aria-hidden": !0,
          }),
          e.jsx("span", { className: "truncate", children: y ?? m }),
        ],
      }),
      o
        ? e.jsxs("div", {
            className:
              "absolute inset-x-0 top-[calc(100%+6px)] z-20 overflow-hidden rounded-2xl border border-border bg-surface shadow-lg",
            children: [
              e.jsx("div", {
                className: "border-b border-border p-2",
                children: e.jsxs("div", {
                  className: "flex items-center gap-2 rounded-lg bg-muted px-3",
                  children: [
                    e.jsx(A, {
                      className: "size-4 shrink-0 text-text-muted",
                      "aria-hidden": !0,
                    }),
                    e.jsx("input", {
                      autoFocus: !0,
                      type: "text",
                      value: c,
                      onChange: (r) => j(r.target.value),
                      placeholder: "جستجو...",
                      className:
                        "h-9 w-full bg-transparent text-small text-foreground placeholder:text-text-muted focus:outline-none",
                    }),
                  ],
                }),
              }),
              e.jsx("ul", {
                className: "max-h-56 overflow-y-auto p-1.5",
                children:
                  w.length === 0
                    ? e.jsx("li", {
                        className: "px-3 py-2.5 text-small text-text-muted",
                        children: "موردی یافت نشد",
                      })
                    : w.map((r) =>
                        e.jsx(
                          "li",
                          {
                            children: e.jsxs("button", {
                              type: "button",
                              onClick: () => {
                                (d(r.value), u(!1), j(""));
                              },
                              className: h(
                                "flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-small transition-colors hover:bg-muted",
                                r.value === l
                                  ? "bg-primary/5 font-medium text-primary"
                                  : "text-foreground",
                              ),
                              children: [
                                r.label,
                                r.value === l
                                  ? e.jsx(v, {
                                      className: "size-4",
                                      "aria-hidden": !0,
                                    })
                                  : null,
                              ],
                            }),
                          },
                          r.value,
                        ),
                      ),
              }),
            ],
          })
        : null,
    ],
  });
}
function ce() {
  const [l, d] = i.useState("cart"),
    [a, m] = i.useState(H),
    [o, u] = i.useState(""),
    [c, j] = i.useState("post"),
    [f, y] = i.useState("parsian"),
    [w, C] = i.useState(""),
    [r, z] = i.useState(null),
    [n, x] = i.useState({
      fullName: "",
      mobile: "",
      landline: "",
      email: "",
      province: "",
      city: "",
      postalCode: "",
      address: "",
      notes: "",
    }),
    N = a.reduce((t, s) => t + s.price * s.qty, 0),
    E = R.find((t) => t.id === c) ?? R[0],
    I = N,
    M = (t, s) => {
      m((b) =>
        b
          .map((k) => (k.id === t ? { ...k, qty: Math.max(1, k.qty + s) } : k))
          .filter(Boolean),
      );
    },
    O = (t) => {
      m((s) => s.filter((b) => b.id !== t));
    },
    P =
      n.fullName.trim() &&
      n.mobile.trim() &&
      n.province &&
      n.city &&
      n.address.trim();
  return e.jsxs("div", {
    className: "mx-auto w-full max-w-[1296px] px-4 py-6",
    children: [
      e.jsx(K, { activeStep: l === "card-details" ? "payment" : l }),
      l === "cart"
        ? e.jsxs("div", {
            children: [
              e.jsxs("div", {
                className: "overflow-hidden rounded-2xl border border-border",
                children: [
                  e.jsxs("div", {
                    className:
                      "hidden items-center gap-4 border-b border-border bg-muted/60 p-4 text-label text-text-secondary sm:grid sm:grid-cols-[1fr_8rem_8rem]",
                    children: [
                      e.jsx("span", { children: "محصول" }),
                      e.jsx("span", {
                        className: "text-center",
                        children: "جمع قیمت",
                      }),
                      e.jsx("span", {
                        className: "text-center",
                        children: "تعداد",
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "flex flex-col divide-y divide-border",
                    children: [
                      a.map((t) =>
                        e.jsxs(
                          "div",
                          {
                            className:
                              "flex flex-col gap-4 p-4 sm:grid sm:grid-cols-[1fr_8rem_8rem] sm:items-center sm:gap-4",
                            children: [
                              e.jsxs("div", {
                                className: "flex items-center gap-3",
                                children: [
                                  e.jsx("div", {
                                    className:
                                      "size-16 shrink-0 overflow-hidden rounded-lg bg-muted",
                                    children: e.jsx("img", {
                                      src: t.image,
                                      alt: "",
                                      className: "size-full object-cover",
                                    }),
                                  }),
                                  e.jsxs("div", {
                                    className: "text-end",
                                    children: [
                                      e.jsx("p", {
                                        className:
                                          "text-small font-medium text-foreground",
                                        children: t.name,
                                      }),
                                      e.jsx("p", {
                                        className:
                                          "text-caption text-text-muted",
                                        children: t.variant,
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              e.jsx("span", {
                                className:
                                  "text-body text-foreground sm:text-center",
                                children: p(t.price * t.qty),
                              }),
                              e.jsxs("div", {
                                className:
                                  "flex items-center gap-2 sm:justify-self-start",
                                children: [
                                  e.jsxs("div", {
                                    className:
                                      "flex items-center rounded-lg border border-border",
                                    children: [
                                      e.jsx("button", {
                                        type: "button",
                                        onClick: () => M(t.id, 1),
                                        "aria-label": "افزایش تعداد",
                                        className:
                                          "flex size-9 items-center justify-center text-text-secondary transition-transform hover:text-foreground active:scale-90",
                                        children: e.jsx($, {
                                          className: "size-3.5",
                                          "aria-hidden": !0,
                                        }),
                                      }),
                                      e.jsx("span", {
                                        className:
                                          "w-7 text-center text-small text-foreground",
                                        children: t.qty.toLocaleString("fa-IR"),
                                      }),
                                      e.jsx("button", {
                                        type: "button",
                                        onClick: () => M(t.id, -1),
                                        "aria-label": "کاهش تعداد",
                                        className:
                                          "flex size-9 items-center justify-center text-text-secondary transition-transform hover:text-foreground active:scale-90",
                                        children: e.jsx(B, {
                                          className: "size-3.5",
                                          "aria-hidden": !0,
                                        }),
                                      }),
                                    ],
                                  }),
                                  e.jsx("button", {
                                    type: "button",
                                    onClick: () => O(t.id),
                                    "aria-label": "حذف از سبد خرید",
                                    className:
                                      "flex size-9 items-center justify-center rounded-lg text-text-muted transition-all hover:bg-muted hover:text-error active:scale-90 active:bg-muted active:text-error",
                                    children: e.jsx(D, {
                                      className: "size-4",
                                      "aria-hidden": !0,
                                    }),
                                  }),
                                ],
                              }),
                            ],
                          },
                          t.id,
                        ),
                      ),
                      a.length === 0
                        ? e.jsx("p", {
                            className:
                              "p-8 text-center text-small text-text-muted",
                            children: "سبد خرید شما خالی است.",
                          })
                        : null,
                    ],
                  }),
                ],
              }),
              a.length > 0
                ? e.jsxs("div", {
                    className: "ms-auto mt-6 flex max-w-sm flex-col gap-2",
                    children: [
                      e.jsxs("div", {
                        className:
                          "flex items-center justify-between text-small text-text-secondary",
                        children: [
                          e.jsx("span", { children: p(N) }),
                          e.jsxs("span", {
                            children: [
                              "قیمت کالاها (",
                              a.length.toLocaleString("fa-IR"),
                              "):",
                            ],
                          }),
                        ],
                      }),
                      e.jsxs("div", {
                        className:
                          "flex items-center justify-between border-t border-border pt-2 text-body font-bold text-foreground",
                        children: [
                          e.jsx("span", { children: p(N) }),
                          e.jsx("span", { children: "جمع سبد خرید:" }),
                        ],
                      }),
                    ],
                  })
                : null,
              e.jsxs("div", {
                className: "mt-8 flex items-center justify-between gap-3",
                children: [
                  e.jsxs("a", {
                    href: siteUrl("shop"),
                    className:
                      "flex h-12 flex-1 items-center justify-center gap-1.5 rounded-lg border border-border px-5 text-button font-normal text-foreground transition-colors hover:bg-muted sm:w-[190px] sm:flex-none sm:rounded-2xl",
                    children: [
                      e.jsx(S, { className: "size-4", "aria-hidden": !0 }),
                      "بازگشت",
                    ],
                  }),
                  e.jsxs(g, {
                    onClick: () => d("shipping"),
                    disabled: a.length === 0,
                    className:
                      "h-12 flex-1 gap-1.5 rounded-lg px-5 font-normal sm:w-[190px] sm:flex-none sm:rounded-2xl",
                    children: [
                      "ثبت سفارش",
                      e.jsx(F, { className: "size-4", "aria-hidden": !0 }),
                    ],
                  }),
                ],
              }),
            ],
          })
        : null,
      l === "shipping"
        ? e.jsxs("div", {
            className: "grid gap-6 lg:grid-cols-[1fr_320px]",
            children: [
              e.jsx("div", {
                className: "rounded-2xl border border-border p-6",
                children: e.jsxs("div", {
                  className: "grid grid-cols-1 gap-4 sm:grid-cols-2",
                  children: [
                    e.jsxs("div", {
                      className: "grid grid-cols-2 gap-4 sm:col-span-2",
                      children: [
                        e.jsxs("label", {
                          className:
                            "flex flex-col gap-1.5 text-small text-text-secondary",
                          children: [
                            "نام و نام‌خانوادگی",
                            e.jsx("input", {
                              type: "text",
                              value: n.fullName,
                              onChange: (t) =>
                                x((s) => ({ ...s, fullName: t.target.value })),
                              className:
                                "h-[50px] rounded-2xl border border-border px-5 text-small text-foreground",
                            }),
                          ],
                        }),
                        e.jsxs("label", {
                          className:
                            "flex flex-col gap-1.5 text-small text-text-secondary",
                          children: [
                            "ایمیل (اختیاری)",
                            e.jsx("input", {
                              type: "email",
                              dir: "ltr",
                              value: n.email,
                              onChange: (t) =>
                                x((s) => ({ ...s, email: t.target.value })),
                              className:
                                "h-[50px] rounded-2xl border border-border px-5 text-end text-small text-foreground",
                            }),
                          ],
                        }),
                      ],
                    }),
                    e.jsxs("div", {
                      className: "grid grid-cols-2 gap-4 sm:col-span-2",
                      children: [
                        e.jsxs("label", {
                          className:
                            "flex flex-col gap-1.5 text-small text-text-secondary",
                          children: [
                            "شماره موبایل",
                            e.jsx("input", {
                              type: "tel",
                              dir: "ltr",
                              value: n.mobile,
                              onChange: (t) =>
                                x((s) => ({ ...s, mobile: t.target.value })),
                              className:
                                "h-[50px] rounded-2xl border border-border px-5 text-end text-small text-foreground",
                            }),
                          ],
                        }),
                        e.jsxs("label", {
                          className:
                            "flex flex-col gap-1.5 text-small text-text-secondary",
                          children: [
                            "تلفن ثابت (اختیاری)",
                            e.jsx("input", {
                              type: "tel",
                              dir: "ltr",
                              value: n.landline,
                              onChange: (t) =>
                                x((s) => ({ ...s, landline: t.target.value })),
                              className:
                                "h-[50px] rounded-2xl border border-border px-5 text-end text-small text-foreground",
                            }),
                          ],
                        }),
                      ],
                    }),
                    e.jsxs("div", {
                      className: "grid grid-cols-2 gap-4 sm:col-span-2",
                      children: [
                        e.jsxs("label", {
                          className:
                            "flex flex-col gap-1.5 text-small text-text-secondary",
                          children: [
                            "استان",
                            e.jsx(L, {
                              value: n.province,
                              onChange: (t) =>
                                x((s) => ({ ...s, province: t })),
                              options: W,
                              placeholder: "انتخاب کنید",
                            }),
                          ],
                        }),
                        e.jsxs("label", {
                          className:
                            "flex flex-col gap-1.5 text-small text-text-secondary",
                          children: [
                            "شهر",
                            e.jsx(L, {
                              value: n.city,
                              onChange: (t) => x((s) => ({ ...s, city: t })),
                              options: X,
                              placeholder: "انتخاب کنید",
                            }),
                          ],
                        }),
                      ],
                    }),
                    e.jsxs("label", {
                      className:
                        "flex flex-col gap-1.5 text-small text-text-secondary",
                      children: [
                        "کدپستی (اختیاری)",
                        e.jsx("input", {
                          type: "text",
                          dir: "ltr",
                          placeholder:
                            "برای ارسال از طریق پست، درج کد پستی الزامی است",
                          value: n.postalCode,
                          onChange: (t) =>
                            x((s) => ({ ...s, postalCode: t.target.value })),
                          className:
                            "h-[50px] rounded-2xl border border-border px-5 text-right text-small text-foreground placeholder:text-text-muted placeholder:text-right",
                        }),
                      ],
                    }),
                    e.jsxs("label", {
                      className:
                        "flex flex-col gap-1.5 text-small text-text-secondary sm:col-span-2",
                      children: [
                        "آدرس",
                        e.jsx("textarea", {
                          rows: 2,
                          placeholder: "شامل خیابان، کوچه، پلاک و...",
                          value: n.address,
                          onChange: (t) =>
                            x((s) => ({ ...s, address: t.target.value })),
                          className:
                            "rounded-2xl border border-border px-5 py-3 text-body text-foreground placeholder:text-text-muted",
                        }),
                      ],
                    }),
                    e.jsxs("label", {
                      className:
                        "flex flex-col gap-1.5 text-small text-text-secondary sm:col-span-2",
                      children: [
                        "توضیحات (اختیاری)",
                        e.jsx("input", {
                          type: "text",
                          placeholder:
                            "توضیحی که نیاز است در رابطه با سفارش بیان کنید",
                          value: n.notes,
                          onChange: (t) =>
                            x((s) => ({ ...s, notes: t.target.value })),
                          className:
                            "h-[50px] rounded-2xl border border-border px-5 text-small text-foreground placeholder:text-text-muted",
                        }),
                      ],
                    }),
                  ],
                }),
              }),
              e.jsxs("div", {
                className:
                  "flex h-fit flex-col gap-3 rounded-2xl border border-border p-5 lg:sticky lg:top-24",
                children: [
                  e.jsxs("div", {
                    className:
                      "flex items-center justify-between text-small text-text-secondary",
                    children: [
                      e.jsx("span", { children: p(N) }),
                      e.jsxs("span", {
                        children: [
                          "قیمت کالاها (",
                          a.length.toLocaleString("fa-IR"),
                          "):",
                        ],
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "border-t border-border pt-3",
                    children: [
                      e.jsx("p", {
                        className:
                          "mb-3 text-small font-medium text-foreground",
                        children: "روش ارسال را انتخاب کنید",
                      }),
                      e.jsx("div", {
                        className: "flex flex-col gap-2",
                        children: R.map((t) => {
                          const s = c === t.id;
                          return e.jsxs(
                            "button",
                            {
                              type: "button",
                              onClick: () => j(t.id),
                              className: h(
                                "flex items-center justify-between gap-2 rounded-2xl border p-3 text-start transition-colors",
                                s
                                  ? "border-2 border-success bg-success/5"
                                  : "border border-border hover:bg-muted",
                              ),
                              children: [
                                e.jsxs("span", {
                                  children: [
                                    e.jsx("span", {
                                      className:
                                        "block text-small font-medium text-foreground",
                                      children: t.label,
                                    }),
                                    e.jsx("span", {
                                      className:
                                        "block text-caption text-text-muted",
                                      children: t.subtitle,
                                    }),
                                  ],
                                }),
                                e.jsxs("span", {
                                  className: "flex shrink-0 items-center gap-2",
                                  children: [
                                    e.jsx("span", {
                                      className:
                                        "whitespace-nowrap rounded-full bg-muted px-2.5 py-1 text-caption font-medium text-text-secondary",
                                      children: "کرایه در محل",
                                    }),
                                    s
                                      ? e.jsx(v, {
                                          className:
                                            "size-5 shrink-0 text-success",
                                          "aria-hidden": !0,
                                        })
                                      : e.jsx("span", {
                                          className:
                                            "size-5 shrink-0 rounded-full border-2 border-border",
                                          "aria-hidden": !0,
                                        }),
                                  ],
                                }),
                              ],
                            },
                            t.id,
                          );
                        }),
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className:
                      "flex items-center justify-between border-t border-border pt-3 text-body font-bold text-foreground",
                    children: [
                      e.jsx("span", { children: p(I) }),
                      e.jsx("span", { children: "مبلغ قابل پرداخت:" }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "flex items-center gap-3",
                    children: [
                      e.jsxs("button", {
                        type: "button",
                        onClick: () => d("cart"),
                        className:
                          "flex h-12 flex-1 items-center justify-center gap-1.5 rounded-lg border border-border px-5 text-button font-normal text-foreground transition-colors hover:bg-muted",
                        children: [
                          e.jsx(S, { className: "size-4", "aria-hidden": !0 }),
                          "بازگشت",
                        ],
                      }),
                      e.jsx(g, {
                        disabled: !P,
                        onClick: () => d("payment"),
                        className:
                          "h-12 flex-1 gap-1.5 rounded-lg px-5 font-normal",
                        children: "نهایی‌سازی سفارش",
                      }),
                    ],
                  }),
                ],
              }),
            ],
          })
        : null,
      l === "payment"
        ? e.jsxs("div", {
            className: "grid gap-6 lg:grid-cols-[1fr_320px]",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsxs("div", {
                    className:
                      "flex items-start gap-2 rounded-xl bg-warning/15 p-4 text-small text-foreground",
                    children: [
                      e.jsx("span", {
                        className: "mt-0.5 shrink-0 text-warning",
                        children: "⚠",
                      }),
                      "در صورتی که از فیلترشکن (VPN) استفاده می‌کنید، قبل از ورود به درگاه پرداخت آن را خاموش کنید.",
                    ],
                  }),
                  e.jsx("p", {
                    className:
                      "mt-4 mb-3 text-small font-medium text-foreground",
                    children: "روش پرداخت",
                  }),
                  e.jsx("div", {
                    className: "flex flex-col gap-3",
                    children: J.map((t) => {
                      const s = f === t.id;
                      return e.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => y(t.id),
                          className: h(
                            "flex items-center justify-between gap-3 rounded-xl border p-4 text-start transition-colors",
                            s
                              ? "border-2 border-success bg-success/5"
                              : "border border-border hover:bg-muted",
                          ),
                          children: [
                            e.jsxs("div", {
                              children: [
                                e.jsx("p", {
                                  className:
                                    "text-body font-medium text-foreground",
                                  children: t.label,
                                }),
                                e.jsx("p", {
                                  className: "text-caption text-text-muted",
                                  children: t.description,
                                }),
                              ],
                            }),
                            s
                              ? e.jsx(v, {
                                  className: "size-6 shrink-0 text-success",
                                  "aria-hidden": !0,
                                })
                              : e.jsx("span", {
                                  className:
                                    "size-5 shrink-0 rounded-full border-2 border-border",
                                  "aria-hidden": !0,
                                }),
                          ],
                        },
                        t.id,
                      );
                    }),
                  }),
                ],
              }),
              e.jsxs("div", {
                className:
                  "flex h-fit flex-col gap-3 rounded-2xl border border-border p-5 lg:sticky lg:top-24",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center gap-2",
                    children: [
                      e.jsx("input", {
                        type: "text",
                        placeholder: "کد تخفیف",
                        value: o,
                        onChange: (t) => u(t.target.value),
                        className:
                          "min-w-0 flex-1 rounded-lg border border-border px-3 py-2 text-small text-foreground placeholder:text-text-muted",
                      }),
                      e.jsx(g, {
                        variant: "outline",
                        size: "sm",
                        disabled: !o.trim(),
                        children: "اعمال تخفیف",
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className:
                      "flex items-center justify-between text-small text-text-secondary",
                    children: [
                      e.jsx("span", { children: p(N) }),
                      e.jsxs("span", {
                        children: [
                          "قیمت کالاها (",
                          a.length.toLocaleString("fa-IR"),
                          "):",
                        ],
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className:
                      "flex items-center justify-between text-small text-text-secondary",
                    children: [
                      e.jsx("span", { children: "کرایه در محل" }),
                      e.jsxs("span", {
                        children: ["هزینه ارسال (", E.label, "):"],
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className:
                      "flex items-center justify-between border-t border-border pt-3 text-body font-bold text-foreground",
                    children: [
                      e.jsx("span", { children: p(I) }),
                      e.jsx("span", { children: "مبلغ قابل پرداخت:" }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "flex items-center gap-3",
                    children: [
                      e.jsxs("button", {
                        type: "button",
                        onClick: () => d("shipping"),
                        className:
                          "flex h-12 flex-1 items-center justify-center gap-1.5 rounded-lg border border-border px-5 text-button font-normal text-foreground transition-colors hover:bg-muted",
                        children: [
                          e.jsx(S, { className: "size-4", "aria-hidden": !0 }),
                          "بازگشت",
                        ],
                      }),
                      e.jsx(g, {
                        onClick: () =>
                          d(f === "card-to-card" ? "card-details" : "done"),
                        className:
                          "h-12 flex-1 gap-1.5 rounded-lg px-5 font-normal",
                        children: "پرداخت",
                      }),
                    ],
                  }),
                ],
              }),
            ],
          })
        : null,
      l === "card-details"
        ? e.jsxs("div", {
            className: "mx-auto max-w-lg rounded-2xl border border-border p-6",
            children: [
              e.jsxs("div", {
                className: "mb-5 flex items-center gap-3",
                children: [
                  e.jsx("span", {
                    className:
                      "flex size-11 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary",
                    children: e.jsx(_, {
                      className: "size-5",
                      "aria-hidden": !0,
                    }),
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx("h1", {
                        className: "text-h3 text-foreground",
                        children: "ثبت اطلاعات پرداخت کارت‌به‌کارت",
                      }),
                      e.jsx("p", {
                        className: "text-caption text-text-muted",
                        children:
                          "این صفحه توسط افزونه‌ی کارت‌به‌کارت فروشگاه تکمیل می‌شود.",
                      }),
                    ],
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "flex flex-col gap-4",
                children: [
                  e.jsxs("label", {
                    className:
                      "flex flex-col gap-1.5 text-small text-text-secondary",
                    children: [
                      "شماره پیگیری تراکنش (اختیاری)",
                      e.jsx("input", {
                        type: "text",
                        value: w,
                        onChange: (t) => C(t.target.value),
                        className:
                          "h-[50px] rounded-2xl border border-border px-5 text-small text-foreground placeholder:text-text-muted",
                      }),
                    ],
                  }),
                  e.jsxs("label", {
                    className:
                      "flex flex-col gap-1.5 text-small text-text-secondary",
                    children: [
                      "تصویر رسید پرداخت",
                      e.jsx("input", {
                        type: "file",
                        accept: "image/*",
                        onChange: (t) => {
                          var s, b;
                          return z(
                            ((b =
                              (s = t.target.files) == null ? void 0 : s[0]) ==
                            null
                              ? void 0
                              : b.name) ?? null,
                          );
                        },
                        className:
                          "rounded-2xl border border-dashed border-border px-4 py-3 text-small text-foreground file:ml-3 file:rounded-lg file:border-0 file:bg-muted file:px-3 file:py-1.5 file:text-caption file:font-medium file:text-foreground",
                      }),
                      r
                        ? e.jsxs("span", {
                            className: "text-caption text-text-muted",
                            children: ["فایل انتخاب‌شده: ", r],
                          })
                        : null,
                    ],
                  }),
                ],
              }),
              e.jsx(g, {
                size: "lg",
                className: "mt-6 w-full",
                onClick: () => d("done"),
                children: "ثبت اطلاعات پرداخت",
              }),
            ],
          })
        : null,
      l === "done"
        ? e.jsxs("div", {
            className:
              "flex flex-col items-center gap-4 rounded-xl border border-border py-16 text-center",
            children: [
              e.jsx(v, {
                className: "size-16 text-success",
                "aria-hidden": !0,
              }),
              e.jsx("h1", {
                className: "text-h2 text-foreground",
                children: "سفارش شما با موفقیت ثبت شد",
              }),
              e.jsx("p", {
                className: "max-w-md text-body text-text-secondary",
                children:
                  "کد رهگیری سفارش به‌زودی از طریق پیامک برای شما ارسال می‌شود. می‌توانید وضعیت سفارش را از بخش پیگیری سفارش دنبال کنید.",
              }),
              e.jsx("a", {
                href: siteUrl("track_order"),
                children: e.jsx(g, { size: "lg", children: "پیگیری سفارش" }),
              }),
            ],
          })
        : null,
    ],
  });
}
export { ce as default };
