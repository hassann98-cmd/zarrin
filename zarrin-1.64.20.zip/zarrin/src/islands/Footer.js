import { siteLink } from "../lib/api.js";
import { j as e } from "../lib/jsx.js";
import { BrandLogo as y } from "./Header.js";
import { g as N } from "../lib/theme-settings.js";
import { N as p } from "../components/nav-icons.js";
import { c as h } from "../lib/icons.js";
import { S as _ } from "../icons/shield-check.js";
import { S as i } from "../icons/send.js";
import { r as ReactDOM } from "../lib/react-dom.js";
import { useState } from "react";
import "../components/button.js";
import "../lib/utils.js";
import "../lib/use-cart.js";
import "../icons/search.js";
import "../icons/tag.js";
import "../icons/shopping-cart.js";
import "../icons/user.js";
import "../icons/x.js";
import "../icons/grid-2x2.js";
import "../icons/heart.js";
import "../icons/phone.js";
import "../icons/truck.js";
/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const k = h("BadgePercent", [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336",
    },
  ],
  ["path", { d: "m15 9-6 6", key: "1uzhvr" }],
  ["path", { d: "M9 9h.01", key: "1q5me6" }],
  ["path", { d: "M15 15h.01", key: "lqbp3k" }],
]);
/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const w = h("Instagram", [
  [
    "rect",
    {
      width: "20",
      height: "20",
      x: "2",
      y: "2",
      rx: "5",
      ry: "5",
      key: "2e1cvw",
    },
  ],
  [
    "path",
    { d: "M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z", key: "9exkf1" },
  ],
  ["line", { x1: "17.5", x2: "17.51", y1: "6.5", y2: "6.5", key: "r4j83e" }],
]);
function C(s) {
  return s >= 4
    ? "flex flex-row flex-wrap items-center justify-center gap-2 sm:grid sm:grid-cols-2 sm:justify-start sm:gap-2.5"
    : "flex flex-row flex-wrap items-center justify-center gap-2.5 sm:justify-start";
}
function z(s) {
  return s <= 2 ? "h-20 w-28 lg:h-24 lg:w-32" : "h-14 w-20 lg:h-16 lg:w-24";
}
function I(s) {
  if (!s || s.mode === "default") return {};
  if (s.mode === "solid")
    return s.solid_color ? { backgroundColor: s.solid_color } : {};
  const r = (s.gradient_colors ?? []).filter(Boolean);
  return r.length < 2
    ? {}
    : {
        backgroundImage: `linear-gradient(${s.gradient_direction || "to bottom"}, ${r.join(", ")})`,
      };
}
const M = { ...p, "badge-percent": k },
  L = [
    {
      enabled: !0,
      icon: "truck",
      title: "ارسال سریع",
      subtitle: "ارسال فوری تهران و شهرستان",
    },
    {
      enabled: !0,
      icon: "headphones",
      title: "پشتیبانی خوب",
      subtitle: "همیشه آنلاینیم",
    },
    {
      enabled: !0,
      icon: "badge-percent",
      title: "بهترین قیمت",
      subtitle: "مطمئن باش کف قیمت بازار",
    },
    {
      enabled: !0,
      icon: "shield-check",
      title: "امنیت کامل",
      subtitle: "دارای درگاه ایمن و مطمئن",
    },
  ],
  B = [
    {
      title: "راهنما",
      links: [
        { label: "راهنمای خرید", url: "/shopping-guide/", icon: "", svg: "" },
        { label: "روش‌های پرداخت", url: "/payment-guide/", icon: "", svg: "" },
        {
          label: "ارسال و پیگیری سفارش",
          url: "/shipping-and-order-tracking/",
          icon: "",
          svg: "",
        },
        {
          label: "بازگشت و مرجوعی کالا",
          url: "/returns-and-exchanges/",
          icon: "",
          svg: "",
        },
        { label: "پیگیری سفارش", url: "/track-order/", icon: "", svg: "" },
      ],
    },
    {
      title: "شرکت",
      links: [
        { label: "درباره ما", url: "/about-us/", icon: "", svg: "" },
        { label: "تماس با ما", url: "/contact-us/", icon: "", svg: "" },
        { label: "سوالات متداول", url: "/faq/", icon: "", svg: "" },
      ],
    },
  ],
  $ = { instagram: w, telegram: i, whatsapp: i, rubika: i, bale: i },
  H = {
    instagram: "اینستاگرام",
    telegram: "تلگرام",
    whatsapp: "واتس‌اپ",
    rubika: "روبیکا",
    bale: "بله",
  },
  T = "پشتیبانی متنی ۲۴ ساعته: اینستاگرام، تلگرام، واتس‌اپ، روبیکا، بله";
/** R88 — جایگاه‌هایی که footer.php سمتِ سرور می‌سازد؛ نبودشان یعنی footer.php قدیمی. */
export function findFooterSlots(
  doc = typeof document === "undefined" ? null : document,
) {
  if (!doc) return null;
  const pick = (name) =>
    doc.querySelector(`[data-jluxe-footer-slot="${name}"]`);
  const features = pick("features"),
    columns = pick("columns"),
    bottom = pick("bottom");
  return features && columns && bottom ? { features, columns, bottom } : null;
}
function re() {
  const [slots] = useState(() => findFooterSlots());
  const s = N(),
    r = s.footer;
  if (r && !r.enabled) return null;
  const g = s.siteName || "زرین",
    b = (r == null ? void 0 : r.support_hours) || "هر روز ۹ تا ۲۲",
    d = ((r == null ? void 0 : r.feature_cards) ?? L).filter((t) => t.enabled),
    f = (r == null ? void 0 : r.feature_cards_mobile_columns) === 2 ? 2 : 1,
    j = (r == null ? void 0 : r.link_columns) ?? B,
    o = (r == null ? void 0 : r.trust_badges) ?? [],
    m = Object.entries(s.social ?? {}).filter(
      ([, t]) => t.enabled && t.url.trim().length > 0,
    ),
    a = r != null && r.text_color ? { color: r.text_color } : void 0,
    u = (r == null ? void 0 : r.link_color) || void 0,
    x = (r == null ? void 0 : r.link_hover_color) || void 0,
    c = (r == null ? void 0 : r.feature_cards_icon_color) || void 0,
    v = c ? { color: c, backgroundColor: `${c}1a` } : void 0;
  const featuresNode = d.length > 0
              ? e.jsxs(e.Fragment, {
                  children: [
                    e.jsx("style", {
                      children: `.jluxe-feature-grid{grid-template-columns:repeat(${f},minmax(0,1fr))}@media (min-width:640px){.jluxe-feature-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (min-width:1024px){.jluxe-feature-grid{grid-template-columns:repeat(4,minmax(0,1fr))}}`,
                    }),
                    e.jsx("div", {
                      className:
                        "jluxe-feature-grid grid gap-3 border-b border-border p-4",
                      children: d.map((t) => {
                        const l = M[t.icon] ?? _;
                        return e.jsxs(
                          "div",
                          {
                            className:
                              "flex items-center gap-3 rounded-xl border border-border bg-surface/70 p-3 transition-colors hover:border-primary/30",
                            children: [
                              e.jsx("span", {
                                className:
                                  "grid size-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary",
                                style: v,
                                children: t.svg
                                  ? e.jsx("span", {
                                      className: "size-5 [&>svg]:size-full",
                                      "aria-hidden": !0,
                                      dangerouslySetInnerHTML: {
                                        __html: t.svg,
                                      },
                                    })
                                  : e.jsx(l, {
                                      className: "size-5",
                                      "aria-hidden": !0,
                                    }),
                              }),
                              e.jsxs("div", {
                                className: "min-w-0",
                                children: [
                                  e.jsx("p", {
                                    className:
                                      "text-caption font-bold text-foreground",
                                    style: a,
                                    children: t.title,
                                  }),
                                  e.jsx("p", {
                                    className:
                                      "truncate text-[10.5px] text-text-muted",
                                    style: a,
                                    children: t.subtitle,
                                  }),
                                ],
                              }),
                            ],
                          },
                          t.title,
                        );
                      }),
                    }),
                  ],
                })
              : null;
  const columnsNode = [
                e.jsxs("div", {
                  className: "sm:col-span-2 lg:col-span-1",
                  children: [
                    e.jsx(y, {}),
                    e.jsx("p", {
                      className: "mt-3 max-w-xs text-caption text-text-muted",
                      style: a,
                      children:
                        s.shortDescription ||
                        "فروشگاه تخصصی جهیزیه با تضمین اصالت کالا و ارسال مطمئن به سراسر ایران.",
                    }),
                    e.jsxs("ul", {
                      className:
                        "mt-4 flex flex-col gap-2.5 text-caption text-text-muted",
                      style: a,
                      children: [
                        e.jsxs("li", { children: ["پشتیبانی تلفنی: ", b] }),
                        e.jsx("li", {
                          children: (r == null ? void 0 : r.support_text) || T,
                        }),
                      ],
                    }),
                  ],
                }),
                e.jsx("div", {
                  className: "grid grid-cols-2 gap-6 sm:contents",
                  children: j.map((t) =>
                    e.jsxs(
                      "div",
                      {
                        children: [
                          e.jsx("h3", {
                            className:
                              "mb-3 text-small font-bold text-foreground",
                            style: a,
                            children: t.title,
                          }),
                          e.jsx("ul", {
                            className: "space-y-2.5",
                            children: t.links.map((l) => {
                              const n = l.icon ? p[l.icon] : void 0;
                              return e.jsx(
                                "li",
                                {
                                  children: e.jsxs("a", {
                                    href: siteLink(l.url),
                                    "data-jluxe-footer-link": !0,
                                    className:
                                      "flex items-center gap-1.5 text-caption text-text-muted transition-colors hover:text-primary",
                                    style: u ? { color: u } : void 0,
                                    children: [
                                      l.svg
                                        ? e.jsx("span", {
                                            className:
                                              "size-3.5 shrink-0 [&>svg]:size-full",
                                            "aria-hidden": !0,
                                            dangerouslySetInnerHTML: {
                                              __html: l.svg,
                                            },
                                          })
                                        : n
                                          ? e.jsx(n, {
                                              className: "size-3.5 shrink-0",
                                              "aria-hidden": !0,
                                            })
                                          : null,
                                      l.label,
                                    ],
                                  }),
                                },
                                l.url,
                              );
                            }),
                          }),
                        ],
                      },
                      t.title,
                    ),
                  ),
                }),
                o.length > 0
                  ? e.jsxs("div", {
                      children: [
                        e.jsx("h3", {
                          className:
                            "mb-3 text-small font-bold text-foreground",
                          style: a,
                          children: "نمادهای سایت",
                        }),
                        e.jsx("div", {
                          className:
                            "flex flex-wrap items-center justify-center gap-3 sm:justify-start",
                          children: o.map((t, l) =>
                            e.jsx(
                              "span",
                              {
                                className:
                                  "inline-flex max-w-[120px] items-center justify-center",
                                dangerouslySetInnerHTML: {
                                  __html: t.html || "",
                                },
                              },
                              l,
                            ),
                          ),
                        }),
                      ],
                    })
                  : null,
              ];
  const bottomNode = [
            m.length > 0
              ? e.jsxs("div", {
                  className:
                    "flex flex-col items-center justify-center gap-3 border-t border-border p-5 sm:flex-row",
                  children: [
                    e.jsx("span", {
                      className: "text-caption font-medium text-text-secondary",
                      children: "ما را دنبال کنید:",
                    }),
                    e.jsx("div", {
                      className: "flex items-center gap-2",
                      children: m.map(([t, l]) => {
                        const n = $[t] ?? i;
                        return e.jsx(
                          "a",
                          {
                            href: siteLink(l.url),
                            target: "_blank",
                            rel: "noopener noreferrer",
                            "aria-label": H[t] ?? t,
                            className:
                              "grid size-9 place-items-center rounded-xl border border-border text-text-muted transition-colors hover:border-primary/40 hover:text-primary",
                            children: l.svg
                              ? e.jsx("span", {
                                  className: "size-4 [&>svg]:size-full",
                                  "aria-hidden": !0,
                                  dangerouslySetInnerHTML: { __html: l.svg },
                                })
                              : e.jsx(n, {
                                  className: "size-4",
                                  "aria-hidden": !0,
                                }),
                          },
                          t,
                        );
                      }),
                    }),
                  ],
                })
              : null,
            e.jsx("div", {
              className:
                "border-t border-border bg-surface/50 px-5 py-4 text-center",
              children: e.jsx("p", {
                className: "text-caption text-text-muted",
                style: a,
                children:
                  (r == null ? void 0 : r.copyright) ||
                  `© ${new Date().getFullYear()} ${g} — تمامی حقوق محفوظ است.`,
              }),
            }),
  ];
  const hoverNode = x
        ? e.jsx("style", {
            children: `[data-jluxe-footer-link]:hover{color:${x}!important}`,
          })
        : null;
  /*
   * R88 — footer.php (سمتِ سرور) پوسته و ستونِ نمادها را در جای درستش رندر
   * می‌کند؛ این آیلند فقط محتوای خودش را با portal داخلِ سه جایگاهِ مشخص
   * (data-jluxe-footer-slot) می‌گذارد. دیگر هیچ جابه‌جاییِ DOM، setInterval،
   * MutationObserver یا انتخابگرِ کلاسِ Tailwind در کار نیست.
   */
  if (slots)
    return e.jsxs(e.Fragment, {
      children: [
        ReactDOM.createPortal(featuresNode, slots.features, "features"),
        ReactDOM.createPortal(
          e.jsxs(e.Fragment, { children: columnsNode }),
          slots.columns,
          "columns",
        ),
        ReactDOM.createPortal(
          e.jsxs(e.Fragment, { children: [...bottomNode, hoverNode] }),
          slots.bottom,
          "bottom",
        ),
      ],
    });
  // سازگاری: قالبِ فرزندی که footer.php قدیمی دارد — کلِ فوتر مثلِ قبل.
  return e.jsxs("footer", {
    className: "flow-root",
    style: I(r == null ? void 0 : r.background),
    children: [
      e.jsx("div", {
        className: "mx-auto mt-4 mb-24 w-full max-w-[1296px] px-4 md:mb-6",
        children: e.jsxs("div", {
          className:
            "overflow-hidden rounded-2xl border border-border bg-muted/40",
          children: [
            featuresNode,
            e.jsxs("div", {
              className: "grid gap-8 p-5 sm:grid-cols-2 lg:grid-cols-4",
              children: columnsNode,
            }),
            ...bottomNode,
          ],
        }),
      }),
      hoverNode,
    ],
  });
}
export { re as default };
