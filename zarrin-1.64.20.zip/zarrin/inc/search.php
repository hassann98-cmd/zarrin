<?php
/**
 * جستجوی زنده‌ی سربرگ/موبایل — یک endpoint سبک AJAX که هم‌زمان محصولات،
 * دسته‌بندی‌ها و برندها رو می‌گرده. جستجوی WP_Query روی عنوان (LIKE) کاملاً
 * زبان‌کوره — فارسی/انگلیسی هر دو بدون نیاز به تنظیم اضافه کار می‌کنن.
 */

defined( 'ABSPATH' ) || exit;

/**
 * نرمال‌سازیِ عبارتِ جستجوی فارسی — ي/ی، ك/ک، ك/کِ عربی، ة/ه، حذفِ اعراب،
 * نیم‌فاصله/فاصله‌های اضافی → یک فاصله. (خروجی برای LIKE و name__like.)
 */
function jluxe_normalize_persian_query( string $term ): string {
	// R87 — «ى» (U+0649، الف مقصوره) هم؛ کیبوردهای عربی «قورى» تایپ می‌کنند و بدونِ این نگاشت نتیجه‌ای نمی‌آمد.
	$term = str_replace( array( 'ي', 'ﻱ', 'ﻲ', 'ى', 'ﻯ', 'ﻰ' ), 'ی', $term );
	$term = str_replace( array( 'ك', 'ﻙ', 'ﻚ' ), 'ک', $term );
	$term = str_replace( 'ة', 'ه', $term );
	// حذفِ اعراب/تشدید (U+064B تا U+0652 و U+0670).
	$term = preg_replace( '/[\x{064B}-\x{0652}\x{0670}]/u', '', $term );
	// نیم‌فاصله (ZWNJ/ZWJ) و هر نوع فاصلهٔ یونیکد → فاصلهٔ ساده.
	$term = preg_replace( '/[\x{200B}-\x{200F}\x{202A}-\x{202E}\x{00A0}]/u', ' ', $term );
	$term = preg_replace( '/\s+/u', ' ', $term );
	return trim( (string) $term );
}

function jluxe_ajax_search(): void {
	check_ajax_referer( 'jluxe_search', 'nonce' );

	$term = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
	$term = trim( $term );

	/* R63 (فاز ۳): نرمال‌سازیِ فارسیِ عبارتِ جستجو — کاربر ممکن است با
	«ي/ي عربی»، «ك عربی»، نیم‌فاصله یا فاصله‌های اضافی تایپ کند؛ درخواستِ
	LIKE کاملاً به شکلِ کاراکترها حساس است. یکسان‌سازیِ ی/ك/ة + تبدیلِ
	نیم‌فاصله به فاصله + فشردنِ فاصله‌ها، عبارت را با محتوای دیتابیس
	هم‌شکل می‌کند (عنوان‌ها خودشان فارسیِ استانداردند). */
	$term = jluxe_normalize_persian_query( $term );

	if ( jluxe_strlen($term) < 2 ) {
		wp_send_json_success(
			array(
				'products'   => array(),
				'categories' => array(),
				'brands'     => array(),
				'viewAllUrl' => '',
			)
		);
	}

	$products = array();
	$query    = new WP_Query(
		array(
			's'                   => $term,
			'post_type'           => 'product',
			'post_status'         => 'publish',
			'posts_per_page'      => 6,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		)
	);
	foreach ( $query->posts as $post ) {
		$product = wc_get_product( $post->ID );
		if ( ! $product ) {
			continue;
		}
		$image_id = $product->get_image_id();
		// get_price_html() خودش داخلاً wc_price() صدا می‌زنه، که فیلترِ
		// jluxe_fa_digits_wc_price (inc/woocommerce.php) دیگه توی AJAX هم
		// (نه فقط بارگذاریِ عادیِ صفحه) ارقام رو فارسی می‌کنه؛ پیچیدنِ دوباره‌ش
		// توی jluxe_fa_digits اینجا آیکونِ SVG تومان رو خراب می‌کرد.
		$products[] = array(
			'id'    => $product->get_id(),
			'name'  => $product->get_name(),
			'price' => $product->get_price_html(),
			'image' => $image_id ? wp_get_attachment_image_url( $image_id, 'thumbnail' ) : wc_placeholder_img_src( 'thumbnail' ),
			'url'   => get_permalink( $product->get_id() ),
		);
	}
	wp_reset_postdata();

	$categories = jluxe_search_taxonomy_terms( 'product_cat', $term );
	$brands     = taxonomy_exists( 'product_brand' ) ? jluxe_search_taxonomy_terms( 'product_brand', $term ) : array();

	wp_send_json_success(
		array(
			'products'   => $products,
			'categories' => $categories,
			'brands'     => $brands,
			'viewAllUrl' => add_query_arg(
				array(
					's'        => rawurlencode( $term ),
					'post_type' => 'product',
				),
				home_url( '/' )
			),
		)
	);
}
add_action( 'wp_ajax_jluxe_search', 'jluxe_ajax_search' );
add_action( 'wp_ajax_nopriv_jluxe_search', 'jluxe_ajax_search' );

/**
 * @return array<int, array{name: string, url: string, count: int}>
 */
function jluxe_search_taxonomy_terms( string $taxonomy, string $term ): array {
	$terms = get_terms(
		array(
			'taxonomy'   => $taxonomy,
			'name__like' => $term,
			'hide_empty' => true,
			'number'     => 4,
		)
	);
	if ( is_wp_error( $terms ) ) {
		return array();
	}

	$results = array();
	foreach ( $terms as $t ) {
		$link = get_term_link( $t );
		if ( is_wp_error( $link ) ) {
			continue;
		}
		$results[] = array(
			'name'  => $t->name,
			'url'   => $link,
			'count' => (int) $t->count,
		);
	}
	return $results;
}
